let vnode = null;
vnode = $C("DIV", "DIV", null);
vnode.setId("ta_1");
{
  const $parent$ = vnode;
  vnode = $C("#text", null, $parent$);
  vnode.setText("\n    a\n    ", false);
  vnode = $C("DIV", "DIV", $parent$);
  {
    const $parent$ = vnode;
    vnode = $C("#text", null, $parent$);
    vnode.setText("\n      b\n      ", false);

    [].forEach(() => {
      vnode = $C("#text", null, $parent$);
      vnode.setText("\n      ", false);
      vnode = $C("P", "P", $parent$);
      {
        const $parent$ = vnode;
        vnode = $C("#text", null, $parent$);
        vnode.setText("\n        c\n      ", false);
      }
      vnode = $C("#text", null, $parent$);
      vnode.setText("\n      ", false);

    });
    vnode = $C("#text", null, $parent$);
    vnode.setText("\n    ", false);
  }
  vnode = $C("#text", null, $parent$);
  vnode.setText("\n  ", false);
}

function _$A$(param) {  }