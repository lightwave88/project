// module 管理
const $g_module = new Map();

export default $g_module;