debugger;
// module 管理
const $g_module = new Map();

import { DomNode } from './domNode.js';
$g_module.set('DomNode', DomNode);

import { Vnode } from './vnode.js';
$g_module.set('Vnode', Vnode);

import { $c } from './c.js';
$g_module.set('$c', $c);

import Compile from './compile.js';
$g_module.set('Compile', Compile);

import api from './api.js';
$g_module.set('api', api);

export default $g_module;