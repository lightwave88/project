import $GM from './g_module.js';





// 記録是 script 標籤的 parent
// 用來辨識命令區塊
const scriptParent = [];

// 組織 render 函式用
// render 函式將 dom 轉爲 vnode
class DomNode {

  constructor(dom, parent) {
    this.dom = dom;
    this.parent = parent || null;
    this.childs = new Map();

    // 命令內容
    // 由 childs 上傳
    this.commandContent = [];

    // 在兄弟的排序是否排在最頭
    this.is_start = false;
    // 在兄弟的排序是否排在最尾
    this.is_end = false;
  }
  //-------------------------------------------
  append(child) {
    this.childs.push(child);
  }
  //-------------------------------------------
  // API
  callParent() {
    if (this.parent == null) {
      return;
    }

    let result = '';

    if (this.is_start) {
      result += `{
        let parent = vnode;\n`;
    }

    // 不同種類標籤必須實作
    result += this._getSelfCommand();

    if (this.is_end) {
      result += `}\n`;
    }

    this._clear();
  }

  //-------------------------------------------
  // API
  getResult() {
    if (this.parent != null) {
      throw new Error('not root');
    }

    let result = `
      let parent = null;
      let vnode = null\n`;

    result += this._getSelfCommand();
    return result;
  }
  //-------------------------------------------
  // 取得命令內容
  _getSelfCommand() {
    throw new Error('need override _getSelfCommand()');
  }
  //-------------------------------------------
  // 清理不要的資料
  _clear() {
    this.childs.clear();
    this.childs = null;
    this.dom = null;
    this.parent = null;
    this.commandContent.length = 0;
    this.commandContent = null;
    this.is_end = null;
    this.is_start = null;
  }

  // attr 是否有 ${}
  // attr 是否由 data 控制 
  _attrHasCompute() {

  }
  //-------------------------------------------
  // API
  static create(dom, parent) {
    let nodeName = dom.nodeName;
    // 有<>的才有
    let tagName = dom.tagName || null;

    let node;
    if (tagName != null) {
      // <>
    } else {
      // text....
      node = new TextNode(dom, parent);
    }
    return node;
  }
}
//==============================================================================
class NormalNode extends DomNode {
  constructor(dom, parent) {
    super(dom, parent);

    // 在命令區塊中嗎
    // 在命令區塊中的 domTree 是由 data 所控制
    // 任何改變過的 attr 在 data 變化後會 reset
    this.inCommandArea = false;
  }
  //-------------------------------------------
  // 取得命令內容
  _getSelfCommand() {
    let result = '';

    let tagName;
    result += `vnode = C(${tagName});`

    // id

    // class

    // attr



    result += `vnode.appendTo(parent);`

    return result;
  }
}
//==============================================================================
class TextNode extends DomNode {

}

//==============================================================================
class ScriptNode extends DomNode {
  constructor() {

  }
  //-------------------------------------------
  // 取得命令內容
  _getSelfCommand() {
    let result = '';

    let tagName;
    result += `vnode = C(${tagName});`

    // id

    // class

    // attr



    result += `vnode.appendTo(parent);`

    return result;
  }
}



export { DomNode as HNode };
