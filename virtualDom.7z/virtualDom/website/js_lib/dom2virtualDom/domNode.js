import $GM from './g_module.js';

const reg_1 = /^@/;

// 組織 render 函式用
// render 函式將 dom 轉爲 vnode
class DomNode {

  constructor(dom, parent) {
    this.dom = dom;
    this.parent = parent || null;
    this.childs = new Map();

    // 命令內容
    // 由 childs 上傳
    this.commandContent = [];

    this.isStatic;

    // 在兄弟的排序是否排在最頭
    this.is_start = false;
    // 在兄弟的排序是否排在最尾
    this.is_end = false;
  }
  //-------------------------------------------
  append(child) {
    this.childs.push(child);
  }
  //-------------------------------------------
  // API
  callParent() {
    if (this.parent == null) {
      return;
    }
    // 檢查 no static 的區塊
    this.parent.checkCommandArea();
    //------------------
    let result = '';

    if (this.is_start) {
      result += `{
        let parent = vnode;\n`;
    }

    // 不同種類標籤必須實作
    result += this._getSelfCommand();

    if (this.is_end) {
      result += `}\n`;
    }

    this._clear();
  }
  //-------------------------------------------
  // dom 是否是 static 節點
  setStatic(value) {
    if (this.isStatic != null) {
      return;
    }
    if (typeof value != 'boolean') {
      return;
    }
    this.isStatic = value;
  }
  //-------------------------------------------
  // API
  // 只有 root 有用
  getResult() {
    if (this.parent != null) {
      throw new Error('not root');
    }

    let result = `
      let parent = null;
      let vnode = null\n`;

    result += this._getSelfCommand();
    return result;
  }
  //-------------------------------------------
  // 取得命令內容
  _getSelfCommand() {
    throw new Error('need override _getSelfCommand()');
  }
  //-------------------------------------------
  // 清理不要的資料
  _clear() {
    this.childs.clear();
    this.childs = null;
    this.dom = null;
    this.parent = null;
    this.commandContent.length = 0;
    this.commandContent = null;
    this.is_end = null;
    this.is_start = null;
  }

  // attr 是否有 ${}
  // attr 是否由 data 控制 
  _hasCompute(content) {

  }
  //-------------------------------------------
  // API
  static create(dom, parent) {
    let nodeName = dom.nodeName;
    // 有<>的才有
    let tagName = dom.tagName || null;

    let node;
    if (tagName != null) {
      // <>

      switch (tagName) {
        case 'script':
          node = new ScriptNode(dom, parent)
          break;
        default:
          node = new NormalNode(dom, parent);
          break;
      }
    } else {
      // text....
      node = new TextNode(dom, parent);
    }
    return node;
  }
}
//==============================================================================
class NormalNode extends DomNode {
  constructor(dom, parent) {
    super(dom, parent);

    // 在命令區塊中嗎
    // 在命令區塊中的 domTree 是由 data 所控制
    // 任何改變過的 attr 在 data 變化後會 reset
    this.inCommandArea = false;

    // 是否檢查過 childs 的 commandArea
    this.has_checkCommandArea = false;
  }
  //-------------------------------------------
  // 在命令區塊中的 dom，受制於 data
  // not static
  checkCommandArea() {
    if (this.has_checkCommandArea) {
      return;
    }
    this.has_checkCommandArea = true;
    //------------------
    let start, end;

    this.childs.forEach((el, i) => {
      if (el instanceof ScriptNode) {
        if (start == null) {
          start = i;
        }
        end = i;
      }
    });

    if (start == null) {
      return;
    }
    //------------------
    if (start == end) {
      end = this.childs.length;
    }

    for (let i = (start + 1); i < end; i++) {
      let el = this.childs[i];
      if (el instanceof ScriptNode) {
        continue;
      }
      el.setStatic(false);
    }
  }
  //-------------------------------------------
  // 取得命令內容
  _getSelfCommand() {
    const dom = this.dom;

    let result = `vnode = C(${dom.nodeName}, ${dom.tagName});\n`;

    // id
    if (dom.hasAttribute('id')) {
      result += `vnode.setId("${dom.getAttribute('id')}")`;
      dom.removeAttribute('id');
    }
    //-----------------------
    // class
    if (dom.hasAttribute('class')) {
      let classList = Array.from(dom.classList);
      result += `vnode.setClass(${classList});\n`;

      dom.removeAttribute('class');
    }

    if (dom.hasAttribute('@class')) {
      // calss 有計算屬性
      let classData = dom.getAttribute('@class');
      result += "vnode.setClass(`${toClass(";
      result += classData + ")}, true);\n";

      dom.removeAttribute('@class');
    }
    //-----------------------
    // style

    if (dom.hasAttribute('style')) {
      let style = dom.getAttribute('style');
      style = JSON.stringify(style);

      result += `vnode.setStyle(${style});\n`;

      dom.removeAttribute('style');
    }

    if (dom.hasAttribute('@style')) {
      let style = dom.getAttribute('@style');

      result += "vnode.setStyle(`" + style + "`);\n";

      dom.removeAttribute('@style');
    }
    //-----------------------
    // attr
    let attrMap = Array.from(dom.attributes);

    attrMap.forEach((attr) => {
      let key = attr.nodeName;
      let value = attr.nodeValue;

      if (reg_1.test(key)) {
        // 計算屬性
      } else {

      }

    });


    result += `vnode.appendTo(parent);`

    return result;
  }
  //-------------------------------------------
}
//==============================================================================
class TextNode extends DomNode {
  constructor(dom, parent) {
    super(dom, parent);
  }

  _getSelfCommand() {
    const dom = this.dom;

    let tagName = dom.tagName || null;
    let text = dom.nodeValue;

    // 文字內容是否有計算
    let has_compute = this._hasCompute(text);

    if (has_compute) {
      text = "`" + text + "`";
    } else {
      text = JSON.stringify(text);
    }

    let result = `
      vnode = C(${dom.nodeName}, ${tagName});
      vnode.setText(${text}, ${has_compute});
    `;

    return result;
  }
}

//==============================================================================
class ScriptNode extends DomNode {
  constructor() {

  }
  //-------------------------------------------
  // 取得命令內容
  _getSelfCommand() {
    let result = '';

    let tagName;
    result += `vnode = C(${tagName});`

    // id

    // class

    // attr



    result += `vnode.appendTo(parent);`

    return result;
  }
}



export { DomNode };
