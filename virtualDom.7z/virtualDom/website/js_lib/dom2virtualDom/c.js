import $GM from './g_module.js';

function $c(nodeName, tagName, parent) {
  const Vnode = $GM.get('Vnode');
  let vnode;

  return vnode;
}

export { $c };