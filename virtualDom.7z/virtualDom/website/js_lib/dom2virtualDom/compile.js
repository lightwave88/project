debugger;
import $GM from './g_module.js';

// 編譯爲 renderFun
class Compile {
  constructor() {
    this.$tempList = [];

    // 記錄父子關係
    this.$parentMap = {};
  }
  //-------------------------------------------
  byDom(dom) {
    debugger;
    let $tempList = this.$tempList;
    let $parentMap = this.$parentMap;

    $tempList.push(dom);
    //------------------
    // domNode link
    const DomNode = $GM.get('DomNode');


    for (let i = 0; i < $tempList.length; i++) {
      debugger;

      // 拜訪所有 dom
      let dom = $tempList[i];
      let tagName = dom.tagName;

      let parent = null;
      if (i in $parentMap) {
        // 檢查父子關係，是否由所屬的 parent
        parent = $parentMap[i];
        delete $parentMap[i];
      }
      let domNode = DomNode.getInstance(dom, parent);

      if (parent != null) {
        // 父子關係
        parent.append(domNode);
      }

      // 替換
      $tempList[i] = domNode;
      //-----------------------
      if (!this._needCheckChild(tagName)) {
        // 不需處理子節點的 dom
        continue;
      }

      // 處理子節點
      let childs = Array.from(dom.childNodes);

      childs.forEach(el => {
        let index = $tempList.length;
        // 記錄 link
        $parentMap[index] = domNode;
        $tempList.push(el);
      });
    }
    //------------------
    let keyList = Object.keys($parentMap);
    if (keyList.length) {
      throw new Error('no clear');
    }
    debugger;
    //------------------
    // 打造 renderFun

    this._buildRenderFun();
    //------------------

  }
  //-------------------------------------------
  _buildRenderFun() {
    debugger;

    let domNode;
    for (let i = this.$tempList.length; i > 0; i--) {
      debugger;
      let j = i - 1;
      domNode = this.$tempList[j];
      domNode.callParent();
    }
    debugger;
    let fun_context = domNode.getResult();

    console.log(fun_context);

    let renderFun = new Function(fun_context);

    console.dir(renderFun);
  }
  //-------------------------------------------
  _needCheckChild(tagName) {
    if (tagName == null) {
      return false;
    }

    tagName = tagName.toLowerCase();

    let res = true;
    switch (tagName) {
      case 'script':
        res = false;
        break;
    }

    return res;
  }
}

export default Compile;
