import $GM from './g_module.js';

const $api = {};
export default $api;

$api.compileFromDom = function (dom) {
  debugger;
  const $Compile = $GM.get('Compile');
  let compile = new $Compile(); 
  compile.byDom(dom);
}

