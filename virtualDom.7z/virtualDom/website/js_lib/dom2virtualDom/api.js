import $GM from './g_module.js';

const $api = {};
export default $api;

{
    const tempList = [];

    // 記錄父子關係
    const $parentMap = {};
    // 轉換 domTress 爲 domNode
    // 方便未來轉成 vnode
    // 回傳 domNode
    $api.domTransform = function (dom) {
        let domNode;

        tempList.push(dom);
        //------------------
        // domNode link
        let i = 0;
        while (i < tempList.length) {
            // 拜訪所有 dom
            let dom = tempList[i];

            let parent = null;
            if (i in $parentMap) {
                // 檢查父子關係，是否由所屬的 parent
                parent = $parentMap[i];
                delete $parentMap[i];
            }
            let domNode = DomNode.create(dom, parent);

            // 父子關係
            parent.append(domNode);

            // 替換
            tempList[i] = domNode;
            //-----------------------
            // 處理子節點
            let childs = dom.childNodes;

            childs.forEach(el => {
                let index = tempList.length;
                // 記錄 link
                $parentMap[index] = domNode;
                tempList.push(el);
            });

            i++;
        }
        //------------------
        tempList.length = 0;

        let keyList = Object.keys($parentMap);
        if (keyList.length) {
            throw new Error('no clear');
        }

        return domNode;
    }
}