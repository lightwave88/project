const $api = {};
{
    const tempList = [];
    const tempMap = {};
    // domNode link
    // 回傳 domNode
    $api.link = function (dom) {
        let domNode;

        tempList.push(dom);
        //------------------
        // domNode link
        let i = 0;
        while (i < tempList.length) {
            // 拜訪所有 dom
            let dom = tempList[i];

            let parent = null;
            if (i in tempMap) {
                // 檢查父子關係
                parent = tempMap[i];
                delete tempMap[i];
            }
            let domNode = DomNode.create(dom, parent);

            // 父子關係
            parent.append(domNode);

            // 替換
            tempList[i] = domNode;
            //-----------------------
            // 處理子節點
            let childs = dom.childNodes;

            childs.forEach(el => {
                let index = tempList.length;
                // 記錄 link
                tempMap[index] = domNode;
                tempList.push(el);
            });

            i++;
        }
        //------------------
        tempList.length = 0;

        let keyList = Object.keys(tempMap);
        if (keyList.length) {
            throw new Error('no clear');
        }

        return domNode;
    }
}