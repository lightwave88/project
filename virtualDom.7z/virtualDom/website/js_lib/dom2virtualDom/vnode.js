import $GM from './g_module.js';

class Vnode {
  constructor(arg) {
    this.dom;
    this.children = [];
    this.id;
    this.className = [];

    // 靜態 dom 不由 data 所控制
    this.is_static = true;
  }

  appendTo(parent) {

  }

  setId(id) {

  }
  // computer:class 是否由 data 所控制
  setClass(data, computer = false) {

  }

  // computer:style 是否由 data 所控制
  setStyle(data, computer = false) {
    
  }

  // computer:attr 是否由 data 所控制
  setAttr(key, value, computer = false) {
    
  }

  // computer:文字內容 是否由 data 所控制
  setText(value, computer = false) {
    this.is_static = !computer;
  }
}

export {Vnode};