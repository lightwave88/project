class VNode {
  constructor(arg) {
    this.dom;
    this.children = [];

    // 靜態 dom 不由 data 所控制
    this.static = true;
  }

  appendTo(parent) {

  }

  setId(){

  }
  // computer:class 是否由 data 所控制
  setClass(data, computer = false){

  }

  // computer:style 是否由 data 所控制
  setStyle(data, computer = false){

  }

  // computer:attr 是否由 data 所控制
  setAttr(key, value, computer = false) {

  }

  // computer:文字內容 是否由 data 所控制
  setTextContent(value, computer = false){

  }
}
