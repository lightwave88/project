import $GM from './g_module.js';

class Vnode {
  constructor(arg) {
    // 代表的 dom
    this.dom;

    // 子節點(vnode)
    this.childs = [];

    // dom.id
    this.id;

    // dom.className
    this.classList = [];

    // dom.style
    this.style = new Map();

    // dom.attrs
    this.attrs = new Map();

    // 非標準標籤節點
    this.text;

    // 有含計算的 attr
    this.com_attrs = new Set();

    // 靜態 dom 不由 data 所控制
    // 若在 command 之間就不是
    // 表示使用者將用 command 控制
    this.is_static = true;
  }
  //-------------------------------------------
  appendTo(parent) {
    parent.childs.push(this);
  }
  //-------------------------------------------
  append(child) {
    this.childs.push(child);
  }
  //-------------------------------------------
  setId(id) {
    this.id = id;
  }
  //-------------------------------------------
  // computer:class 是否由 data 所控制
  setClass(data, computer = false) {
    if (computer == true) {
      this.com_attrs.add('class');
    }
    let className = []

    if (!Array.isArray(className)) {
      className.push(data);
    } else {
      className = data;
    }

    className.forEach(c => {
      if (this.classList.includes(c)) {
        return;
      }
      this.classList.push(c);
    });

    this.classList.sort();
  }
  //-------------------------------------------
  // computer:style 是否由 data 所控制
  setStyle(data, computer = false) {
    if (computer == true) {
      this.com_attrs.add('style');
    }
  }
  //-------------------------------------------
  // computer:attr 是否由 data 所控制
  setAttr(key, value, computer = false) {
    if (computer == true) {
      this.com_attrs.add('key');
    }
  }
  //-------------------------------------------
  // computer:文字內容 是否由 data 所控制
  setText(value, computer = false) {
    this.is_static = !computer;
    this.text = value;
  }
}

export { Vnode };