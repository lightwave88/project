// debugger;
import $GM from './g_module.js';

let api = $GM.get('api');
export default api;