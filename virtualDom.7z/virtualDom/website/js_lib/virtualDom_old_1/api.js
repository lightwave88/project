import $GM from './g_module.js';

const $api = {
  templateList: new Map(),
};
export default $api;

const $reg_1 = /^TEMPLATE$/i;
//------------------------------------------------------------------------------
// 取得 template
$api.getTemplate = function (key) {
  if (!this.templateList.has(key)) {
    return null;
  }
  return this.templateList.get(key);
};
//------------------------------------------------------------------------------
// 從 dom 取得渲染函式
$api.templateByDom = function (name, dom) {

  if (dom == null) {
    dom = name;
    name = null;
  }

  if (dom == null) {
    throw new Error('no dom');
  }

  let parentDom = dom;

  dom = mergeTemplate(parentDom);

  // 先把模板移除，未來才能渲染新的內容
  // dom = dom.cloneNode(true);
  //------------------
  const $Compile = $GM.get('Compile');
  let compile = new $Compile();

  // 建造產生 vnode 的工廠函式
  let render = compile.byDom(dom);

  if (render == null) {
    // 建立 render_fun 失敗
    return null;
  }

  // fix here

  // 返回與 dom 綁定的 render_fun
  render.bind = function (dom) {
    return bindTemplate(render, dom);
  };

  if (name) {
    templateList.set(name, render);
  }
  return render;
};
//------------------------------------------------------------------------------
// 把 render 與 dom 綁定，以後只需要更新 data 即可
function bindTemplate(render, dom, optios = {}) {

  // 管理者
  const $manager = getManager();

  const $container = dom;
  let prev_vnode = null;
  let prev_rootDom = null;
  //------------------
  return function _render(data = {}) {
    debugger;

    // 渲染模板得到 dom 藍圖
    let node = render(data) || null;

    console.log('create vnode');
    console.dir(node);
    console.log('----------');

    debugger
    if (prev_vnode == null) {
      // 試圖取得舊的 vnode
      let child = getFirstChild_tag(dom);
      prev_vnode = (child == null ? null : $api.getVnode(child));
    }

    if (prev_vnode == null) {
      // 沒有 vnode 表示沒有 html 內容
      let dom_childs = Array.from($container.childNodes);
      if (dom_childs.length > 0) {
        $container.innerHTML = '';
      }
    }

    // 建構 dom
    $patch(prev_vnode, node, $container);

    //------------------
    // manager 檢查

    // 

    //------------------
    // 更新記錄
    prev_vnode = node;

    if (node == null) {
      prev_rootDom = null;
    } else {
      prev_rootDom = node.dom;
    }
  }

}
//------------------------------------------------------------------------------

$api.getVnode = function (dom) {
  const Vnode = $GM.get('Vnode');
  return Vnode.getVnodeByDom(dom);
}
//------------------------------------------------------------------------------

function $patch(oldNode, node, parentDom) {
  const ModifyDom = $GM.get('ModifyDom');
  const $modifyDom = new ModifyDom();

  let dom = $modifyDom.patch(oldNode, node, parentDom);
  debugger;
  return dom;
};
//------------------------------------------------------------------------------
// 取得 dom 的第一個孩子（不包含 text）
function getFirstChild_tag(dom) {
  let childs = Array.from(dom.children);
  if (!childs.length) {
    return null;
  }
  return childs.shift();
}
//------------------------------------------------------------------------------
// 模板背後的管理者
function getManager() {
  return {};
}
//------------------------------------------------------------------------------
// 去除 <template>
function mergeTemplate(rootDom) {
  debugger;

  // container 不能是 <template>
  if (rootDom == null || $reg_1.test(rootDom.tagName)) {
    throw new Error('...');
  }

  let root = rootDom;

  // 找尋 container 的第一個子 dom
  // 必須不是 <template>
  // 第一個子 dom 必須與 container 脫離
  // 避免 container 內的 <script> 發生作用
  do {
    let childs;

    if ($reg_1.test(root.tagName)) {
      // 第一個子標籤是 <template>
      let p = root.parentNode;

      if(p != null){
        p.removeChild(root);
      }

      childs = Array.from(root.content.children);

    } else {
      // 此區塊只會經過一次
      childs = Array.from(root.childNodes);

      childs = childs.filter((c) => {
        root.removeChild(c);
        if (c.tagName != null) {
          return true;
        }
        return false;
      });
    }

    if (childs.length !== 1) {
      throw new Error('only one child');
    }

    root = childs[0] || null;

  } while (root != null && $reg_1.test(root.tagName));

  // 確保 root 不是 <template>
  if (root == null) {
    return root;
  }
  //------------------
  while (true) {
    let temp = root.querySelector('template');
    if (temp == null) {
      break;
    }

    let parent = temp.parentNode || null;
    let next = temp.nextSibling || null;
    let frag = temp.content;

    if (parent != null) {
      parent.removeChild(_temp);
      parent.insertBefore(frag, next);
    }
  }

  return root;
}



