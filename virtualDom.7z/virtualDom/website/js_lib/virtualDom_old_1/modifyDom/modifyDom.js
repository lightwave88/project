// 根據 vnode 建構 old_dom
import $GM from '../g_module.js';

let $domApi;
let $util;
let $Vnode;

(async () => {
  // 延時注入模組

  await Promise.resolve();
  // debugger;

  try {
    $domApi = $GM.get('domApi');
    $util = $GM.get('util');
    $Vnode = $GM.get('Vnode');
  } catch (er) {
    console.log(er);
  }
})();
//------------------------------------------------------------------------------


class ModifyDom {
  constructor(options = {}) {
    this.keepAliveMap = {};
    this.destroyVnodeList = [];
  }
  //-----------------------------------------------------
  // start here
  patch(oldVnode, vnode, parentDom) {

    this._travelAllVnode(oldVnode, vnode, parentDom);

    let root_dom = (vnode == null ? null : vnode.dom);

    // 要返回 rootDom, keepAliveMap

    return root_dom;
  }
  //-----------------------------------------------------
  // 片歷所有樹節點
  _travelAllVnode(oldVnode, vnode, parentDom) {
    let rootVnode = vnode;

    let travelList = [];

    // 片歷的起頭
    travelList.push({
      o: oldVnode,
      n: vnode,
      p: parentDom,
      sameType: null,
    });
    //-----------------------
    // dom 不用任何改變
    const domNoChangeList = [];

    // dom 需進行 attr 變化
    const sameTypeNodeList = [];

    // dom 需要重建
    const diffNodeList = [];

    // 有被保留的 dom
    const keepAliveList = [];
    //-----------------------
    let index = 0;

    while (true) {
      debugger;

      let i = index++;
      let data = travelList[i];
      if (data == null) {
        break;
      }
      //------------------
      let { o, n, p, sameType = null } = data;

      if (sameType == null) {
        sameType = this._is_sameTypeVnode(o, n);
      }

      debugger;
      if (sameType) {
        console.log('sameTypeNode');

        if (n.is_static) {

          let judge_1 = (n.compute_attrs.size == 0 && o.compute_attrs.size == 0);

          if (judge_1) {
            console.log('static');
            // 完全靜態 node
            // 沒事作
            domNoChangeList.push({ o, n, p });

          } else {

            console.log('static, but attr not static');
            // 靜態 node，但有部分動態 attr
            sameTypeNodeList.push({ o, n, p });
          }
        } else {
          console.log('not static');
          sameTypeNodeList.push({ o, n, p });
        }

      } else {
        console.log('diff node');

        if (o != null) {
          dom = o.dom;
          $domApi.detach(dom);
        }

        diffNodeList.push({ o, n, p });
        continue;
      }
      //------------------
      // 繼續往下拜訪
      // 並試圖匹配相同的 child
      let list = this.matchChilds(o, n);

      debugger;
      if (list.length) {
        travelList = travelList.concat(list);
      }

    } // endWhile

    //-----------------------
    debugger;
    this.aboutDiffNodes(diffNodeList);

    this.aboutSameTypeNodes(sameTypeNodeList);

    this.aboutDomNochange(domNoChangeList);

    this.aboutKeepAlive(keepAliveList);

    debugger;
    console.dir(this.destroyVnodeList);

    this.removeChildVnodes();
  }
  //-----------------------------------------------------
  // 比較兩個 vnode 性質是否相同
  _is_sameTypeVnode(a, b) {
    // debugger;

    if (a == null || b == null) {
      return false;
    }

    // 比較 nodeName
    if (a.nodeName !== b.nodeName) {
      return false;
    }

    if (a.is_static != b.is_static) {
      return false;
    }

    const a_attrs = a.attrs;
    const b_attrs = b.attrs;

    // old_dom.type 不同就視爲不同
    // old_dom 必須重建 不然可能有問題
    // <input> 尤其嚴重
    let a_type = (a_attrs.has('type') ? a_attrs.get('type') : null);
    let b_type = (b_attrs.has('type') ? b_attrs.get('type') : null);



    if (a_type !== b_type) {
      return false;
    }

    // 比較 old_dom.id
    if ((a.id != null || b.id != null) && a.id !== b.id) {
      return false;
    }

    // 比較 old_dom.class
    // if (a.classList.length != b.classList.length) {
    //   return false;
    // }

    // if (a.classString != b.classString) {
    //   return false;
    // }

    return true;
  }
  //-----------------------------------------------------
  aboutDomNochange(list = []) {
    debugger;

    while (list.length) {
      let { o, n } = list.pop();

      let dom = o.dom;
      let index = n.index;

      // 與 vnode 對應的 dom 的位置可能不對      
      // 處理 dom 的位置
      this._fixDomPosition(dom, index);
      let old = n.setDom(dom);

      if (old) {
        this.destroyVnodeList.push(old);
      }
    }
  }
  //-----------------------------------------------------
  aboutSameTypeNodes(list) {
    debugger;

    const $attrsUpdate = $GM.get('attrsUpdate');

    while (list.length) {
      let { o, n } = list.pop();


      let dom = o.dom;
      let index = n.index;

      console.log('-----------\n');
      console.log('update old_dom(%s)', o.nodeName);
      console.dir(o.dom);
      console.log('-----------\n');

      // 與 vnode 對應的 dom 的位置可能不對      
      // 處理 dom 的位置
      this._fixDomPosition(dom, index);

      if (dom.tagName != null) {
        // 標籤 old_dom
        $attrsUpdate.update(o, n);
      } else {
        // 非標籤 old_dom
        $domApi.setTextContent(dom, n.text);
      }
      let old = n.setDom(dom);

      if (old) {
        this.destroyVnodeList.push(old);
      }
    }
  }
  //-----------------------------------------------------
  aboutKeepAlive(list = []) {
    // 更新 this.keepAliveMap


  }
  //-----------------------------------------------------
  aboutDiffNodes(list = []) {
    debugger;

    while (list.length) {

      let { o, n = null, p = null } = list.shift();

      if (o != null) {
        this.destroyVnodeList.push(o);
      }

      if (n != null) {
        debugger;
        // 建立一棵新的 domThree
        let dom_new = this._createElm(n);

        if (dom_new != null) {
          let index = n.index;
          let dom_next = this._getDomChildByIndex(p, index);
          $domApi.insertBefore(p, dom_new, dom_next);
        }
      }
    } // endWhile
  }
  //-----------------------------------------------------
  _getDomChildByIndex(p_dom, index) {
    let list = Array.from(p_dom.childNodes);

    if (index >= list.length) {
      return null;
    }

    return list[index];
  }
  //-----------------------------------------------------
  removeChildVnodes() {
    debugger;

    const destroyVnodeList = this.destroyVnodeList;

    function job() {

      destroyVnodeList.forEach((node) => {

        const vnodeList = [node];

        let index = 0;

        while (true) {
          // debugger;
          let i = index++;

          let vnode = vnodeList[i];
          if (vnode == null) {
            break;
          }
          let childs = vnode.childs.slice();

          // destroy vnode 
          vnode.destroy();

          while (childs.length) {
            let c = childs.shift();
            vnodeList.push(c);
          }
        }
      });

      destroyVnodeList.length = 0;

    } // endJob


    $util.nextStep(job);
  }
  //-----------------------------------------------------
  _createElm(rootVnode) {
    // debugger;

    if (rootVnode == null) {
      return null;
    }

    const $attrsUpdate = $GM.get('attrsUpdate');

    // 要處理的列表
    let tempList = [rootVnode];
    let parentMap = {};

    let new_dom;

    let i = 0;
    //-----------------------
    while (true) {
      // debugger;

      let vnode = tempList[i];
      if (vnode == null) {
        break;
      }
      let nodeName = vnode.nodeName;
      let oldVnode;

      if (vnode.tagName == null) {
        // 不是 tag  

        new_dom = this._createDom(null, nodeName, vnode.text);
        oldVnode = vnode.setDom(new_dom);

        console.log('create new_dom(%s)', new_dom.nodeName);

        if (i in parentMap) {
          let parent_dom = parentMap[i];
          delete parentMap[i];
          $domApi.appendChild(parent_dom, new_dom);
        }

      } else {
        // tag
        new_dom = this._createDom(vnode.tagName);
        oldVnode = vnode.setDom(new_dom);

        console.log('create new_dom(%s)', new_dom.nodeName);

        // 處理 attrs
        $attrsUpdate.create(vnode);

        if (i in parentMap) {
          let parent_dom = parentMap[i];
          delete parentMap[i];
          $domApi.appendChild(parent_dom, new_dom);
        }

        let childList = vnode.childs;
        if (!Array.isArray(childList)) {
          return;
        }

        childList.forEach((vnode) => {
          let j = tempList.length;
          tempList.push(vnode);
          parentMap[j] = new_dom;
        });

      } // endif

      if (oldVnode) {
        this.destroyVnodeList.push(oldVnode);
      }

      i++;
    } // end while

    return rootVnode.dom;
  }
  //-----------------------------------------------------
  _createDom(tagName, nodeName, text) {
    let dom;

    if (tagName == null) {
      switch (nodeName) {
        case '#comment':
          dom = $domApi.createComment(text);
          break;
        case '#text':
          dom = $domApi.createTextNode(text);
          break;
        default:
          console.dir(vnode);
          throw new Error(`no deal with this domType(${nodeName})`);
          break;
      }
    } else {
      dom = $domApi.createElement(tagName);
    }
    return dom;
  }
  //-----------------------------------------------------
  // 試圖匹配相同的 child
  // 只移動 oldVnode.childs
  matchChilds(oldvnode, vnode) {
    // debugger;

    const parentDom = oldvnode.dom;

    let o_list = oldvnode.childs;
    let n_list = vnode.childs;
    let n_length = n_list.length;

    //-----------------------
    // 先過濾出 vnode.static, vnode.no_static

    const no_staticList = [];
    const staticList = [];

    o_list.forEach((n) => {
      if (n.is_static) {
        staticList.push({ node: n });
      } else {
        no_staticList.push({ node: n });
      }
    });

    oldvnode.clearChilds();

    let matchList = Array(n_length).fill(null);
    //-----------------------
    let i = 0;
    let static_count = 0;
    while (i < n_length) {
      // debugger;

      let j = i++;
      let n = n_list[j];
      //-----------------------
      // needFindMatch
      let searchList;

      if (n.is_static) {
        searchList = staticList;
      } else {
        searchList = no_staticList;
      }

      let findNode = this._findTarget(n, searchList, static_count);

      if (n.is_static) {
        ++static_count;
      }

      if (findNode != null) {
        matchList[j] = findNode;
      }

    } // endWhile
    //------------------
    // 處理剩下沒匹配的
    let no_matchList = staticList.concat(no_staticList);

    no_matchList.forEach(d => {
      let { node } = d;

      if (node == null) {
        // 已經被匹配走了
        return;
      }
      let dom = node.dom;
      $domApi.detach(dom);

      this.destroyVnodeList.push(node);
    });
    //------------------
    // 需要往下探索
    let childList = matchList.map((match, i) => {
      let sameType = (match == null ? false : true);
      let node = n_list[i];

      return {
        o: match,
        n: node,
        p: parentDom,
        sameType,
      };
    });

    return childList;
  }
  //-----------------------------------------------------
  // 在 list 中找尋
  // 搜尋策略
  _findTarget(vnode, searchList, static_count) {
    // debugger;

    const is_static = vnode.is_static;

    let find = null;

    if (is_static) {
      // 靜態節點的配對方式
      let res = searchList[static_count];

      if (res == null) {
        // 規則可改
        throw new Error('should not be happen');
      }

      let { node } = res;

      if (node == null) {
        // 標記已被指定
        // 規則可改
        throw new Error('should not be happen');
      }
      find = node;

      // 標記已被指定
      (searchList[static_count]).node = null;

    } else {

      let findIndex = null;

      searchList.some((d, i) => {
        // debugger;

        let { node: oldVnode } = d;

        if (oldVnode == null) {
          // 已經被人取走
          return;
        }
        //------------------
        let sameType = this._is_sameTypeVnode(vnode, oldVnode);
        if (sameType) {
          findIndex = (findIndex != null ? findIndex : i);
        } else {
          return;
        }
        //------------------
        if (vnode.childs.length == oldVnode.childs.length) {
          // 兩個子結構數量相同
          // 猜測有很大可能有相同的結構
          // 再細談索下去會耗費時間
          findIndex = i;
          return true;
        }
      }); // endSome

      if (findIndex != null) {
        find = (searchList[findIndex]).node;
        // 標記已被指定
        (searchList[findIndex]).node = null;
      }

    } // endif

    return find;
  }
  //-----------------------------------------------------
  // index: dom 正確的位置
  _fixDomPosition(dom, index) {

    if (dom.parentNode == null) {
      // dom 被手動移除
      console.dir(dom);
      throw new Error('dom no parent');
    }

    let parent = dom.parentNode;
    let list = Array.from(parent.childNodes);

    let findIndex = list.findIndex(el => {
      return (el === dom);
    });

    if (findIndex < 0) {
      throw new Error('dom no find position');
    }

    if (index == findIndex) {
      // 位置沒變動
      return;
    }

    let dom_next = list[index];
    $domApi.insertBefore(parent, dom, dom_next);
  }
}

export default ModifyDom;

