// 根據 vnode 建構 old_dom
import $GM from '../g_module.js';

let $domApi;
let $util;
let $Vnode;

(async () => {
  // 延時注入模組

  await Promise.resolve();
  // debugger;

  try {
    $domApi = $GM.get('domApi');
    $util = $GM.get('util');
    $Vnode = $GM.get('Vnode');
  } catch (er) {
    console.log(er);
  }
})();
//------------------------------------------------------------------------------


class ModifyDom {
  constructor(options = {}) {
    this.keepAliveMap = {};
  }
  //-----------------------------------------------------
  // start here
  patch(oldVnode, vnode, parentDom) {

    this._travelAllVnode(oldVnode, vnode, parentDom);

    let root_dom = (vnode == null ? null : vnode.dom);

    // 要返回 rootDom, keepAliveMap

    return root_dom;
  }
  //-----------------------------------------------------
  _travelAllVnode(oldVnode, vnode, _parentDom) {
    let rootVnode = vnode;

    let travelList = [];

    travelList.push([oldVnode, vnode, _parentDom]);
    //-----------------------
    // dom 不用任何改變
    let domNoChangeList = [];

    // dom 需進行 attr 變化
    let sameTypeNodeList = [];

    // dom 需要重建
    let diffNodeList = [];

    // 有被保留的 dom
    let keepAliveList = [];
    //-----------------------
    let index = 0;
    while (true) {
      debugger;

      let i = index++;
      let data = travelList[i];

      console.dir(data);

      if (data == null) {
        break;
      }
      let [_oldVnode, _vnode, parentDom] = data;
      let old_dom = (_oldVnode == null ? null : (_oldVnode.dom || null));
      //------------------

      if (this._is_sameVnode(_oldVnode, _vnode)) {
        debugger;

        console.log('sameNode');

        // keepAlive 暫無
        function keepAlive_1() {
          // 進入 keepAlive 的分支
          // 確保以下的 dom 順序都不變
          keepAliveList.push([_oldVnode, _vnode, parentDom]);
        }

        if (_vnode.is_static != _oldVnode.is_static) {
          console.log('problem');
        }

        if (_vnode.is_static && _oldVnode.is_static) {
          if (_vnode.compute_attrs.size == 0 && _oldVnode.compute_attrs.size == 0) {
            console.log('static');
            // 完全靜態 node
            // 沒事作
            domNoChangeList.push([_vnode, old_dom]);

          } else {

            console.log('static, attr not static');
            // 靜態 node，但有部分動態 attr
            sameTypeNodeList.push([_oldVnode, _vnode, parentDom]);
          }
        } else {
          console.log('not static');
          sameTypeNodeList.push([_oldVnode, _vnode, parentDom]);
        }
      } else {
        debugger;

        // keepAlive 暫無
        function keepAlive_2() {
          let oldNode;

          // 在 this.keepAliveMap 找 oldNode
          if (oldNode != null) {
            // 在 this.keepAliveMap 中找到 oldNode
            data[0] = oldNode;
            index = i;
          } else {
            // 假如 this.keepAliveMap 裏面沒 oldNode
            // 就要進入新建的程序
            diffNodeList.push([null, _vnode, parentDom]);
          }
        }

        if (_oldVnode != null || _vnode != null) {
          console.log('diff node');
          diffNodeList.push([_oldVnode, _vnode, parentDom]);
        }
        travelList.splice(i, 1);
        index = i;
        continue;
      }
      //------------------
      debugger;
      // 繼續往下拜訪
      // 這邊可進化
      let oldCh_length = _oldVnode.childs.length;
      let ch_length = _vnode.childs.length;
      let length = (oldCh_length > ch_length ? oldCh_length : ch_length);

      for (let k = 0; k < length; k++) {
        let a = _oldVnode.childs[k] || null;
        let b = _vnode.childs[k] || null;

        if (old_dom == null) {
          console.dir(_oldVnode);
          throw new Error('...');
        }

        travelList.push([a, b, old_dom]);
      }

    } // endWhile
    //-----------------------
    debugger;
    this.aboutDomNochange(domNoChangeList);

    this.aboutDiffNodes(diffNodeList);

    this.aboutSameTypeNodes(sameTypeNodeList);

    this.aboutKeepAlive(keepAliveList);
  }
  //-----------------------------------------------------
  // 比較兩個 vnode 性質是否相同
  _is_sameVnode(a, b) {
    // debugger;

    if (a == null || b == null) {
      return false;
    }

    // 比較 nodeName
    if (a.nodeName !== b.nodeName) {
      return false;
    }

    const a_attrs = a.attrs;
    const b_attrs = b.attrs;

    // old_dom.type 不同就視爲不同
    // old_dom 必須重建 不然可能有問題
    // <input> 尤其嚴重
    let a_type = (a_attrs.has('type') ? a_attrs.get('type') : null);
    let b_type = (b_attrs.has('type') ? b_attrs.get('type') : null);

    if (a_type !== b_type) {
      return false;
    }

    // 比較 old_dom.id
    if ((a.id != null || b.id != null) && a.id !== b.id) {
      return false;
    }

    // 比較 old_dom.class
    // if (a.classList.length != b.classList.length) {
    //   return false;
    // }

    // if (a.classString != b.classString) {
    //   return false;
    // }

    return true;
  }
  //-----------------------------------------------------
  aboutDomNochange(list = []) {
    while (list.length) {
      let d = list.pop();
      let [vnode, old_dom] = d;
      vnode.setDom(old_dom);
    }
  }
  //-----------------------------------------------------
  aboutSameTypeNodes(list) {
    const $attrsUpdate = $GM.get('attrsUpdate');

    while (list.length) {
      let data = list.pop();

      let [oldNode, node] = data;
      let old_dom = oldNode.dom;

      console.log('-----------\n');
      console.log('update old_dom(%s)', old_dom.nodeName);
      console.dir(oldNode.dom);
      console.log('-----------\n');


      if (old_dom.tagName != null) {
        // 標籤 old_dom
        $attrsUpdate.update(oldNode, node);
      } else {
        // 非標籤 old_dom
        $domApi.setTextContent(old_dom, node.text);
      }
      node.setDom(old_dom);
    }
  }
  //-----------------------------------------------------
  aboutKeepAlive(list = []) {
    // 更新 this.keepAliveMap


  }
  //-----------------------------------------------------
  aboutDiffNodes(list = []) {

    while (list.length) {

      let data = list.shift();

      let [oldVnode, vnode, parentDom] = data;
      let old_dom;
      let dom_next = null;

      if (oldVnode != null) {
        old_dom = oldVnode.dom;
        dom_next = old_dom.nextSibling || null;

        this._removeChildVnodes(oldVnode);
      }
      debugger;
      // 建立一棵新的 domThree
      let new_dom = this._createElm(vnode);

      if (new_dom != null) {
        $domApi.insertBefore(parentDom, new_dom, dom_next);
      }
    }
  }
  //-----------------------------------------------------
  _removeChildVnodes(vnodes = []) {
    // debugger;

    if (vnodes == null) {
      return;
    }

    if (!Array.isArray(vnodes)) {
      vnodes = [vnodes];
    }

    let tempList = [];

    vnodes.forEach(v => {
      // 先脫鉤第一層 old_dom

      tempList.push(v);

      // 有可能碰到 空 vnode
      let old_dom = v.dom || null;

      if (old_dom == null) {
        return;
      }

      let parent = old_dom.parentNode;

      if (parent != null) {
        $domApi.removeChild(parent, old_dom);
      }
    });

    $util.nextStep(() => {
      this._clearVnodeTree(tempList);
    });

  }
  //-----------------------------------------------------
  _clearVnodeTree(list) {
    let index = 0;
    while (true) {
      // debugger;
      let i = index++;

      let vnode = list[i];
      if (vnode == null) {
        break;
      }
      // destroy vnode 
      vnode.destroy();

      let childs = vnode.childs;

      childs.forEach((child) => {
        list.push(child);
      });
    } // endwhile

  }
  //-----------------------------------------------------
  _createElm(rootVnode) {
    // debugger;

    if (rootVnode == null) {
      return null;
    }

    const $attrsUpdate = $GM.get('attrsUpdate');

    // 要處理的列表
    let tempList = [rootVnode];
    let parentMap = {};

    let new_dom;

    let i = 0;
    //-----------------------
    while (true) {
      // debugger;

      let vnode = tempList[i];
      if (vnode == null) {
        break;
      }
      let nodeName = vnode.nodeName;

      if (vnode.tagName == null) {
        // 不是 tag  

        new_dom = this._createDom(null, nodeName, vnode.text);
        vnode.setDom(new_dom);

        console.log('create new_dom(%s)', new_dom.nodeName);

        if (i in parentMap) {
          let parent_dom = parentMap[i];
          delete parentMap[i];
          $domApi.appendChild(parent_dom, new_dom);
        }

      } else {
        // tag
        new_dom = this._createDom(vnode.tagName);
        vnode.setDom(new_dom);

        console.log('create new_dom(%s)', new_dom.nodeName);

        // 處理 attrs
        $attrsUpdate.create(vnode);

        if (i in parentMap) {
          let parent_dom = parentMap[i];
          delete parentMap[i];
          $domApi.appendChild(parent_dom, new_dom);
        }

        let childList = vnode.childs;
        if (!Array.isArray(childList)) {
          return;
        }

        childList.forEach((vnode) => {
          let j = tempList.length;
          tempList.push(vnode);
          parentMap[j] = new_dom;
        });

      } // endif

      i++;
    } // end while

    return rootVnode.dom;
  }
  //-----------------------------------------------------
  _createDom(tagName, nodeName, text) {
    let dom;

    if (tagName == null) {
      switch (nodeName) {
        case '#comment':
          dom = $domApi.createComment(text);
          break;
        case '#text':
          dom = $domApi.createTextNode(text);
          break;
        default:
          console.dir(vnode);
          throw new Error(`no deal with this domType(${nodeName})`);
          break;
      }
    } else {
      dom = $domApi.createElement(tagName);
    }
    return dom;
  }
}

export default ModifyDom;

