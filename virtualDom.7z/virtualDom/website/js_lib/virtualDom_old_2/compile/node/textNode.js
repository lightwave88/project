import $GM from '../../g_module.js';


class TextNode extends DomNode {
  constructor(dom, parent) {
    super(dom, parent);  
  }
  //-------------------------------------------
  callByChild() {
    // no childs
  }
  //-------------------------------------------
  _getSelfCommand() {
    // debugger;
    
    const dom = this.dom;

    let text = dom.nodeValue;

    // 文字內容是否有計算
    let has_compute = this._hasCompute(text);

    if (has_compute) {
      if (this.is_static) {
        this.is_static = false;
      }
      text = this._ss(text);
    } else {
      text = JSON.stringify(text);
    }

    let lines = [];

    // createVnode
    lines.push(`${$vnodeVarName} = ${$createVarName}("${dom.nodeName}", null, ${$parentVarName});\n`);

    // static
    if (!this.is_static) {
      lines.push(`${$vnodeVarName}.setStatic(false);\n`);
    }

    lines.push(`${$vnodeVarName}.setText(${has_compute}, ${text});\n`);

    lines.push(`${$vnodeVarName}.end();\n`);

    lines = lines.map((l) => {
      // format
      return (this._space() + l);
    });

    return lines.join('');
  }
  //-------------------------------------------
  clear() {
    super.clear();
  }
}