import $GM from '../../g_module.js';

class DomNode {

  static getInstance(dom, parent) {
    // 根據 dom 指派相應的 node
    let node = getNode(dom, parent);
    return node;
  }
  //-------------------------------------------
  constructor(dom, parent) {
    this.level;
    this.dom = dom;
    this.parent = parent || null;
    this.childs = null;

    // 命令內容
    // 由 childs 上傳
    this.commandContent = null;

    this.is_static = true;
  }
  //-------------------------------------------
  init() {
    this.level = (this.parent == null ? 0 : (this.parent.level + 1));
  }
  //-------------------------------------------
  append(child) {
    this.childs.push(child);
  }
  //-------------------------------------------
  // API
  callParent() {
    // debugger;
    if (this.parent == null) {
      return;
    }
    // 檢查 no static 的區塊
    this.parent.checkCommandArea();
    //------------------
    // 不同種類標籤必須實作
    let res = this._getSelfCommand();

    this.parent.callByChild(res);
  }
  //-------------------------------------------
  callByChild(text) {
    this.commandContent.unshift(text);
  }
  //-------------------------------------------
  // dom 是否是 static 節點
  setStatic(value) {
    this.is_static = value;
  }
  //-------------------------------------------
  // API
  // 只有 root 有用
  getResult() {
    if (this.parent != null) {
      throw new Error('not root');
    }

    let res = this._getSelfCommand();
    res += "\n";
    res += `return (typeof ${$rootVarName} == "undefined"? null: ${$rootVarName});`;

    return res;
  }

  //-------------------------------------------
  // 取得命令內容
  // override
  _getSelfCommand() {
    throw new Error('need override _getSelfCommand()');
  }
  //-------------------------------------------
  // 清理不要的資料
  clear() {
    this.level = null;
    this.dom = null;
    this.parent = null;

    if (Array.isArray(this.childs)) {
      this.childs.length = 0;
    }
    this.childs = null;

    if (Array.isArray(this.commandContent)) {
      this.commandContent.length = 0;
    }
    this.commandContent = null;

    this.is_static = null;
  }
  //-------------------------------------------
  // text 有 {{}}
  // attr 是否由 data 控制 
  _ss(content, attr = null) {

    if (attr != null) {
      // 前後空白對 attr 無意義
      content = content.trim();
    }

    let list = [];
    const reg_1 = RegExp($reg_2a, 'g');

    content = content.replace(reg_1, (m, g1, g2) => {
      if (g1.length) {
        list.push(JSON.stringify(g1));
      }
      if (g2.length) {
        list.push(g2);
      }
      return '';
    });
    //------------------    
    if (content.length) {
      list.push(JSON.stringify(content));
    }
    // 以變數形態輸出
    return list.join(',');
  }
  //-------------------------------------------
  _hasCompute(text) {
    return ($reg_2.test(text));
  }
  //-------------------------------------------
  // format
  _space(count = 0) {
    let c = (this.level + count) * $space;
    let i = 0;
    let r = '';
    while (i++ < c) {
      r += ' ';
    }
    return r;
  }
}

function getNode(dom, parent) {
  let tagName = dom.tagName || null;

  let node;
  if (tagName != null) {
    // <>
    tagName = tagName.toLowerCase();

    switch (tagName) {
      case 'script':
        node = new ScriptNode(dom, parent)
        break;
      default:
        node = new NormalNode(dom, parent);
        break;
    }
  } else {
    // text....
    node = new TextNode(dom, parent);
  }

  node.init();

  return node;
}