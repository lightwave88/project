// debugger;
// module 管理
const $g_module = new Map();

import util from './util.js';
$g_module.set('util', util);

import { DomNode } from './compile/domNode.js';
$g_module.set('DomNode', DomNode);

import { Vnode } from './vnode.js';
$g_module.set('Vnode', Vnode);

import { templateManager } from './templateManager/index.js';
$g_module.set('templateManager', templateManager);

import { attrsUpdate } from './attrsUpdate/index.js';
$g_module.set('attrsUpdate', attrsUpdate);

import Compile from './compile/compile.js';
$g_module.set('Compile', Compile);

import domApi from './modifyDom/htmldomapi.js';
$g_module.set('domApi', domApi);

import ModifyDom from './modifyDom/modifyDom.js';
$g_module.set('ModifyDom', ModifyDom);

import { api } from './api.js';
$g_module.set('api', api);

export default $g_module;