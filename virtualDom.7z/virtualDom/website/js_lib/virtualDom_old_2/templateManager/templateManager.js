import $GM from '../g_module.js';

class TemplateManager {

  static getInstance(options) {
    let ins = new TemplateManager(options);
    ins.init();
    return ins;
  }

  constructor(options) {
    this.options = Object.assign({}, options);

    // 把 manager 與 controller 橋接
    this.controller = null;

    this.name = null;

    this.prev_vnode = null;
    this.prevRoot_dom = null;

    // 上下文
    this.executeContext = null;

    this.keepAlives = {};

    this.event_setting = {};

    this.slots = {};

    // 模板
    this.templateObj;
    // 與模板綁定的 dom
    this.container_dom;
  }
  //----------------------------------------------------------
  setController(controller) {
    let errors = [];
    // 檢查 controller

    if ('$data' in controller) {
      // 取得資料的渠道
      errors.push('controller must have $data property');
    }

    if (errors.length) {
      throw new Error(errors.join('|'));
    }

    this.controller = controller;


    // check slots
  }
  //----------------------------------------------------------
  init() {
    let { dom, template } = this.options;

    this.container_dom = dom;
    this.templateObj = template;

    if (this.templateObj.name != null) {
      this.name = this.templateObj.name;
    }

    // 告訴管理者，template 裏有幾個 slot
    Object.assign(this.slots, this.templateObj.slots);

    this.options = null;
  }

  setSlot(name, fn) {

  }
  //----------------------------------------------------------
  setExecuteContext(context) {
    this.executeContext = context;

    if (!this.executeContext) {
      this.executeContext = null;
    }
  }
  //----------------------------------------------------------
  // 模板的 dom 事件綁定
  on() {

  }
  //----------------------------------------------------------
  off() {

  }
  //----------------------------------------------------------
  // API render 的映射
  _render(options = {}, data = {}) {
    debugger;

    const { slots, context } = options;

    let node = this.templateObj.render(data, slots, context);
    node = node || null;

    if (this.prev_vnode == null) {
      // 沒有 vnode 表示沒有 html 內容
      let innerHTML = this.container_dom.innerHTML;
      if (innerHTML.length > 0) {
        this.container_dom.innerHTML = '';
      }
    }

    // 建構 dom
    $patch(this.prev_vnode, node, this.container_dom);

    //------------------
    // 事件綁定



    //------------------
    // 更新記錄
    this.prev_vnode = node;
    this.prevRoot_dom = (this.prev_vnode == null ? null : this.prev_vnode.dom);

  }
  //------------------------------------------------------------------------------
  // API 由 controller 控制
  _renderByController() {

  }
  //------------------------------------------------------------------------------
  // 避免 render 的上下文改變
  get render() {
    let options = {
      slots: (this.slots),
      context: (this.executeContext)
    }
    return this._render.bind(this, options);
  }
  //------------------------------------------------------------------------------
  get renderByController() {
    let slots = {};

    let list = Object.getOwnPropertyNames(this.slots);
    list.forEach((k) => {
      let key = 'slot_' + k;

      if (typeof this.controller[key] == 'function') {
        let fn = this.controller[key];
        slots[k] = fn.bind(this.controller);
      }
    });

    let options = {
      slots,
      context: (this.constroller),
    }
    return this._renderByController.bind(this, options);
  }
}

export { TemplateManager };
export default TemplateManager;
//------------------------------------------------------------------------------
function $patch(oldNode, node, parentDom) {
  const ModifyDom = $GM.get('ModifyDom');
  const $modifyDom = new ModifyDom();

  let dom = $modifyDom.patch(oldNode, node, parentDom);
  return dom;
};