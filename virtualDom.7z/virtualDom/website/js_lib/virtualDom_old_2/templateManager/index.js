import $TemplateManager from './templateManager.js';
import { TemplateManagerWithController } from './templateManagerWithController.js';

const templateManager = {
  'TemplateManager': $TemplateManager,
  TemplateManagerWithController
};

export { templateManager };