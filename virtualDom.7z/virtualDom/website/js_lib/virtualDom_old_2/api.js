import $GM from './g_module.js';

const $api = {
  templateList: new Map(),
};

export default $api;
export { $api as api };

const $reg_1 = /^TEMPLATE$/i;
//------------------------------------------------------------------------------
// 取得 template
$api.getTemplate = function (key) {
  if (!this.templateList.has(key)) {
    return null;
  }
  return this.templateList.get(key);
};
//------------------------------------------------------------------------------
// 從 dom 取得渲染函式
$api.getByDom = function (name, dom, options = {}) {

  if (typeof name != 'string') {
    options = dom;
    dom = name;
    name = null;
  }

  options = Object.assign({}, options);
  let { include } = options;
  //------------------
  let includeDom = (include == null ? true : include);

  let rootDom = findRootDom(dom, includeDom);

  // 去除 <template>
  mergeTemplate(rootDom);
  //------------------
  const $Compile = $GM.get('Compile');
  let compile = new $Compile();

  // 建造產生 vnode 的工廠函式
  let vnodeTemplate = compile.byDom(rootDom);

  if (vnodeTemplate == null) {
    // 建立 render_fun 失敗
    return null;
  }

  if (name) {
    vnodeTemplate.name = name;
  }

  // 爲 vnodeTemplate 多加幾個功能
  extendTemplate(vnodeTemplate);

  if (name) {
    templateList.set(name, vnodeTemplate);
  }
  return vnodeTemplate;
};
//------------------------------------------------------------------------------
$api.getByText = function () {

};

//------------------------------------------------------------------------------

$api.getVnode = function (dom) {
  const Vnode = $GM.get('Vnode');
  return Vnode.getVnodeByDom(dom);
}

//------------------------------------------------------------------------------
// 取得 dom 的第一個孩子（不包含 text）
function getFirstChild_tag(dom) {
  let childs = Array.from(dom.children);
  if (!childs.length) {
    return null;
  }
  return childs.shift();
}
//------------------------------------------------------------------------------
// 模板背後的管理者
function getManager() {
  return {};
}
//------------------------------------------------------------------------------
function findRootDom(topDom, includeTop) {
  debugger;
  let rootDom;

  if (includeTop) {
    let parent = topDom.parentNode;
    parent.removeChild(topDom);
    rootDom = topDom;
  } else {
    rootDom = getFirstChild_tag(topDom);
    topDom.removeChild(rootDom);
  }

  // 若遇到 <template> 或 <template> 套嵌
  while (rootDom != null && rootDom.content != null) {
    let p = rootDom.content;
    rootDom = getFirstChild_tag(p);
  }

  if (rootDom == null || rootDom.tagName == null) {
    throw new Error('......');
  }

  if (rootDom.parent != null) {
    rootDom.parent.removeChild(rootDom);
  }

  // check rootDom
  // 必須是實體 tag
  return rootDom;
}
//------------------------------------------------------------------------------
// 去除 <template>
function mergeTemplate(rootDom) {
  debugger;

  while (true) {
    let temp = rootDom.querySelector('template');
    if (temp == null) {
      break;
    }

    let parent = temp.parentNode || null;
    let next = temp.nextSibling || null;
    let frag = temp.content;

    if (parent != null) {
      parent.removeChild(temp);
      parent.insertBefore(frag, next);
    }
  }
}

//------------------------------------------------------------------------------


function extendTemplate(vnodeTemplate) {
  const $templateManager = $GM.get('templateManager');

  const {
    TemplateManager,
    TemplateManagerWithController
  } = $templateManager;

  //-----------------------
  vnodeTemplate.bindDom = function (dom, options = {}) {
    // 設定 slot_fun
    let slotsSet = options, slots;
    // 設定 controller(可有可無)
    let events = options.events;

    // template 後面的管理者
    let manager = TemplateManager.getInstance({
      dom: dom,
      template: vnodeTemplate,
    });

    manager.setSlot(slotsSet);
    manager.on(events);

    return manager;
  };
  //-----------------------
  vnodeTemplate.bindController = function (controller) {

  };
}

