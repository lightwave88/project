import { style } from './style/index.js';


const $tool = {
  style,
};


export default $tool;