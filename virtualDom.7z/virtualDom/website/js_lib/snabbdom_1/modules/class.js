/**
 * class 模块：支持 vnode 使用 className 来操作 html class。
 */

import { isArray } from '../utils.js';

// main hook
function updateClassName(oldVnode, vnode) {
  debugger;

  const oldName = oldVnode.data.className;
  const newName = vnode.data.className;
  //------------------
  if (!oldName && !newName) {
    // 都沒 class
    return;
  }
  if (oldName === newName) {
    // class 相同
    return;
  }
  //------------------
  // new dom
  const elm = vnode.elm;
  
  if (typeof newName === 'string' && newName) {

    elm.className = newName.toString();

  } else if (isArray(newName)) {

    elm.className = '';
    newName.forEach(v => {
      elm.classList.add(v);
    });

  } else {
    // 所有不合法的值或者空值，都把 className 设为 ''
    elm.className = '';
  }
}
//------------------------------------------------------------------------------
// 匯出 hook
export const classModule = {
  create: updateClassName,
  update: updateClassName
};
export default classModule;
