import { init } from './init.js';
import { classModule } from './modules/class.js';
import {styleModule} from './modules/style.js';
import { h } from './h.js';


const patch = init([ // Init patch function with chosen modules
  classModule, // makes it easy to toggle classes
  styleModule
]);

export { h, patch };