import $GM from '../../g_module.js';
import { domNode_classList, varnames, printSpace } from './index.js';

const { DomNode } = domNode_classList;

// b-for, b-if, b-if-else,b-else
class ActionNode extends DomNode {

  action;
  //----------------------------------------------------------------------------
  constructor(config) {
    super(config);
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {
  }
  //----------------------------------------------------------------------------
  _getAction(){
    let dom = this.dom;

    if (!dom.hasAttribute('b-action')) {
      return;
    }
    let action = dom.getAttribute('b-action');
  }
  //----------------------------------------------------------------------------
}

export { ActionNode };