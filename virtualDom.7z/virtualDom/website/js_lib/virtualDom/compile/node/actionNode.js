import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';
import { domNode_classList, varnames, printSpace } from './index.js';

// b-for, b-if, b-if-else,b-else
class ActionNode extends DomNode {

  action;
  //----------------------------------------------------------------------------
  constructor(config) {
    super(config);
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {
  }
  //----------------------------------------------------------------------------
  _getAction(){
    let dom = this.dom;

    if (!dom.hasAttribute('b-action')) {
      return;
    }
    let action = dom.getAttribute('b-action');
  }
  //----------------------------------------------------------------------------
}

export { ActionNode };