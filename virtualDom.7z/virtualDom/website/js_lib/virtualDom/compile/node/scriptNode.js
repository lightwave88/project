import { DomNode } from './domNode.js';


class ScriptNode extends DomNode {

  name = 'ScriptNode';

  constructor(config) {
    super(config);
  }
  //----------------------------------------------------------------------------
  static getInstance(config){
    return new ScriptNode(config);
  }
  //----------------------------------------------------------------------------
  // 取得命令內容
  getSelfCommand() {
    // debugger;

    let content = this.dom.textContent;
    content = content.trim();

    // 要 format 需要分行
    let lines = content.split('\n');

    /*
    let reg_1 = /^\s+/;
    lines = lines.map(line=>{
      return line.replace(reg_1, '');
    });
    */    

    lines.unshift('// script-----');
    lines.push('// endScript-----');

    lines.push(`// level(${this.level}), index(${this.index})\n`);

    // format
    lines = lines.map((l) => {
      let r = this._space() + l;
      return r;
    });

    // 還原字串
    let res = '\n\n' + lines.join('\n') + '\n\n';

    return res;
  }
  //----------------------------------------------------------------------------
  clear() {
    super.clear();
  }
}

export { ScriptNode };
