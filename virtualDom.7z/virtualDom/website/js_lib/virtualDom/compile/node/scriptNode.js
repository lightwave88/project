import { DomNode } from './domNode.js';
import { domNode_classList, printSpace } from './index.js';

class ScriptNode extends DomNode {
  constructor(config) {
    super(config);
  }
  //-------------------------------------------
  // 取得命令內容
  getSelfCommand() {
    // debugger;
    let content = this.dom.textContent;
    content = content.trim();

    // 要 format 需要分行
    let lines = content.split('\n');
    lines.unshift('// script');
    lines.push('// endScript');

    // format
    lines = lines.map((l) => {
      let r = printSpace(this) + l;
      return r;
    });

    // 還原字串
    let res = '\n\n' + lines.join('\n') + '\n\n';

    return res;
  }
  //-------------------------------------------
  clear() {
    super.clear();
  }
}

export { ScriptNode };