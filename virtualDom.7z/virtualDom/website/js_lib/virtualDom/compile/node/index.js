
const $domNode = {
  classList: {},
};

const { varnames, attrComputeHead, classList } = $domNode;
//----------------------------
import { DomNode } from './domNode.js';
classList['DomNode'] = DomNode;

import { TagNode } from './tagNode.js';
classList['TagNode'] = TagNode;

import { TextNode } from './textNode.js';
classList['TextNode'] = TextNode;

import { ScriptNode } from './scriptNode.js';
classList['ScriptNode'] = ScriptNode;

import { FragmentNode } from './fragmentNode.js';
classList['fragmentNode'] = FragmentNode;

import { BSlotNode } from './b-slot.js';
classList['BSlotNode'] = BSlotNode;

import { BForNode } from './b-for.js';
classList['BForNode'] = BForNode;

// import { BIfNode } from './b-if.js';
// classList['BIfNode'] = BIfNode;
//------------------------------------------------------------------------------

// 根據給的 dom 產生對應的 domNode
$domNode.getInstance = function (config = {}) {
  const { dom, parent, isStatic, nodeName } = config;

  let tagName = dom.tagName || null;

  let node;
  if (tagName != null) {

    if (/^b-\w/i.test(nodeName)) {
      // 系統 tag
      node = _getSysNode(config)
    } else {
      switch (nodeName) {
        case 'script':
          node = new ScriptNode(config)
          break;

        default:
          node = new TagNode(config);
          break;
      }
    }
  } else {
    switch (nodeName) {
      case '#document-fragment':
        node = new FragmentNode(config);
        break;
      default:
        // text....
        node = new TextNode(config);
        break;
    }
  }

  return node;
}
//------------------------------------------------------------------------------
// 系統 tag
function _getSysNode(config = {}) {
  const { dom, parent, isStatic, nodeName } = config;

  let node;

  switch (nodeName) {
    case 'b-slot':
      node = new BSlotNode(config);
      break;
    case 'b-for':
      node = new BForNode(config);
      break;
    case 'b-if':
    case 'b-if-else':
    case 'b-else':

      break;
    default:
      throw new Error(`tag(${nodeName})  not allowed`);
      break;
  }
  return node;
}
//------------------------------------------------------------------------------

export { classList as domNode_classList };
export { $domNode as domNode };
export default $domNode;
