
let $format = true;
let $spaceNum = 2;

const $domNode = {
  classList: {},
  varnames: {
    var_root: '$_root',
    var_parentNode: '$_parent',
    var_vnode: '$_vnode',
    var_createVnode: '$_C',
  },
  attrComputeHead: ':',
};

const { varnames, attrComputeHead, classList } = $domNode;
//----------------------------
import { DomNode } from './domNode.js';
classList['DomNode'] = DomNode;

import { TagNode } from './tagNode.js';
classList['TagNode'] = TagNode;

import { TextNode } from './textNode.js';
classList['TextNode'] = TextNode;

import { ScriptNode } from './scriptNode.js';
classList['ScriptNode'] = ScriptNode;

import { FragmentNode } from './fragmentNode.js';
classList['fragmentNode'] = FragmentNode;
//------------------------------------------------------------------------------
// 根據給的 dom 產生對應的 domNode
$domNode.getInstance = function (dom, parent) {
  
  let tagName = dom.tagName || null;
  let nodeName = dom.nodeName.toLowerCase();

  let node;
  if (tagName != null) {
    // <>
    tagName = tagName.toLowerCase();

    switch (tagName) {
      case 'script':
        node = new ScriptNode(dom, parent)
        break;
      case 'b-slot':
        node = new BSlotNode(dom, parent);
        break;
      default:
        node = new TagNode(dom, parent);
        break;
    }
  } else {

    switch (nodeName) {
      case '#document-fragment':
        node = new FragmentNode(dom, parent);
        break;
      default:
        // text....
        node = new TextNode(dom, parent);
        break;
    }
  }

  return node;
}
//------------------------------------------------------------------------------
// format 用
function printSpace(level, count = 0) {
  let r = '';
  if (!$format) {
    return r;
  }
  let c = (level + count) * $spaceNum;
  let i = 0;
  while (i++ < c) {
    r += ' ';
  }
  return r;
}
//------------------------------------------------------------------------------

export { classList as domNode_classList };
export { varnames };
export { printSpace };
export { attrComputeHead };

export { $domNode as domNode };
export default $domNode;