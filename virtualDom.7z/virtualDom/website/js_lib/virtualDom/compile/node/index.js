
let $format = true;
let $spaceNum = 2;

debugger;

const $domNode = {
  classList: {},
  varnames: {
    var_root: '$_root',
    var_parentNode: '$_parent',
    var_vnode: '$_vnode',
    var_createVnode: '$_C',
  },
  attrComputeHead: ':',
};

const { varnames, attrComputeHead, classList } = $domNode;
//----------------------------
import { DomNode } from './domNode.js';
classList['DomNode'] = DomNode;

import { TagNode } from './tagNode.js';
classList['TagNode'] = TagNode;

import { TextNode } from './textNode.js';
classList['TextNode'] = TextNode;

import { ScriptNode } from './scriptNode.js';
classList['ScriptNode'] = ScriptNode;

import { FragmentNode } from './fragmentNode.js';
classList['fragmentNode'] = FragmentNode;
//------------------------------------------------------------------------------

// 根據給的 dom 產生對應的 domNode
$domNode.getInstance = function (config = {}) {
  const { dom, parent, isStatic } = config;

  let tagName = dom.tagName || null;
  let nodeName = dom.nodeName.toLowerCase();
  
  config.nodeName = nodeName;

  let node;
  if (tagName != null) {
    // <>
    tagName = tagName.toLowerCase();

    switch (tagName) {
      case 'script':
        node = new ScriptNode(config)
        break;
      case 'b-slot':
        node = new BSlotNode(config);
        break;
      default:
        node = new TagNode(config);
        break;
    }
  } else {

    switch (nodeName) {
      case '#document-fragment':
        node = new FragmentNode(config);
        break;
      default:
        // text....
        node = new TextNode(config);
        break;
    }
  }

  return node;
}
//------------------------------------------------------------------------------
// format 用
function printSpace(obj, count = 0) {
  let level = obj.level;
  let r = '';
  if (!$format) {
    return r;
  }
  let c = (level + count) * $spaceNum;
  let i = 0;
  while (i++ < c) {
    r += ' ';
  }
  return r;
}
//------------------------------------------------------------------------------

export { classList as domNode_classList };
export { varnames as temp_varnames };
export { printSpace };
export { attrComputeHead };

export { $domNode as domNode };
export default $domNode;