import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';

// 根節點
class FragmentNode extends DomNode {

  name = 'FragmentNode';

  constructor(config) {
    super(config);
  }
  //----------------------------------------------------------------------------
  static getInstance(config) {
    return new FragmentNode(config);
  }
  //----------------------------------------------------------------------------
  // API
  // 只有 root 有用
  getResult() {
    if (this.parent != null) {
      throw new Error('not root');
    }

    let res = this.getSelfCommand();

    return res;
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {

    const sysConfig = $GM.get('sysConfig');

    const {
      var_parentNode,
      var_vnode,
      var_createVnode,
      var_sys,
    } = sysConfig.tempSysVarName;

    let lines = [];

    const space = this._space();

    // createVnode
    // lines.push('\n');

    let content = `// start
${var_vnode} = ${var_createVnode}(null, null, null);
${var_vnode}.end();
${var_sys}.setRootVnode(${var_vnode});
//-------
{`;

    lines.push(content);
    //-----------------------
    // child
    // 合併 child 的內文    

    if (this.childContents != null) {
      lines.push('\n');
      // 子節點
      let _lines = this.mergeChilds(this.childContents);
      lines = lines.concat(_lines);
    }

    lines.push(`}\n`);
    //-----------------------

    let res = lines.join('');
    return res;
  }

  //----------------------------------------------------------------------------
  clear() {
    super.clear();
  }

}


export { FragmentNode };
