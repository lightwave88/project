import { DomNode } from './domNode.js';
import { domNode_classList, temp_varnames, printSpace } from './index.js';

// 根節點
class FragmentNode extends DomNode {
  
  name = 'FragmentNode';
  
  constructor(config) {
    super(config);
  }
  //----------------------------------------------------------------------------  
  // API
  // 只有 root 有用
  getResult() {
    if (this.parent != null) {
      throw new Error('not root');
    }

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = temp_varnames;

    let res = this.getSelfCommand();
    res += "\n";
    res += `return (typeof ${var_root} == "undefined"? null: ${var_root});`;

    return res;
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {
    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = temp_varnames;

    let lines = [];

    lines.push(`let ${var_vnode} = null;\n`);

    // createVnode
    lines.push(`${var_vnode} = ${var_createVnode}(null, null, null);\n`);

    lines.push(`${var_vnode}.end();\n`);

    lines.push(`const ${var_root} = ${var_vnode};\n`);

    lines.push('//-------\n');

    // format
    lines = lines.map((line) => {
      return (printSpace(this) + line);
    });
    //-----------------------
    // child
    // 合併 child 的內文
    if (this.commandContent.length) {
      lines.push(printSpace(this) + "{\n");     

      // child 的內文
      this.commandContent.forEach((l) => {
        lines.push(l);
      });

      lines.push(printSpace(this) + "}\n");
    }

    let res = lines.join('');
    return res;
  }

  //----------------------------------------------------------------------------
  clear() {
    super.clear();
  }

}


export { FragmentNode };
