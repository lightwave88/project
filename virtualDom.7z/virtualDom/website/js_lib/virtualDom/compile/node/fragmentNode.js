import { DomNode } from './domNode.js';
import { template_varNames as temp_varNames, compileConfig } from '../compile_config.js';

// 根節點
class FragmentNode extends DomNode {

  name = 'FragmentNode';

  constructor(config) {
    super(config);
  }
  //----------------------------------------------------------------------------
  static getInstance(config) {
    return new FragmentNode(config);
  }
  //----------------------------------------------------------------------------
  // API
  // 只有 root 有用
  getResult() {
    if (this.parent != null) {
      throw new Error('not root');
    }

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = temp_varNames;

    let res = this.getSelfCommand();

    return res;
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {
    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = temp_varNames;

    let lines = [];

    // createVnode
    lines.push('\n');
    lines.push(`${var_vnode} = ${var_createVnode}(null, null, null);\n`);

    if (this.slotChildName != null) {
      let slotName = Array.from(this.slotChildName);
      slotName = JSON.stringify(slotName);
      lines.push(`${var_vnode}.setSlotName(${slotName});\n`);
    }

    lines.push(`${var_vnode}.end();\n`);

    lines.push(`const ${var_root} = ${var_vnode};\n`);

    lines.push('//-------\n');

    // format
    lines = lines.map((line) => {
      return (this._space() + line);
    });
    //-----------------------
    // child
    // 合併 child 的內文
    lines.push(this._space() + "{");

    if (this.commandContent.length) {
      lines.push('\n');
      // 子節點
      this.mergeChilds(this.commandContent, lines);
    }

    lines.push(this._space() + "}\n");
    //-----------------------

    let res = lines.join('');
    return res;
  }

  //----------------------------------------------------------------------------
  clear() {
    super.clear();
  }

}


export { FragmentNode };
