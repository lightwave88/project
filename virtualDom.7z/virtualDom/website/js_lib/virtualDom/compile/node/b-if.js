import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';
import { template_varNames as temp_varNames, compileConfig } from '../compile_config.js';

// b-for, b-if, b-if-else,b-else
class BIfNode extends DomNode {

  name = 'BIfNode';

  $scriptContent;


  // 0: b-if
  // 1: b-if-else
  // 2: b-else
  $if_type = 0;

  // <b-if>
  $is_end = true;

  //----------------------------------------------------------------------------
  constructor(config) {
    super(config);

    this.isEmpty = true;
    this.isStatic = false;

    switch (this.tagName) {
      case 'b-if':
        this.$if_type = 0;
        break;
      case 'b-if-else':
        this.$if_type = 1;
        break;
      case 'b-else':
        this.$if_type = 2;
        break;
      default:
        throw new TypeError('error tag');
        break;
    }

    this._getAction();

    this._checkPrevNode();
  }
  //----------------------------------------------------------------------------
  static getInstance(config){
    return new BIfNode(config);
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {
    debugger;
    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
      var_sys,
    } = temp_varNames;

    let lines = [];

    switch (this.$if_type) {
      case 1:
        lines.push(` if-else( ${var_sys}.booleanVal(${this.$scriptContent}) ){`);
        break;
      case 2:
        lines.push(` else {`);
        break;
      default:
        lines.push(`\n${this._space()}if( ${var_sys}.booleanVal(${this.$scriptContent}) ){`);
        break;
    }
    //------------------
    // 子節點
    if (this.commandContent.length) {
      lines.push('\n\n');
      this.mergeChilds(this.commandContent, lines);
    }
    //------------------
    let foot = '\n'+ this._space() + '}';
    if (this.$is_end) {
      foot += '\n';
    }
    lines.push(foot);

    let res = lines.join('');
    lines.length = 0;

    console.log('%s:\n%s', this.tagName, res);

    return res;
  }
  //----------------------------------------------------------------------------
  _getAction() {
    let dom = this.dom;

    if (this.$if_type == 2) {
      return;
    }

    if (!dom.hasAttribute('b-script')) {
      throw new Error(`<${this.tagName}> no attr.b-script`);
    }
    this.$scriptContent = dom.getAttribute('b-script').trim();
  }
  //----------------------------------------------------------------------------
  // <b-if><b-else-if><b-else>
  // 彼此必須緊鄰
  _checkPrevNode() {
    debugger;

    if (this.$if_type == 0) {
      // <b-if> 不用檢查
      return;
    }

    if (this.parent == null) {
      return;
    }
    const parent = this.parent;

    let childList = this.parent.childs;

    let index = this.index-1;

    while (true) {
      debugger;
      let i = index--;

      if (i < 0) {
        break;
      }

      let prevNode = childList[i];

      if (prevNode instanceof BIfNode) {
        if (prevNode.$if_type == 2) {
          // <b-else><b-else> 重疊
          throw new Error(`<${this.tagName}> should adjacent to <b-if><b-else-if>`);
        }
        prevNode.$is_end = false;
        break;
      } else {
        if (prevNode.name == 'TextNode' && prevNode.contentIsEmpty()) {
          parent.removeChild(null, i);
        } else {
          throw new Error(`<${this.tagName}> should adjacent to <b-if><b-else-if>`);
        }
      }
    }
  }
}

export { BIfNode };
