import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';
import { template_varNames as temp_varNames, compileConfig } from '../compile_config.js';

// b-for, b-if, b-if-else,b-else
class BIfNode extends DomNode {

  name = 'ActionNode';

  $tagName;

  checkNextToTag = ['b-if-else', 'b-else'];

  action;
  //----------------------------------------------------------------------------
  constructor(config) {
    super(config);

    this.$tagName = dom.tagName.toLowerCase();

    this._getAction();

    this._checkIsNextTo();
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {
  }
  //----------------------------------------------------------------------------
  _getAction() {
    let dom = this.dom;

    if (!dom.hasAttribute('b-action')) {
      return;
    }
    let action = dom.getAttribute('b-action');
  }
  //----------------------------------------------------------------------------
  _checkIsNextTo() {

    if (!this.checkNextToTag.includes(this.$tagName)) {
      return;
    }

    let childList = this.parent.childs;

    let findHead = false;

    for (let i = (this.index - 1); i >= 0; i--) {
      let prev = childList[i];

      if (prev.$tagName == null) {
        throw new Error('.............');
      }

      if (prev.$tagName == 'b-if') {
        findHead = true;
        break;
      }
    }
    if (!findHead) {
      throw new Error('.............');
    }
  }
}

export { BIfNode as ActionNode };
