import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';

// b-for, b-if, b-if-else,b-else
class BIfNode extends DomNode {

  name = 'BIfNode';

  $scriptContent;


  // 0: b-if
  // 1: b-if-else
  // 2: b-else
  $if_type = 0;

  // <b-if>
  $is_last = true;

  //----------------------------------------------------------------------------
  constructor(config) {
    super(config);

    if (this.parentIsKeepAll) {
      throw new Error('');
    }

    // this.isEmpty = true;
    this.isStatic = false;

    switch (this.tagName) {
      case 'b-if':
        this.$if_type = 0;
        break;
      case 'b-if-else':
        this.$if_type = 1;
        break;
      case 'b-else':
        this.$if_type = 2;
        break;
      default:
        throw new Error('error tag');
        break;
    }

    this._getAction();

    this._checkPrevNode();
  }
  //----------------------------------------------------------------------------
  static getInstance(config) {
    return new BIfNode(config);
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {
    debugger;
    const sysConfig = $GM.get('sysConfig');

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
      var_sys,
    } = sysConfig.tempSysVarName;;

    let lines = [];

    switch (this.$if_type) {
      case 1:
        lines.push(` if-else( ${var_sys}.booleanVal(${this.$scriptContent}) ){`);
        break;
      case 2:
        lines.push(` else {`);
        break;
      default:
        lines.push(`\n${this._space()}if( ${var_sys}.booleanVal(${this.$scriptContent}) ){`);
        break;
    }
    //------------------
    // 子節點
    if (this.childContents != null) {
      lines.push('\n\n');
      let _lines = this.mergeChilds(this.childContents, true);
      lines = lines.concat(_lines);
    }
    //------------------
    let foot = '\n' + this._space() + '}';
    if (this.$is_last) {
      foot += '\n';
    }
    lines.push(foot);

    let res = lines.join('');
    lines.length = 0;

    console.log('%s:\n%s', this.tagName, res);

    return res;
  }
  //----------------------------------------------------------------------------
  _getAction() {
    let dom = this.dom;

    if (this.$if_type == 2) {
      return;
    }

    if (!dom.hasAttribute('b-script')) {
      throw new Error(`<${this.tagName}> no attr.b-script`);
    }
    this.$scriptContent = dom.getAttribute('b-script').trim();
  }
  //----------------------------------------------------------------------------
  // <b-if><b-else-if><b-else>
  // 彼此必須緊鄰
  _checkPrevNode() {
    debugger;

    if (this.$if_type == 0) {
      // <b-if> 不用檢查
      return;
    }

    if (this.parent == null) {
      // return;
    }

    let childList = this.parent.childs;

    let index = this.index - 1;

    while (true) {
      debugger;
      let i = index--;

      if (i < 0) {
        break;
      }

      let prevNode = childList[i];

      if (prevNode instanceof BIfNode) {
        if (prevNode.$if_type == 2) {
          // <b-else> 錯置
          throw new Error(`<${this.tagName}> should adjacent to <b-if><b-else-if>`);
        }
        prevNode.$is_last = false;

        if (prevNode.$if_type == 0) {
          // 來到 <b-if> 確保有正確的區塊
          break;
        }

      } else {


        if (!prevNode.isPrint) {
          // 遇到空文字節點
          // parent.removeChild(null, i);
          continue;
        } else {
          throw new Error(`<${this.tagName}> should adjacent to <b-if><b-else-if>`);
        }
      }
    }
  }
}

export { BIfNode };
