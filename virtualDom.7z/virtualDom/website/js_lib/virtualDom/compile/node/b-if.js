import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';
import { template_varNames as temp_varNames, compileConfig } from '../compile_config.js';

// b-for, b-if, b-if-else,b-else
class BIfNode extends DomNode {

  name = 'BIfNode';

  $scriptContent;
  $data_varName;

  // 0: b-if
  // 1: b-if-else
  // 2: b-else
  $if_type = 0;

  // <b-if>
  $is_end = true;

  //----------------------------------------------------------------------------
  constructor(config) {
    super(config);

    this.isEmpty = true;

    switch (this.tagName) {
      case 'b-if':
        this.$if_type = 0;
        break;
      case 'b-if-else':
        this.$if_type = 1;
        break;
      case 'b-else':
        this.$if_type = 2;
        break;
      default:
        throw new TypeError('error tag');
        break;
    }

    this._getAction();

    this._checkPrevNode();
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {
    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
      var_sys,
    } = temp_varNames;

    let lines = [];

    switch (this.$if_type) {
      case 1:
        lines.push(`if-else(${var_sys}.getBooleanVal(${this.$data_varName}){\n`);
        break;
      case 2:
        lines.push(`else{\n`);
        break;
      default:
        lines.push(`${this._space()}if(${var_sys}.getBooleanVal(${this.$data_varName}){`);
        break;
    }
    //------------------
    // 子節點
    if (this.commandContent.length) {
      lines.push('\n');
      this.mergeChilds(this.commandContent, lines);
    }
    //------------------
    let foot = `${this._space()}\}`;
    if (this.$is_end) {
      foot += '\n';
    }
    lines.push(foot);

    let res = lines.join('');
    lines.length = 0;

    return res;
  }
  //----------------------------------------------------------------------------
  _getAction() {
    let dom = this.dom;

    if (!dom.hasAttribute('b-script')) {
      throw new Error(`<${this.tagName}> no attr.b-script`);
    }
    this.$scriptContent = dom.getAttribute('b-script').trim();
  }
  //----------------------------------------------------------------------------
  // <b-if><b-else-if><b-else>
  // 彼此必須緊鄰
  _checkPrevNode() {
    if (this.$if_type == 0) {
      // <b-if> 不用檢查
      return;
    }

    if (this.parent == null) {
      return;
    }

    let childList = this.parent.childs;

    let prev_index = this.index - 1;
    let prevNode = childList[prev_index] || null;

    if (!(prevNode instanceof BIfNode) && prevNode.$if_type == 2) {
      throw new Error(`<${this.tagName}> should adjacent to <b-if><b-else-if>`);
    }
    prevNode.$is_end = false;
  }
}

export { BIfNode };
