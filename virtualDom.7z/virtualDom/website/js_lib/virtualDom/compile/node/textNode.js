import { DomNode } from './domNode.js';
import { template_varNames as temp_varNames, compileConfig } from '../compile_config.js';

class TextNode extends DomNode {

  name = 'TextNode';

  constructor(config) {
    super(config);
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {
    debugger;

    // console.dir(this);

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = temp_varNames;

    const dom = this.dom;

    let text = dom.nodeValue;

    // 文字內容是否有計算
    let has_compute = this._hasCompute(text);

    if (has_compute) {
      if (this.isStatic) {
        this.isStatic = false;
      }
      text = this._ss(text);
    } else {
      text = JSON.stringify(text);
    }

    let lines = [];

    // createVnode
    lines.push(`${var_vnode} = ${var_createVnode}("${dom.nodeName}", null, ${var_parentNode});\n`);

    lines.push(`// level(${this.level}), index(${this.index})\n`);
    // static
    if (!this.isStatic) {
      lines.push(`${var_vnode}.setStatic(false);\n`);
    }

    lines.push(`${var_vnode}.setText(${has_compute}, ${text});\n`);

    lines.push(`${var_vnode}.end();\n`);

    lines = lines.map((l) => {
      // format
      return (this._space() + l);
    });

    return lines.join('');
  }
  //----------------------------------------------------------------------------
  clear() {
    super.clear();
  }
  //----------------------------------------------------------------------------
}

export { TextNode };
