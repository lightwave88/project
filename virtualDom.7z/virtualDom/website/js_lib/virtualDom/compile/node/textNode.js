import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';

// const $reg_1 = /^#text$/i;

class TextNode extends DomNode {

  name = 'TextNode';
  text;
  //----------------------------------------------------------------------------
  constructor(config) {
    super(config);

    // 重點
    // 重點
    // 不要落入比較字串耗時的步驟
    this.isStatic = false;
    this.text = this.dom.nodeValue;

    if (this.nodeName == '#text' && this.contentIsEmpty()) {
      // 空文字節點
      this.isPrint = false;
    }
  }
  //----------------------------------------------------------------------------
  static getInstance(config) {
    let node = new TextNode(config);

    return node;
  }
  //----------------------------------------------------------------------------
  // @ override
  setStatic(value) {

  }
  //----------------------------------------------------------------------------
  getSelfCommand() {
    // debugger;

    if (!this.isPrint) {
      // 空文字節點
      return '';
    }
    //-------------
    const $util = $GM.get('util');
    const sysConfig = $GM.get('sysConfig');

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = sysConfig.tempSysVarName;

    // 文字內容是否有計算
    let has_compute = $util.hasComputeVar(this.text);

    if (has_compute) {
      text = this._ss(this.text);
    } else {
      text = JSON.stringify(this.text);
    }

    let lines = [];

    // createVnode
    lines.push(`${var_vnode} = ${var_createVnode}("${this.nodeName}", null, ${var_parentNode});\n`);

    lines.push(`// level(${this.level}), index(${this.index})\n`);

    // static
    lines.push(`${var_vnode}.setStatic(false);\n`);


    lines.push(`${var_vnode}.setText(${has_compute}, ${text});\n`);

    lines.push(`${var_vnode}.end();\n`);

    lines = lines.map((l) => {
      // format
      return (this._space() + l);
    });

    return lines.join('');
  }
  //----------------------------------------------------------------------------
  clear() {
    super.clear();
  }
  //----------------------------------------------------------------------------
  // 特殊
  contentIsEmpty() {
    let val = this.text.trim();
    return (val.length < 1);
  }

}

export { TextNode };
