'use strict';

import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';

class TagNode extends DomNode {

  name = 'TagNode';
  lines = [];

  constructor(config) {
    super(config);
  }
  //----------------------------------------------------------------------------
  static getInstance(config) {
    return new TagNode(config);
  }
  //----------------------------------------------------------------------------
  // 取得命令內容
  // important
  getSelfCommand() {
    debugger;
    const sysConfig = $GM.get('sysConfig');

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
      var_sys,
    } = sysConfig.tempSysVarName;
    //-----------------------
    let lines = [];

    let tagName = JSON.stringify(this.tagName);
    let dom_nodeName = JSON.stringify(this.nodeName);
    const space = this._space();

    // createVnode
    lines.push(`${space}${var_vnode} = ${var_createVnode}(${dom_nodeName}, ${tagName}, ${var_parentNode});\n`);

    lines.push(`${space}// level(${this.level}), index(${this.index})\n`);

    //-----------------------

    // keep
    if (this.keep != null) {
      let name = JSON.stringify(this.keep);
      lines.push(`${space}${var_vnode}.setKeep('${name}');\n`);
    }

    // keepAll
    if (this.keepAll != null) {
      let name = JSON.stringify(this.keepAll);
      lines.push(`${space}${var_vnode}.setKeepAll('${name}');\n`);
    }
    //-----------------------
    // attrs
    this._attrs(space, lines);

    // static
    if (!this.isStatic) {
      lines.push(`${space}${var_vnode}.setStatic(false);\n`);
    }

    lines.push(`${space}${var_vnode}.end();\n//-------\n`);

    //-----------------------

    lines.push(`${space}{`);
    // child
    if (this.childContents != null) {
      lines.push('\n');
      // 子節點
      let _lines = this.mergeChilds(this.childContents);
      lines = lines.concat(_lines);
    }
    lines.push(`${space}}\n`);

    let res = lines.join('');
    return res;
  }
  //----------------------------------------------------------------------------
  // 記錄 attr
  _attrs(space, lines) {
    debugger;

    const dom = this.dom;
    const sysConfig = $GM.get('sysConfig');
    const $util = $GM.get('util');

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = sysConfig.tempSysVarName;
    //-----------------------
    let attrMap = Array.from(dom.attributes);

    // 一般屬性
    let attrs = {};
    // 計算屬性
    let comp_attrs = {};

    // 把 attr 分優先性
    // 有計算屬性的放後面

    attrMap.forEach((attr) => {
      debugger;
      const { nodeName: key, nodeValue: value } = attr;

      if ($util.hasComputeAttr(key)) {
        // 計算屬性
        let k = $util.getComputeAttrKey(key);
        comp_attrs[k] = $util.SS(value);
      } else {

        attrs[key] = JSON.stringify(value);
      }
    });
    //------------------

    const jobList = [attrs, comp_attrs];

    jobList.forEach((job, i) => {
      let isCompute = i > 0 ? 'true' : 'false';
      for (let key in job) {
        let v = job[key];
        let k = JSON.stringify(key);
        lines.push(`${space}${var_vnode}.setAttr(${isCompute}, ${k}, ${v});\n`);
      }
    });

    return lines;;
  }
  //----------------------------------------------------------------------------
  // 清理不要的資料
  clear() {
    super.clear();
    this.has_checkCommandArea = null;
  }
  //----------------------------------------------------------------------------

}

export { TagNode };
