import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';
import { domNode_classList, temp_varnames, printSpace, attrComputeHead } from './index.js';
debugger;


// 計算屬性的前綴
let $attr_prev;

class TagNode extends DomNode {

  constructor(config) {
    super(config);
  }
  //----------------------------------------------------------------------------
  // 取得命令內容
  // important
  getSelfCommand() {
    // debugger;

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = temp_varnames;

    const dom = this.dom;
    let tagName = JSON.stringify(dom.tagName);
    let dom_nodeName = JSON.stringify(dom.nodeName);
    //-----------------------
    let lines = [];

    // createVnode
    lines.push(`${var_vnode} = ${var_createVnode}("${dom_nodeName}", ${tagName}, ${var_parentNode});\n`);

    //-----------------------
    // 檢查 attr 帶的訊息
    this._checkAttrInfo(dom);

    // id
    this._attr_id(dom, lines);

    // class
    this._attr_class(dom, lines);

    // style
    this._attr_style(dom, lines);

    // attrs
    this._attrs(dom, lines);

    // static
    if (!this.is_static) {
      lines.push(`${var_vnode}.setStatic(false);\n`);
    }

    lines.push(`${$vnodeVarName}.end();\n//-------\n`);

    // format
    lines = lines.map((line) => {
      return (printSpace() + line);
    });
    //-----------------------

    // child
    if (this.commandContent.length) {
      lines.push(printSpace(this) + "{\n");
      lines.push(printSpace(this, 1) + `const ${$parentVarName} = ${$vnodeVarName};\n`);

      this.commandContent.forEach((l) => {
        lines.push(l);
      });

      lines.push(printSpace(this) + "}\n");
    }

    let res = lines.join('');
    return res;
  }
  //----------------------------------------------------------------------------
  _attr_id(dom, lines) {
    const {
      var_vnode,
    } = temp_varnames;

    if (dom.hasAttribute('id')) {
      let id = dom.getAttribute('id');
      lines.push(`${var_vnode}.setId("${id}");\n`);
      dom.removeAttribute('id');
    }
  }
  //----------------------------------------------------------------------------
  _attr_class(dom, lines) {

    if (dom.hasAttribute('class')) {
      let classList = Array.from(dom.classList);
      classList = JSON.stringify(classList);

      lines.push(`${$vnodeVarName}.setClass(false, ${classList});\n`);
      dom.removeAttribute('class');
    }

    let attrName = `${$attr_prev}class`;
    if (dom.hasAttribute(attrName)) {
      // calss 有計算屬性
      let classData = dom.getAttribute(attrName);
      let v = this._ss(classData, 'class');
      lines.push(`${$vnodeVarName}.setClass(true, ${v});\n`);
      dom.removeAttribute(attrName);
    }
  }
  //----------------------------------------------------------------------------
  _attr_style(dom, lines) {
    if (dom.hasAttribute('style')) {
      let style = dom.getAttribute('style');

      let v = JSON.stringify(style);
      lines.push(`${$vnodeVarName}.setStyle(false, ${v});\n`);
      dom.removeAttribute('style');
    }

    attrName = `${$attr_prev}style`;
    if (dom.hasAttribute(attrName)) {
      // computer
      let style = dom.getAttribute(attrName);
      let v = this._ss(style, 'style');

      lines.push(`${$vnodeVarName}.setStyle(true, ${v});\n`);
      dom.removeAttribute(attrName);
    }
  }
  //----------------------------------------------------------------------------
  _attrs(dom, lines) {
    let attrMap = Array.from(dom.attributes);

    attrMap.forEach((attr) => {

      let key = attr.nodeName;
      let value = attr.nodeValue;

      let v;
      if ($reg_1.test(key)) {
        // 計算屬性
        v = this._ss(value, key);
        lines.push(`${$vnodeVarName}.setAttr(true, "${key}", ${v});\n`);
      } else {
        v = JSON.stringify(value);
        lines.push(`${$vnodeVarName}.setAttr(false, "${key}", ${v});\n`);
      }
    });
  }
  //----------------------------------------------------------------------------
  // 清理不要的資料
  clear() {
    super.clear();
    this.has_checkCommandArea = null;
  }
}

export { TagNode };


(async () => {
  await Promise.resolve();
  $attr_prev = attrComputeHead;
})();