import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';
import { domNode_classList, temp_varnames, printSpace, attrComputeHead } from './index.js';

// 計算屬性的前綴
let $attr_prev;

class TagNode extends DomNode {

  name = 'TagNode';
  lines = [];

  constructor(config) {
    super(config);
  }
  //----------------------------------------------------------------------------
  // 取得命令內容
  // important
  getSelfCommand() {
    debugger;

    // console.dir(this);

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = temp_varnames;

    const dom = this.dom;
    //-----------------------
    let lines = this.lines;

    this.isFirstChild(lines);

    let tagName = JSON.stringify(dom.tagName);
    let dom_nodeName = JSON.stringify(dom.nodeName);

    // createVnode
    lines.push(`${var_vnode} = ${var_createVnode}("${dom_nodeName}", ${tagName}, ${var_parentNode});\n`);

    lines.push(`// level(${this.level}), index(${this.index})\n`);
    //-----------------------

    // id
    this._attr_id();

    // class
    this._attr_class();

    // style
    this._attr_style();

    // attrs
    this._attrs();

    // static
    if (!this.isStatic) {
      lines.push(`${var_vnode}.setStatic(false);\n`);
    }

    lines.push(`${var_vnode}.end();\n//-------\n`);

    // format
    lines = lines.map((line) => {
      return (printSpace(this) + line);
    });
    //-----------------------

    // child
    if (this.commandContent.length) {
      lines.push(printSpace(this) + "{\n");


      this.commandContent.forEach((l) => {
        lines.push(l);
      });

      lines.push(printSpace(this) + "}\n");
    }

    let res = lines.join('');
    return res;
  }
  //----------------------------------------------------------------------------
  _attr_id() {
    const dom = this.dom;

    const {
      var_vnode,
    } = temp_varnames;

    if (dom.hasAttribute('id')) {
      let id = dom.getAttribute('id');
      this.lines.push(`${var_vnode}.setId("${id}");\n`);
      dom.removeAttribute('id');
    }
  }
  //----------------------------------------------------------------------------
  _attr_class() {
    const dom = this.dom;

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = temp_varnames;

    if (dom.hasAttribute('class')) {
      let classList = Array.from(dom.classList);
      classList = JSON.stringify(classList);

      this.lines.push(`${var_vnode}.setClass(false, ${classList});\n`);
      dom.removeAttribute('class');
    }

    let attrName = attrComputeHead + 'class';
    if (dom.hasAttribute(attrName)) {
      // calss 有計算屬性
      let classData = dom.getAttribute(attrName);
      let v = this._ss(classData, 'class');
      this.lines.push(`${var_vnode}.setClass(true, ${v});\n`);
      dom.removeAttribute(attrName);
    }
  }
  //----------------------------------------------------------------------------
  _attr_style() {
    const dom = this.dom;

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = temp_varnames;

    if (dom.hasAttribute('style')) {
      let style = dom.getAttribute('style');

      let v = JSON.stringify(style);
      this.lines.push(`${var_vnode}.setStyle(false, ${v});\n`);
      dom.removeAttribute('style');
    }

    // console.log('attrComputeHead(%s)', attrComputeHead);

    let attrName = attrComputeHead + 'style';
    if (dom.hasAttribute(attrName)) {
      // computer
      let style = dom.getAttribute(attrName);
      let v = this._ss(style, 'style');

      this.lines.push(`${var_vnode}.setStyle(true, ${v});\n`);
      dom.removeAttribute(attrName);
    }
  }
  //----------------------------------------------------------------------------
  _attrs() {
    const dom = this.dom;

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = temp_varnames;

    let attrMap = Array.from(dom.attributes);

    let $reg_1 = RegExp('^' + attrComputeHead);

    attrMap.forEach((attr) => {

      let key = attr.nodeName;
      let value = attr.nodeValue;

      let v;
      if ($reg_1.test(key)) {
        // 計算屬性
        v = this._ss(value, key);
        this.lines.push(`${var_vnode}.setAttr(true, "${key}", ${v});\n`);
      } else {
        v = JSON.stringify(value);
        this.lines.push(`${var_vnode}.setAttr(false, "${key}", ${v});\n`);
      }
    });
  }
  //----------------------------------------------------------------------------
  // 清理不要的資料
  clear() {
    super.clear();
    this.has_checkCommandArea = null;
  }


  //----------------------------------------------------------------------------

  }
}

export { TagNode };


(async () => {
  await Promise.resolve();
  $attr_prev = attrComputeHead;
})();
