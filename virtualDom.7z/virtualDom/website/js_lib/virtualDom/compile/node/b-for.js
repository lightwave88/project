import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';
import { template_varNames as temp_varNames, compileConfig } from '../compile_config.js';

const $reg_1 = /^\s*(?:(\([^]*?\))|(\S*))\s+in\s+(\S*)\s*$/;
const $reg_2 = /\b(index|key|item)\b/;


// b-for
// (item, key, index)
class BForNode extends DomNode {

    name = 'BForNode';

    $scriptContent;
    $dataName;

    $varMap = {
        key: false,
        index: false,
        item: false
    };
    //----------------------------------------------------------------------------
    constructor(config) {
        super(config);

        this.$tagName = dom.tagName.toLowerCase();

        this._getAction();

        this._checkIsNextTo();
    }
    //----------------------------------------------------------------------------
    getSelfCommand() {
        const {
            var_root,
            var_parentNode,
            var_vnode,
            var_createVnode,
            var_sys,
            var_loopData
        } = temp_varNames;

        let lines = this.lines;

        this.isFirstChild(lines, this._space);

        lines.push(`${this._space()}(${var_sys}.renderList(${this.$dataName}, (item)=>{\n`);

        // 子節點
        if (this.commandContent.length) {
            this.commandContent.forEach((l) => {
                lines.push(l);
            });
        }

        lines.push(`${this._space()});\n`);

        let res = lines.join('');
        lines.length = 0;
        this.lines = null;

        return res;
    }
    //----------------------------------------------------------------------------
    _getAction() {
        let dom = this.dom;

        if (!dom.hasAttribute('b-script')) {
            throw new Error('<b-for> no attr.b-script');
        }
        let script = dom.getAttribute('b-script');
        this.$scriptContent = script.trim();

        let res = $reg_1.exec(this.$scriptContent);

        let head, dataName;

        let typeError = false;
        if(res == null){
          typeError = true;
        }else{
          head = res[1] || res[2];
          dataName = res[3];

          if(!head.length || !dataName.length){
            typeError = true;
          }
        }

        if(typeError){
          throw new Error('<b-for> attr.b-script typeError');
        }

        this.$dataName = dataName;

        let reg_2 = RegExp($reg_2, 'g');
        let res;

        while(res = reg_2.exec(head)){
          if(res == null){
            break;
          }
          let k = res[1];

          if(k in this.$varMap){
            this.$varMap[k] = true;
          }
        }
        //-------------

    }
    //----------------------------------------------------------------------------

}

export { BForNode };
