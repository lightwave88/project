import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';
import { template_varNames as temp_varNames, compileConfig } from '../compile_config.js';

// b-for
// (item, key, index)
class BForNode extends DomNode {

    name = 'BForNode';

    $scriptContent;
    $dataName;

    $varMap = {
        val: null,
        key: null
    };
    //----------------------------------------------------------------------------
    constructor(config) {
        super(config);

        this.$tagName = dom.tagName.toLowerCase();

        this._getAction();

        this._checkIsNextTo();
    }
    //----------------------------------------------------------------------------
    getSelfCommand() {
        const {
            var_root,
            var_parentNode,
            var_vnode,
            var_createVnode,
            var_sys,
            var_loopData
        } = temp_varNames;

        let lines = this.lines;

        this.isFirstChild(lines, this._space);

        lines.push(`${this._space()}(${var_sys}.renderList(${this.$dataName}, (item,index,key)=>{\n`);

        // 子節點
        if (this.commandContent.length) {
            this.commandContent.forEach((l) => {
                lines.push(l);
            });
        }

        lines.push(`${this._space()});\n`);

        let res = lines.join('');
        lines.length = 0;
        this.lines = null;

        return res;
    }
    //----------------------------------------------------------------------------
    _getAction() {
        let dom = this.dom;

        if (!dom.hasAttribute('b-script')) {
            throw new Error();
        }
        let action = dom.getAttribute('b-script');
    }
    //----------------------------------------------------------------------------

}

export { BForNode };
