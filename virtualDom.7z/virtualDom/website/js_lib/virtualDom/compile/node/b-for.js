import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';
import { template_varNames as temp_varNames, compileConfig } from '../compile_config.js';

const $reg_1 = /^\s*(?:(\([^]*?\))|(\S*))\s+in\s+(\S*)\s*$/;
const $reg_2 = /\b(index|key|item)\b/;


// b-for
// (item, key, index)
class BForNode extends DomNode {

  name = 'BForNode';

  $scriptContent;
  $data_varName;

  $varMap = {
    key: false,
    index: false,
    item: false
  };
  //----------------------------------------------------------------------------
  constructor(config) {
    super(config);

    this.isEmpty = true;

    this._getAction();
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {
    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
      var_sys,
      var_loopData
    } = temp_varNames;

    let lines = [];

    // 使用者選用的參數
    let args = [];
    for (let k in this.$varMap) {
      if (this.$varMap[k]) {
        args.push(k);
      }
    }

    args = args.join(',');

    lines.push('\n');
    lines.push(`${this._space()}${var_sys}.renderList(${this.$data_varName}, ({${args}})=>{`);

    // 子節點
    if (this.commandContent.length) {
      // 子節點
      lines.push('\n\n');
      this.mergeChilds(this.commandContent, lines);
    }

    lines.push(`${this._space()}});\n`);
    lines.push('\n');

    let res = lines.join('');
    lines.length = 0;
    this.lines = null;

    return res;
  }
  //----------------------------------------------------------------------------
  _getAction() {
    let dom = this.dom;

    if (!dom.hasAttribute('b-script')) {
      throw new Error('<b-for> no attr.b-script');
    }
    let script = dom.getAttribute('b-script');
    this.$scriptContent = script.trim();

    let res = $reg_1.exec(this.$scriptContent);

    let head, data_varName;

    let typeError = false;
    if (res == null) {
      typeError = true;
    } else {
      head = res[1] || res[2];
      data_varName = res[3];

      if (!head.length || !data_varName.length) {
        typeError = true;
      }
    }

    if (typeError) {
      throw new Error('<b-for> attr.b-script typeError');
    }

    this.$data_varName = data_varName;

    let reg_2 = RegExp($reg_2, 'g');

    while (res = reg_2.exec(head)) {
      if (res == null) {
        break;
      }
      let k = res[1];

      if (k in this.$varMap) {
        this.$varMap[k] = true;
      }
    }
    //-------------

  }
  //----------------------------------------------------------------------------

}

export { BForNode };
