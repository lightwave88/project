import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';
import { template_varNames as temp_varNames, compileConfig } from '../compile_config.js';

// b-for 內容
const $reg_1 = /^\s*(?:\{([^]*?)\}|(\S+))\s+in\s+(\S*)\s*$/;

// b-for 預訂的變數
const $reg_2 = /\b(index|key|item)\b/;

const $reg_3 = /\s*\,\s*/;

// {...,...}
const $reg_4 = /\b(\w+)\s*[:]\s*(\w+)\b|\b(\w+)\b/;

// b-for
// (item, key, index)
// (item in data)
// ({item} in data)
// ({item:it} in data) item 別名 it
class BForNode extends DomNode {

  name = 'BForNode';

  $scriptContent;
  $data_varName;

  $varMap = {
    key: null,
    index: null,
    item: null
  };
  //----------------------------------------------------------------------------
  constructor(config) {
    super(config);

    this.isEmpty = true;
    this.isStatic = false;

    this._getAction();
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {
    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
      var_sys,
      var_loopData
    } = temp_varNames;

    let lines = [];

    //------------------
    // 使用者選用的參數
    let args = this._aboutVars();
    //------------------
    lines.push('\n');
    lines.push(`${this._space()}${var_sys}.renderList(${this.$data_varName}, ({${args}})=>{`);

    // 子節點
    if (this.commandContent.length) {
      // 子節點
      lines.push('\n\n');
      this.mergeChilds(this.commandContent, lines);
    }

    lines.push(`${this._space()}});\n`);
    lines.push('\n');

    let res = lines.join('');
    lines.length = 0;
    this.lines = null;

    return res;
  }
  //----------------------------------------------------------------------------
  _getAction() {
    let dom = this.dom;

    if (!dom.hasAttribute('b-script')) {
      throw new Error('<b-for> no attr.b-script');
    }
    let script = dom.getAttribute('b-script');
    this.$scriptContent = script.trim();

    // 驗證
    let res = $reg_1.exec(this.$scriptContent);

    let typeError = 0;

    let head_1;
    let head_2;
    let data_varName;

    if (res == null) {
      ++typeError;
    } else {

      head_1 = res[1] || null;
      head_2 = res[2] || null;
      data_varName = res[3] || null;
      if ((!head_1 && !head_2) || !data_varName) {
        ++typeError;
      }
    }

    if (typeError > 0) {
      throw new Error('<b-for> attr.b-script typeError');
    }

    this.$data_varName = data_varName;
    //-------------
    if (head_1) {
      // 變數複雜格式
      this._aboutHead_1(head_1);
    } else {
      // 變數簡單格式
      this._aboutHead_2(head_2);
    }
  }
  //----------------------------------------------------------------------------
  // 變數複雜格式
  _aboutHead_1(head) {
    let list_1 = head.split($reg_3);

    list_1.forEach(el => {
      debugger;

      let res = $reg_4.exec(el);

      let key;
      let value;
      if (res[3]) {
        key = res[3];
      } else {
        // key: value
        key = res[1];
        value = res[2];
      }
      //-------------
      if (key in this.$varMap) {
        value = (value == null) ? key : value;
        this.$varMap[key] = value;
      } else {
        throw new Error('...');
      }
    });

  }
  //----------------------------------------------------------------------------
  // 變數簡單格式
  _aboutHead_2(head) {
    let reg_2 = RegExp($reg_2, 'g');

    let i = 0;
    let res;
    while (res = reg_2.exec(head)) {
      debugger;

      if (res == null) {
        break;
      }
      if (i++ > 0) {
        // 預設只能有一個變數
        throw new Error('too much args');
      }

      let k = res[1];
      if (k in this.$varMap) {
        this.$varMap[k] = k;
      }
    }
  }
  //----------------------------------------------------------------------------
  // 整理 loop 的變數
  _aboutVars() {
    debugger;

    let args = [];
    for (let k in this.$varMap) {
      let value = this.$varMap[k];
      if (value == null) {
        continue;
      }

      let res;
      if (value == k) {
        res = k;
      } else {
        res = `${k}:${value}`;
      }
      args.push(res);
    }

    let res = args.join(',');

    return res;
  }
}

export { BForNode };
