import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';
import { template_varNames as temp_varNames, compileConfig } from '../compile_config.js';

// b-for
// (item, key, index)
class BForNode extends DomNode {

    name = 'BForNode';

    $scriptContent;
    $dataName;

    $varMap = {
        val: null,
        key: null
    };
    //----------------------------------------------------------------------------
    constructor(config) {
        super(config);

        this.$tagName = dom.tagName.toLowerCase();

        this._getAction();

        this._checkIsNextTo();
    }
    //----------------------------------------------------------------------------
    getSelfCommand() {
        const {
            var_root,
            var_parentNode,
            var_vnode,
            var_createVnode,
            var_sys,
            var_loopData
        } = temp_varNames;

        let lines = this.lines;

        lines.push(`(${var_sys}.getLoopData(${this.$dataName}).forEach(($$$item, index)=>{`);

        lines.push(`let item = $$$item.item;`);

        lines.push(`let key = $$$item.key;`);

        lines.push('});')
    }
    //----------------------------------------------------------------------------
    _getAction() {
        let dom = this.dom;

        if (!dom.hasAttribute('b-script')) {
            throw new Error();
        }
        let action = dom.getAttribute('b-script');
    }
    //----------------------------------------------------------------------------

}

export { BForNode };
