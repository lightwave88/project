import $GM from '../../g_module.js';
import { domNode_classList, varnames, printSpace } from './index.js';

const {DomNode} = domNode_classList;

class BSlotNode extends DomNode {

  slotName;

  // 變數對應
  varsMap = {};
  //----------------------------------------------------------------------------
  constructor(config) {
    super(config);
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {
    this._getVarsMap();
  }
  //----------------------------------------------------------------------------
  _getVarsMap() {
    let dom = this.dom;

    if (!dom.hasAttribute('b-action')) {
      return;
    }
    let action = dom.getAttribute('b-action');
  }
  //----------------------------------------------------------------------------
}

export { BSlotNode };