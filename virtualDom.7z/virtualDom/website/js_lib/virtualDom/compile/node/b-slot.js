import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';
import { domNode_classList, temp_varnames, printSpace } from './index.js';


// 轉換成 <div>
class BSlotNode extends DomNode {

  $scriptContent;

  // 變數對應
  $args = '';

  $reg_1 = /^\{([^]*)\}$/;
  $reg_2 = /\s*\:\s*/;

  $attr_id;
  //----------------------------------------------------------------------------
  constructor(config) {
    super(config);

    let dom = this.dom;

    if (!dom.hasAttribute('id')) {
      throw new Error('...');
    }
    this.$attr_id = dom.getAttribute('id');

    if (dom.hasAttribute('b-script')) {
      this.$scriptContent = dom.getAttribute('b-script').trim();
    }

    if (this.$scriptContent.length != 0) {
      if (!this.$reg_1.exec(script)) {
        throw new Error(`<b-slot> attr.b-script(${script}) type error`);
      }
      this.$args = this.$scriptContent;
    }
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
      var_sys,
    } = temp_varnames;

    let lines = [];

    this.isFirstChild(lines);

    let tagName = 'div';
    let dom_nodeName = 'div';

    // createVnode
    lines.push(`${var_vnode} = ${var_createVnode}("${dom_nodeName}", ${tagName}, ${var_parentNode});`);

    lines.push(`${var_vnode}.setId("${this.$attr_id}")`);

    let command = `${var_sys}.callSlot(${this.$attr_id}, ${this.$args})`;
    command = `${var_parentNode}.append(${command});\n`;

    lines.push(command);

    let res = lines.join('\n');

    return res;
  }
  //----------------------------------------------------------------------------

}

export { BSlotNode };
