import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';
import { domNode_classList, temp_varnames, printSpace } from './index.js';

class BSlotNode extends DomNode {

  $slotName;
  $scriptContent;

  // 變數對應
  $args = '';

  $reg_1 = /^\{([^]*)\}$/;
  $reg_2 = /\s*\:\s*/


  //----------------------------------------------------------------------------
  constructor(config) {
    super(config);

    let dom = this.dom;

    if (dom.hasAttribute('name')) {
      this.$slotName = dom.getAttribute('name').trim();
    }

    if (dom.hasAttribute('b-script')) {
      this.$scriptContent = dom.getAttribute('b-script').trim();
    }

    if (this.$scriptContent.length != 0) {

      if (!this.$reg_1.exec(script)) {
        throw new Error(`<b-slot> attr.b-script(${script}) type error`);
      }
      this.$args = this.$scriptContent;
    }
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
      var_sys,
    } = temp_varnames;

    let lines = [];

    this.isFirstChild(lines);

    let command = `${var_sys}.callSlot(${this.$slotName}, ${this.$args})`;
    command = `${var_parentNode}.append(${command});\n`;
  }
  //----------------------------------------------------------------------------

}

export { BSlotNode };
