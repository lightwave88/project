import $GM from '../../g_module.js';
import { DomNode } from './domNode.js';
import { template_varNames as temp_varNames, compileConfig } from '../compile_config.js';


// 轉換成 <div>
class BSlotNode extends DomNode {

  name = 'BSlotNode';
  $scriptContent;

  // 變數對應
  $args = '';

  $reg_1 = /^\{([^]*)\}$/;
  $reg_2 = /\s*\:\s*/;

  slotID;
  slotName;
  //----------------------------------------------------------------------------
  constructor(config) {
    super(config);

    let dom = this.dom;

    if (!dom.hasAttribute('name')) {
      // 必須要有 id 方便未來的事件綁定
      throw new Error('<b-slot>...attr.name...');
    }
    this.slotName = dom.getAttribute('name');

    // 從管理者哪裏得到一個 id
    this.slotID = this.compile.getSlotID();

    if (dom.hasAttribute('b-script')) {
      // 要傳遞的 data
      this.$scriptContent = dom.getAttribute('b-script').trim();
    }

    if (this.$scriptContent.length != 0) {
      // 驗證 b-script 的內容
      if (!this.$reg_1.exec(script)) {
        throw new Error(`<b-slot> attr.b-script(${script}) type error`);
      }
      this.$args = this.$scriptContent;
    }

    this.parent.addSlotChildID(this.slotID);
  }
  //----------------------------------------------------------------------------
  static getInstance(config) {
    return new BSlotNode(config);
  }
  //----------------------------------------------------------------------------
  getSelfCommand() {

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
      var_sys,
    } = temp_varNames;

    let lines = [];

    // let tagName = 'div';
    // let dom_nodeName = 'div';

    // createVnode
    // lines.push(`${var_vnode} = ${var_createVnode}("${dom_nodeName}", ${tagName}, ${var_parentNode});`);

    // lines.push(`${var_vnode}.setId("${this.$attr_id}")`);

    let command = `${var_sys}.callSlot(${this.slotID}, ${this.slotName}, ${this.$args})`;
    command = `${var_parentNode}.append(${command});`;

    lines.push(command);

    lines = lines.map(line => {
      return (this._space() + line);
    });

    let res = lines.join('\n');

    return res;
  }
  //----------------------------------------------------------------------------

}

export { BSlotNode };
