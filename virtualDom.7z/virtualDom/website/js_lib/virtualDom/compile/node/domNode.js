import $GM from '../../g_module.js';

// {{...}}
const $reg_1 = /\{\{([^}]*)\}\}/;
// ...{{...}}
const $reg_2 = /([^]*?)\{\{([^}]*)\}\}/;

const $reg_3 = /\btrue\b/i;

let $UID = 0;

class DomNode {
  uid;
  name = 'DomNode';
  level = 0;
  dom;
  parent;
  childs = [];

  // 排序
  index;

  nodeName;
  tagName;

  // 命令內容
  // 由 childs 上傳
  commandContent = [];

  // 外部的編譯程式
  compile;
  //------------------
  keep;
  keepAll;
  parentIsKeepAll = false;
  //------------------
  // domTree 重要結構特性
  isStatic;

  // 包含那些 <b-slot>
  childSlots;

  // <b-for><b-if><b-if-else><b-else>
  isEmpty = false;
  //----------------------------------------------------------------------------
  constructor(config = {}) {
    this.uid = $UID++;

    let { dom, parent, isStatic, nodeName, compile } = config;

    this.dom = dom;
    this.nodeName = nodeName;
    this.isStatic = (isStatic == null ? true : isStatic);
    this.compile = compile;

    if (parent != null) {
      // debugger;
      parent.append(this);
    }

    if (dom.tagName == null) {
      return;
    } else {
      this.tagName = dom.tagName.toLowerCase();
    }

    this._checkAttrInfo();
  }
  //----------------------------------------------------------------------------
  append(child, index) {

    const childs = this.childs;

    if (index == null) {
      index = childs.length;
      childs.push(child);
      child.index = index;
    } else {
      childs.splice(index, 0, child);

      // 必須更新插入點後的排序
      for (var i = index; i < childs.length; i++) {
        childs[i].index = i;
      }
    }

    child._inheritParent(this);
  }
  //----------------------------------------------------------------------------
  // <b-if> 會用到
  removeChild(node, index) {

    const childs = this.childs;
    if (node != null) {
      index = childs.findIndex((item) => {
        node.isEqual(item);
      });
    }

    if (index < 0 || index == null) {
      return;
    }

    let removes = childs.splice(index, 1);

    removes.forEach((it) => {
      it.level = null;
      it.parent = null;
      it.isStatic = true;
    });

    // 必須更新插入點後的排序
    for (var i = index; i < childs.length; i++) {
      let node = childs[i];
      node.index = i;
    }
  }
  //----------------------------------------------------------------------------
  // API
  callParent() {
    // debugger;
    if (this.parent == null) {
      return;
    }
    // 檢查 no static 的區塊
    // this.parent.checkCommandArea();
    //------------------
    // 不同種類標籤必須實作
    let res = this.getSelfCommand();

    this.parent.callByChild(res, this.index);
  }
  //----------------------------------------------------------------------------
  // 列印命令內容
  callByChild(text, index) {
    if (this.commandContent == null) {
      this.commandContent = new Array(this.childs.length);
    }
    this.commandContent[index] = text;
  }
  //----------------------------------------------------------------------------
  // 取得命令內容
  // override
  getSelfCommand() {
    throw new Error('need override _getSelfCommand()');
  }
  //----------------------------------------------------------------------------
  setStatic(value) {
    if (this.isStatic === false) {
      return;
    }
    this.isStatic = value;
  }
  //----------------------------------------------------------------------------
  // 若 child 是 <b-slot> 會被呼叫
  addSlotChildID(id) {
    if(this.childSlots == null){
      this.childSlots = [];
    }
    this.childSlots.push(id);
  }
  //----------------------------------------------------------------------------
  // 繼承 parent 某些資訊
  _inheritParent(parent) {

    this.parent = parent;

    if (parent.isStatic == false) {
      this.isStatic = false;
    }

    this.level = this.parent.level + 1;

    if(parent.keepAll != null || parent.parentIsKeepAll){
      this.parentIsKeepAll = true;
    }
  }
  //----------------------------------------------------------------------------
  // 清理不要的資料
  clear() {

    this.childs.length = 0;
    this.childs = null;

    if (Array.isArray(this.commandContent)) {
      this.commandContent.length = 0;
      this.commandContent = null;
    }

    this.isStatic = null;
  }
  //----------------------------------------------------------------------------
  // text 有 {{}}
  // attr 是否由 data 控制
  static _ss(content, attr = null) {

    if (attr != null) {
      // 前後空白對 attr 無意義
      content = content.trim();
    }

    let list = [];
    const reg_1 = RegExp($reg_2, 'g');

    content = content.replace(reg_1, (m, g1, g2) => {
      if (g1.length) {
        list.push(JSON.stringify(g1));
      }
      if (g2.length) {
        list.push(g2);
      }
      return '';
    });
    //------------------
    if (content.length) {
      list.push(JSON.stringify(content));
    }
    // 以變數形態輸出
    return list.join(',');
  }

  _ss(content, attr = null){
    return DomNode._ss(content, attr);
  }
  //----------------------------------------------------------------------------
  // 是否包含 {{...}}
  _hasCompute(text) {
    return ($reg_1.test(text));
  }
  //----------------------------------------------------------------------------
  _checkAttrInfo() {
    const dom = this.dom;

    if (typeof dom.getAttribute != 'function') {
      return;
    }

    if (dom.hasAttribute('b-static')) {
      let value = dom.getAttribute('b-static');
      if (this._getAttrBooleanValue(value)) {
        this.isStatic = true;
      }
      dom.removeAttribute('b-static');
    }
    //------------------
    /*
    if (dom.hasAttribute('b-keep')) {
      if (this.isStatic) {
        // keep 只對動態節點有用
        throw new Error(`can't be static dom`);
      }

      if(this.parentIsKeepAll){
        throw new Error('');
      }
      let name = dom.getAttribute('b-keep').trim();
      this.keep = name;
      dom.removeAttribute('b-keep');

      // 重複名字檢查
      this.compile.addKeep(this.keep);
    }
    //------------------
    if (dom.hasAttribute('b-keepAll')) {
      if (this.isStatic) {
        // keep 只對動態節點有用
        throw new Error(`can't be static dom`);
      }

      if(this.parentIsKeepAll){
        // keepAll -不能套嵌
        throw new Error('');
      }

      let name = dom.getAttribute('b-keepAll').trim();
      this.keepAll = name;
      dom.removeAttribute('b-keepAll');

      // 重複名字檢查
      this.compile.addKeepAll(this.keepAll);
    }
    */
  }
  //----------------------------------------------------------------------------
  // format 用
  _space(count = 0, _level = null) {

    const sysConfig = $GM.get('sysConfig');
    const { formatSpace, format } = sysConfig;

    let level = (_level == null) ? this.level : _level;

    let r = '';
    if (!format) {
      return r;
    }
    let c = (level + count) * formatSpace;
    let i = 0;
    while (i++ < c) {
      r += ' ';
    }
    return r;
  }
  //----------------------------------------------------------------------------
  isEqual(node) {
    if (!(node instanceof DomNode)) {
      return false;
    }
    if (this.uid !== node.uid) {
      return false;
    }

    return true;
  }
  //----------------------------------------------------------------------------
  mergeChilds(commandContents, lines) {

    const sysConfig = $GM.get('sysConfig');

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = sysConfig.tempSysVarName;

    let isEmptyNode = this.isEmpty;

    let space = this.childs[0]._space();

    commandContents.forEach((l, i) => {
      if (i == 0 && !isEmptyNode) {
        let res = `${space}const ${var_parentNode} = ${var_vnode};\n`;
        lines.push(res);
      }

      lines.push(l);
    });
  }
  //----------------------------------------------------------------------------
  _getAttrBooleanValue(val) {
    return $reg_3.test(val);
  }

}

export { DomNode };
