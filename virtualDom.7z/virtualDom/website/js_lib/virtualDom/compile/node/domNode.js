'use strict';

import $GM from '../../g_module.js';

let $UID = 0;

class DomNode {
  uid;
  name = 'DomNode';
  level = 0;
  dom;
  parent;
  childs = [];

  // 排序
  index;

  nodeName;
  tagName;

  // childs 的命令內容
  // 由 childs 上傳
  // []
  childContents;

  // 外部的編譯程式
  compile;
  //------------------
  keep;
  keepAll;
  parentIsKeepAll = false;
  //------------------
  // domTree 重要結構特性
  isStatic;

  // <b-for><b-if><b-if-else><b-else>
  // isEmpty = false;

  isPrint = true;
  //----------------------------------------------------------------------------
  constructor(config = {}) {
    this.uid = $UID++;

    let { dom, parent, isStatic, nodeName, compile } = config;

    this.dom = dom;
    this.nodeName = nodeName;
    this.isStatic = (isStatic == null ? true : isStatic);
    this.compile = compile;

    if (parent != null) {
      // debugger;
      parent.append(this);
    }

    if (dom.tagName == null) {
      return;
    } else {
      this.tagName = dom.tagName.toLowerCase();
    }

    this._checkAttrInfo();
  }
  //----------------------------------------------------------------------------
  append(child, index) {

    const childs = this.childs;

    if (index == null) {
      index = childs.length;
      childs.push(child);
      child.index = index;
    } else {
      childs.splice(index, 0, child);

      // 必須更新插入點後的排序
      for (var i = index; i < childs.length; i++) {
        childs[i].index = i;
      }
    }

    child._inheritParent(this);
  }
  //----------------------------------------------------------------------------
  // <b-if> 會用到
  // 移除空的文字節點
  removeChild(node, index) {

    const childs = this.childs;
    if (node != null) {
      index = childs.findIndex((item) => {
        return node.isEqual(item);
      });
    }

    if (index < 0 || index == null) {
      return;
    }

    let removes = childs.splice(index, 1);

    removes.forEach((it) => {
      it.level = null;
      it.parent = null;
      it.isStatic = true;
    });

    // 必須更新插入點後的排序
    for (var i = index; i < childs.length; i++) {
      let node = childs[i];
      node.index = i;
    }
  }
  //----------------------------------------------------------------------------
  // API
  callParent() {
    // debugger;
    if (this.parent == null) {
      return;
    }
    // 檢查 no static 的區塊
    // this.parent.checkCommandArea();
    //------------------
    // 不同種類標籤必須實作
    let res = this.getSelfCommand() || '';

    this.parent.callByChild(res, this.index);
  }
  //----------------------------------------------------------------------------
  // 列印命令內容
  callByChild(text, index) {
    if (this.childContents == null) {
      this.childContents = new Array(this.childs.length);
    }
    this.childContents[index] = text;
  }
  //----------------------------------------------------------------------------
  // 取得命令內容
  // override
  getSelfCommand() {
    throw new Error('need override _getSelfCommand()');
  }
  //----------------------------------------------------------------------------
  setStatic(value) {
    if (this.isStatic === false) {
      return;
    }
    this.isStatic = value;
  }
  //----------------------------------------------------------------------------
  // 繼承 parent 某些資訊
  _inheritParent(parent) {

    this.parent = parent;

    if (parent.isStatic == false) {
      this.isStatic = false;
    }

    this.level = this.parent.level + 1;

    // 比較奇特的規則
    if (parent.keepAll != null || parent.parentIsKeepAll != null) {
      this.parentIsKeepAll = parent.parentIsKeepAll || parent.keepAll;
    }
  }
  //----------------------------------------------------------------------------
  // 清理不要的資料
  clear() {

    this.childs.length = 0;
    this.childs = null;

    if (Array.isArray(this.childContents)) {
      this.childContents.length = 0;
      this.childContents = null;
    }

    this.isStatic = null;
  }
  //----------------------------------------------------------------------------
  _checkAttrInfo() {
    const dom = this.dom;

    if (typeof dom.getAttribute != 'function') {
      return;
    }

    if (dom.hasAttribute('b-static')) {

      if (this.isStatic == true) {
        throw new Error('只能用在動態結構裏');
      }

      this.isStatic = true;

      dom.removeAttribute('b-static');
    }

  }
  //----------------------------------------------------------------------------
  // format 用
  _space(count = 0, _level = null) {

    const sysConfig = $GM.get('sysConfig');
    const { formatSpace, format } = sysConfig;

    let level = (_level == null) ? this.level : _level;

    let r = '';
    if (!format) {
      return r;
    }
    let c = (level + count) * formatSpace;
    let i = 0;
    while (i++ < c) {
      r += ' ';
    }
    return r;
  }
  //----------------------------------------------------------------------------
  isEqual(node) {
    if (!(node instanceof DomNode)) {
      return false;
    }
    if (this.uid !== node.uid) {
      return false;
    }

    return true;
  }
  //----------------------------------------------------------------------------
  // 輸出命令用
  mergeChilds(childContentss = [], isEmptyNode = false) {

    const sysConfig = $GM.get('sysConfig');

    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = sysConfig.tempSysVarName;

    let space = this.childs[0]._space();

    let lines = [];

    if (!isEmptyNode) {
      lines.push(`${space}const ${var_parentNode} = ${var_vnode};\n`);
    }

    childContentss.forEach((l, i) => {
      lines.push(l);
    });
    return lines;
  }
  //----------------------------------------------------------------------------

}

export { DomNode };
