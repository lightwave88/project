import $GM from '../../g_module.js';
import { template_varNames as temp_varNames, compileConfig } from '../compile_config.js';

// {{...}}
const $reg_2 = /\{\{([^}]*)\}\}/;
// ...{{...}}
const $reg_2a = /([^]*?)\{\{([^}]*)\}\}/;

let $UID = 0;

class DomNode {
  //uid;
  name = 'DomNode';
  level = 0;
  dom;
  parent;
  childs = [];

  // 排序
  index;

  nodeName;
  tagName;

  // 命令內容
  // 由 childs 上傳
  commandContent = [];

  // 外部的編譯程式
  compile;

  isKeep;
  isKeepAll;
  isStatic;

  // [0,1,2]
  // 0: 不是空節點
  // 1: 是空節點，但帶有命令
  // 2: 指示性空節點
  isEmpty;
  //----------------------------------------------------------------------------
  constructor(config = {}) {
    //this.uid = $UID++;
    let { dom, parent, isStatic, nodeName, compile } = config;

    this.dom = dom;
    this.nodeName = nodeName;
    this.isStatic = (isStatic == null ? true : isStatic);
    this.compile = compile;

    if (parent != null) {
      // debugger;
      parent.append(this);
    }

    if (dom.tagName == null) {
      return;
    } else {
      this.tagName = dom.tagName.toLowerCase();
    }

    this._checkAttrInfo();
  }
  //----------------------------------------------------------------------------
  append(child, index) {

    const childs = this.childs;

    if (index == null) {
      index = childs.length;
      childs.push(child);
      child.index = index;

    } else {
      childs.splice(index, 0, child);

      // 必須更新插入點後的排序
      for (var i = index; i < childs.length; i++) {
        childs[i].index = i;
      }
    }

    child._inheritParentInfo(this);
  }
  //----------------------------------------------------------------------------
  // API
  callParent() {
    // debugger;
    if (this.parent == null) {
      return;
    }
    // 檢查 no static 的區塊
    // this.parent.checkCommandArea();
    //------------------
    // 不同種類標籤必須實作
    let res = this.getSelfCommand();

    this.parent.callByChild(res, this.index);
  }
  //----------------------------------------------------------------------------
  callByChild(text, index) {
    if (this.commandContent == null) {
      this.commandContent = new Array(this.childs.length);
    }
    this.commandContent[index] = text;
  }
  //----------------------------------------------------------------------------
  // 取得命令內容
  // override
  getSelfCommand() {
    throw new Error('need override _getSelfCommand()');
  }
  //----------------------------------------------------------------------------
  setStatic(value) {
    if (this.isStatic === false) {
      return;
    }
    this.isStatic = value;
  }
  //----------------------------------------------------------------------------
  // 繼承 parent 某些資訊
  _inheritParentInfo(parent) {

    this.parent = parent;

    if (parent.isStatic == false) {
      this.isStatic = false;
    }

    this.level = this.parent.level + 1;
  }
  //----------------------------------------------------------------------------
  // 清理不要的資料
  clear() {

    this.childs.length = 0;
    this.childs = null;

    if (Array.isArray(this.commandContent)) {
      this.commandContent.length = 0;
      this.commandContent = null;
    }

    this.isStatic = null;
  }
  //----------------------------------------------------------------------------
  // text 有 {{}}
  // attr 是否由 data 控制
  _ss(content, attr = null) {

    if (attr != null) {
      // 前後空白對 attr 無意義
      content = content.trim();
    }

    let list = [];
    const reg_1 = RegExp($reg_2a, 'g');

    content = content.replace(reg_1, (m, g1, g2) => {
      if (g1.length) {
        list.push(JSON.stringify(g1));
      }
      if (g2.length) {
        list.push(g2);
      }
      return '';
    });
    //------------------
    if (content.length) {
      list.push(JSON.stringify(content));
    }
    // 以變數形態輸出
    return list.join(',');
  }
  //----------------------------------------------------------------------------
  // 是否包含 {{...}}
  _hasCompute(text) {
    return ($reg_2.test(text));
  }
  //----------------------------------------------------------------------------
  _checkAttrInfo() {
    const dom = this.dom;

    if (typeof dom.getAttribute != 'function') {
      return;
    }

    if (dom.hasAttribute('b-static')) {
      let value = dom.getAttribute('b-static').trim();
      if (/^true/.test(value)) {
        this.isStatic = true;
      }
      dom.removeAttribute('b-static');
    }

    if (dom.hasAttribute('b-keep')) {
      let value = dom.getAttribute('b-keep').trim();
      // this.compile.addKeep(value);
      this.isKeep = value;
      dom.removeAttribute('b-keep');
    }

    if (dom.hasAttribute('b-keepAll')) {
      let value = dom.getAttribute('b-keepAll').trim();
      // this.compile.addKeepAll(value);
      this.isKeepAll = value;
      dom.removeAttribute('b-keepAll');
    }
  }
  //----------------------------------------------------------------------------
  isFirstChild(lines) {
    const {
      var_root,
      var_parentNode,
      var_vnode,
      var_createVnode,
    } = temp_varNames;

    if (this.index == 0) {
      lines.push(`const ${var_parentNode} = ${var_vnode};\n`);
    }
  }
  //----------------------------------------------------------------------------
  // format 用
  _space(count = 0, _level = null) {

    const {spaceNum, format} = compileConfig;

    let level = (_level == null) ? this.level : _level;

    let r = '';
    if (!format) {
      return r;
    }
    let c = (level + count) * spaceNum;
    let i = 0;
    while (i++ < c) {
      r += ' ';
    }
    return r;
  }

}

export { DomNode };
