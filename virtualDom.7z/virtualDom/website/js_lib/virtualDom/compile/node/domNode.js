import $GM from '../../g_module.js';
import { temp_varnames } from './index.js';

// {{...}}
const $reg_2 = /\{\{([^}]*)\}\}/;
// ...{{...}}
const $reg_2a = /([^]*?)\{\{([^}]*)\}\}/;

let $UID = 0;

class DomNode {
  //uid;
  name = 'DomNode';
  level = 0;
  dom;
  parent;
  childs = [];

  // 排序
  index;

  nodeName;
  tagName;

  // 命令內容
  // 由 childs 上傳
  commandContent;

  isKeep;
  isKeepAll;
  isStatic;

  // [0,1,2]
  // 0: 不是空節點
  // 1: 是空節點，但帶有命令
  // 2: 指示性空節點
  isEmpty;
  //----------------------------------------------------------------------------
  constructor(config = {}) {
    //this.uid = $UID++;
    let { dom, parent, isStatic , nodeName} = config;

    this.dom = dom;
    this.nodeName = nodeName;

    if (parent != null) {
      parent.append(this);
    }

    if (dom.tagName == null) {
      return;
    }
    this.tagName = dom.tagName.toLowerCase();

    try {
      if (dom.hasAttribute('b-keep') && dom.getAttribute('b-keep')) {
        this.isKeep = dom.getAttribute('b-keep');
      }

      if (dom.hasAttribute('b-keepAll') && dom.getAttribute('b-keepAll')) {
        this.isKeepAll = dom.getAttribute('b-keepAll');
      }
    } catch (e) {
      console.log(e);
    }
  }
  //----------------------------------------------------------------------------
  append(child, index) {

    const childs = this.childs;

    if (index == null) {
      index = childs.length;
      childs.push(child);
      child.index = index;

    } else {
      childs.splice(index, 0, child);

      // 必須更新插入點後的排序
      for (var i = index; i < childs.length; i++) {
        childs[i].index = i;
      }
    }

    child._inheritParentInfo(this);
  }
  //----------------------------------------------------------------------------
  replaceChild(index, child) {
    let old_child = this.childs[index];
    old_child.parent = null;

    this.childs[index] = child;
    child.index = index;
    child._inheritParentInfo(this);
  }
  //----------------------------------------------------------------------------
  // 轉換子節點
  // 針對空 tag
  switchChildParent() {

    let index = this.index;
    let parent = this.parent;

    this.childs.forEach((c, i) => {
      if (i == 0) {
        parent.replaceChild(index, c);
      } else {
        parent.append(c, index + i);
      }
    });

    this.childs.length = 0;
  }
  //----------------------------------------------------------------------------
  // API
  callParent() {
    // debugger;
    if (this.parent == null) {
      return;
    }
    // 檢查 no static 的區塊
    // this.parent.checkCommandArea();
    //------------------
    // 不同種類標籤必須實作
    let res = this.getSelfCommand();

    this.parent.callByChild(res, this.index);
  }
  //----------------------------------------------------------------------------
  callByChild(text, index) {
    if (this.commandContent == null) {
      this.commandContent = new Array(this.childs.length);
    }
    this.commandContent[index] = text;
  }
  //----------------------------------------------------------------------------
  // 取得命令內容
  // override
  getSelfCommand() {
    throw new Error('need override _getSelfCommand()');
  }
  //----------------------------------------------------------------------------

  // 繼承 parent 某些資訊
  _inheritParentInfo(parent) {

    this.parent = parent;

    if (parent.isStatic == false) {
      this.isStatic = false;
    }

    this.level = this.parent.level + 1;
  }
  //----------------------------------------------------------------------------
  // 清理不要的資料
  clear() {

    this.childs.length = 0;
    this.childs = null;

    if (Array.isArray(this.commandContent)) {
      this.commandContent.length = 0;
      this.commandContent = null;
    }

    this.isStatic = null;
  }
  //----------------------------------------------------------------------------
  // text 有 {{}}
  // attr 是否由 data 控制 
  _ss(content, attr = null) {

    if (attr != null) {
      // 前後空白對 attr 無意義
      content = content.trim();
    }

    let list = [];
    const reg_1 = RegExp($reg_2a, 'g');

    content = content.replace(reg_1, (m, g1, g2) => {
      if (g1.length) {
        list.push(JSON.stringify(g1));
      }
      if (g2.length) {
        list.push(g2);
      }
      return '';
    });
    //------------------    
    if (content.length) {
      list.push(JSON.stringify(content));
    }
    // 以變數形態輸出
    return list.join(',');
  }
  //----------------------------------------------------------------------------
  _hasCompute(text) {
    return ($reg_2.test(text));
  }
  //----------------------------------------------------------------------------

}

export { DomNode };