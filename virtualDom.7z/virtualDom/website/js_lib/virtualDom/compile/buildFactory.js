

class BuildFactory{

  constructor(){

  }
  
  //----------------------------------------------------------------------------
  
  //-------------------------------------------
  // 對 render 函式進一步加工
  _buildRenderFun_2(fun_text) {

    debugger;

    const null_fun = function (...args) {
      return null;
    };

    if (fun_text == null) {
      return null_fun;
    }
    //------------------
    // about modules   

    const variables = getTemplateVariables();
    let variableText = '';

    for (let key in variables) {
      let k = JSON.stringify(key);
      variableText += `const ${key} = variables[${k}]`;
      variableText += `delete `
    }


    // render 函式裏面要用的模組
    const modules = getTemplateModuler();
    let moduleText = '';


    for (let key in modules) {
      let k = JSON.stringify(key);
      moduleText += `const ${key} = modules[${k}];\n`;
      moduleText += `delete modules[${k}];\n`;
    }

    moduleText += 'modules = null;\n';
    //------------------
    let render_1;

    const renderContent = `
debugger;

const $$$slots = slots;      
const $$$compute = compute;
const $data = data;

compute = null;
slots = null;
data = null;

${moduleText};

//------------------
${fun_text}
    `;

    try {
      render_1 = new Function('modules', 'funs', 'data', 'variables', renderContent);
    } catch (error) {
      console.log('build factory error(%s)', error);
      return null;
    }
    //------------------

    // 渲染函式
    // 渲染函式
    // 渲染函式
    const render = function (data, context, variables) {

      context = context || null;
      data = Object.assign({}, data);
      slots = Object.assign({}, slots);

      let cloneModule = Object.assign({}, modules);

      //-------------

      // vnode_factory
      let vnode = render_1.apply(context, [cloneModule, data, variables]);
      return (vnode || null);
    };

    console.log(renderContent);

    return {
      render,
      renderContent,
      slots: (this.slots),
    };
  }

}

function getCreateFun() {
  const Vnode = $GM.get('Vnode');

  return function C(nodeName, tagName, parent) {
    return new Vnode(nodeName, tagName, parent);
  }
}
//------------------------------------------------------------------------------
// 釋放記憶體
function domNodesClear(list = []) {

  if (!list.length) {
    return;
  }
  const $util = $GM.get('util');

  $util.nextStep(function () {
    while (list.length > 0) {
      let node = list.pop();
      node.clear();
    }
  });
}
//------------------------------------------------------------------------------
// 構建模板內部重要的函式
function getTemplateModuler(module) {

  module = Object.assign({
    '$$$getData': null,
    '$$$setData': null,
    '$$$getCompute': null,
    // 文字過濾器
    '$$$getFilter': null,
    '$$$getSlot': null,
  }, module);

  // 變數名稱
  let createVarName = DomNode.get_varName('createVarName');
  const $C = getCreateFun();
  modules[createVarName] = $C;

  //------------------
  module['$$$getData'] = function (data, path) {
    path = path.replace(/\[['"]/g, '.');
    path = path.replace(/'"]/g, '');

    path = path.split('.');
    path = path.filter(d => {
      if (!d.length) {
        return false;
      }
      return true;
    });

    let res = data;
    let i = 0;
    while (i < path.length) {
      let j = i++;
      let key = path[j];
      try {
        res = res[key];
      } catch (error) {
        let er = path.slice(0, j);
        throw new Error(`keyList(${er.join('.')}) getData error`);
      }
    }
    return res;
  };
  //------------------
  module['$$$setData'] = function (data, path, value) {
    path = path.replace(/\[['"]/g, '.');
    path = path.replace(/'"]/g, '');

    path = path.split('.');
    path = path.filter(d => {
      if (!d.length) {
        return false;
      }
      return true;
    });

    let res = data;
    let key;
    while (path.length) {
      key = path.shift();
      if (!path.length) {
        break;
      }
      res = res[key];
    } // endWhile

    if (key == null) {
      throw new Error('no key');
    }
    res[key] = value;
  };
  //------------------
  module['$$$getCompute'] = function (computes = {}, name) {
    if (!(name in computes)) {
      throw new Error(`no this compute(${name})`);
    }
    return computes[name];
  };
  //------------------
  module['$$$callFilter'] = function (filters = {}, text, ...list) {

    list.forEach(name => {
      let filter;
      if (name in filters) {
        filter = filters[name];
      }
      if (filter == null) {
        throw new Error(`no this filter(${name})`);
      }
      text = filter(text);
    });
    return text;
  }
  //------------------

  module['$$$getSlot'] = function (slots, name) {
    let fn = function () {
      return [];
    }
    if (name in slots) {
      fn = slots[name];
    }
    return fn;
  }
  return module;
}
//------------------------------------------------------------------------------
// template 內部給使用者的 API
function getTemplateFuns() {
  let funs = {
    '$getData': null,
    '$setData': null,
    '$compute': null,
    '$filter': null,
  };

  funs['$getData'] = `$$$getData($data, path);\n`;
  funs['$setData'] = `$$$setData($data, path, value);\n`;
  funs['$compute'] = `
      return $$$getCompute(t['$$$computes'],k);
    }
  });\n`;

  funs['$filter'] = `$$$callFilter($$$filter, text);\n`;
}
//------------------------------------------------------------------------------
// template 內部重要隱藏變數
function getTemplateVariables() {
  let variables = {
    '$$$slots': `variables['slots'];\n`,
    '$$$computes': `variables['computes'];\n`,
    '$$$filters': `variables['filters'];\n`,
  };
};