import {
  TemplateInnerSys
} from './templateInnerSys.js';

// 組織 template(vnode_factory)
class BuildFactory {
  $args;

  constructor() {

  }
  //----------------------------------------------------------------------------
  build(context) {
    let content =this._build_1(content);

    let fun = this._build_2(content);

    // 供使用者操作
    let tempHandle = new TemplateHandle(fun);

    return tempHandle;
  }
  //----------------------------------------------------------------------------
  _build_1(fun_text) {

    this.$args = ['data', 'createVnode', '$system', 'compute'];

    const fun_content = `
debugger;

const $_C = createVnode;
const $_SYS = $system;
const $compute = compute;
const $data = data;
data = null;
$system = null;
compute = null;
createVnode = null;

debugger;
//------------------
${fun_text}`;

    return fun_content;
  }

  //----------------------------------------------------------------------------
  _build_2(content) {
    let args = this.$args

    let fun;
    try {
      fun = new Function(args[0], args[1], args[2], args[3], content);
    } catch (error) {
      console.log('build vnode_factory error')
      throw error;
    }
    return fun;
  }
  //----------------------------------------------------------------------------
}
export {
  BuildFactory
};


//==============================================================================

class TemplateHandle {
  $fun;
  $slotTemplate = {};
  //----------------------------------------------------------------------------
  constructor(fun, config = {}) {
    this.$fun = fun;
    let {
      $slotTemplate
    } = config;

    if (slotTemplate != null) {
      Object.assign(this.$slotTemplate, slotTemplate);
    }
  }
  //----------------------------------------------------------------------------
  render(data, view) {
    debugger;

    let args = {
      data,
      view
    };

    // 收集 factory 內部要用的模組

    // 取得 vnode_factory 裏的 system
    const sys = new TemplateInnerSys(args);

    const $compute = sys.getComputeFun();

    const Vnode = $GM.get('Vnode');

    const $createVnode = Vnode.createVnode;

    // 把所有東西灌入工廠
    let vnode;

    try {
      debugger;
      vnode = this.$fun(data, $createVnode, sys, $compute);
    } catch (error) {
      console.log('render error')
      throw error;
    }

    return vnode;
  }
  //----------------------------------------------------------------------------
}
