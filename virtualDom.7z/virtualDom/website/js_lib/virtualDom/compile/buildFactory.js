
// 組織 template(vnode_factory) 
class BuildFactory {
  // render_fun
  $fun;

  // Set()
  $slots;

  // Set()
  $keeps;

  // Set()
  $keepAlls;
  //----------------------------------------------------------------------------
  constructor(fun, config = {}) {
    this.$fun = fun;
    let { slots, keeps, keepAlls } = config;

    if (slots != null) {
      this.$slots = slots;
    }

    if (keeps != null) {
      this.$keeps = keeps;
    }

    if (keepAlls != null) {
      this.$keepAlls = keepAlls;
    }
  }
  //----------------------------------------------------------------------------
  // API
  render(data, config = {}) {
    debugger;

    let { view, context } = config;

    let args = Object.assign({
      slots: null,
      keeps: null,
      keepAlls: null,
    }, config);

    // vnode_factory 裏的 system
    const sys = new TemplateInnerSys(args);

    const $compute = sys.getComputeFun();

    const Vnode = $GM.get('Vnode');

    const $createVnode = Vnode.createVnode;

    // 把所有東西灌入工廠
    let vnode;

    try {
      debugger;
      vnode = this.$fun(data, $createVnode, sys, $compute);
    } catch (error) {
      console.log('render error')
      throw error;
    }

    return vnode;
  }
  //----------------------------------------------------------------------------
  static build(config) {
    let { slots, content, keeps, keepAlls } = config;

    let args = BuildFactory._build_1(content);

    let fun = BuildFactory._build_2(args);

    const template = new BuildFactory(fun, config);

    return template;
  }
  //----------------------------------------------------------------------------

  static _build_1(fun_text) {

    const args = ['data', 'createVnode', '$system', 'compute'];

    const fun_content = `
debugger;

const $_C = createVnode;
const $_SYS = $system;
const $compute = compute;
const $data = data;
data = null;
$system = null;
compute = null;
createVnode = null;

debugger;
//------------------
${fun_text}`;

    return {
      content: fun_content,
      args
    };
  }

  //----------------------------------------------------------------------------
  _build_2(_args = {}) {

    let { content, args } = _args;
    let fun;
    try {
      fun = new Function(args[0], args[1], args[2], args[3], content);
    } catch (error) {
      console.log('build vnode_factory error')
      throw error;
    }
    return fun;
  }
  //----------------------------------------------------------------------------
}
export { BuildFactory };


// template 裏隱藏的 system
class TemplateInnerSys {

  $data = {};

  $view;

  $context;

  $slotsMap = {};

  // Set()
  $slotNameList = new Set();
  //--------------------------------------------------------------------------
  constructor(config = {}) {

    let { context, view, slots, keeps, keepAlls } = config;
    if (context != null) {
      this.$context = context;
    }

    if (view != null) {
      this.$view = view;
    }

    // 取得模板自帶訊息
  }
  //--------------------------------------------------------------------------
  setData(data = {}) {
    Object.assign(this.$data, data);
  }

  // 來自使用者設定
  setSlot(slots = {}) {
    Object.assign(this.$slotsMap, slots);
  }
  //--------------------------------------------------------------------------

  setSlotNameList(list) {
    list = Array.from(list);

    list.forEach((name) => {
      this.$slotName.add(name);
    });

  }
  //--------------------------------------------------------------------------
  // return vnodeList
  callSlot(name, args) {
    let vnodeList;

    if (this.$view != null) {
      vnodeList = this.$view.$$$callSlot(name, args);
    }

    vnodeList = (Array.isArray(vnodeList)) ? vnodeList : [];

    return vnodeList;
  }
  //--------------------------------------------------------------------------


  compute(name, args) {
    let value = null;
    if (this.$view != null) {
      value = this.$view.$$$callCompute(name, args);
    }
    return value;
  }

  getComputeFun() {
    return this.compute.bind(this);
  }
  //--------------------------------------------------------------------------
  getTemplateSelf() {

    if (true) {

    } else {

    }
  }
}


