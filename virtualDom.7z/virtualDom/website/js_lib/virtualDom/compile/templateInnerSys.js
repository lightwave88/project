'use strict';

import $GM from '../g_module.js';


// template 裏隱藏的 system
class TemplateInnerSys {

  $$$data;

  $factory;

  $view;
  $context;

  $keep = {};

  $keepAll = {};

  // 爲了 slotEvents 綁定
  $slotParents = new Set();

  $rootVnode;

  // 是否是套嵌在 <b-slot> 裏
  // { factory, slotId }
  $slotInfo = null;
  //----------------------------------------------------------------------------
  constructor(data, config = {}) {
    let { view, context, factory } = config;

    this.$$$data = data;

    this.$factory = factory;

    if (view != null) {
      this.$view = view;
      this.$context = view;
    } else {
      this.$context = context || null;
    }
  }
  //----------------------------------------------------------------------------
  get $$$rootFactory() {
    let rootFactory;

    if (this.$slotInfo) {
      rootFactory = this.$slotInfo.factory;
    } else {
      rootFactory = this.$factory;
    }
    return rootFactory;
  }
  //----------------------------------------------------------------------------
  setSlotInfo(slotInfo = {}) {
    this.$slotInfo = slotInfo;
  }
  //----------------------------------------------------------------------------
  getData() {
    return this.$$$data;
  }
  //----------------------------------------------------------------------------
  // 創建 vnode
  C(nodeName, tagName, parent) {
    const Vnode = $GM.get('Vnode');
    const vnode = Vnode.create(nodeName, tagName, parent, this);
    return vnode;
  }
  //----------------------------------------------------------------------------
  attrSS(attr, value) {
    const $attr = $GM.get('attr');
    return $attr.attrSS(attr, value);
  }
  //----------------------------------------------------------------------------
  // return vnodeList
  callSlot(id, slotName, args = {}) {
    debugger;

    if (this.$slotInfo != null) {
      // slot 模式不能套嵌呼叫 slot
      return null;
    }
    if (this.$view == null) {
      // 必須是在 view 模式
      return null;
    }
    //------------------
    const $Vnode = $GM.get('Vnode');

    // 執行，返回使用者給的資料
    // { render, events }
    let res = this.$view.$$$callSlot(id, slotName, args);

    if (res == null) {
      return null;
    }

    let { render, events } = res;

    let vnodeList = [];

    // rootList
    render = Array.isArray(render) ? render : [render];

    //------------------
    // 整理 vnode
    render.forEach(vnode => {
      if (!$Vnode.is_emptyNode(vnode)) {
        throw new Error('...');
      }
      let childs = vnode.removeAllChild();
      vnodeList = vnodeList.concat(childs);
    });

    return {
      id,
      render: vnodeList,
      events
    };
  }
  //----------------------------------------------------------------------------
  // call view.compute
  compute(name, ...args) {
    let value = null;
    if (this.$view != null) {
      value = this.$view.$$$callCompute(name, args);
    }
    return value;
  }

  getComputeFun() {
    return this.compute.bind(this);
  }
  //----------------------------------------------------------------------------
  // <b-for>
  renderList(data, cb) {
    const $util = $GM.get('util');

    let type = $util.getType(data).toLowerCase();
    let i = 0;

    switch (type) {
      case 'string':
        for (; i < data.length; i++) {
          let key = i++;
          let item = data.charAt(k);
          cb({
            item,
            key,
            index: key,
          });
        }
        break;
      case 'object':
        let keyList = Object.getOwnPropertyNames(data);
        keyList.forEach(function (key) {
          let index = i++;
          let item = data[key];
          cb({
            item,
            key,
            index,
          });
        });
        break;
      case 'array':
        for (; i < data.length; i++) {
          let key = i++;
          let item = data[k];
          cb({
            item,
            key,
            index: key,
          });
        }
        break;
      default:
        throw new TypeError(`no support this data.type(${type});`);
        break;
    }
  }
  //----------------------------------------------------------------------------
  // <b-if><b-if-else>
  booleanVal(value) {
    return value;
  }
  //----------------------------------------------------------------------------
  // callBy 模板
  // rname node.keep
  addKeep(node) {

    let keep = node.keep;
    let prefix = '';
    if (this.$slotInfo != null) {
      let { factory, slotId } = this.$slotInfo;
      prefix = factory.id + '|' + slotId + '|';
    }
    // rename
    node.keep = prefix + this.$factory.id + '|' + keep;

    this.$$$rootFactory.addKeep(node);
  }
  //----------------------------------------------------------------------------
  // callBy 模板
  addKeepAll(node) {
    let keepAll = node.keepAll;
    let prefix = '';
    if (this.$slotInfo != null) {
      let { factory, slotId } = this.$slotInfo;
      prefix = factory.id + '|' + slotId + '|';
    }
    // rename
    node.keepAll = prefix + this.$factory.id + '|' + keepAll;

    this.$$$rootFactory.addKeepAll(node);
  }
  //----------------------------------------------------------------------------
  // 綁定事件用
  registSlotParent(vnode) {

    if (this.$slotInfo != null) {
      return;
    }
    this.$factory.addSlotParent(vnode);
  }
  //----------------------------------------------------------------------------
  // callBy 模板
  setRootVnode(node) {
    this.$rootVnode = node;
  }
  // callBy compile
  getRootVnode() {
    return this.$rootVnode || null;
  }
  //----------------------------------------------------------------------------
  getFactory(){
    return this.$factory;
  }
  //----------------------------------------------------------------------------
  getSlotParents(){
    return Array.from(this.$slotParents);
  }
}
//==============================================================================


export { TemplateInnerSys };
