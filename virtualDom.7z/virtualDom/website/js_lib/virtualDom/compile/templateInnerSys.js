import $GM from '../g_module.js';


// template 裏隱藏的 system
class TemplateInnerSys {

  $$$data = {};

  $view;
  $context;

  $keep = {};

  $keepAll = {};

  $rootVnode;
  //----------------------------------------------------------------------------
  constructor(data, config = {}) {
    let { view, context } = config;

    this.$$$data = data;

    if (view != null) {
      this.$view = view;
      this.$context = view;
    } else if (context != null) {
      this.$context = context;
    }
  }
  //----------------------------------------------------------------------------
  get $data() {
    return this.$$$data[key];
  }

  set $data(v) {
    // 避免覆寫 data
  }
  //----------------------------------------------------------------------------
  // 創建 vnode
  C(nodeName, tagName, parent){
    const Vnode = $GM.get('Vnode');
    return Vnode.createVnode(nodeName, tagName, parent, this);
  }
  //----------------------------------------------------------------------------
  // return vnodeList
  callSlot(name, args) {
    let vnodeList;

    if (this.$view != null) {
      vnodeList = this.$view.$$$callSlot(name, args);
    }

    vnodeList = (Array.isArray(vnodeList)) ? vnodeList : [];

    return vnodeList;
  }
  //----------------------------------------------------------------------------
  // call view.compute
  compute(name, args) {
    let value = null;
    if (this.$view != null) {
      value = this.$view.$$$callCompute(name, args);
    }
    return value;
  }

  getComputeFun() {
    return this.compute.bind(this);
  }
  //----------------------------------------------------------------------------
  // <b-for>
  renderList(data, cb) {
    const $util = $GM.get('util');

    let type = $util.getType(data).toLowerCase();
    let i = 0;

    switch (type) {
      case 'string':
        for (; i < data.length; i++) {
          let key = i++;
          let item = data.charAt(k);
          cb({
            item,
            key,
            index: key,
          });
        }
        break;
      case 'object':
        let keyList = Object.getOwnPropertyNames(data);
        keyList.forEach(function (key) {
          let index = i++;
          let item = data[key];
          cb({
            item,
            key,
            index,
          });
        });
        break;
      case 'array':
        for (; i < data.length; i++) {
          let key = i++;
          let item = data[k];
          cb({
            item,
            key,
            index: key,
          });
        }
        break;
      default:
        throw new TypeError(`no support this data.type(${type});`);
        break;
    }
  }
  //----------------------------------------------------------------------------
  // <b-if><b-if-else>
  booleanVal(value) {
    return value;
  }
  //----------------------------------------------------------------------------
  // callBy 模板
  addKeep(name, node) {
    if(name in this.$keep){
      throw new Error('has double keepName');
    }
    this.$keep[name] = node;
  }

  // callBy 模板
  addKeepAll(name, node) {
    if(name in this.$keepAll){
      throw new Error('has double keepAllName');
    }
    this.$keepAll[name] = node;
  }
  // callBy view
  getKeep() {
    return Object.values(this.$keep);
  }
  // callBy view
  getKeepAll() {
    return Object.values(this.$keepAll);
  }
  // callBy 模板
  setRootVnode(node){
    this.$rootVnode = node;
  }
  // callBy compile
  getRootVnode(){
    return this.$rootVnode;
  }
}
//==============================================================================


export { TemplateInnerSys };
