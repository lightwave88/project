// template 裏隱藏的 system
class TemplateInnerSys {

  $$$data = {};

  $view;
  //----------------------------------------------------------------------------
  constructor(config = {}) {
    let {
      view,
      data
    } = config;

    this.$$$data = data;
    this.$view = view;
  }
  //----------------------------------------------------------------------------
  get $data() {
    return this.$$$data[key];
  }

  set $data(v) {
    // 避免覆寫 data
  }
  //----------------------------------------------------------------------------
  // return vnodeList
  callSlot(name, args) {
    let vnodeList;

    if (this.$view != null) {
      vnodeList = this.$view.$$$callSlot(name, args);
    }

    vnodeList = (Array.isArray(vnodeList)) ? vnodeList : [];

    return vnodeList;
  }
  //----------------------------------------------------------------------------
  // call view.compute
  compute(name, args) {
    let value = null;
    if (this.$view != null) {
      value = this.$view.$$$callCompute(name, args);
    }
    return value;
  }

  getComputeFun() {
    return this.compute.bind(this);
  }
  //----------------------------------------------------------------------------

}

export { TemplateInnerSys };
