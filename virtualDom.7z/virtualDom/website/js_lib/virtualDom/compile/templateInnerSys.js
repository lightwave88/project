// template 裏隱藏的 system
class TemplateInnerSys {

  $$$data = {};

  $view;
  //----------------------------------------------------------------------------
  constructor(config = {}) {
    let {
      view,
      data
    } = config;

    this.$$$data = data;
    this.$view = view;
  }
  //----------------------------------------------------------------------------
  get $data() {
    return this.$$$data[key];
  }

  set $data(v) {
    // 避免覆寫 data
  }
  //----------------------------------------------------------------------------
  // return vnodeList
  callSlot(name, args) {
    let vnodeList;

    if (this.$view != null) {
      vnodeList = this.$view.$$$callSlot(name, args);
    }

    vnodeList = (Array.isArray(vnodeList)) ? vnodeList : [];

    return vnodeList;
  }
  //----------------------------------------------------------------------------
  // call view.compute
  compute(name, args) {
    let value = null;
    if (this.$view != null) {
      value = this.$view.$$$callCompute(name, args);
    }
    return value;
  }

  getComputeFun() {
    return this.compute.bind(this);
  }
  //----------------------------------------------------------------------------
  getLoopData(data) {
    let list;

    if (Array.isArray(data)) {
      list = data.map((d, i) => {
        return new ItemData(d, i);
      });
    } else {
      list = [];
      for (let k in data) {
        list.push(new ItemData(data[k], k));
      }
    }

    return list;
  }
}
//==============================================================================
class ItemData {
  $key;
  $value;
  constructor(value, key) {
    this.$key = key;
    this.$value = value;
  }
  get item() {
    return this.$value;
  }
  get key() {
    return this.$key;
  }
}

export { TemplateInnerSys };
