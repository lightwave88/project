// 模板內部的變數名稱
const template_varNames = {
  var_parentNode: '$_PARENT',
  var_vnode: '$_VNODE',
  var_sys: '$_SYS',
  var_loopData: '$_LOOPDATA',
  var_createVnode: '$_SYS.C',
};
export { template_varNames };

const config = {
  attrComputeHead: ':',
  format: true,
  spaceNum: 2,
}
export { config as compileConfig };
