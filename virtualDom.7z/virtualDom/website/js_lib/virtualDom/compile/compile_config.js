// 模板內部的變數名稱
const template_varNames = {
  var_root: '$_ROOT',
  var_parentNode: '$_PARENT',
  var_vnode: '$_VNODE',
  var_createVnode: '$_C',
  var_sys: '$_SYS',
  var_loopData: '$_LOOPDATA',
};
export { template_varNames };

const config = {
  attrComputeHead: ':',
  format: true,
  spaceNum: 2,
}
export { config as compileConfig };
