import { TemplateInnerSys } from './templateInnerSys.js';

// 使用者操作
class TemplateHandle {
  $$$fun;
  $$$slotTemplate = {};
  //----------------------------------------------------------------------------
  constructor(fun, config = {}) {
    this.$$$fun = fun;
    let { slotTemplates } = config;

    if (slotTemplate != null) {
      Object.assign(this.$$$slotTemplate, slotTemplate);
    }
  }
  //----------------------------------------------------------------------------
  render(data, view) {
    debugger;

    let args = {
      data,
      view
    };

    // 收集 factory 內部要用的模組

    // 取得 vnode_factory 裏的 system
    const sys = new TemplateInnerSys(args);

    const $compute = sys.getComputeFun();

    const Vnode = $GM.get('Vnode');

    const $createVnode = Vnode.createVnode;

    // 把所有東西灌入工廠
    let vnode;

    debugger;

    try {
      debugger;
      vnode = this.$$$fun.call(view, data, $createVnode, sys, $compute);
    } catch (error) {
      console.log('render error')
      throw error;
    }

    return vnode;
  }
  //----------------------------------------------------------------------------
  getSlotTemplate(id) {
    let res = null;
    if (id in this.$$$slotTemplate) {
      res = this.$$$slotTemplate[id];
    }
    return res;
  }
}

export { TemplateHandle };
