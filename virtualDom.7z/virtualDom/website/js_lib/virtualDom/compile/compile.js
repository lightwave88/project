debugger;
import $GM from '../g_module.js';
import { domNode, varnames } from './node/index.js';
const $domNode = domNode;

// 編譯爲 renderFun
class Compile {

  emptyNodes = [];

  slots = {};
  keepAlives = {};

  constructor() {

  }
  //----------------------------------------------------------------------------
  // 必須注意 dom = null 的問題
  byDom(dom) {
    debugger;

    let $tempList = [];

    if (dom != null) {
      let tempNode = getTempNode({ dom });
      $tempList.push(tempNode);
    }
    //----------------------------    
    let index = 0;

    while (true) {
      let i = index++;

      // 拜訪所有 dom
      let tempNode = $tempList[i];

      if (tempNode == null) {
        break;
      }      

      let domNode = $domNode.getInstance(tempNode);
      //-----------------------
      // 檢查 domNode 特性
      let is_emptyNode = this._is_emptyNode(domNode);
      let is_keepAlive = this._is_keepAliveTag(domNode);

      // 記錄特殊 node
      this._getSlot(domNode);

      // 置換節點
      $tempList[i] = domNode;
      //-----------------------
      // 處理子節點

      let childDoms;
      if ((childDoms = this._is_needCheckChild(domNode)) == null) {
        // 不需處理子節點的 dom
        continue;
      }
      // 要檢查的列表      

      let checkList = childDoms.map((el) => {
        let j = $tempList.length;
        checkIndexList.push(j);

        let p = domNode;

        let tempNode = getTempNode({
          dom: el,
          parent: p,
          isKeepAlive: is_keepAlive,
          isEmpty: is_emptyNode
        });

        $tempList.push(tempNode);
        return tempNode;
      });

      // 檢查 node.is_static
      this._checkNodeStatic(checkList);

    } // endWhile

    //------------------
    // 打造 renderFun

    let fun_text = this._buildRenderFun_1($tempList);

    let res = this._buildRenderFun_2(fun_text);

    return res;
  }
  //----------------------------------------------------------------------------
  byText(text) {

  }
  //----------------------------------------------------------------------------
  _buildRenderFun_1($tempList = []) {
    debugger;

    let domNode;

    let i = $tempList.length;
    while (--i >= 0) {
      domNode = $tempList[i];

      if (domNode.is_emptyNode) {
        continue;
      }
      domNode.callParent();
    }

    // 釋放記憶體
    domNodesClear($tempList);

    // debugger;
    // 工廠函式文本
    let fun_text = (domNode == null ? null : domNode.getResult());

    return fun_text;
  }
  //-------------------------------------------
  // 對 render 函式進一步加工
  _buildRenderFun_2(fun_text) {

    debugger;

    const null_fun = function (...args) {
      return null;
    };

    if (fun_text == null) {
      return null_fun;
    }
    //------------------
    // about modules   

    const variables = getTemplateVariables();
    let variableText = '';

    for (let key in variables) {
      let k = JSON.stringify(key);
      variableText += `const ${key} = variables[${k}]`;
      variableText += `delete `
    }


    // render 函式裏面要用的模組
    const modules = getTemplateModuler();
    let moduleText = '';


    for (let key in modules) {
      let k = JSON.stringify(key);
      moduleText += `const ${key} = modules[${k}];\n`;
      moduleText += `delete modules[${k}];\n`;
    }

    moduleText += 'modules = null;\n';
    //------------------
    let render_1;

    const renderContent = `
debugger;

const $$$slots = slots;      
const $$$compute = compute;
const $data = data;

compute = null;
slots = null;
data = null;

${moduleText};

//------------------
${fun_text}
    `;

    try {
      render_1 = new Function('modules', 'funs', 'data', 'variables', renderContent);
    } catch (error) {
      console.log('build factory error(%s)', error);
      return null;
    }
    //------------------

    // 渲染函式
    // 渲染函式
    // 渲染函式
    const render = function (data, context, variables) {

      context = context || null;
      data = Object.assign({}, data);
      slots = Object.assign({}, slots);

      let cloneModule = Object.assign({}, modules);

      //-------------

      // vnode_factory
      let vnode = render_1.apply(context, [cloneModule, data, variables]);
      return (vnode || null);
    };

    console.log(renderContent);

    return {
      render,
      renderContent,
      slots: (this.slots),
    };
  }
  //----------------------------------------------------------------------------
  _getSlot(domNode) {

    let dom = domNode.dom;

    let tagName = dom.tagName || null;

    if (tagName == null) {
      return null;
    }
    if (/^b-slot$/i.test(tagName)) {
      return null;
    }

    let name = dom.getAttribute('name');

    if (!name) {
      throw new Error('');
    }
    this.slots[name] = null;
  }
  //----------------------------------------------------------------------------
  _is_needCheckChild(domNode) {
    let dom = domNode.dom;

    let tagName = dom.tagName || null;

    if (tagName == null) {
      return null;
    }

    let childs = null;

    tagName = tagName.toLowerCase();

    switch (tagName) {
      case 'script':
        break;
      default:
        childs = Array.from(dom.childNodes);
        break;
    }

    return childs;
  }
  //----------------------------------------------------------------------------
  // 是否是指示性標籤，而無本質作用
  // 指示性標籤不能有子節點
  _is_emptyNode(domNode) {

    let res = 0;

    let dom = domNode.dom;

    if (dom.tagName == null) {
      return res;
    }

    let res = false;
    let nodeName = dom.nodeName.toLowerCase();

    switch (nodeName) {
      case 'keep-alive':
      case 'template':
        res = 2;
        break;
      case 'b-for':
      case 'b-if':
      case 'b-if-else':
      case 'b-else':
        res = 1;
        break;
      default:
        break;
    }

    if (res > 0) {
      this.emptyNodes.push(domNode);
    }

    return res;
  }
  //----------------------------------------------------------------------------
  // 是否是 <keep-alive>
  _is_keepAliveTag(domNode) {
    let dom = domNode.dom;

    if (dom.tagName == null) {
      return false;
    }
    let nodeName = dom.nodeName;
    let res = /^keep-alive$/i.test(nodeName);

    return res;
  }
  //----------------------------------------------------------------------------
  // 檢查 node.is_static
  _checkNodeStatic(list) {

  }
}


//==============================================================================


function getCreateFun() {
  const Vnode = $GM.get('Vnode');

  return function C(nodeName, tagName, parent) {
    return new Vnode(nodeName, tagName, parent);
  }
}
//------------------------------------------------------------------------------
// 釋放記憶體
function domNodesClear(list = []) {

  if (!list.length) {
    return;
  }
  const $util = $GM.get('util');

  $util.nextStep(function () {
    while (list.length > 0) {
      let node = list.pop();
      node.clear();
    }
  });
}
//------------------------------------------------------------------------------
// 構建模板內部重要的函式
function getTemplateModuler(module) {

  module = Object.assign({
    '$$$getData': null,
    '$$$setData': null,
    '$$$getCompute': null,
    // 文字過濾器
    '$$$getFilter': null,
    '$$$getSlot': null,
  }, module);

  // 變數名稱
  let createVarName = DomNode.get_varName('createVarName');
  const $C = getCreateFun();
  modules[createVarName] = $C;

  //------------------
  module['$$$getData'] = function (data, path) {
    path = path.replace(/\[['"]/g, '.');
    path = path.replace(/'"]/g, '');

    path = path.split('.');
    path = path.filter(d => {
      if (!d.length) {
        return false;
      }
      return true;
    });

    let res = data;
    let i = 0;
    while (i < path.length) {
      let j = i++;
      let key = path[j];
      try {
        res = res[key];
      } catch (error) {
        let er = path.slice(0, j);
        throw new Error(`keyList(${er.join('.')}) getData error`);
      }
    }
    return res;
  };
  //------------------
  module['$$$setData'] = function (data, path, value) {
    path = path.replace(/\[['"]/g, '.');
    path = path.replace(/'"]/g, '');

    path = path.split('.');
    path = path.filter(d => {
      if (!d.length) {
        return false;
      }
      return true;
    });

    let res = data;
    let key;
    while (path.length) {
      key = path.shift();
      if (!path.length) {
        break;
      }
      res = res[key];
    } // endWhile

    if (key == null) {
      throw new Error('no key');
    }
    res[key] = value;
  };
  //------------------
  module['$$$getCompute'] = function (computes = {}, name) {
    if (!(name in computes)) {
      throw new Error(`no this compute(${name})`);
    }
    return computes[name];
  };
  //------------------
  module['$$$callFilter'] = function (filters = {}, text, ...list) {

    list.forEach(name => {
      let filter;
      if (name in filters) {
        filter = filters[name];
      }
      if (filter == null) {
        throw new Error(`no this filter(${name})`);
      }
      text = filter(text);
    });
    return text;
  }
  //------------------

  module['$$$getSlot'] = function (slots, name) {
    let fn = function () {
      return [];
    }
    if (name in slots) {
      fn = slots[name];
    }
    return fn;
  }
  return module;
}
//------------------------------------------------------------------------------
// template 內部給使用者的 API
function getTemplateFuns() {
  let funs = {
    '$getData': null,
    '$setData': null,
    '$compute': null,
    '$filter': null,
  };

  funs['$getData'] = `$$$getData($data, path);\n`;
  funs['$setData'] = `$$$setData($data, path, value);\n`;
  funs['$compute'] = `
      return $$$getCompute(t['$$$computes'],k);
    }
  });\n`;

  funs['$filter'] = `$$$callFilter($$$filter, text);\n`;
}
//------------------------------------------------------------------------------
// template 內部重要隱藏變數
function getTemplateVariables() {
  let variables = {
    '$$$slots': `variables['slots'];\n`,
    '$$$computes': `variables['computes'];\n`,
    '$$$filters': `variables['filters'];\n`,
  };
};
//------------------------------------------------------------------------------
function getTempNode(config = {}) {
  let res = {
    dom: null,
    parent: null,
    isKeepAlive: false,
    isStatic: true,
    isEmpty: 0,
  }
  Object.assign(res, config);
  return res;
}

export default Compile;




