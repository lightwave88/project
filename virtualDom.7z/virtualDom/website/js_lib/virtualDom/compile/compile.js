debugger;
import $GM from '../g_module.js';

// 編譯爲 renderFun
class Compile {
  constructor() {
    this.slots = {};
  }
  //-------------------------------------------
  // 必須注意 dom = null 的問題
  byDom(dom, slots = {}) {
    debugger;

    const DomNode = $GM.get('DomNode');
    Object.assign(this.slots, slots);

    let $tempList = [];
    let $parentMap = {};

    if (dom != null) {
      $tempList.push(dom);
    }
    //------------------    
    let index = 0;

    while (true) {
      let i = index++;

      // 拜訪所有 dom
      let dom = $tempList[i];

      if (dom == null) {
        break;
      }

      let parent = null;
      if (i in $parentMap) {
        // 檢查父子關係，是否由所屬的 parent
        parent = $parentMap[i];
        delete $parentMap[i];
      }
      let domNode = DomNode.getInstance(dom, parent);

      if (parent != null) {
        // 父子關係
        parent.append(domNode);
      }

      // 置換節點
      $tempList[i] = domNode;
      //-----------------------
      // 處理子節點

      let childs;
      if ((childs = is_needCheckChild(dom)) == null) {
        // 不需處理子節點的 dom
        continue;
      }

      childs.forEach(el => {
        let j = $tempList.length;
        // 記錄 link
        $parentMap[j] = domNode;
        $tempList.push(el);
      });
    }
    //------------------
    let keyList = Object.keys($parentMap);
    if (keyList.length) {
      throw new Error('no clear');
    }
    debugger;
    //------------------
    // 打造 renderFun

    let fun_text = this._buildRenderFun_1($tempList);

    let res = this._buildRenderFun_2(fun_text);

    return res;
  }
  //-------------------------------------------
  byText(text) {

  }
  //-------------------------------------------
  _buildRenderFun_1($tempList = []) {
    debugger;

    let domNode;

    let i = $tempList.length;
    while (--i >= 0) {
      domNode = $tempList[i];
      domNode.callParent();
    }

    // 釋放記憶體
    domNodesClear($tempList);

    // debugger;
    // 工廠函式文本
    let fun_text = (domNode == null ? null : domNode.getResult());

    return fun_text;
  }
  //-------------------------------------------
  // 對 render 函式進一步加工
  _buildRenderFun_2(fun_text) {

    debugger;

    const null_fun = function (...args) {
      return null;
    };

    if (fun_text == null) {
      return null_fun;
    }
    //------------------
    // about modules   

    const DomNode = $GM.get('DomNode');

    // render 函式裏面要用的模組
    const modules = {};

    // 變數名稱
    let createVarName = DomNode.get_varName('createVarName');
    const $C = getCreateFun();

    modules[createVarName] = $C;


    let moduleText = '';

    for (const key in modules) {
      if (modules.hasOwnProperty(key)) {
        let k = JSON.stringify(key);
        moduleText += `const ${key} = modules[${k}];\n`;
        moduleText += `delete modules[${k}];\n`;
      }
    }

    moduleText += 'modules = null;\n';
    //------------------
    let render_1;

    const renderContent = `
      debugger;

      ${moduleText}

      const $$$slots = slots;      
      const $data = data;

      slots = null;
      data = null;

      ${fun_text}
    `;

    try {
      render_1 = new Function('modules', 'data', 'slots', renderContent);
    } catch (error) {
      console.log('build factory error(%s)', error);
      return null;
    }
    //------------------

    // 渲染函式
    const render = function (data, slots, context) {
      context = context || null;
      data = Object.assign({}, data);
      slots = Object.assign({}, slots);

      let vnode = render_1.call(context, modules, data, slots);
      return (vnode || null);
    };

    console.log(renderContent);

    return {
      render,
      renderContent,
      slots: (this.slots),
    };
  }
}
//==============================================================================
// 是否要處理這個 dom.childs 
function is_needCheckChild(dom) {

  let tagName = dom.tagName || null;

  if (tagName == null) {
    return null;
  }

  let childs = null;

  tagName = tagName.toLowerCase();

  switch (tagName) {
    case 'script':
      break;
    default:
      childs = Array.from(dom.childNodes);
      break;
  }

  return childs;
}

//-------------------------------------------
function getCreateFun() {
  const Vnode = $GM.get('Vnode');

  return function C(nodeName, tagName, parent) {
    return new Vnode(nodeName, tagName, parent);
  }
}
//-------------------------------------------
// 釋放記憶體
function domNodesClear(list = []) {

  if (!list.length) {
    return;
  }
  const $util = $GM.get('util');

  $util.nextStep(function () {
    while (list.length > 0) {
      let node = list.pop();
      node.clear();
    }
  });
}

export default Compile;



