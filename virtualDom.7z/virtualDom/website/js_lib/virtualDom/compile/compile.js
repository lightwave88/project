debugger;
import $GM from '../g_module.js';

// 編譯爲 renderFun
class Compile {
  constructor() {
    this.$tempList = [];

    // 記錄父子關係
    this.$parentMap = {};
  }
  //-------------------------------------------
  byDom(dom) {
    debugger;
    let $tempList = this.$tempList;
    let $parentMap = this.$parentMap;

    // 清除一些不必的資訊
    clearRootDomData(dom);

    $tempList.push(dom);
    //------------------
    // domNode link
    const DomNode = $GM.get('DomNode');

    for (let i = 0; i < $tempList.length; i++) {
      // debugger;

      // 拜訪所有 dom
      let dom = $tempList[i];
      let tagName = dom.tagName;

      let parent = null;
      if (i in $parentMap) {
        // 檢查父子關係，是否由所屬的 parent
        parent = $parentMap[i];
        delete $parentMap[i];
      }
      let domNode = DomNode.getInstance(dom, parent);

      if (parent != null) {
        // 父子關係
        parent.append(domNode);
      }

      // 替換
      $tempList[i] = domNode;
      //-----------------------
      if (!this._needCheckChild(tagName)) {
        // 不需處理子節點的 dom
        continue;
      }

      // 處理子節點
      let childs = Array.from(dom.childNodes);

      childs.forEach(el => {
        let index = $tempList.length;
        // 記錄 link
        $parentMap[index] = domNode;
        $tempList.push(el);
      });
    }
    //------------------
    let keyList = Object.keys($parentMap);
    if (keyList.length) {
      throw new Error('no clear');
    }
    debugger;
    //------------------
    // 打造 renderFun

    let fun_context = this._buildRenderFun();

    console.log(fun_context);
    //------------------
    let render_fun = this._buildVnodeThree(fun_context);

    return render_fun;
  }
  //-------------------------------------------
  _buildRenderFun() {
    debugger;

    let domNode;
    for (let i = this.$tempList.length; i > 0; i--) {
      // debugger;
      let j = i - 1;
      domNode = this.$tempList[j];
      domNode.callParent();
    }
    // debugger;
    // 工廠函式文本
    let fun_context = domNode.getResult();

    return fun_context;
  }
  //-------------------------------------------
  _needCheckChild(tagName) {
    if (tagName == null) {
      return false;
    }

    tagName = tagName.toLowerCase();

    let res = true;
    switch (tagName) {
      case 'script':
        res = false;
        break;
    }

    return res;
  }
  //-------------------------------------------
  _buildVnodeThree(fun_context) {
    debugger;
    let r_vnode = null;

    const DomNode = $GM.get('DomNode');

    // 變數名稱
    let createVarName = DomNode.get_varName('createVarName');

    let factory;

    try {
      factory = new Function(createVarName, 'data', fun_context);
    } catch (error) {
      console.log('build factory error(%s)', error);
    }

    if (factory == null) {
      return r_vnode;
    }
    //------------------
    const Vnode = $GM.get('Vnode');

    function C(nodeName, tagName, parent) {
      return Vnode.getInstance(nodeName, tagName, parent);
    }

    console.log(factory);

    // 渲染函式
    let render_fun = function (data) {
      debugger;
      data = Object.assign({}, data);
      return factory(C, data);
    }

    return render_fun;
  }
}

export default Compile;


function clearRootDomData(dom) {
  dom.removeAttribute('id');
}
