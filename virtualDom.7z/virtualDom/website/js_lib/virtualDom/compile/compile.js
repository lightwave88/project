// debugger;
import $GM from '../g_module.js';
import { createDomNode, DomNode } from './node/index.js';

const $reg_1 = /^script$/i;
const $reg_2 = /^#text$/i;
const $reg_3 = /^b-slot$/i;


// 編譯爲 renderFun
class Compile {

  //$id;

  $tempNodeList = [];

  // <b-slot> 裏的模板內容
  // 須在稍後編譯
  // {}
  $slotTemplates = {};

  $rootNode;

  // $fun_args;

  $slotID = 0;

  // 用來檢查 keepName 是否有重複
  $keeps = {};

  // 用來檢查 keepAllName 是否有重複
  $keepAlls = {};

  $content = '';

  //----------------------------------------------------------------------------
  constructor() {

  }
  //----------------------------------------------------------------------------
  // API
  // 必須注意 dom = null 的問題
  byDom(dom) {
    return this._main(dom);
  }
  //----------------------------------------------------------------------------
  // API
  byText(text) {

  }
  //----------------------------------------------------------------------------
  // 給 <b-slot> 編號用
  getSlotID() {
    return `slot_${this.$slotID++}`;
  }
  //----------------------------------------------------------------------------
  _main(dom) {
    debugger;
    this._loopChild(dom);

    // 編譯 <b-slot> 內部的模板
    this._compileSlotTemplate();

    let content = this._buildFactory_1();

    // debugger;
    // console.dir(content);

    let fun = this._buildFactory_2(content);
    // return;

    debugger;
    // 提供一個可操作 fun 的柄
    let tempHandle = this._buildTempHandle(fun);

    return tempHandle;
  }
  //----------------------------------------------------------------------------
  _loopChild(dom) {
    let $tempList = [];

    // 初始化
    let tempNode = this._getTempNode({ dom });

    $tempList.push(tempNode);
    //----------------------------
    let index = 0;

    while (true) {
      // console.dir($tempList);
      // debugger;

      let i = index++;

      // 拜訪所有 dom
      let tempNode = $tempList[i];
      if (tempNode == null) {
        break;
      }
      //-----------------------
      /*
      if (this._isEmptyText(tempNode)) {
        // 空的文字節點
        $tempList[i] = null;
        continue;
      }
      */

      let domNode = createDomNode(tempNode);

      // <b-slot>
      this._isSlotTag(domNode);

      // 置換節點
      $tempList[i] = domNode;
      //------------------------------------------------

      // 處理子節點
      // 處理子節點
      // 處理子節點
      // 處理子節點

      let childDoms = this._is_needCheckChild(domNode);

      if (childDoms == null) {
        // 不需處理子節點的 dom
        continue;
      }
      // 若有出現 <script>
      let scripts = [];
      // 要檢查的列表
      // let checkList = [];

      let k = 0;

      while (true) {
        // debugger;
        let p = domNode;
        let j = k++;
        let node = childDoms[j];
        if (node == null) {
          break;
        }

        let dom;
        let nodeName;

        if (node instanceof TempNode) {
          dom = node.dom;
          nodeName = node.nodeName;
        } else {
          dom = node;
          nodeName = dom.nodeName.toLowerCase();
        }

        // debugger;
        //------------------

        if (this._isEmptyNode(nodeName)) {
          // 碰到空 dom 如 <template>
          k = j;
          let childs = this._getEmptyNodeChilds(nodeName, dom);

          if (childs != null && childs.length > 0) {
            let args = [j, 1];
            args = args.concat(childs);
            Array.prototype.splice.apply(childDoms, args);
          } else {
            childDoms.splice(j, 1);
          }
          continue;
        }
        //------------------
        if (this._isScript(nodeName, dom) && !scripts.includes(j)) {
          scripts.push(j);
        }
        //------------------

        // debugger;
        if (!(node instanceof TempNode)) {
          k = j;
          dom = node;
          let tempNode = this._getTempNode({
            dom: dom,
            parent: p,
            nodeName,
          });
          childDoms[j] = tempNode;
          continue;
        } else {

          if (node.parent == null) {
            node.parent = p;
          }

        }
      } // endWhile

      // debugger;

      // 檢查 node.is_static
      this._checkStatic(childDoms, scripts);

      if (scripts.length > 0) {
        scripts.length = 0;
      }

      // debugger;
      $tempList = $tempList.concat(childDoms);

    } // endWhile

    //------------------
    this.$rootNode = $tempList[0];

    this.$tempNodeList = $tempList;
  }
  //----------------------------------------------------------------------------
  // 處理 <b-slot>
  _isSlotTag(domNode) {

    // console.dir(domNode);
    let dom = domNode.dom;

    let tagName = dom.tagName || '';

    if (!$reg_3.test(tagName)) {
      return;
    }
    //------------------
    debugger;

    const $util = $GM.get('util');

    // 賦予 slot.id
    let slotID = this.getSlotID();
    domNode.slotID = slotID;

    // <b-slot> 若有內容
    let childList = $util.clear2SideEmptyDom(dom);

    if (childList.length == 0) {
      return;
    }

    let rootDom = document.createDocumentFragment();
    childList.forEach(d => {
      rootDom.appendChild(d);
    });

    this.$slotTemplates[slotID] = rootDom;
  }
  //----------------------------------------------------------------------------
  // 不同節點 child 的提取不同
  _is_needCheckChild(domNode) {
    // debugger;

    const dom = domNode.dom;
    let nodeName = domNode.nodeName;

    let childs = null;

    switch (nodeName) {
      case 'script':
        break;
      case 'template':
        let content = dom.content;
        childs = Array.from(content.childNodes);
        break;
      default:
        if (dom.childNodes != null) {
          childs = Array.from(dom.childNodes);
        }
        break;
    }

    if (Array.isArray(childs) && childs.length == 0) {
      childs = null;
    }
    return childs;
  }
  //----------------------------------------------------------------------------
  _checkStatic(list = [], markList = []) {
    if (markList.length < 2) {
      return;
    }

    let end = markList[markList.length - 1];
    let start = markList[0];

    for (let i = start; i <= end; i++) {
      let tempNode = list[i];
      if (tempNode.isStatic == null) {
        tempNode.isStatic = false;
      }
    }
  }
  //----------------------------------------------------------------------------
  // 繞過示意用但不輸出的空 dom
  // <template> <b-static>
  _getEmptyNodeChilds(nodeName, dom) {
    let childs = null;

    switch (nodeName) {
      case 'template':
        let content = dom.content;
        childs = Array.from(content.childNodes);
        childs = childs.map(c => {
          return this._getTempNode({ dom: c });
        });
        break;
      case 'b-static':
        childs = Array.from(dom.childNodes);
        childs = childs.map(c => {
          return this._getTempNode({ dom: c, isStatic: true });
        });
        break;
      default:
        break;
    }
    return childs;
  }
  //----------------------------------------------------------------------------
  // 是否只是示意的空 dom
  _isEmptyNode(nodeName) {
    let res = false;

    switch (nodeName) {
      case 'b-static':
      case 'template':
        res = true;
        break;
    }
    return res;
  }
  //----------------------------------------------------------------------------
  _isScript(tagName) {
    return $reg_1.test(tagName);
  }
  //----------------------------------------------------------------------------
  // 有爭議
  // 略過空的文字節點可以加快節點樹的操作
  _isEmptyText(tempNode) {

    let {
      dom,
      nodeName
    } = tempNode;

    if ($reg_2.test(nodeName)) {
      // debugger;
      let text = dom.nodeValue.trim();
      if (!text.length) {
        // 空的文字節點
        return true;
      }
    }
    return false;
  }
  //----------------------------------------------------------------------------
  // 暫存節點
  // 儲存資料用
  _getTempNode(config = {}) {
    return new TempNode(config, this);
  }
  //----------------------------------------------------------------------------
  // 編譯 <b-slot> 內部的模板
  _compileSlotTemplate() {
    // debugger;

    const slotTemplates = this.$slotTemplates;

    for (let key in slotTemplates) {
      debugger;
      let rootDom = slotTemplates[key];

      if (rootDom == null) {
        continue;
      }

      let compile = new Compile();

      // 建造產生 vnode 的工廠函式
      slotTemplates[key] = compile.byDom(rootDom);
    }
  }
  //----------------------------------------------------------------------------
  // 打造 vnode_factory
  _buildFactory_1() {
    let domNode;

    let nodeList = this.$tempNodeList;

    let i = nodeList.length;

    console.log('length=%s', i);

    while (--i >= 0) {
      domNode = nodeList[i];
      if (domNode == null) {
        // 空文字節點
        continue;
      }
      domNode.callParent();
    }

    // 釋放記憶體
    // domNodesClear(nodeList);

    // debugger;
    // 工廠函式文本
    let fun_text = (domNode == null ? '' : domNode.getResult());

    return fun_text;
  }
  //----------------------------------------------------------------------------
  _buildFactory_2(fun_text) {

    const sysConfig = $GM.get('sysConfig');

    const {
      var_root,
      var_vnode,
      var_createVnode,
      var_sys,
    } = sysConfig.tempSysVarName;

    const fun_content = `
    'use strict';
		debugger;

		const ${var_sys} = $system;
		const $data = ${var_sys}.getData();
		const $compute = $system.getComputeFun();
		let ${var_vnode} = null;
		//------------------
		$system = null;

		debugger;
		//------------------
		${fun_text}
		debugger;`;
    //----------------------------

    this.$content = fun_content;
    console.log(fun_content);

    let fun;
    try {
      fun = new Function('$system', fun_content);
    } catch (error) {
      console.log('build vnode_factory error')
      throw error;
    }
    return fun;
  }
  //----------------------------------------------------------------------------
  _buildTempHandle(fun) {

    let config = {
      fun: fun,
      fun_content: this.$content,
      slotTemplates: (this.$slotTemplates)
    };

    const FactoryHandle = $GM.get('FactoryHandle');
    let handle = new FactoryHandle(config);

    return handle;
  }
}
//==============================================================================
// 攜帶資訊用
class TempNode {
  dom;
  parent;
  isStatic;

  // 編譯者
  compile;
  nodeName;

  constructor(_config = {}, compile) {

    let config = {
      dom: null,
      parent: null,
      isStatic: null,
      compile: compile,
      nodeName: null,
    };

    Object.assign(config, _config);

    this.dom = config.dom;
    this.parent = config.parent;
    this.isStatic = config.isStatic;
    this.compile = config.compile;
    this.nodeName = config.nodeName;

    if (this.nodeName == null) {
      this.nodeName = this.dom.nodeName;
    }

    this.nodeName = this.nodeName.toLowerCase();
  }
}

export { Compile };
