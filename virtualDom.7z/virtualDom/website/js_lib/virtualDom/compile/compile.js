debugger;
import $GM from '../g_module.js';
import { domNode, temp_varnames } from './node/index.js';
const $domNode = domNode;

// 編譯爲 renderFun
class Compile {

  emptyNodes = [];

  slot_list = [];

  slotTemp_list = {};
  
  keep_list = new Set();
  keepAll_list = new Set();
  //----------------------------------------------------------------------------
  constructor() {

  }
  //----------------------------------------------------------------------------
  // 必須注意 dom = null 的問題
  byDom(dom) {
    debugger;

    let $tempList = [];

    let tempNode = this._getTempNode({ dom });
    $tempList.push(tempNode);
    //----------------------------    
    let index = 0;

    while (true) {
      console.dir($tempList);
      debugger;

      let i = index++;

      // 拜訪所有 dom
      let tempNode = $tempList[i];
      if (tempNode == null) {
        break;
      }
      //-----------------------

      let domNode = $domNode.getInstance(tempNode);
      // 檢查 domNode 特性
      this._is_emptyNode(domNode);
      this._is_keepAlive(domNode);

      // 記錄特殊 node
      this._isSlotTag(domNode);

      // 置換節點
      $tempList[i] = domNode;
      //-----------------------
      // 處理子節點

      let childDoms = this._is_needCheckChild(domNode);

      if (childDoms == null) {
        // 不需處理子節點的 dom
        continue;
      }
      // 要檢查的列表      

      let checkList = childDoms.map((el) => {
        let p = domNode;

        let tempNode = this._getTempNode({
          dom: el,
          parent: p,
        });

        $tempList.push(tempNode);
        return tempNode;
      });

      // 檢查 node.is_static
      this._checkNodeStatic(checkList);

    } // endWhile

    //------------------
    this._aboutKeepAlive();

    this._processEmptyNode();
    //------------------
    // 打造 renderFun

    let res = this._getFactoryContent($tempList);

    return res;
  }
  //----------------------------------------------------------------------------
  byText(text) {

  }
  //----------------------------------------------------------------------------
  _processEmptyNode() {
    this.emptyNodes.forEach(node => {
      let index = node.index;
      node.switchChildParent();
    });
  }
  //----------------------------------------------------------------------------
  // 打造 vnode_factory
  _getFactoryContent(nodeList) {
    let domNode;

    let i = nodeList.length;
    while (--i >= 0) {
      domNode = nodeList[i];
      domNode.callParent();
    }

    // 釋放記憶體
    // domNodesClear(nodeList);

    // debugger;
    // 工廠函式文本
    let fun_text = (domNode == null ? null : domNode.getResult());

    return fun_text;
  }
  //----------------------------------------------------------------------------
  _isSlotTag(domNode) {

    let dom = domNode.dom;

    let tagName = dom.tagName || null;

    if (tagName == null) {
      return;
    }
    if (!/^b-slot$/i.test(tagName)) {
      return;
    }

    let name = dom.getAttribute('name');

    if (!name) {
      throw new Error('<b-slot> no attr("name")');
    }
    // fix fix
  }

  
  //----------------------------------------------------------------------------
  _is_needCheckChild(domNode) {
    let dom = domNode.dom;

    let tagName = dom.tagName || null;

    if (tagName == null) {
      return null;
    }

    let childs = null;

    tagName = tagName.toLowerCase();

    switch (tagName) {
      case 'script':
        break;
      case 'template':
        let content = dom.content;
        childs = Array.from(content.childNodes);
        break;
      default:
        childs = Array.from(dom.childNodes);
        break;
    }

    return childs;
  }
  //----------------------------------------------------------------------------
  // 是否是指示性標籤，而無本質作用
  // 指示性標籤不能有子節點
  _is_emptyNode(domNode) {

    let res = 0;

    let dom = domNode.dom;

    if (dom.tagName == null) {
      return res;
    }
    let nodeName = dom.nodeName.toLowerCase();

    switch (nodeName) {
      // case 'keep-alive':
      case 'template':
        // 完全沒實體作用的節點
        res = 2;
        break;
      case 'b-for':
      case 'b-if':
      case 'b-if-else':
      case 'b-else':
        res = 1;
        break;
      default:
        break;
    }

    domNode.isEmpty = res;

    if (res > 1) {
      this.emptyNodes.push(domNode);
    }
  }
  //----------------------------------------------------------------------------
  // 是否是 <keep-alive>
  _is_keepAlive(domNode) {


    if (typeof domNode.keep == 'string') {
      this.keep_list = {}
    } else if (typeof domNode.keepAll == 'string') {

    }
  }
  //----------------------------------------------------------------------------
  // 檢查 node.is_static
  _checkNodeStatic(list) {
    let start, end;

    list.forEach((tempNode, i) => {

      let dom = tempNode.dom;

      let tagName = dom.tagName || '';
      tagName = tagName.toLowerCase();

      switch (tagName) {
        case 'b-for':
        case 'b-if':
        case 'b-if-else':
        case 'b-else':
          tempNode.isStatic = false;
          break;
        case 'script':
          if (start == null) {
            start = i;
          }
          end = i;
        default:
          break;
      }
    });

    if (start == null) {
      return;
    }
    //------------------
    // 在 <script> 區塊裏
    for (let i = (start + 1); i < end; i++) {
      let tempNode = list[i];
      let dom = tempNode.dom;

      if (dom.hasAttribute('b-static')) {
        // 若使用者有設定 attr.b-static
        let value = dom.getAttribute('b-static')
        let is_static = new Boolean(value);
        if (is_static) {
          continue;
        }
      }
      tempNode.isStatic = false;
    }
  }
  //----------------------------------------------------------------------------
  _aboutKeepAlive() {

    this.keepAlives.forEach(parent => {
      parent.childs.forEach(node => {
        let dom = node.dom;
        if (dom.tagName != null && !dom.hasAttribute('id')) {
          throw new Error(`tag(${dom.tagName}) must has attr.id when use keep-alive`);
        }
        node.isKeepAlive = true;
      });
    });
  }
  //----------------------------------------------------------------------------
  _getTempNode(config = {}) {
    let node = {
      dom: null,
      parent: null,
      isStatic: true,
    }
    Object.assign(node, config);
    return node;
  }
}


export { Compile };
export { temp_varnames };




