debugger;
import $GM from '../g_module.js';

// 編譯爲 renderFun
class Compile {
  constructor() {
  }
  //-------------------------------------------
  // 必須注意 dom = null 的問題
  byDom(dom) {
    debugger;

    const DomNode = $GM.get('DomNode');
    let $tempList = [];
    let $parentMap = {};

    if (dom != null) {
      $tempList.push(dom);
    }
    //------------------    
    let index = 0;

    while (true) {
      let i = index++;

      // 拜訪所有 dom
      let dom = $tempList[i];

      if (dom == null) {
        break;
      }

      let parent = null;
      if (i in $parentMap) {
        // 檢查父子關係，是否由所屬的 parent
        parent = $parentMap[i];
        delete $parentMap[i];
      }
      let domNode = DomNode.getInstance(dom, parent);

      if (parent != null) {
        // 父子關係
        parent.append(domNode);
      }

      // 置換節點
      $tempList[i] = domNode;
      //-----------------------
      // 處理子節點

      let childs;
      if ((childs = is_needCheckChild(dom)) == null) {
        // 不需處理子節點的 dom
        continue;
      }

      childs.forEach(el => {
        let j = $tempList.length;
        // 記錄 link
        $parentMap[j] = domNode;
        $tempList.push(el);
      });
    }
    //------------------
    let keyList = Object.keys($parentMap);
    if (keyList.length) {
      throw new Error('no clear');
    }
    debugger;
    //------------------
    // 打造 renderFun

    let fun_text = this._buildRenderFun_1($tempList);

    console.log('fun_context:\n%s', fun_text);
    //------------------
    let render_fun = this._buildRenderFun_2(fun_text);

    return render_fun;
  }
  //-------------------------------------------
  byText(text) {

  }
  //-------------------------------------------
  _buildRenderFun_1($tempList = []) {
    debugger;

    let domNode;

    let i = $tempList.length;
    while (--i >= 0) {
      domNode = $tempList[i];
      domNode.callParent();
    }

    domNodesClear($tempList);

    // debugger;
    // 工廠函式文本
    let fun_context = (domNode == null ? null : domNode.getResult());

    return fun_context;
  }

  //-------------------------------------------
  _buildRenderFun_2(fun_text) {

    debugger;

    const null_fun = function (...args) {
      return null;
    };

    if (fun_text == null) {
      return null_fun;
    }
    //------------------   

    const DomNode = $GM.get('DomNode');

    // 變數名稱
    let createVarName = DomNode.get_varName('createVarName');

    let factory;

    try {
      factory = new Function(createVarName, 'data', fun_text);
    } catch (error) {
      console.log('build factory error(%s)', error);
      return null;
    }
    //------------------
    const $C = getCreateFun();

    // 渲染函式
    return function (data) {

      data = Object.assign({}, data);
      debugger;

      // 返回 html 藍本 vnodeThree
      const root_vnode = factory($C, data);
      return (root_vnode || null);
    };
  }
}
//==============================================================================
// 是否要處理這個 dom.childs 
function is_needCheckChild(dom) {

  let tagName = dom.tagName || null;

  if (tagName == null) {
    return null;
  }

  let childs = null;

  tagName = tagName.toLowerCase();

  switch (tagName) {
    case 'script':
      break;
    default:
      childs = Array.from(dom.childNodes);
      break;
  }

  return childs;
}

//-------------------------------------------
function getCreateFun() {
  const Vnode = $GM.get('Vnode');

  return function C(nodeName, tagName, parent) {
    return new Vnode(nodeName, tagName, parent);
  }
}
//-------------------------------------------
// 釋放記憶體
function domNodesClear(list = []) {

  if (!list.length) {
    return;
  }
  const $util = $GM.get('util');

  $util.nextStep(function () {
    while (list.length > 0) {
      let node = list.pop();
      node.clear();
    }
  });
}

export default Compile;



