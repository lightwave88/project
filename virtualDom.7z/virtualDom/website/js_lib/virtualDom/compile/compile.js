// debugger;
import $GM from '../g_module.js';
import { domNode } from './node/index.js';
import { TemplateHandle } from './templateHandle.js';
import { template_varNames, compileConfig } from './compile_config.js';

const $domNode = domNode;

const $reg_1 = /^script$/i;
const $reg_2 = /^#text$/i;

// 編譯爲 renderFun
class Compile {

	$tempNodeList = [];

	$emptyNodes = [];

	// <b-slot>
	// slotName_list = new Set();

	// <b-slot> 裏的模板內容
	// 須在稍後編譯
	$slotTemplates = {};

	keeps = {};
	keepAlls = {};

	$rootNode;

	$fun_args;
	
	//----------------------------------------------------------------------------
	constructor() {

	}
	//----------------------------------------------------------------------------
	// 必須注意 dom = null 的問題
	byDom(dom) {
		return this.main(dom);
	}
	//----------------------------------------------------------------------------
	byText(text) {

	}
	//----------------------------------------------------------------------------
	main(dom) {
		debugger;
		this._loopChild(dom);

		// 編譯 <b-slot> 內部的模板
		this._compileSlotTemplate();

		let content = this._buildFactory_1();

		// debugger;
		// console.dir(content);

		content = this._buildFactory_2(content);

		debugger;
		console.dir(content);


		let fun = this._buildFactory_3(content);
		return;

		debugger;
		let tempHandle = this._buildTempHandle(fun);

		return tempHandle;
	}
	//----------------------------------------------------------------------------
	_loopChild(dom) {
		let $tempList = [];

		// 初始化
		let tempNode = this._getTempNode({
			dom
		});

		$tempList.push(tempNode);
		//----------------------------
		let index = 0;

		while (true) {
			console.dir($tempList);
			debugger;

			let i = index++;

			// 拜訪所有 dom
			let tempNode = $tempList[i];
			if (tempNode == null) {
				break;
			}
			//-----------------------
			if (this._isEmptyText(tempNode)) {
				// 空的文字節點
				$tempList[i] = null;
				continue;
			}

			let domNode = $domNode.getInstance(tempNode);


			// 記錄特殊 node
			this._isSlotTag(domNode);

			// 置換節點
			$tempList[i] = domNode;
			//-----------------------
			// 處理子節點
			// 處理子節點
			let childDoms = this._is_needCheckChild(domNode);

			if (childDoms == null) {
				// 不需處理子節點的 dom
				continue;
			}
			// 若有出現 <script>
			let scripts = [];
			// 要檢查的列表
			// let checkList = [];

			let k = 0;

			while (true) {
				debugger;
				let p = domNode;
				let j = k++;
				let node = childDoms[j];
				if (node == null) {
					break;
				}

				let dom;
				let nodeName;

				if (node instanceof TempNode) {
					dom = node.dom;
					nodeName = node.nodeName;
				} else {
					dom = node;
					nodeName = dom.nodeName.toLowerCase();
				}

				debugger;
				//------------------

				if (this._isEmptyNode(nodeName)) {
					// 碰到空 dom 如 <template>
					k = j;
					let childs = this._getEmptyNodeChilds(nodeName, dom);

					if (childs != null && childs.length > 0) {
						let args = [j, 1];
						args = args.concat(childs);
						Array.prototype.splice.apply(childDoms, args);
					} else {
						childDoms.splice(j, 1);
					}
					continue;
				}
				//------------------
				if (this._isScript(nodeName, dom) && !scripts.includes(j)) {
					scripts.push(j);
				}
				//------------------

				debugger;
				if (!(node instanceof TempNode)) {
					k = j;
					dom = node;
					let tempNode = this._getTempNode({
						dom: dom,
						parent: p,
						nodeName,
					});
					childDoms[j] = tempNode;
					continue;
				} else {

					if (node.parent == null) {
						node.parent = p;
					}

				}
			} // endWhile

			// debugger;

			// 檢查 node.is_static
			this._checkStatic(childDoms, scripts);

			scripts.length = 0;

			// debugger;
			$tempList = $tempList.concat(childDoms);

		} // endWhile

		//------------------
		this.$rootNode = $tempList[0];

		this.$tempNodeList = $tempList;
	}
	//----------------------------------------------------------------------------
	// 處理 <b-slot>
	_isSlotTag(domNode) {

		// console.dir(domNode);

		let dom = domNode.dom;

		let tagName = dom.tagName || '';

		if (!/^b-slot$/i.test(tagName)) {
			return;
		}
		//------------------
		const $util = $GM.get('util');

		// <b-slot> 若有內容
		let childList = $util.clear2SideEmptyDom(dom);

		if (childList.length > 0) {

			let id = dom.getAttribute('id');

			if (id in this.$slotTemplates) {
				throw new Error(`<b-slot> templateName(${key}) has repeat`);
			}

			let rootDom = document.createDocumentFragment;
			childList.forEach(d => {
				rootDom.appendChild(d);
			});

			this.$slotTemplates[id] = rootDom;
		}
	}
	//----------------------------------------------------------------------------
	_is_needCheckChild(domNode) {
		// debugger;

		const dom = domNode.dom;
		let nodeName = domNode.nodeName;

		let childs = null;

		switch (nodeName) {
			case 'script':
				break;
			case 'template':
				let content = dom.content;
				childs = Array.from(content.childNodes);
				break;
			default:
				if (dom.childNodes != null) {
					childs = Array.from(dom.childNodes);
				}
				break;
		}

		if (Array.isArray(childs) && childs.length == 0) {
			childs = null;
		}
		return childs;
	}
	//----------------------------------------------------------------------------
	_checkStatic(list = [], markList = []) {
		if (markList.length < 2) {
			return;
		}

		let end = markList[markList.length - 1];
		let start = markList[0];

		for (let i = start; i <= end; i++) {
			let tempNode = list[i];
			if (tempNode.isStatic == null) {
				tempNode.isStatic = false;
			}
		}
	}
	//----------------------------------------------------------------------------
	// 繞過示意用但不輸出的空 dom
	// <template> <b-static>
	_getEmptyNodeChilds(nodeName, dom) {
		let childs = null;

		switch (nodeName) {
			case 'template':
				let content = dom.content;
				childs = Array.from(content.childNodes);
				childs = childs.map(c => {
					return this._getTempNode({
						dom: c
					});
				});
				break;
			case 'b-static':
				childs = Array.from(dom.childNodes);
				childs = childs.map(c => {
					return this._getTempNode({
						dom: c,
						isStatic: true
					});
				});
			default:
				break;
		}
		return childs;
	}
	//----------------------------------------------------------------------------
	// 是否只是示意的空 dom
	_isEmptyNode(nodeName) {
		let res = false;

		switch (nodeName) {
			case 'b-static':
			case 'template':
				res = true;
				break;
		}
		return res;
	}
	//----------------------------------------------------------------------------
	_isScript(tagName) {
		return $reg_1.test(tagName);
	}
	//----------------------------------------------------------------------------
	// 有爭議
	// 略過空的文字節點可以加快節點樹的操作
	_isEmptyText(tempNode) {		

		let { dom, nodeName } = tempNode;

		if ($reg_2.test(nodeName)) {
			debugger;
			let text = dom.nodeValue.trim();
			if (!text.length) {
				// 空的文字節點
				return true;
			}
		}
		return false;
	}
	//----------------------------------------------------------------------------
	_getTempNode(config = {}) {
		return new TempNode(config, this);
	}
	//----------------------------------------------------------------------------
	// 編譯 <b-slot> 內部的模板
	_compileSlotTemplate() {
		debugger;

		const slotTemplates = this.$slotTemplates;

		for (let key in slotTemplates) {
			debugger;
			let rootDom = slotTemplates[key];

			if (rootDom == null) {
				continue;
			}

			let compile = new Compile();

			// 建造產生 vnode 的工廠函式
			let vnodeFactory = compile.byDom(rootDom);

			if (vnodeFactory == null) {
				// 建立 render_fun 失敗
				delete slotTemplates[key];
			} else {
				slotTemplates[key] = vnodeFactory;
			}

		}
	}
	//----------------------------------------------------------------------------
	// 打造 vnode_factory
	_buildFactory_1() {
		let domNode;

		let nodeList = this.$tempNodeList;

		let i = nodeList.length;

		console.log('length=%s', i);

		while (--i >= 0) {
			domNode = nodeList[i];
			if(domNode == null){
				continue;
			}
			domNode.callParent();
		}

		// 釋放記憶體
		// domNodesClear(nodeList);

		// debugger;
		// 工廠函式文本
		let fun_text = (domNode == null ? null : domNode.getResult());

		return fun_text;
	}
	//----------------------------------------------------------------------------
	_buildFactory_2(fun_text) {
		this.$fun_args = ['data', 'createVnode', '$system', 'compute'];

		const {
			var_root,
			var_vnode,
			var_createVnode,
			var_sys,
		} = template_varNames;

		const fun_content = `
		debugger;

		const ${var_createVnode} = createVnode;
		const ${var_sys} = $system;
		const $compute = compute;
		const $data = data;
		let ${var_vnode} = null;
		//------------------
		data = null;
		$system = null;
		compute = null;
		createVnode = null;

		debugger;
		//------------------
		${fun_text}

		return (typeof ${var_root} == "undefined"? null: ${var_root});`;

		return fun_content;
	}
	//----------------------------------------------------------------------------
	_buildFactory_3(content) {
		let args = this.$fun_args

		let fun;
		try {
			fun = new Function(args[0], args[1], args[2], args[3], content);
		} catch (error) {
			console.log('build vnode_factory error')
			throw error;
		}
		return fun;
	}
	//----------------------------------------------------------------------------
	_buildTempHandle(fun) {

		let config = { slotTemplate: (this.$slotTemplates) };

		let handle = new TemplateHandle(fun, config);
		return handle;
	}
}
//==============================================================================
// 攜帶資訊用
class TempNode {
	dom;
	parent;
	isStatic;

	// 編譯者
	compile;
	nodeName;

	constructor(_config = {}, compile) {

		let config = {
			dom: null,
			parent: null,
			isStatic: null,
			compile: compile,
			nodeName: null,
		};

		Object.assign(config, _config);

		this.dom = config.dom;
		this.parent = config.parent;
		this.isStatic = config.isStatic;
		this.compile = config.compile;
		this.nodeName = config.nodeName;

		if (this.nodeName == null) {
			this.nodeName = this.dom.nodeName.toLowerCase();
		}

	}
}

export { Compile };
// export { template_varNames };
