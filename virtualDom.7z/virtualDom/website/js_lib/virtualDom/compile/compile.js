// debugger;
import $GM from '../g_module.js';
import { domNode, temp_varnames } from './node/index.js';
const $domNode = domNode;

// 編譯爲 renderFun
class Compile {

  emptyNodes = [];

  // <b-slot>
  slot_list = new Set();

  // <b-slot> 裏的模板內容
  // 須在稍後編譯
  slotTemp_list = {};

  keep_list = new Set();
  keepAll_list = new Set();
  //----------------------------------------------------------------------------
  constructor() {

  }
  //----------------------------------------------------------------------------
  // 必須注意 dom = null 的問題
  byDom(dom) {
    debugger;

    let $tempList = [];

    let tempNode = this._getTempNode({ dom });
    $tempList.push(tempNode);
    //----------------------------    
    let index = 0;

    while (true) {
      console.dir($tempList);
      debugger;

      let i = index++;

      // 拜訪所有 dom
      let tempNode = $tempList[i];
      if (tempNode == null) {
        break;
      }
      //-----------------------

      let domNode = $domNode.getInstance(tempNode);
      // 檢查 domNode 特性
      this._is_emptyNode(domNode);
      this._is_keepAlive(domNode);

      // 記錄特殊 node
      this._isSlotTag(domNode);

      // 置換節點
      $tempList[i] = domNode;
      //-----------------------
      // 處理子節點

      let childDoms = this._is_needCheckChild(domNode);

      if (childDoms == null) {
        // 不需處理子節點的 dom
        continue;
      }
      // 要檢查的列表      

      let checkList = childDoms.map((el) => {
        let p = domNode;

        let tempNode = this._getTempNode({
          dom: el,
          parent: p,
        });

        $tempList.push(tempNode);
        return tempNode;
      });

      // 檢查 node.is_static
      this._checkStatic(checkList);

    } // endWhile

    //------------------   

    this._processEmptyNode();

    // 編譯 <b-slot> 內部的模板
    this._aboutSlotTemplate();
    //------------------
    // 打造 renderFun

    let res = this._getFactoryContent($tempList);

    return res;
  }
  //----------------------------------------------------------------------------
  byText(text) {

  }
  //----------------------------------------------------------------------------
  _processEmptyNode() {
    this.emptyNodes.forEach(node => {
      node.switchChildParent();
    });
  }
  //----------------------------------------------------------------------------
  // 打造 vnode_factory
  _getFactoryContent(nodeList) {
    let domNode;

    let i = nodeList.length;
    while (--i >= 0) {
      domNode = nodeList[i];
      domNode.callParent();
    }

    // 釋放記憶體
    // domNodesClear(nodeList);

    // debugger;
    // 工廠函式文本
    let fun_text = (domNode == null ? null : domNode.getResult());

    return fun_text;
  }
  //----------------------------------------------------------------------------
  _isSlotTag(domNode) {

    const $util = $GM.get('util');

    let dom = domNode.dom;

    let tagName = dom.tagName || null;

    if (tagName == null) {
      return;
    }
    if (!/^b-slot$/i.test(tagName)) {
      return;
    }

    // 取得 slot 的名稱
    // 取得 slot 模板的名稱
    let slot_name = (dom.hasAttribute('name') ? dom.getAttribute('name') : null);
    let tempName = (dom.hasAttribute('b-template') ? dom.getAttribute('b-template') : null);

    if (!slot_name) {
      throw new Error('<b-slot> no attr("name")');
    }
    this.slot_list.add(slot_name);

    // <b-slot> 若有內容
    let childList = $util.clear2SideEmptyDom(dom);

    if (childList.length > 0) {
      let rootDom = document.createDocumentFragment;
      childList.forEach(d => {
        rootDom.appendChild(d);
      });

      let key = tempName || slot_name;

      if (key in this.slotTemp_list) {
        throw new Error(`<b-slot> templateName(${key}) has repeat`);
      }

      slotTemp_list[key] = rootDom
    }

  }
  //----------------------------------------------------------------------------
  _is_needCheckChild(domNode) {
    debugger;

    const dom = domNode.dom;
    let tagName = domNode.tagName;

    let childs = null;

    if (tagName == null) {
      if (dom.childNodes != null) {
        childs = Array.from(dom.childNodes);
      }
    } else {

      switch (tagName) {
        case 'script':
          break;
        case 'template':
          let content = dom.content;
          childs = Array.from(content.childNodes);
          break;
        default:
          childs = Array.from(dom.childNodes);
          break;
      }
    }

    if(Array.isArray(childs) && childs.length == 0){
      childs = null;
    }

    return childs;
  }
  //----------------------------------------------------------------------------
  // 是否是指示性標籤，而無本質作用
  // 指示性標籤不能有子節點
  _is_emptyNode(domNode) {

    let res = 0;

    let nodeName = domNode.nodeName;

    switch (nodeName) {
      // case 'keep-alive':
      case 'template':
        // 完全沒實體作用的節點
        res = 2;
        break;
      case 'b-for':
      case 'b-if':
      case 'b-if-else':
      case 'b-else':
        res = 1;
        break;
      default:
        break;
    }

    domNode.isEmpty = res;

    if (res > 1) {
      this.emptyNodes.push(domNode);
    }
  }
  //----------------------------------------------------------------------------
  // 是否是 <keep-alive>
  _is_keepAlive(domNode) {

    let name;
    if (typeof domNode.keep == 'string') {

      name = domNode.keep;
      if (this.keep_list.has(name)) {
        throw new Error(`b-keep(${name}) has not only one`);
      }
      this.keep_list.add(name);
    } else if (typeof domNode.keepAll == 'string') {

      name = domNode.keepAll;
      if (this.keepAll_list.has(name)) {
        throw new Error(`b-keepAll(${name}) has not only one`);
      }
      this.keepAll_list.add(name);
    }
  }
  //----------------------------------------------------------------------------
  // 檢查 node.is_static
  _checkStatic(list) {
    let start, end;

    list.forEach((tempNode, i) => {

      let dom = tempNode.dom;

      let tagName = dom.tagName || '';
      tagName = tagName.toLowerCase();

      switch (tagName) {
        case 'b-for':
        case 'b-if':
        case 'b-if-else':
        case 'b-else':
          tempNode.isStatic = false;
          break;
        case 'script':
          if (start == null) {
            start = i;
          }
          end = i;
        default:
          tempNode.isStatic = true;
          break;
      }
    });

    if (start == null) {
      return;
    }
    //------------------
    // 在 <script> 區塊裏
    for (let i = (start + 1); i < end; i++) {
      let tempNode = list[i];
      let dom = tempNode.dom;

      if (dom.hasAttribute('b-static')) {
        // 若使用者有設定 attr.b-static
        let value = dom.getAttribute('b-static')
        let is_static = new Boolean(value);
        if (is_static) {
          continue;
        }
      }
      tempNode.isStatic = false;
    }
  }
  //----------------------------------------------------------------------------
  _getTempNode(config = {}) {
    let node = {
      dom: null,
      parent: null,
      isStatic: true,
    }
    Object.assign(node, config);
    return node;
  }
  //----------------------------------------------------------------------------
  // 編譯 <b-slot> 內部的模板
  _aboutSlotTemplate() {

  }
}


export { Compile };
export { temp_varnames };




