debugger;
import $GM from '../g_module.js';

// 編譯爲 renderFun
class Compile {
  constructor() {
    this.$tempList = [];

    // 記錄父子關係
    this.$parentMap = {};
  }
  //-------------------------------------------
  byDom(dom) {
    debugger;

    let $tempList = this.$tempList;
    let $parentMap = this.$parentMap;

    $tempList.push(dom);
    //------------------
    // domNode link
    const DomNode = $GM.get('DomNode');

    for (let i = 0; i < $tempList.length; i++) {
      // debugger;

      // 拜訪所有 dom
      let dom = $tempList[i];
      let tagName = dom.tagName;

      let parent = null;
      if (i in $parentMap) {
        // 檢查父子關係，是否由所屬的 parent
        parent = $parentMap[i];
        delete $parentMap[i];
      }
      let domNode = DomNode.getInstance(dom, parent);

      // <template> domNode = null
      if (parent != null && domNode != null) {
        // 父子關係
        parent.append(domNode);
      }

      // 置換節點
      $tempList[i] = domNode;
      //-----------------------
      // 處理子節點

      let childs;
      if ((childs = is_needCheckChild(dom)) == null) {
        // 不需處理子節點的 dom
        continue;
      }

      childs.forEach(el => {
        let index = $tempList.length;
        // 記錄 link
        $parentMap[index] = domNode || parent;
        $tempList.push(el);
      });
    }
    //------------------
    let keyList = Object.keys($parentMap);
    if (keyList.length) {
      throw new Error('no clear');
    }
    debugger;
    //------------------
    // 打造 renderFun

    let fun_context = this._buildRenderFun_1();

    console.log(fun_context);
    //------------------
    let render_fun = this._buildRenderFun_2(fun_context);

    return render_fun;
  }
  //-------------------------------------------
  _buildRenderFun_1() {
    debugger;

    let domNode;
    for (let i = this.$tempList.length; i > 0; i--) {
      // debugger;
      let j = i - 1;
      domNode = this.$tempList[j];

      if (domNode == null) {
        // <template>
        continue;
      }

      domNode.callParent();
    }
    // debugger;
    // 工廠函式文本
    let fun_context = domNode.getResult();

    return fun_context;
  }

  //-------------------------------------------
  _buildRenderFun_2(fun_context) {
    debugger;
    let r_vnode = null;

    const DomNode = $GM.get('DomNode');

    // 變數名稱
    let createVarName = DomNode.get_varName('createVarName');

    let factory;

    try {
      factory = new Function(createVarName, 'data', fun_context);
    } catch (error) {
      console.log('build factory error(%s)', error);
    }

    if (factory == null) {
      return r_vnode;
    }
    //------------------
    const Vnode = $GM.get('Vnode');

    function C(nodeName, tagName, parent) {
      return Vnode.getInstance(nodeName, tagName, parent);
    }

    console.log(factory);

    // 渲染函式
    let render_fun = function (data) {
      debugger;
      data = Object.assign({}, data);
      return factory(C, data);
    }

    return render_fun;
  }
}
//------------------------------------------------------------------------------
// 是否要處理這個 dom.childs 
function is_needCheckChild(dom) {

  let tagName = dom.tagName || null;

  if (tagName == null) {
    return null;
  }

  let childs = null;

  tagName = tagName.toLowerCase();

  switch (tagName) {
    case 'script':
      break;
    default:
      childs = Array.from(dom.childNodes);
      break;
  }

  return childs;
}

//------------------------------------------------------------------------------


export default Compile;



