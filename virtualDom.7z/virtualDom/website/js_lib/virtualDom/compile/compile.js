// debugger;
import $GM from '../g_module.js';
import { domNode, temp_varnames } from './node/index.js';
const $domNode = domNode;

// 編譯爲 renderFun
class Compile {

  emptyNodes = [];

  // <b-slot>
  slotName_list = new Set();

  // <b-slot> 裏的模板內容
  // 須在稍後編譯
  slotTemp_list = {};

  keep_list = new Set();
  keepAll_list = new Set();

  rootNode;
  //----------------------------------------------------------------------------
  constructor() {

  }
  //----------------------------------------------------------------------------
  // 必須注意 dom = null 的問題
  byDom(dom) {
    // debugger;

    let $tempList = [];

    let tempNode = this._getTempNode({ dom });
    $tempList.push(tempNode);
    //----------------------------
    let index = 0;

    while (true) {
      console.dir($tempList);
      debugger;

      let i = index++;

      // 拜訪所有 dom
      let tempNode = $tempList[i];
      if (tempNode == null) {
        break;
      }
      //-----------------------

      let domNode = $domNode.getInstance(tempNode);

      // 記錄特殊 node
      this._isSlotTag(domNode);

      // 置換節點
      $tempList[i] = domNode;
      //-----------------------
      // 處理子節點

      let childDoms = this._is_needCheckChild(domNode);

      if (childDoms == null) {
        // 不需處理子節點的 dom
        continue;
      }
      // 若有出現 <script>
      let scripts = [];
      // 要檢查的列表
      let checkList = [];

      let k = 0;

      while (true) {
        debugger;

        let p = domNode;
        let i = k++;
        let node = childDoms[i];
        if (node == null) {
          break;
        }

        let dom;

        if (node instanceof TempNode) {
          dom = node.dom;
        } else {
          dom = node;
        }

        let nodeName = dom.nodeName || '';
        nodeName = nodeName.toLowerCase();

        let tempNode;

        if (this._isEmptyNode(nodeName)) {
          // 處理 <template>

          let childs = this._getEmptyNodeChilds(nodeName, dom);

          if (childs != null) {
            k = i;
            let args = [i, 1];
            args = args.concat(childs);
            Array.prototype.splice.apply(childDoms, args);
          }

        } else {
          // 一般 dom

          if (this._isScript(nodeName, dom)) {
            scripts.push(i);
          }

          if (node instanceof TempNode) {
            node.parent = p;
            tempNode = node;
          } else {
            tempNode = this._getTempNode({
              dom: dom,
              parent: p,
            });
          }
          checkList.push(tempNode);
          $tempList.push(tempNode);
        }
      } // endWhile

      if (scripts.length > 1) {
        // 檢查 node.is_static
        this._checkStatic(checkList, scripts);
      } else {
        checkList.length = 0;
        scripts.length = 0;
      }

      $tempList = $tempList.concat(checkList);

    } // endWhile

    //------------------

    // 編譯 <b-slot> 內部的模板
    this._aboutSlotTemplate();

    this.rootNode = $tempList[0];
    //------------------
    // 打造 renderFun

    let res = this._getFactoryContent($tempList);

    console.dir(this);

    return res;
  }
  //----------------------------------------------------------------------------
  byText(text) {

  }
  //----------------------------------------------------------------------------
  addKeep(name) {
    if (!name) {
      throw new Error('.....');
    }
    if (keep_list.has(name)) {
      throw new Error('.....');
    }
    keep_list.add(name);
  }
  //----------------------------------------------------------------------------
  addKeepAll(name) {
    if (!name) {
      throw new Error('.....');
    }
    if (keepAll_list.has(name)) {
      throw new Error('.....');
    }
    keepAll_list.add(name);
  }
  //----------------------------------------------------------------------------
  // 打造 vnode_factory
  _getFactoryContent(nodeList) {
    let domNode;

    let i = nodeList.length;
    while (--i >= 0) {
      domNode = nodeList[i];
      domNode.callParent();
    }

    // 釋放記憶體
    // domNodesClear(nodeList);

    // debugger;
    // 工廠函式文本
    let fun_text = (domNode == null ? null : domNode.getResult());

    console.log(fun_text);

    return fun_text;
  }
  //----------------------------------------------------------------------------
  // 處理 <b-slot>
  _isSlotTag(domNode) {
    let dom = domNode.dom;

    let tagName = dom.tagName || null;

    if (tagName == null) {
      return;
    }

    if (!/^b-slot$/i.test(tagName)) {
      return;
    }
    //------------------
    // 取得 slot 的名稱
    // 取得 slot 模板的名稱
    let slot_name = (dom.hasAttribute('name') ? dom.getAttribute('name') : null);
    let tempName = (dom.hasAttribute('b-template') ? dom.getAttribute('b-template') : null);

    if (!slot_name) {
      throw new Error('<b-slot> no attr("name")');
    }
    this.slotName_list.add(slot_name);

    const $util = $GM.get('util');

    // <b-slot> 若有內容
    let childList = $util.clear2SideEmptyDom(dom);

    if (childList.length > 0) {
      let rootDom = document.createDocumentFragment;
      childList.forEach(d => {
        rootDom.appendChild(d);
      });

      let key = tempName || slot_name;

      if (key in this.slotTemp_list) {
        throw new Error(`<b-slot> templateName(${key}) has repeat`);
      }

      slotTemp_list[key] = rootDom
    }
  }
  //----------------------------------------------------------------------------
  _is_needCheckChild(domNode) {
    // debugger;

    const dom = domNode.dom;
    let tagName = domNode.tagName;

    let childs = null;

    if (tagName == null) {
      if (dom.childNodes != null) {
        childs = Array.from(dom.childNodes);
      }
    } else {

      switch (tagName) {
        case 'script':
          break;
        case 'template':
          let content = dom.content;
          childs = Array.from(content.childNodes);
          break;
        default:
          childs = Array.from(dom.childNodes);
          break;
      }
    }

    if (Array.isArray(childs) && childs.length == 0) {
      childs = null;
    }
    return childs;
  }
  //----------------------------------------------------------------------------

  _checkStatic(list = [], markList = []) {
    let end = markList[markList.length - 1];
    let start = markList[0];

    for (let i = start; i <= end; i++) {
      let tempNode = list[i];
      if (tempNode.isStatic == null) {
        tempNode.isStatic = false;
      }
    }
  }

  // 檢查 node.is_static
  _$checkStatic(list = []) {
    // debugger;

    let start, end;

    list.forEach((tempNode, i) => {
      // debugger;

      let dom = tempNode.dom;

      let tagName = dom.tagName || '';
      tagName = tagName.toLowerCase();

      switch (tagName) {
        case 'b-for':
        case 'b-if':
        case 'b-if-else':
        case 'b-else':
          tempNode.isStatic = false;
          break;
        case 'script':
          if (start == null) {
            start = i;
          }
          end = i;
          tempNode.isStatic = false;
          break;
        default:
          tempNode.isStatic = true;
          break;
      }
    });

    if (start == null) {
      return;
    }
    //------------------
    // 在 <script> 區塊裏
    for (let i = (start + 1); i < end; i++) {
      let tempNode = list[i];
      tempNode.isStatic = false;
    }
  }
  //----------------------------------------------------------------------------
  // 繞過示意用但不輸出的空 dom
  // <template> <b-static>
  _getEmptyNodeChilds(nodeName, dom) {
    let childs = null;

    switch (nodeName) {
      case 'template':
        let content = dom.content;
        childs = Array.from(content.childNodes);
        childs = childs.map(c => {
          return this._getTempNode({ dom: c });
        });
        break;
      case 'b-static':
        childs = Array.from(dom.childNodes);
        childs = childs.map(c => {
          return this._getTempNode({ dom: c, isStatic: true });
        });
      default:
        break;
    }

    if (Array.isArray(childs) && childs.length == 0) {
      childs = null;
    }
    return childs;
  }
  //----------------------------------------------------------------------------
  _isEmptyNode(nodeName) {
    let res = false;

    switch (nodeName) {
      case 'b-static':
      case 'template':
        res = true;
        break;
    }
    return res;
  }
  //----------------------------------------------------------------------------
  _isScript(tagName) {
    return /^script$/.test(tagName);
  }
  //----------------------------------------------------------------------------
  _getTempNode(config = {}) {
    let c = {
      dom: null,
      parent: null,
      isStatic: null,
      compile: this,
    }
    Object.assign(c, config);
    return new TempNode(c);
  }
  //----------------------------------------------------------------------------
  // 編譯 <b-slot> 內部的模板
  _aboutSlotTemplate() {
    debugger;

    for (let key in this.slotTemp_list) {
      let rootDom = this.slotTemp_list[key];

      let compile = new Compile();

      // 建造產生 vnode 的工廠函式
      let vnodeFactory = compile.byDom(rootDom);

      if (vnodeFactory == null) {
        // 建立 render_fun 失敗
        delete this.slotTemp_list[key];
      } else {
        this.slotTemp_list[key] = vnodeFactory;
      }

    }

  }
}
//==============================================================================
// 攜帶資訊用
class TempNode {
  dom;
  parent;
  isStatic;

  // 編譯者
  compile;
  constructor(config = {}) {

    this.dom = config.dom;
    this.parent = config.parent;
    this.isStatic = config.isStatic;
    this.compile = config.compile;
  }
}

export { Compile };
export { temp_varnames };
