'use strict';
import { TemplateInnerSys } from './templateInnerSys.js';

// view.slot 會用到
let HANDLE_ID = 0;


// 使用者操作
// 用於產生 vnode
class VnodeFactoryHandle {

  // view.slot 會用到
  id;

  // 核心 vnodefactory
  // 兩者是 1:1
  $_fun;
  //------------------
  // 來自模板編譯
  // 會從 dom 模板中得到 slotTemplate
  $_slotTemplates = {};
  //------------------
  // 來自模板執行
  $_keeps = [];

  // 來自模板執行
  $_keepAlls = [];

  // slot 對應的 vnode
  $_slotParents = {};
  //----------------------------------------------------------------------------
  constructor(fun, config = {}) {

    this.id = `f_${HANDLE_ID++}`;

    this.$_fun = fun;

    //------------------
    // 會從 dom 模板中得到 slotTemplate
    let { slotTemplates, keep, keepAll } = config;

    if (slotTemplates != null) {
      Object.assign(this.$_slotTemplates, slotTemplates);
    }

    if (keep != null) {
      this.$_keeps = new Set(keep);
    }

    if (keepAll) {
      this.$_keepAlls = new Set(keepAll);
    }
  }
  //----------------------------------------------------------------------------
  // 產生 vnode
  render(data, config = {}) {
    debugger;

    // reset
    this.reset();

    let { view, context } = config;

    // 收集 factory 內部要用的模組

    // 取得 vnode_factory 裏的 system
    const sys = new TemplateInnerSys(data, config);

    const $compute = sys.getComputeFun();

    const Vnode = $GM.get('Vnode');

    const $createVnode = Vnode.createVnode;

    debugger;

    // 把所有東西灌入工廠
    try {
      debugger;
      // 執行工廠
      this.$_fun.call((view || context), data, $createVnode, sys, $compute);
    } catch (error) {
      console.log('render error')
      throw error;
    }
    //------------------
    // 取得 render 後收集的資料

    // keep
    let keep = sys.getKeep();
    if (Array.isArray(keep)) {
      this.$_keeps = this.$_keeps.concat(keep);
    }

    // keepAll
    let KeepAll = sys.getKeepAll();
    if (Array.isArray(KeepAll)) {
      this.$_keepAlls = this.$_keepAlls.concat(keepAll);
    }

    // slot
    let slotParents = sys.getSlotParents();
    Object.assign(this.$_slotParents, slotParents);

    let vnode = sys.getRootVnode();

    return vnode;
  }
  //----------------------------------------------------------------------------
  // 取得 <b-slot> 裏面的 template
  // 假如模板有設定的話
  getSlotTemplate(id) {
    let res = null;
    if (id in this.$_slotTemplates) {
      res = this.$_slotTemplates[id];
    }
    return res;
  }
  //----------------------------------------------------------------------------
  // render 的再包裝
  makeRender(config = {}) {
    const $this = this;
    return function render(data) {
      $this.render(data, config);
    };
  }
  //----------------------------------------------------------------------------

  // render 後收集的資料
  getRenderData() {
    let data = {
      keeps: (this.$_keeps),
      keepAlls: (this.$_keepAlls),
      slotParents: (this.$_slotParents),
    };

    return data;
  }

  reset() {
    this.$_keeps.length = 0;
    this.$_keepAlls.length = 0;

    for (let k in this.$_slotParents) {
      delete this.$_slotParents[k];
    }
  }
}

export { VnodeFactoryHandle };
