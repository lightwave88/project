'use strict';
import { TemplateInnerSys } from './templateInnerSys.js';

// view.slot 會用到
let HANDLE_ID = 0;


// 使用者操作
// 用於產生 vnode
class VnodeFactoryHandle {

  // view.slot 會用到
  $_uid;

  // 核心 vnodefactory
  // 兩者是 1:1
  $_fun;
  //------------------
  // 來自模板編譯
  // 會從 dom 模板中得到 slotTemplate
  $_slotTemplate = {};
  //------------------
  // 來自模板執行
  $_keep = [];

  // 來自模板執行
  $_keepAll = [];
  //----------------------------------------------------------------------------
  constructor(fun, config = {}) {

    this.$_uid = HANDLE_ID++;

    this.$_fun = fun;

    //------------------
    // 會從 dom 模板中得到 slotTemplate
    let { slotTemplate, keep, keepAll } = config;

    if (slotTemplate != null) {
      Object.assign(this.$_slotTemplate, slotTemplate);
    }

    if (keep != null) {
      this.$_keep = new Set(keep);
    }

    if (keepAll) {
      this.$_keepAll = new Set(keepAll);
    }
  }
  //----------------------------------------------------------------------------
  // 產生 vnode
  render(data, config = {}) {
    debugger;

    // reset
    this.$_keep.length = 0;
    this.$_keepAll.length = 0;

    let { view, context } = config;

    // 收集 factory 內部要用的模組

    // 取得 vnode_factory 裏的 system
    const sys = new TemplateInnerSys(data, config);

    const $compute = sys.getComputeFun();

    const Vnode = $GM.get('Vnode');

    const $createVnode = Vnode.createVnode;

    debugger;

    // 把所有東西灌入工廠
    try {
      debugger;
      // 執行工廠
      this.$_fun.call((view || context), data, $createVnode, sys, $compute);
    } catch (error) {
      console.log('render error')
      throw error;
    }

    // 取得要的節點
    let keep = sys.getKeep();
    if (Array.isArray(keep)) {
      this.$_keep = this.$_keep.concat(keep);
    }
    let KeepAll = sys.getKeepAll();
    if (Array.isArray(KeepAll)) {
      this.$_keepAll = this.$_keepAll.concat(keepAll);
    }
    let vnode = sys.getRootVnode();

    return vnode;
  }
  //----------------------------------------------------------------------------
  // 取得 <b-slot> 裏面的 template
  // 假如模板有設定的話
  getSlotTemplate(id) {
    let res = null;
    if (id in this.$_slotTemplate) {
      res = this.$_slotTemplate[id];
    }
    return res;
  }
  //----------------------------------------------------------------------------
  // render 的再包裝
  makeRender(config = {}) {
    const $this = this;
    return function render(data) {
      $this.render(data, config);
    };
  }
  //----------------------------------------------------------------------------
  // 取得 fun 執行後有 attr.keep 的 vnode
  // slot.keep
  getKeep() {
    if (!this.$_keep.length) {
      return null;
    }
    return this.$_keep.slice();
  }

  // 取得 fun 執行後有 attr.keepAll 的 vnode
  getKeepAll() {
    if (!this.$_keepAll.length) {
      return null;
    }
    return this.$_keepAll.slice();
  }
  //----------------------------------------------------------------------------
}

export { VnodeFactoryHandle };
