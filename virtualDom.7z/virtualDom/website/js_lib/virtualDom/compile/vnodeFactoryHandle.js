import { TemplateInnerSys } from './templateInnerSys.js';

// 使用者操作
// 用於產生 vnode
class VnodeFactoryHandle {
  // 核心 vnodefactory
  $$$fun;
  $$$slotTemplate = {};
  //----------------------------------------------------------------------------
  constructor(fun, config = {}) {
    this.$$$fun = fun;

    // 會從 dom 模板中得到 slotTemplate
    let { slotTemplates } = config;

    if (slotTemplate != null) {
      Object.assign(this.$$$slotTemplate, slotTemplate);
    }
  }
  //----------------------------------------------------------------------------
  // 產生 vnode
  render(data, config = {}) {
    debugger;

    let { view, context } = config;

    // 收集 factory 內部要用的模組

    // 取得 vnode_factory 裏的 system
    const sys = new TemplateInnerSys(data, config);

    const $compute = sys.getComputeFun();

    const Vnode = $GM.get('Vnode');

    const $createVnode = Vnode.createVnode;

    // 把所有東西灌入工廠
    let vnode;

    debugger;

    try {
      debugger;
      vnode = this.$$$fun.call((view || context), data, $createVnode, sys, $compute);
    } catch (error) {
      console.log('render error')
      throw error;
    }

    return vnode;
  }
  //----------------------------------------------------------------------------
  // 取得 <b-slot> 裏面的 template
  // 假如模板有設定的話
  getSlotTemplate(id) {
    let res = null;
    if (id in this.$$$slotTemplate) {
      res = this.$$$slotTemplate[id];
    }
    return res;
  }
  //----------------------------------------------------------------------------
  // render 的再包裝
  makeRender(config = {}) {
    const $this = this;
    return function render(data) {
      $this.render(data, config);
    };
  }
  
}

export { VnodeFactoryHandle };
