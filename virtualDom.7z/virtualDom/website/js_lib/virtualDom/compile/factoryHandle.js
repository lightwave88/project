'use strict';
import { TemplateInnerSys } from './templateInnerSys.js';

let $UID = 0;

// 使用者操作
// 用於產生 vnode
class FactoryHandle {

  // view.slot 會用到
  id;

  // 核心 vnodefactory
  // 兩者是 1:1
  $_fun;
  //------------------
  // 來自模板編譯
  // 會從 dom 模板中得到 slotTemplate
  $_slotTemplates = {};
  //------------------
  // 來自模板執行
  $_keeps = {};

  // 來自模板執行
  $_keepAlls = {};

  // slot 對應的 vnode
  $_slotParents = {};

  $_isSlot;

  $_content = '';
  //----------------------------------------------------------------------------
  constructor(config = {}) {
    debugger;

    const { fun, fun_content, slotTemplates } = config;

    this.id = 'vfactory_' + $UID++;
    this.$_content = fun_content;
    this.$_fun = fun;

    // 會從 dom 模板中得到 slotTemplate
    Object.assign(this.$_slotTemplates, slotTemplates);
  }
  //----------------------------------------------------------------------------
  // 若被 slot 呼叫，套嵌於另一個 vfactory 
  isSlot(data = {}) {
    this.$_isSlot = data;
  }
  //----------------------------------------------------------------------------
  // API
  // 產生 vnode
  render(data, config = {}) {
    debugger;

    // reset
    this.reset();

    let { view, context } = config;

    // 收集 factory 內部要用的模組

    // 取得 vnode_factory 裏的 system
    const sys = new TemplateInnerSys(data, config);

    if (this.$_isSlot != null) {
      sys.isSlot();
    }

    let _context = (view || context || null);
    debugger;

    // 把所有東西灌入工廠
    try {
      debugger;
      // 執行工廠
      this.$_fun.call(_context, sys);
    } catch (error) {
      console.log('render error')
      throw error;
    }
    //------------------
    // 取得 render 後收集的資料

    // keep
    let keep = sys.getKeep();
    Object.assign(this.$_keeps, keep);

    // keepAll
    let KeepAll = sys.getKeepAll();
    Object.assign(this.$_keepAlls, KeepAll);

    // slot
    let slotParents = sys.getSlotParents();
    Object.assign(this.$_slotParents, slotParents);

    //------------------
    // 若是 slot
    if (this.$_isSlot != null) {
      // 是 slot 環境
      // 重命名 keep,keepAll
      renameKeepNodes(this.$_isSlot, {
        keeps: this.$_keeps,
        keepAlls: this.$_keepAlls,
      });
      this.$_isSlot = null;
    }
    //------------------
    let vnode = sys.getRootVnode();
    debugger;

    console.dir(this);

    return vnode;
  }
  //----------------------------------------------------------------------------
  // 取得 <b-slot> 裏面的 template
  // 假如模板有設定的話
  getSlotTemplate(id) {
    let res = null;
    if (id in this.$_slotTemplates) {
      res = this.$_slotTemplates[id];
    }
    return res;
  }
  //----------------------------------------------------------------------------
  // render 的再包裝
  makeRender(config = {}) {
    const $this = this;
    return function render(data) {
      $this.render(data, config);
    };
  }
  //----------------------------------------------------------------------------

  // render 後收集的資料
  getRenderData() {
    let data = {
      keeps: (this.$_keeps),
      keepAlls: (this.$_keepAlls),
      slotParents: (this.$_slotParents),
    };

    return data;
  }
  //----------------------------------------------------------------------------
  reset() {
    this.$_keeps = {};
    this.$_keepAlls = {};

    for (let k in this.$_slotParents) {
      delete this.$_slotParents[k];
    }
  }
}

export { FactoryHandle };
//------------------------------------------------------------------------------
function renameKeepNodes(keepName, data = {}) {

  const { keeps, keepAlls } = data;

  for (let k in keeps) {
    let vnode = keeps[k];
    vnode.keep = keepName + vnode.keep;
  }

  for (let k in keepAlls) {
    let vnode = keeps[k];
    vnode.keepAll = keepName + vnode.keepAll;
  }
}
