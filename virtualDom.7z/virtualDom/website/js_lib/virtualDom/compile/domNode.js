import $GM from '../g_module.js';

const $C = '_';

// 計算屬性的開頭名
const $reg_1 = RegExp(`^${$C}`);
// 計算屬性的代號
const $reg_2 = /\{\{([^}]*)\}\}/;

const $reg_3 = /\\n$/;

// 輸出的文本是否要 format
const $format = true;

// parent 變數的代稱
const $rootVarName = '$_root';
const $parentVarName = "$_parent";
const $vnodeVarName = '$_vnode';
const $createVarName = '$_C';
const $fun_toString = "$_st";

// format 
const $space = 2;

const VAR_NAMES = {
  rootVarName: $rootVarName,
  parentVarName: $parentVarName,
  vnodeVarName: $vnodeVarName,
  createVarName: $createVarName
};


// 組織 render 函式用
// render 函式將 dom 轉爲 vnode
class DomNode {

  // 外部要使用
  static get_varName(key) {
    if (key in VAR_NAMES) {
      return VAR_NAMES[key];
    }
    return null;
  }

  constructor(dom, parent) {
    // for test
    this.level;
    this.dom = dom;
    this.parent = parent || null;
    this.childs = [];

    // 命令內容
    // 由 childs 上傳
    this.commandContent = [];

    this.isStatic = null;

    this._init();
  }
  //-------------------------------------------
  _init() {
    this.level = (this.parent == null ? 0 : (this.parent.level + 1));
  }
  //-------------------------------------------
  append(child) {
    this.childs.push(child);
  }
  //-------------------------------------------
  // API
  callParent() {
    // debugger;
    if (this.parent == null) {
      return;
    }
    // 檢查 no static 的區塊
    this.parent.checkCommandArea();
    //------------------
    // 不同種類標籤必須實作
    let res = this._getSelfCommand();

    this.parent.callByChild(res);

    res = null;
    this._clear();
  }
  //-------------------------------------------
  callByChild(text) {
    this.commandContent.unshift(text);
  }
  //-------------------------------------------
  // dom 是否是 static 節點
  setStatic(value) {
    if (this.isStatic != null) {
      return;
    }
    if (typeof value != 'boolean') {
      return;
    }
    this.isStatic = value;
  }
  //-------------------------------------------
  // API
  // 只有 root 有用
  getResult() {
    if (this.parent != null) {
      throw new Error('not root');
    }
    let res = `let ${$vnodeVarName} = null;\n`;
    res += this._getSelfCommand();
    res += `return ${$rootVarName};`;

    return res;
  }

  //-------------------------------------------
  // 取得命令內容
  _getSelfCommand() {
    throw new Error('need override _getSelfCommand()');
  }
  //-------------------------------------------
  // 清理不要的資料
  _clear() {
    throw new Error('need override _clear()');
  }
  //-------------------------------------------
  // text 有 {{}}
  // attr 是否由 data 控制 
  _ss(content, attr = null) {

    if (attr != null) {
      // 前後空白對 attr 無意義
      content = content.trim();
    }

    let list = [];

    let c = content;

    while (true) {
      let r = $reg_2.exec(c);

      if (r == null) {
        (c.length && list.push(JSON.stringify(c)));
        break;
      }
      //------------------

      let { index, 0: match, 1: text } = r;

      // 文字段
      let font = c.slice(0, index);

      (font.length && list.push(JSON.stringify(font)));

      // 命令段
      list.push(text);

      let last = index + match.length;
      c = c.slice(last);
    } // endWhile    
    //------------------
    let res;
    if (false && attr == null) {
      res = list.join('+');
    } else {
      res = list.join(',');
    }

    return res;
  }
  //-------------------------------------------
  _hasCompute(text) {
    return ($reg_2.test(text));
  }
  //-------------------------------------------
  // for test
  _space(count = 0) {
    let c = (this.level + count) * $space;
    let i = 0;
    let r = '';
    while (i++ < c) {
      r += ' ';
    }
    return r;
  }
  //-------------------------------------------
  // API
  static getInstance(dom, parent) {
    let nodeName = dom.nodeName;
    // 有<>的才有
    let tagName = dom.tagName || null;

    let node;
    if (tagName != null) {
      // <>
      tagName = tagName.toLowerCase();

      switch (tagName) {
        case 'script':
          node = new ScriptNode(dom, parent)
          break;
        default:
          node = new NormalNode(dom, parent);
          break;
      }
    } else {
      // text....
      node = new TextNode(dom, parent);
    }
    return node;
  }
}
//==============================================================================
class NormalNode extends DomNode {
  constructor(dom, parent) {
    super(dom, parent);

    // 在命令區塊中嗎
    // 在命令區塊中的 domTree 是由 data 所控制
    // 任何改變過的 attr 在 data 變化後會 reset
    this.inCommandArea = false;

    // 是否檢查過 childs 的 commandArea
    this.has_checkCommandArea = false;
  }
  //-------------------------------------------
  // 在命令區塊中的 dom，受制於 data
  // not static
  checkCommandArea() {
    if (this.has_checkCommandArea) {
      return;
    }
    this.has_checkCommandArea = true;
    //------------------
    let start, end;

    this.childs.forEach((el, i) => {
      if (el instanceof ScriptNode) {
        if (start == null) {
          start = i;
        }
        end = i;
      }
    });

    if (start == null) {
      return;
    }
    //------------------
    if (start == end) {
      end = this.childs.length;
    }

    for (let i = (start + 1); i < end; i++) {
      let el = this.childs[i];
      if (el instanceof ScriptNode) {
        continue;
      }
      el.setStatic(false);
    }
  }
  //-------------------------------------------
  // 取得命令內容
  _getSelfCommand() {
    // debugger;

    const dom = this.dom;
    let tagName = (dom.tagName == null ? "null" : `"${dom.tagName}"`);
    //-----------------------
    let lines = [];

    // 開頭
    let p = $parentVarName;    
    if(this.parent == null) {
      p = "null";
    }

    lines.push(`${$vnodeVarName} = ${$createVarName}("${dom.nodeName}", ${tagName}, ${p});\n`);
    
    if(this.parent == null){
      lines.push(`const ${$rootVarName} = ${$vnodeVarName};\n`);
    }
    //-----------------------
    // id
    if (dom.hasAttribute('id')) {
      lines.push(`${$vnodeVarName}.setId("${dom.getAttribute('id')}");\n`);     
    }
    //-----------------------
    // class
    if (dom.hasAttribute('class')) {
      let classList = Array.from(dom.classList);
      classList = JSON.stringify(classList);

      lines.push(`${$vnodeVarName}.setClass(false, ${classList});\n`);

      dom.removeAttribute('class');
    }

    let attrName = `${$C}class`;
    if (dom.hasAttribute(attrName)) {
      // calss 有計算屬性
      let classData = dom.getAttribute(attrName);

      lines.push(`${$vnodeVarName}.setClass(true, ${this._ss(classData, 'class')} );\n`);

      dom.removeAttribute(attrName);
    }
    //-----------------------
    // style
    if (dom.hasAttribute('style')) {
      let style = dom.getAttribute('style');

      style = JSON.stringify(style);
      lines.push(`${$vnodeVarName}.setStyle(false, ${style});\n`);

      dom.removeAttribute('style');
    }

    attrName = `${$C}style`;
    if (dom.hasAttribute(attrName)) {
      // computer
      let style = dom.getAttribute(attrName);

      lines.push(`${$vnodeVarName}.setStyle(true, ${this._ss(style, 'style')});\n`);

      dom.removeAttribute(attrName);
    }
    //-----------------------
    // attr
    let attrMap = Array.from(dom.attributes);

    attrMap.forEach((attr) => {

      let key = attr.nodeName;
      let value = attr.nodeValue;

      if ($reg_1.test(key)) {
        // 計算屬性        
        lines.push(`${$vnodeVarName}.setAttr(true, "${key}", ${this._ss(value, key)});\n`);
        dom.removeAttribute(key);
      } else {
        value = JSON.stringify(value);
        lines.push(`${$vnodeVarName}.setAttr(false, "${key}", ${value});\n`);
      }
    });

    lines.push('//-------\n');

    // format
    lines = lines.map((line) => {
      return (this._space() + line);
    });
    //-----------------------

    // child
    if (this.commandContent.length) {
      lines.push(this._space() + "{\n");
      lines.push(this._space(1) + `const ${$parentVarName} = ${$vnodeVarName};\n`);

      this.commandContent.forEach((l) => {
        lines.push(l);
      });

      lines.push(this._space() + "}\n");
    }

    let res = lines.join('');
    return res;
  }
  //-------------------------------------------
  // 清理不要的資料
  _clear() {
    this.childs.length = 0;
    this.childs = null;
    this.dom = null;
    this.parent = null;
    this.commandContent.length = 0;
    this.commandContent = null;
  }
}
//==============================================================================
class TextNode extends DomNode {
  constructor(dom, parent) {
    super(dom, parent);
    this.childs = null;
    this.commandContent = null;
  }
  //-------------------------------------------
  _getSelfCommand() {
    const dom = this.dom;

    let tagName = (dom.tagName == null ? "null" : `"${dom.tagName}"`);
    let text = dom.nodeValue;

    // 文字內容是否有計算
    let has_compute = this._hasCompute(text);

    if (has_compute) {
      text = this._ss(text);
    } else {
      text = JSON.stringify(text);
    }

    let lines = [];

    lines.push(`${$vnodeVarName} = ${$createVarName}("${dom.nodeName}", ${tagName}, ${$parentVarName});\n`);
    lines.push(`${$vnodeVarName}.setText(${has_compute}, ${text});\n`);

    lines = lines.map((l) => {
      return (this._space() + l);
    });

    let res = lines.join('');

    return res;
  }
  //-------------------------------------------
  _clear() {
    this.dom = null;
    this.parent = null;
  }
}

//==============================================================================
class ScriptNode extends DomNode {
  constructor(dom, parent) {
    super(dom, parent);
    this.childs = null;
    this.commandContent = null;
  }
  //-------------------------------------------
  // 取得命令內容
  _getSelfCommand() {
    // debugger;
    let content = this.dom.textContent;
    content = content.trim();

    // 要 format 需要分行
    let lines = content.split('\n');

    // format
    lines = lines.map((l) => {
      let r = this._space() + l;
      return r;
    });

    // 還原字串
    let res = lines.join('\n');

    if (!$reg_3.test(res)) {
      res += '\n';
    }

    return res;
  }
  //-------------------------------------------
  _clear() {
    this.dom = null;
    this.parent = null;
  }
}
export { DomNode };


