import $GM from '../g_module.js';

const $C = '_';

// 計算屬性的開頭名
const $reg_1 = RegExp(`^${$C}`);
// 計算屬性的代號
const $reg_2 = /\{\{([^}]*)\}\}/;
const $reg_2a = /([^]*?)\{\{([^}]*)\}\}/;

// 輸出的文本是否要 format
const $format = true;

// 建構函式裏的變數代稱
const $rootVarName = '$_root';
const $parentVarName = "$_parent";
const $vnodeVarName = '$_vnode';
const $createVarName = '$_C';
const $fun_toString = "$_st";

// format 
const $space = 2;

const VAR_NAMES = {
  rootVarName: $rootVarName,
  parentVarName: $parentVarName,
  vnodeVarName: $vnodeVarName,
  createVarName: $createVarName
};


// 組織 render 函式用
// render 函式將 dom 轉爲 vnode
class DomNode {

  // API
  static getInstance(dom, parent) {
    // 有<>的才有
    let tagName = dom.tagName || null;

    let node;
    if (tagName != null) {
      // <>
      tagName = tagName.toLowerCase();

      switch (tagName) {
        case 'script':
          node = new ScriptNode(dom, parent)
          break;
        default:
          node = new NormalNode(dom, parent);
          break;
      }
    } else {
      // text....
      node = new TextNode(dom, parent);
    }
    return node;
  }
  //-------------------------------------------

  // 外部要使用
  static get_varName(key) {
    if (key in VAR_NAMES) {
      return VAR_NAMES[key];
    }
    return null;
  }
  //-------------------------------------------
  constructor(dom, parent) {
    // for test
    this.level;
    this.dom = dom;
    this.parent = parent || null;
    this.childs = [];

    // 命令內容
    // 由 childs 上傳
    this.commandContent = [];

    this.is_static = true;

    this._init();
  }
  //-------------------------------------------
  _init() {
    this.level = (this.parent == null ? 0 : (this.parent.level + 1));
  }
  //-------------------------------------------
  append(child) {
    this.childs.push(child);
  }
  //-------------------------------------------
  // API
  callParent() {
    // debugger;
    if (this.parent == null) {
      return;
    }
    // 檢查 no static 的區塊
    this.parent.checkCommandArea();
    //------------------
    // 不同種類標籤必須實作
    let res = this._getSelfCommand();

    this.parent.callByChild(res);
  }
  //-------------------------------------------
  callByChild(text) {
    this.commandContent.unshift(text);
  }
  //-------------------------------------------
  // dom 是否是 static 節點
  setStatic(value) {
    this.is_static = value;
  }
  //-------------------------------------------
  // API
  // 只有 root 有用
  getResult() {
    if (this.parent != null) {
      throw new Error('not root');
    }

    let res = this._getSelfCommand();
    res += "\n";
    res += `return (typeof ${$rootVarName} == "undefined"? null: ${$rootVarName});`;

    return res;
  }

  //-------------------------------------------
  // 取得命令內容
  _getSelfCommand() {
    throw new Error('need override _getSelfCommand()');
  }
  //-------------------------------------------
  // 清理不要的資料
  clear() {
    this.level = null;
    this.dom = null;
    this.parent = null;

    if (Array.isArray(this.childs)) {
      this.childs.length = 0;
    }
    this.childs = null;

    if (Array.isArray(this.commandContent)) {
      this.commandContent.length = 0;
    }
    this.commandContent = null;

    this.is_static = null;
  }
  //-------------------------------------------
  // text 有 {{}}
  // attr 是否由 data 控制 
  _ss(content, attr = null) {

    if (attr != null) {
      // 前後空白對 attr 無意義
      content = content.trim();
    }

    let list = [];
    const reg_1 = RegExp($reg_2a, 'g');

    content = content.replace(reg_1, (m, g1, g2) => {
      if (g1.length) {
        list.push(JSON.stringify(g1));
      }
      if (g2.length) {
        list.push(g2);
      }
      return '';
    });
    //------------------    
    if (content.length) {
      list.push(JSON.stringify(content));
    }
    // 以變數形態輸出
    return list.join(',');
  }
  //-------------------------------------------
  _hasCompute(text) {
    return ($reg_2.test(text));
  }
  //-------------------------------------------
  // for test
  _space(count = 0) {
    let c = (this.level + count) * $space;
    let i = 0;
    let r = '';
    while (i++ < c) {
      r += ' ';
    }
    return r;
  }
  //-------------------------------------------
}
//==============================================================================
class NormalNode extends DomNode {
  constructor(dom, parent) {
    super(dom, parent);

    // 是否檢查過 childs 的 commandArea
    this.has_checkCommandArea = false;
  }
  //-------------------------------------------
  // 在命令區塊中的 dom，受制於 data
  // not static
  checkCommandArea() {
    debugger;
    if (this.has_checkCommandArea) {
      return;
    }
    this.has_checkCommandArea = true;
    //------------------
    let start, end;

    this.childs.forEach((el, i) => {
      if (el instanceof ScriptNode) {
        if (start == null) {
          start = i;
        }
        end = i;
      }
    });

    if (start == null) {
      return;
    }
    //------------------
    for (let i = (start + 1); i < end; i++) {
      let el = this.childs[i];
      el.setStatic(false);
    }
  }
  //-------------------------------------------
  // 取得命令內容
  // important
  _getSelfCommand() {
    // debugger;

    const dom = this.dom;
    let tagName = `"${dom.tagName}"`;
    //-----------------------
    let lines = [];

    // 開頭
    let p = $parentVarName;
    if (this.parent == null) {
      p = "null";
    }

    // 最 top 
    if (this.parent == null) {
      lines.push(`let ${$vnodeVarName} = null;\n`);
    }

    // createVnode
    lines.push(`${$vnodeVarName} = ${$createVarName}("${dom.nodeName}", ${tagName}, ${p});\n`);

    //-----------------------
    // static

    if (!this.is_static) {
      lines.push(`${$vnodeVarName}.setStatic(false);\n`);
    }
    //-----------------------
    // id

    if (dom.hasAttribute('id')) {
      let id = dom.getAttribute('id');
      lines.push(`${$vnodeVarName}.setId("${id}");\n`);
    }
    //-----------------------
    // class

    if (dom.hasAttribute('class')) {
      let classList = Array.from(dom.classList);
      classList = JSON.stringify(classList);

      lines.push(`${$vnodeVarName}.setClass(false, ${classList});\n`);
    }

    let attrName = `${$C}class`;
    if (dom.hasAttribute(attrName)) {
      // calss 有計算屬性
      let classData = dom.getAttribute(attrName);
      let v = this._ss(classData, 'class');
      lines.push(`${$vnodeVarName}.setClass(true, ${v});\n`);
    }
    //-----------------------
    // style
    if (dom.hasAttribute('style')) {
      let style = dom.getAttribute('style');

      let v = JSON.stringify(style);
      lines.push(`${$vnodeVarName}.setStyle(false, ${v});\n`);
    }

    attrName = `${$C}style`;
    if (dom.hasAttribute(attrName)) {
      // computer
      let style = dom.getAttribute(attrName);
      let v = this._ss(style, 'style');

      lines.push(`${$vnodeVarName}.setStyle(true, ${v});\n`);
    }
    //-----------------------
    // attr
    let attrMap = Array.from(dom.attributes);

    attrMap.forEach((attr) => {

      let key = attr.nodeName;
      let value = attr.nodeValue;

      let v;
      if ($reg_1.test(key)) {
        // 計算屬性
        v = this._ss(value, key);
        lines.push(`${$vnodeVarName}.setAttr(true, "${key}", ${v});\n`);
        dom.removeAttribute(key);
      } else {
        v = JSON.stringify(value);
        lines.push(`${$vnodeVarName}.setAttr(false, "${key}", ${v});\n`);
      }
    });

    lines.push(`${$vnodeVarName}.end();\n`);

    // 最 top 
    if (this.parent == null) {
      lines.push(`const ${$rootVarName} = ${$vnodeVarName};\n`);
    }

    lines.push('//-------\n');

    // format
    lines = lines.map((line) => {
      return (this._space() + line);
    });
    //-----------------------

    // child
    if (this.commandContent.length) {
      lines.push(this._space() + "{\n");
      lines.push(this._space(1) + `const ${$parentVarName} = ${$vnodeVarName};\n`);

      this.commandContent.forEach((l) => {
        lines.push(l);
      });

      lines.push(this._space() + "}\n");
    }

    let res = lines.join('');
    return res;
  }
  //-------------------------------------------
  // 清理不要的資料
  clear() {
    super.clear();
    this.has_checkCommandArea = null;
  }
}
//==============================================================================
class TextNode extends DomNode {
  constructor(dom, parent) {
    super(dom, parent);

    // 不需要
    this.childs = null;
    // 不需要
    this.commandContent = null;
  }
  //-------------------------------------------
  callByChild() {

  }
  //-------------------------------------------
  _getSelfCommand() {
    const dom = this.dom;

    let text = dom.nodeValue;

    // 文字內容是否有計算
    let has_compute = this._hasCompute(text);

    if (has_compute) {
      if (this.is_static) {
        this.is_static = false;
      }
      text = this._ss(text);
    } else {
      text = JSON.stringify(text);
    }

    let lines = [];

    // createVnode
    lines.push(`${$vnodeVarName} = ${$createVarName}("${dom.nodeName}", null, ${$parentVarName});\n`);

    // static
    if (!this.is_static) {
      lines.push(`${$vnodeVarName}.setStatic(false);\n`);
    }

    lines.push(`${$vnodeVarName}.setText(${has_compute}, ${text});\n`);

    lines.push(`${$vnodeVarName}.end();\n`);

    lines = lines.map((l) => {
      // format
      return (this._space() + l);
    });

    return lines.join('');
  }
  //-------------------------------------------
  clear() {
    super.clear();
  }
}

//==============================================================================
class ScriptNode extends DomNode {
  constructor(dom, parent) {
    super(dom, parent);

    // 不需要
    this.childs = null;
    // 不需要
    this.commandContent = null;
    // 不需要
    this.is_static = null;
  }
  //-------------------------------------------
  // 取得命令內容
  _getSelfCommand() {
    // debugger;
    let content = this.dom.textContent;
    content = content.trim();

    // 要 format 需要分行
    let lines = content.split('\n');
    lines.unshift('// script');
    lines.push('// endScript');

    // format
    lines = lines.map((l) => {
      let r = this._space() + l;
      return r;
    });

    // 還原字串
    let res = '\n\n' + lines.join('\n') + '\n\n';

    return res;
  }
  //-------------------------------------------
  setStatic() {

  }
  //-------------------------------------------
  clear() {
    super.clear();
  }
}
export { DomNode };


