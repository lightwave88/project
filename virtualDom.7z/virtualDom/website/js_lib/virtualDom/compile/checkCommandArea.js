import $GM from './g_module.js';

const checkList = [];

// 爲確認 commandArea
// 更精細的做法
const checkCommand = {
  check(content) {
    let check = null;

    checkList.some((c) => {
      return c.checkStart(c);
    });
    return check;
  }
};

class CheckInterface {
  checkStart(content) {
    throw new Error('need override checkStart()');
  }

  checkEnd(content) {
    throw new Error('need override checkEnd()');
  }
}

// 在 {} 之間
class A extends CheckInterface {
  checkStart(content) {

    // 先去掉 // /* */ ${}

    // 由後往前找
    for (let i = content.length; i > 0; i--) {
      let j = i - 1;

      let a = content.charAt(j);
      

    }
  }
  checkEnd(content) {
  }
}

// (e=>...) 之間
class B extends CheckInterface {
  checkStart(content) {

  }
  checkEnd(content) {
  }
}

// 在 switch 之間
class C extends CheckInterface {
  checkStart(content) {

  }
  checkEnd(content) {
  }
}