// 參數
const $argument = {};







export { $argument as argument };