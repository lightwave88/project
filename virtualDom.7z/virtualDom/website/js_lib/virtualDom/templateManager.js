import $GM from './g_module.js';

class TemplateManager {

  // 要操作的 dom
  $container_dom;

  // 模板工廠
  $template;

  // 記錄 html 建構時的 keepAlive
  $keeps = {};

  $keepAlls = {};
  //----------------------------------------------------------------------------
  constructor(dom, template) {
    this.$container_dom = dom;
    this.$template = template;
  }
  //----------------------------------------------------------------------------
  // API
  render(data = {}, config = {}) {

    let { view, events, slotEvents } = config;

    if (view == null) {
      view = {};
    }
    //------------------
    let prev_vnode = this.$container_dom['$$$prevVnode'];

    let node = this.$template.render(data, view);
    node = node || null;

    if (prev_vnode == null) {
      // 沒有 vnode 表示沒有 html 內容
      let innerHTML = this.$container_dom.innerHTML;
      if (innerHTML.length > 0) {
        this.$container_dom.innerHTML = '';
      }
    }

    // 建構 dom
    this._patch(prev_vnode, node, this.$container_dom, manager);
    //------------------
    // events



    //------------------
    // 更新記錄

    if (!('$$$prevVnode' in this.$container_dom)) {
      Object.defineProperty(this.$container_dom, '$$$prevVnode', {
        enumerable: false,
        configurable: true,
        value: node
      });
    } else {
      this.$container_dom['$$$prevVnode'] = node;
    }
  }
  //----------------------------------------------------------------------------
  // 建構 dom
  _patch(oldNode, node, parentDom) {
    const ModifyDom = $GM.get('ModifyDom');
    const $modifyDom = new ModifyDom();
    $modifyDom.patch(oldNode, node, parentDom, this);
  }
  //----------------------------------------------------------------------------
  bindEvent() {

  }
  //----------------------------------------------------------------------------

}

export { TemplateManager };
export default TemplateManager;
