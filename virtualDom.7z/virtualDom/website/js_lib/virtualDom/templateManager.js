import $GM from './g_module.js';

class TemplateManager {

  // 要操作的 dom
  $dom;

  // 模板工廠
  $factory;

  // 綁定事件用
  $slotParentDoms = {};
  //------------------

  // 記錄 html 建構時的 keepAlive
  $keeps = {};

  $keepAlls = {};
  //----------------------------------------------------------------------------
  constructor(dom, template) {
    this.$dom = dom;
    this.$factory = template;

    const API = $GM.get('API');

    const domData = API.getDomData(this.$dom);
    let { tempManagers } = domData;

    let tempID = this.$factory.id;

    if (!(tempID in tempManagers)) {
      // 註冊
      tempManagers[tempID] = this;
    }
  }
  //----------------------------------------------------------------------------
  // import API
  render(data = {}, config = {}) {

    const API = $GM.get('API');

    let { view, context, events, slotEvents } = config;

    //------------------
    const domData = API.getDomData(this.$dom);
    let {
      prevVnode = null,
      tempManager = null,
      tempManagers,
    } = domData;

    if (tempManager != null) {
      // 斷除 keep, keepAll 的連接
      tempManager.unlinkKeeps();
    }
    //------------------
    let node = this.$factory.render(data, config);
    node = node || null;


    // 取得 slotParentVnode
    // slotID => vnode
    let { slotParents } = this.$factory.getRenderData();

    if (prevVnode == null) {
      // 沒有 vnode 表示沒有 html 內容
      let innerHTML = this.$dom.innerHTML;
      if (innerHTML.length > 0) {
        this.$dom.innerHTML = '';
      }
    }

    // 建構 dom
    this._patch(prevVnode, node, this.$dom, manager);

    //------------------
    // 更新記錄

    domData['tempManager'] = this;
    domData['preVnode'] = node;
    //------------------
    // events

    let slotEvents;
    if (view != null) {
      // slotID => events
      slotEvents = view.$$$getSlotParents(this.$factory.id);
    }

  }
  //----------------------------------------------------------------------------
  // 建構 dom
  _patch(oldNode, node, parentDom) {
    const ModifyDom = $GM.get('ModifyDom');
    const $modifyDom = new ModifyDom();
    $modifyDom.patch(oldNode, node, parentDom, this);
  }
  //----------------------------------------------------------------------------
  bindEvent() {

  }

  slotBindEvent() {

  }
  //----------------------------------------------------------------------------
  // 模板工廠呼叫
  setKeep(name, dom) {

  }
  // 模板工廠呼叫
  setKeepAll(name, dom) {

  }

  // 模板工廠呼叫
  getKeep(name) {
    let res = null;


    return res;
  }
  // 模板工廠呼叫
  getKeepAll(name) {
    let res = null;


    return res;
  }
  //----------------------------------------------------------------------------
  // 打斷 keeps, keepAlls 的連接
  unlinkKeeps() {

    for (let key in object) {

    }

    for (let key in object) {

    }
  }

}

export { TemplateManager };
export default TemplateManager;
