import $GM from './g_module.js';

class TemplateManager {

  // 要操作的 dom
  $dom;

  // 模板工廠
  $factory;
  //------------------
  // 綁定事件用
  // slot => vnode
  $slotParentVnodes = {};

  // slot => events
  $slotEvents = {};
  //------------------

  // 記錄 factory 建構時的有 keep, keepAll 屬性的 vnode
  $keeps = {};

  $keepAlls = {};
  //----------------------------------------------------------------------------
  constructor(dom, template) {
    debugger;

    this.$dom = dom;
    this.$factory = template;

    const API = $GM.get('API');

    // 讀取 dom 裏的資料
    let domData = API.getDomData(dom);
    if(domData == null){
      API.setDomData(dom);
      domData = API.getDomData(dom);
    }

    let { tempManagers } = domData;

    let tempID = this.$factory.id;

    if (!(tempID in tempManagers)) {
      // 註冊
      tempManagers[tempID] = this;
    }
  }
  //----------------------------------------------------------------------------
  // import API
  render(data = {}, config = {}) {

    const API = $GM.get('API');

    let { view = null, context = null, events, slotEvents } = config;

    //------------------
    const domData = API.getDomData(this.$dom);

    let {
      prevVnode = null,
      tempManager = null,
      tempManagers,
    } = domData;

    if (tempManager != null) {
      // 斷除 keep, keepAll 的連接
      // tempManager.unlinkKeeps();
    }
    //------------------
		//
    let node = this.$factory.render(data, { view, context });
    node = node || null;


    // 取得 slotParentVnode
    // slotID => vnode
    let { slotParents } = this.$factory.getRenderData();
    this.$slotParentVnodes = Object.assign({}, slotParents);

    if (prevVnode == null) {
      // 沒有 vnode 表示沒有 html 內容
      let innerHTML = this.$dom.innerHTML;
      if (innerHTML.length > 0) {
        this.$dom.innerHTML = '';
      }
    }

    // 建構 dom
    this._patch(prevVnode, node, this.$dom, manager);

    //------------------
    // 更新記錄

    domData['tempManager'] = this;
    domData['preVnode'] = node;
    //------------------
    // slotEvents
    for (let slotID in this.$slotEvents) {
      let events = this.$slotEvents[slotID];
      let vnode = this.$slotParentVnodes[slotID];
      let dom = vnode.getDom();
      // 綁定 slot 事件
    }

    // events

  }
  //----------------------------------------------------------------------------
  // 建構 dom
  _patch(oldNode, node, parentDom) {
    const ModifyDom = $GM.get('ModifyDom');
    const $modifyDom = new ModifyDom();
    $modifyDom.patch(oldNode, node, parentDom, this);
  }
  //----------------------------------------------------------------------------
  bindEvent() {

  }

  slotBindEvent() {

  }
  //----------------------------------------------------------------------------
  // buildHtml 呼叫
  // 記錄 keep
  setKeep(name, vnode) {

  }

  // buildHtml 呼叫
  // 記錄 keepAll
  setKeepAll(name, vnode) {

  }
  //----------------------------------------------------------------------------
  getFactory() {
    return this.$factory;
  }
  // 來自 view.fun(slot) 的呼叫
  addSlotEvents(slotID, events) {
    this.$slotEvents[slotID] = events;
  }
  //----------------------------------------------------------------------------
  // 打斷 keeps, keepAlls 的連接
  unlinkKeeps() {

    for (let k in this.$keeps) {

    }

    for (let k in this.$keepAlls) {

    }
  }

}

export { TemplateManager };
export default TemplateManager;
