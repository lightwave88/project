'use strict';

import $GM from './g_module.js';

let UID = 0;

class TemplateManager {
  id;

  // 要操作的 dom
  $dom;

  // 模板工廠
  $factory;
  //------------------
  // 綁定事件用
  // slot => vnode
  $slotParentVnodes = {};

  // slot => events
  $slotEvents = {};
  //------------------

  // 記錄 factory 建構時的有 keep, keepAll 屬性的 vnode
  $keeps = {};

  $keepAlls = {};
  //----------------------------------------------------------------------------
  constructor(dom, template) {
    debugger;

    this.id = "m_" + UID++;

    this.$dom = dom;
    this.$factory = template;

    const $util = $GM.get('util');

    // 讀取 dom 裏的資料
    let domData = $util.getDomData(dom);
    if (domData == null) {
      API.setDomData(dom);
      domData = $util.getDomData(dom);
    }

    let {
      tempManagers
    } = domData;

    let tempID = this.$factory.id;

    if (!(tempID in tempManagers)) {
      // 註冊
      tempManagers[tempID] = this;
    }
  }
  //----------------------------------------------------------------------------
  // import API
  render(data = {}, config = {}) {

    const API = $GM.get('API');
    const Vnode = $GM.get('Vnode');

    let {
      view = null, context = null, events, slotEvents
    } = config;

    //------------------
    let prevVnode = Vnode.getVnode(this.$dom);
    const domData = API.getDomData(this.$dom);
    let { tempManager = null, tempManagers } = domData;

    //------------------
    //
    let node = this.$factory.render(data, { view, context });
    node = node || this._getEmptyVnode();

    // 取得 slotParentVnode
    // slotID => vnode
    let { slotParents, keeps, keepAlls } = this.$factory.getRenderData();

    // 建構 dom
    const ModifyDom = $GM.get('ModifyDom');
    const $modifyDom = new ModifyDom(tempManager, this);

    // render
    // 根據 vnode 建構 html
    $modifyDom.patch(prevVnode, node, this.dom);

    // after render
    //------------------
    // 更新 keep, keepAll
    this._$updateKeeps({ keeps, keepAlls });
    //------------------
    // 更新記錄
    domData['tempManager'] = this;
    //------------------
    // slotEvents
    slotParents.forEach((v, i) => {
      let events;
      let dom = v.getDom();
    });


    // events

  }
  //----------------------------------------------------------------------------
  bindEvent() {

  }

  slotBindEvent() {

  }
  //----------------------------------------------------------------------------
  // 處理 keep, keepAll
  beforeRender(manager) {

    if (manager.id != this.id) {
      // template 不同
      // 斷去所有 keepAll

      for (let k in this.$keepAlls) {
        let vnode = this.$keepAlls;
        vnode.parent = null;
        const dom = vnode.getDom();

        if (dom.parentNode != null) {
          dom.parentNode.removeChild(dom);
        }
      }
    }
    //------------------

    for (let k in this.$keeps) {
      let dom = $keeps[k];
      if (dom.parentNode != null) {
        // 特殊點
        dom = dom.cloneNode();
        this.$keeps[k] = dom;
      }
    }
  }
  //----------------------------------------------------------------------------
  // 處理 keepAll
  _$updateKeeps({ keeps, keepAlls }) {

    Object.assign(this.$keepAlls, keepAlls);

    for (let k in keeps) {
      let vnode = keeps[k];
      let dom = vnode.getDom();
      this.$keeps[k] = dom;
    }

    //------------------
    // 檢查斷線的 keepAll
    for (let k in this.$keepAlls) {
      let vnode = this.$keepAlls[k];
      const dom = vnode.getDom();

      if (dom.parentNode != null && !this.$dom.contains(dom)) {
        // 斷去不在線上的 node
        vnode.parent = null;
        dom.parentNode.removeChild(dom);
      }
    }
  }
  //----------------------------------------------------------------------------
  getKeep(name = null) {
    let node = null;

    if (name == null) {
      let res = Object.assign({}, this.$keeps);
      return res;
    } else {
      if (name in this.$keeps) {
        node = this.$keeps[name] || null;
      }
      return node;
    }
  }
  //----------------------------------------------------------------------------
  getKeepAll(name = null) {
    let node = null;

    if (name == null) {
      let res = Object.assign({}, this.$keepAlls);
      return res;
    } else {
      if (name in this.$keepAlls) {
        node = this.$keepAlls[name] || null;

      }
      return node;
    }
  }
  //----------------------------------------------------------------------------
  getFactory() {
    return this.$factory;
  }
  //----------------------------------------------------------------------------
  // 打斷 keeps, keepAlls 的連接
  unlinkKeeps() {

    for (let k in this.$keeps) {

    }

    for (let k in this.$keepAlls) {

    }
  }
  //----------------------------------------------------------------------------
  _getEmptyVnode() {
    const Vnode = $GM.get('Vnode');
    return Vnode.create(null, null);
  }

}

export { TemplateManager };
export default TemplateManager;
