import $GM from './g_module.js';

class TemplateManager {

  // 要操作的 dom
  $dom;

  // 模板工廠
  $tempFactory;

  // 綁定事件用
  $slotParentDoms = {};
  //------------------

  // 記錄 html 建構時的 keepAlive
  $keeps = {};

  $keepAlls = {};
  //----------------------------------------------------------------------------
  constructor(dom, template) {
    this.$dom = dom;
    this.$tempFactory = template;
  }
  //----------------------------------------------------------------------------
  // import API
  render(data = {}, config = {}) {

    const API = $GM.get('GlobalManager');
    const gManager = API.getGlobalManager();

    let { view, context, events, slotEvents } = config;

    //------------------
    const domData = gManager.getDomData(this.$dom);
    let { prevVnode = null, tempManager = null } = domData;

    if (tempManager != null) {
      // 斷除 keep, keepAll 的連接
      tempManager.unlinkKeeps();
    }

    //------------------
    let node = this.$tempFactory.render(data, config);
    node = node || null;

    if (prevVnode == null) {
      // 沒有 vnode 表示沒有 html 內容
      let innerHTML = this.$dom.innerHTML;
      if (innerHTML.length > 0) {
        this.$dom.innerHTML = '';
      }
    }

    // 建構 dom
    this._patch(prevVnode, node, this.$dom, manager);

    //------------------
    // 更新記錄

    domData['tempManager'] = this;
    domData['prevVnode'] = node;
    //------------------
    // events

  }
  //----------------------------------------------------------------------------
  // 建構 dom
  _patch(oldNode, node, parentDom) {
    const ModifyDom = $GM.get('ModifyDom');
    const $modifyDom = new ModifyDom();
    $modifyDom.patch(oldNode, node, parentDom, this);
  }
  //----------------------------------------------------------------------------
  bindEvent() {

  }

  slotBindEvent() {

  }
  //----------------------------------------------------------------------------
  // 模板工廠呼叫
  setKeep(name, dom) {

  }
  // 模板工廠呼叫
  setKeepAll(name, dom) {

  }

  // 模板工廠呼叫
  getKeep(name) {
    let res = null;


    return res;
  }
  // 模板工廠呼叫
  getKeepAll(name) {
    let res = null;


    return res;
  }

  // 模板工廠呼叫
  // 取得 <b-slot> 的 parentDom
  // 爲了 slotBindEvent
  setSlotParentDom(name, dom) {
    this.$slotParentDoms[name] = dom;
  }
  //----------------------------------------------------------------------------
  // view 呼叫
  getSlotTemplate(slotName) {
    debugger;
    return this.$tempFactory.getSlotTemplate(slotName);
  }
  //----------------------------------------------------------------------------
  // 打斷 keeps, keepAlls 的連接
  unlinkKeeps() {

    for (let key in object) {

    }

    for (let key in object) {

    }
  }

}

export { TemplateManager };
export default TemplateManager;
