'use strict';

import $GM from './g_module.js';

let UID = 0;

class TemplateManager {
  id;

  // 要操作的 dom
  $dom;

  // 模板工廠
  $factory;
  //------------------
  // 綁定事件用
  // slot => vnode
  $slotParentVnodes = {};

  // slot => events
  $slotEvents = {};
  //------------------

  // 記錄 factory 建構時的有 keep, keepAll 屬性的 vnode
  $keeps = {};

  $keepAlls = {};
  //----------------------------------------------------------------------------
  constructor(dom, template) {
    // debugger;

    this.id = "m_" + UID++;

    this.$dom = dom;
    this.$factory = template;
  }
  //----------------------------------------------------------------------------
  // import API
  render(job) {
    debugger;

    const $util = $GM.get('util');
    const Vnode = $GM.get('Vnode');

    let view = job.getView();
    let context = job.getContext();
    let events = job.getEvents();

    //------------------
    let prevVnode = Vnode.getVnode(this.$dom);

    if (prevVnode == null) {
      prevVnode = this._getEmptyVnode();
    }

    //------------------
    const domData = $util.getDomData(this.$dom);
    let { vManager, vManagerList } = domData;

    // keep, keepAll
    if (vManager != null && vManager.id != this.id) {
      vManager.unlinkKeepAll();
      vManager.updateKeep();
    }

    this.updateKeep();
    //------------------
    debugger;
    let data = job.getData();

    let node;
    let slotParents;
    let keeps;
    let keepAlls;

    if (this.$factory) {
      // vfactory()
      node = this.$factory.render(data, { view, context });

      ({ slotParents, keeps, keepAlls } = this.$factory.getRenderData());
    }
    debugger;    
    //------------------
    // 建構 dom
    const ModifyDom = $GM.get('ModifyDom');
    const $modifyDom = new ModifyDom(vManager, this);

    debugger;
    // render
    // 根據 vnode 建構 html
    $modifyDom.patch(prevVnode, node, this.$dom);

    debugger;
    // after render
    //------------------
    // 更新 keep, keepAll
    this._$updateKeeps({ keeps, keepAlls });
    //------------------
    // 更新記錄
    domData['vManager'] = this;
    //------------------

    return;
    // slotEvents
    if (slotParents) {
      slotParents.forEach((v, i) => {
        let events = v.slotEvents;
        let dom = v.getDom();
      });
    }


    // events

  }
  //----------------------------------------------------------------------------
  bindEvent() {

  }

  slotBindEvent() {

  }
  //----------------------------------------------------------------------------
  // 處理 keep, keepAll
  unlinkKeepAll() {
    debugger;

    for (let k in this.$keepAlls) {
      let vnode = this.$keepAlls[k];
      vnode.parent = null;
      const dom = vnode.getDom();

      if (dom.parentNode != null) {
        dom.parentNode.removeChild(dom);
      }
    }

  }
  //----------------------------------------------------------------------------
  updateKeep() {
    debugger;
    
    const VNODE_VARNAME = $GM.get('sysConfig').domVarname.vnode;
    
    for (let k in this.$keeps) {
      let dom = $keeps[k];
      if (dom.parentNode != null) {
        // 特殊點
        dom = dom.cloneNode();
        dom[VNODE_VARNAME] = null;
        this.$keeps[k] = dom;
      }
    }
  }
  //----------------------------------------------------------------------------
  // 處理 keepAll
  _$updateKeeps(data) {
    debugger;

    const { keeps, keepAlls } = data;

    if (keeps) {
      for (let k in keeps) {
        let vnode = keeps[k];
        let dom = vnode.getDom();
        this.$keeps[k] = dom;
      }
    }
    //------------------
    Object.assign(this.$keepAlls, keepAlls);

    // 檢查斷線的 keepAll
    for (let k in this.$keepAlls) {
      let vnode = this.$keepAlls[k];
      const dom = vnode.getDom();

      if (dom.parentNode != null && !this.$dom.contains(dom)) {
        // 斷去不在線上的 node
        vnode.parent = null;
        dom.parentNode.removeChild(dom);
      }
    }
  }
  //----------------------------------------------------------------------------
  getKeep(name = null) {
    let node = null;

    if (name == null) {
      let res = Object.assign({}, this.$keeps);
      return res;
    } else {
      if (name in this.$keeps) {
        node = this.$keeps[name] || null;
      }
      return node;
    }
  }
  //----------------------------------------------------------------------------
  getKeepAll(name = null) {
    let node = null;

    if (name == null) {
      let res = Object.assign({}, this.$keepAlls);
      return res;
    } else {
      if (name in this.$keepAlls) {
        node = this.$keepAlls[name] || null;

      }
      return node;
    }
  }
  //----------------------------------------------------------------------------
  getFactory() {
    return this.$factory;
  }
  //----------------------------------------------------------------------------
  _getEmptyVnode() {
    const Vnode = $GM.get('Vnode');
    return Vnode.create(null, null, null, null);
  }

}

export { TemplateManager };
export default TemplateManager;

