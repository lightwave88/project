import $GM from '../g_module.js';

class TemplateManager {

  // 要操作的 dom
  container_dom;

  // 模板工廠
  template;

  prev_vnode;

  // 記錄 html 建構時的 keepAlive
  keepAlives = {};

  slots = {};
  //----------------------------------------------------------------------------
  constructor(dom, template) {
    this.container_dom = dom;
    this.template = template;

    // 告訴管理者，template 裏有幾個 slot
    Object.assign(this.slots, this.template.slots);
  }
  //----------------------------------------------------------------------------
  // API 
  render(data = {}, config = {}) {

    let {
      view,
      context,
      events,
      slots
    } = config;

    if (view != null) {
      context = (context == null ? view : null);
      slots = (slots == null ? this._getViewSlots(view) : slots);
    } else {
      context = (context == null ? context : null);
    }

    this._render(data, {
      context,
      events,
      slots
    });
  }
  //----------------------------------------------------------------------------

  _render(data = {}, config = {}) {
    debugger;

    const {
      context,
      events,
      slots
    } = config;

    let node = this.template.render(data, slots, context);
    node = node || null;

    if (this.prev_vnode == null) {
      // 沒有 vnode 表示沒有 html 內容
      let innerHTML = this.container_dom.innerHTML;
      if (innerHTML.length > 0) {
        this.container_dom.innerHTML = '';
      }
    }

    // 建構 dom
    this._patch(this.prev_vnode, node, this.container_dom, manager);

    //------------------
    // 事件綁定



    //------------------
    // 更新記錄
    this.prev_vnode = node;
  }
  //----------------------------------------------------------------------------
  // 建構 dom
  _patch(oldNode, node, parentDom) {
    const ModifyDom = $GM.get('ModifyDom');
    const $modifyDom = new ModifyDom();
    $modifyDom.patch(oldNode, node, parentDom, this);
  }
  //----------------------------------------------------------------------------
  // 組織 slots
  _getViewSlots(view) {
    let res = {};

    for (let k in this.slots) {
      let key = "slot_" + k;
      if (typeof this.view[key] == 'function') {

        let fn = this.view[key];
        res[key] = fn.bind(view);
      }
    } // endFor
    return res;
  }

}

export { TemplateManager };
export default TemplateManager;

