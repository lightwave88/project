const className = {
    attrName: 'class',
    create,
    update,
};
//------------------------------------------------------------------------------
function create(dom, vnode) {
    let classList = vnode.classList;

    classList.forEach(el => {
        dom.classList.add(el);
    });
}
//------------------------------------------------------------------------------
function update(dom, oldVnode, vnode) {

    let old_list = oldVnode.classList;
    let list = vnode.classList;

    old_list = new Set(old_list);
    list = new Set(list);

    old_list.forEach(el => {
        if (list.has(el)) {
            old_list.delete(el);
            list.delete(el);
        }
    });

    old_list.forEach(el => {
        dom.classList.remove(el);
    });

    list.forEach(el => {
        dom.classList.add(el);
    });
}

//------------------------------------------------------------------------------

export default className;
export { className };