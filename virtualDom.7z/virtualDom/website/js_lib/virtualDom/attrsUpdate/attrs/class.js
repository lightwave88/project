const className = {
    create,
    update,
};
//------------------------------------------------------------------------------
function create(dom, vnode){
    let classList = vnode.classList;
    
    
}

function update(dom, oldVnode, vnode){
    let old_classList = oldVnode.classList;
    let classList = vnode.classList;
}
//------------------------------------------------------------------------------

export default className; 
export {className};