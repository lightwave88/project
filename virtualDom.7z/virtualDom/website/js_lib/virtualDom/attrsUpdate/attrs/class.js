const className = {
    attrName: 'class',
    create,
    update,
};
//------------------------------------------------------------------------------
function create(dom, vnode) {
    let classList = vnode.classList;

    dom.className = classList.join(' ');
}

function update(dom, oldVnode, vnode) {

    let old_classList = oldVnode.classList;
    let classList = vnode.classList;

    let not_equal = (() => {
        if (old_classList.length != classList.length) {
            return true;
        }

        let res = classList.some((a, i) => {
            let b = old_classList[i];

            if (a !== b) {
                return true;
            }
            return false;
        });

        return res;
    })();

    if (!not_equal) {
        return;
    }

    dom.className = classList.join(' ');

}
//------------------------------------------------------------------------------

export default className;
export { className };