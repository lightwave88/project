const style = {
    attrName: 'style',
    create,
    update,
};
//------------------------------------------------------------------------------
function create(dom, vnode) {

    let style = vnode.style;

    let list = [];

    let keys = Object.keys(style);

    keys.forEach(key => {
        let value = ('' + style[key]) || '';
        list.push(`${key}:${value}`);
    });

    
}
//------------------------------------------------------------------------------
function update(dom, oldVnode, vnode) {

}
//------------------------------------------------------------------------------

export default style;
export { style };