const style = {
    attrName: 'style',
    create,
    update,
};
//------------------------------------------------------------------------------
function create(dom, vnode) {


    let style = vnode.style;


}

function update(dom, oldVnode, vnode) {

}
//------------------------------------------------------------------------------

export default style;
export { style };