import $GM from '../g_module.js';
// attrs
import className from './attrs/class.js';
import style from './attrs/style.js';

const $importList = [className, style];

let cbs = {
  create: new Map(),
  update: new Map(),
  destroy: new Map(),
  remove: new Map(),
};


// 處理關於 attr
const attrsUpdate = {
  create,
  update,
  destroy,
  remove
};
//----------------------------------------------------------
function create(vnode) {
  // debugger;
  let dom = vnode.dom;

  let createList = cbs.create.values();
  createList = Array.from(createList);

  let updateAttrs = new Map(vnode.attrs);

  createList.forEach((fn, attr) => {
    updateAttrs.delete(attr);
    fn(dom, vnode);
  });

  updateAttrs.forEach((v, attr) => {
    v = '' + v;
    dom.setAttribute(attr, v);
  });

  // for test
  if (dom.tagName != null) {
    dom.setAttribute('_static', vnode.is_static);
  }
}
//----------------------------------------------------------
// update attr
function update(oldVnode, vnode, isStatic = null) {
  // debugger;
  let dom = oldVnode.dom || null;

  if (!dom) {
    throw new Error('attrs update() no dom');
  }

  if (vnode.dom == null) {
    // 補救措施
    vnode.setDom(dom);
  }

  let is_static = (isStatic != null) ? isStatic : vnode.isStatic;

  if (is_static) {
    // 靜態節點
    // 靜態節點會採用之前的 dom
    // 除動態 attr 外，都是屬於繼承

    const $util = $GM.get('util');
    console.dir($util);

    // Set
    // a,b 應該要一樣
    let a = oldVnode.compute_attrs;
    let b = vnode.compute_attrs;
    b = new Set(b);

    let diff = $util.intersection(a, b);

    if (a.size != b.size || a.size != diff.size) {
      // 檢查
      throw new Error('should not be happen');
    }

    // here
    cbs.update.forEach((fn, attr) => {
      // debugger;
      if (b.has(attr)) {
        // attr 由 data 控制
        b.delete(attr);
        fn(dom, oldVnode, vnode);
      }
    });

    let checkList = Array.from(b);

    _default_update_1(dom, vnode, checkList);
  } else {
    // 動態
    // 動態節點可能會對到不同地 dom
    // 所有 attr 由 new_vnode 決定
    let updateAttrs = new Map(vnode.attrs);

    cbs.update.forEach((fn, attr) => {
      // debugger;

      updateAttrs.delete(attr);
      fn(dom, oldVnode, vnode);
    });

    // debugger;
    _default_update(dom, updateAttrs);

    
}
}
//----------------------------------------------------------
function destroy() {

}
//----------------------------------------------------------
function remove() {

}
//----------------------------------------------------------
// 針對動態節點
// 所有 attr 都需更新
function _default_update(dom, updateAttrs) {
  // debugger;
  let removeAttrs = [];

  let dom_attrs = Array.from(dom.attributes)

  dom_attrs.forEach((attr) => {
    let {name, value} = attr;
    if (updateAttrs.has(attr)) {
      let new_value = updateAttrs.get(attr);

      if (new_value === value) {
        updateAttrs.delete(attr);
      }

    } else {
      removeAttrs.push(name);
    }
  });
  //-----------------------
  updateAttrs.forEach((v, k) => {
    v = '' + v;
    dom.setAttribute(k, v);
  });

  removeAttrs.forEach((k) => {
    dom.removeAttribute(k);
  });
}
//----------------------------------------------------------
// 針對靜態節點，只更新他的動態 attrs
function _default_update_1(dom, vnode, checkList = []) {

  if (!checkList.length) {
    return;
  }

  const new_attrs = vnode.attrs;

  checkList.forEach((attr) => {
    let dom_attrValue = dom.getAttribute(attr);
    let attrValue = new_attrs.get(attr) + '';

    if (attrValue === dom_attrValue) {
      return;
    }
    dom.setAttribute(attr, attrValue);
  });
}
//----------------------------------------------------------


(async () => {

  await Promise.resolve();
  debugger;
  // 事先注入
  let keys = Object.keys(cbs);

  $importList.forEach((module) => {
    let attrName = module.attrName;

    keys.forEach((k) => {
      if ((k in module) && typeof module[k] == 'function') {
        let list = cbs[k];
        list.set(attrName, module[k]);
      }
    })

  });

})();


export { attrsUpdate };
