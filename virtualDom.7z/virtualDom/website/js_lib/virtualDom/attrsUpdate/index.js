
import className from './attrs/class.js';
import style from './attrs/style.js';

const $importList = [className, style];

let cbs = {
  create: new Map(),
  update: new Map(),
  destroy: new Map(),
  remove: new Map(),
};


// 處理關於 attr
const attrsUpdate = {
  create,
  update,
  destroy,
  remove
}
//------------------------------------------------------------------------------
function create(vnode) {
  debugger;
  let dom = vnode.dom;

  let excludeList = cbs.create.keys();
  let list = cbs.create.values();
  
  excludeList = Array.from(excludeList);
  list = Array.from(list);

  list.forEach((fn) => {
    debugger;
    fn(dom, vnode);
  });

  debugger;
  _default_create(dom, vnode, excludeList);
}
//------------------------------------------------------------------------------

function update(oldVnode, vnode) {
  debugger;
  let dom = oldVnode.dom;

  if (vnode.dom == null) {
    // 補救措施
    vnode.setDom(dom);
  }

  let excludeList = cbs.update.keys();
  let list = cbs.update.values();
  
  excludeList = Array.from(excludeList);
  list = Array.from(list);

  list.forEach((fn) => {
    debugger;
    fn(dom, oldVnode, vnode);
  });

  debugger;
  _default_update(dom, oldVnode, vnode, excludeList);
}
//------------------------------------------------------------------------------
function destroy() {

}
//------------------------------------------------------------------------------
function remove() {

}
//------------------------------------------------------------------------------


function _default_create(dom, vnode, excludeList) {

  let attrs = vnode.attrs;

  if (!attrs.size) {
    return;
  }

  attrs.forEach((value, key) => {
    if (excludeList.includes(key)) {
      // 排除不需要考慮的 attr
      return;
    }
    value = '' + value;

    dom.setAttribute(key, value);
  });

}

function _default_update(dom, oldVnode, vnode, excludeList) {
  debugger;

  let old_attrs = oldVnode.attrs;
  let attrs = vnode.attrs;

  // 副本
  old_attrs = new Map(old_attrs);
  attrs = new Map(attrs);

  excludeList.forEach((k) => {
    // 排除不需要考慮的 attr
    old_attrs.delete(k);
    attrs.delete(k);
  });

  let old_keys = old_attrs.keys;
  old_keys = Array.from(old_keys);

  let removeKey = old_keys.filter((key) => {

    if (!attrs.has(key)) {
      return true;
    } else {
      let oldValue = old_attrs.get(key);
      let value = attrs.get(key);
      if (oldValue === value) {
        // 相同的 attrs 
        // 不用重複設定
        attrs.delete(key);
      }
    }
    return false;
  });

  debugger;

  removeKey.forEach((key) => {
    dom.removeAttribute(key);
  });

  attrs.forEach((v, k) => {
    v = '' + v;
    dom.setAttribute(k, v);
  });
}

//------------------------------------------------------------------------------

(async () => {
  
  await Promise.resolve();
  debugger;
  // 事先注入
  let keys = Object.keys(cbs);

  $importList.forEach((module) => {
    let attrName = module.attrName;

    keys.forEach((k) => {
      if ((k in module) && typeof module[k] == 'function') {
        let list = cbs[k];
        list.set(attrName, module[k]);
      }
    })

  });

})();


export { attrsUpdate };
