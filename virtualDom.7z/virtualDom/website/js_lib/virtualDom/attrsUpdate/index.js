// attrs
import className from './attrs/class.js';
import style from './attrs/style.js';

const $importList = [className, style];

let cbs = {
  create: new Map(),
  update: new Map(),
  destroy: new Map(),
  remove: new Map(),
};


// 處理關於 attr
const attrsUpdate = {
  create,
  update,
  destroy,
  remove
}
//------------------------------------------------------------------------------
function create(vnode) {
  // debugger;
  let dom = vnode.dom;


  let createList = cbs.create.values();
  createList = Array.from(createList);

  createList.forEach((fn) => {
    // debugger;
    fn(dom, vnode);
  });

  // debugger;
  _default_create(dom, vnode);
}
//------------------------------------------------------------------------------

function update(oldVnode, vnode) {
  // debugger;
  let dom = oldVnode.dom || null;

  if(!dom){
    throw new Error('attrs update() no dom');
  }

  if (vnode.dom == null) {
    // 補救措施
    vnode.setDom(dom);
  }

  if (oldVnode.is_static && vnodeis_static) {
    // 靜態

    let a = oldVnode.compute_attrs;
    let b = vnode.compute_attrs;

    b = new Set(b);
    let checkList = [];

    for (let k of a) {
      if (b.has(k)) {
        b.delete(k);
      }
      checkList.push(k);
    }
    for (let k of b) {
      checkList.push(k);
    }

    cbs.update.forEach((fn, key) => {
      if (checkList.includes(key)) {
        fn(dom, oldVnode, vnode);
      }
    });

    _default_update_1(dom, oldVnode, vnode, checkList);
  } else {
    // 動態

    cbs.update.forEach((fn) => {
      // debugger;
      fn(dom, oldVnode, vnode);
    });

    // debugger;
    _default_update(dom, oldVnode, vnode);
  }
}
//------------------------------------------------------------------------------
function destroy() {

}
//------------------------------------------------------------------------------
function remove() {

}
//------------------------------------------------------------------------------


function _default_create(dom, vnode) {

  let attrs = vnode.attrs;

  if (!attrs.size) {
    return;
  }

  attrs = new Map(attrs);

  // 需排除的 attr
  let excludeList = _getExcludeList();

  excludeList.forEach((key) => {
    attrs.delete(key);
  });

  attrs.forEach((value, key) => {
    value = '' + value;
    dom.setAttribute(key, value);
  });
}

function _default_update(dom, oldVnode, vnode) {
  debugger;

  let excludeList = _getExcludeList();

  let old_attrs = oldVnode.attrs;
  let attrs = vnode.attrs;
  //-----------------------
  // 副本
  old_attrs = new Map(old_attrs);
  attrs = new Map(attrs);

  excludeList.forEach((k) => {
    // 排除不需要考慮的 attr
    old_attrs.delete(k);
    attrs.delete(k);
  });
  //-----------------------
  let removeKey = [];

  old_attrs.forEach((v, k) => {
    if (!attrs.has(k)) {
      removeKey.push(k);
    } else {

      let value = attrs.get(k);
      if (v === value) {
        // 相同的 attrs 
        // 不用重複設定
        attrs.delete(k);
      }
    }
  });

  removeKey.forEach((key) => {
    dom.removeAttribute(key);
  });

  attrs.forEach((v, k) => {
    v = '' + v;
    dom.setAttribute(k, v);
  });
}
//------------------------------------------------------------------------------

function _default_update_1(dom, oldVnode, vnode, includeList = []) {

  let excludeList = _getExcludeList();

  let old_attrs = oldVnode.attrs;
  let attrs = vnode.attrs;
  //-----------------------
  // 副本
  old_attrs = new Map(old_attrs);
  attrs = new Map(attrs);

  excludeList.forEach((k) => {
    // 排除不需要考慮的 attr
    old_attrs.delete(k);
    attrs.delete(k);
  });

  let removeKey = [];
  
  old_attrs.forEach((v, k) => {
    if (attrs.has(k)) {

      let value = attrs.get(k);

      if (v == value) {
        attrs.delete(k);
      }

    } else {
      if (includeList.includes(k)) {
        removeKey.push(k);
      }
    }
  });
  //-----------------------

  removeKey.forEach((key) => {
    dom.removeAttribute(key);
  });

  attrs.forEach((v, k) => {
    if (!includeList.includes(k)) {
      return;
    }
    v = '' + v;
    dom.setAttribute(k, v);
  });
}

function _getExcludeList() {
  let excludeList = cbs.create.keys();
  excludeList = Array.from(excludeList);
  return excludeList;
}
//------------------------------------------------------------------------------
function intersection(a, b) {

}

function union(a, b) {

}


(async () => {

  await Promise.resolve();
  debugger;
  // 事先注入
  let keys = Object.keys(cbs);

  $importList.forEach((module) => {
    let attrName = module.attrName;

    keys.forEach((k) => {
      if ((k in module) && typeof module[k] == 'function') {
        let list = cbs[k];
        list.set(attrName, module[k]);
      }
    })

  });

})();


export { attrsUpdate };
