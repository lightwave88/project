
import className from './attrs/class.js';
import style from './attrs/style.js';

const $importList = [className, style];

let cbs = {
  create: {},
  update: {},
  destroy: {},
  remove: {},
};


// 處理關於 attr
const attrsUpdate = {
  create,
  update,
  destroy,
  remove
}
//------------------------------------------------------------------------------
function create(vnode) {
  let dom = vnode.dom;

  let list = Object.values(cbs.create);

  list.forEach((fn) => {
    fn(dom, vnode);
  });

}
//------------------------------------------------------------------------------

function update(oldVnode, vnode) {
  let dom = vnode.dom;

  if (vnode.dom == null) {
    vnode.setDom(dom);
  }

  let list = Object.values(cbs.update);

  list.forEach((fn) => {
    fn(dom, oldVnode, vnode);
  });
}
//------------------------------------------------------------------------------
function destroy() {

}
//------------------------------------------------------------------------------
function remove() {

}
//------------------------------------------------------------------------------


function nextStep(callback) {
  Promise.resolve().tehn(() => {
    callback();
  });
}


nextStep(() => {
    // 事先注入
  let keys = Object.keys(cbs);

  $importList.forEach((module) => {

    keys.forEach((k) => {
      if ((k in module) && typeof module[k] == 'function') {
        let list = cbs[k];

        list.push(module[k]);
      }
    })

  });
});


export { attrsUpdate };
