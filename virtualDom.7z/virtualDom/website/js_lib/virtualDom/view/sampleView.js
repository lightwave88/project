import GM from '../g_module.js';

class SampleView {
  
  // 一般 temp
  $templates = {};

  // slot 用的 temp
  $comps = {};

  $compute = {};

  // 記錄正在 render 的 templateName
  $_operateTempName;

  // 記錄正在 render 的 templateName
  // 呼叫到的 slot
  $_tempSlotEvents = {};

  $_slotTemplate = {};

  $_callSlotName_list = [];

  // 萬一 slot 返回 string
  // 用字數當 key
  $_stringTemplateCache = {};

  //----------------------------------------------------------------------------
  constructor() {

  }

  _init() {

  }
  //----------------------------------------------------------------------------
  // 註冊 template
  registTemplate(template, name) {

  }
  // slot 用的 template
  registComp() {

  }
  //----------------------------------------------------------------------------
  // slot 內使用
  compRender(name, data) {

    // renderFactory
    // get vnode

    // 取得 keep, keepAll vnode
    // change keep, keepAll name

  }
  //----------------------------------------------------------------------------
  // main API
  // render template
  templateRender(dom, name, data, events) {
    this.$_operateTempName = name;

    //-----------------------
    let temp = $template[name] || null;

    if (temp == null) {
      // 沒有相對應的模板
      throw new Error(`no this template ${name}`);
    }

    const API = $GM.get('API');

    let config = {};

    // render
    API.render(dom, temp, data, config);

    //-----------------------
    this.$_operateTempName = null;

    // slotEvent 記錄
    if (this.$_tempSlotEvents[operateTempName] != null) {
      delete this.$_tempSlotEvents[operateTempName];
    }
  }
  //----------------------------------------------------------------------------
  // call compute
  $$$callCompute(name, args) {

    if (typeof this.$compute[name] != 'function') {
      throw new Error();
    }
    let fun = this.$compute[name];
    let value = fun.call(this, args);
    return value;
  }
  //----------------------------------------------------------------------------
  // call slot
  // 麻煩的地方
  $$$callSlot(slotName, args = {}) {

    // 避免多層次
    // slot 只允許一層
    this.$_callSlotName_list.push(slotName);

    let res = (() => {

      if (this.$_callSlotName_list.length > 1) {
        // 禁止 slot 巢狀呼叫
        return null;
      }
      const funName = 'slot_' + slotName;
      if (typeof this[funName] != 'function') {
        return null;
      }
      //------------------
      // 現在操做中的 template.name
      const operateTempName = this.$_operateTempName;

      // 取得現在運作的 template
      const template = this.$template[operateTempName];

      // innerTemplate
      let innerTemplate = null;
      // 是否有所屬該 slot 的 factory
      let slotFactory = template.getSlotTemplate(slotName);

      if (slotFactory != null) {
        innerTemplate = {
          "$this": this,
          config: {
            tempName: operateTempName
          },
          render(data) {
            compRender(this.$this, slotFactory);
          }
        };
      }

      // 要給使用者的訊息
      let e = {
        templateName: operateTempName,
        innerTemplate,
      }

      // 執行 slot_fun
      // 使用者要返回的資料
      let res = this[funName].call(this, args, e);
      res = Object.assign({}, res);

      let {
        vnode,
        event
      } = res;

      if (event != null) {
        // slotEvent
        
        this.$_tempSlotEvents[operateTempName] = {};
        let slotTempEvent = this.$_tempSlotEvents[operateTempName];

        slotTempEvent[slotName] = Object.assign({}, event);
      }

      if (typeof vnode == 'string') {
        // vnode 需要編譯
        // vnode 需要編譯
        // vnode 需要編譯
        // vnode 需要編譯
      }

      return vnode;
    })();

    this.$_callSlotName_list.pop();

    return res;
  }
  //----------------------------------------------------------------------------
  render() {

  }
}


export default SampleView;
export { SampleView };

function compRender(view, factry, data, c = {}) {

  let { tempName, slotName } = c;
  let config = { view };
  let vnode = factry.render(data, config);

  tempName = tempName || 'innerTemp';
  let headName = slotName + '_' + tempName + '_';
  // rename keep

  // rename keepAll

  return vnode;
}
