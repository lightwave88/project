class SampleView {
  $template = {};

  $compute = {};

  // 記錄正在 render 的 templateName
  $_renderTempName;

  // 記錄正在 render 的 templateName
  // 呼叫到的 slot
  $_slotEvents;

  $_slotTemplate = {};

  //----------------------------------------------------------------------------
  constructor() {

  }
  //----------------------------------------------------------------------------
  linkTemplate(dom,template,name) {
    let API;

    let slotTemplate = template.slotTemplate;
    Object.assign(this.$_slotTemplate, slotTemplate);

    let tempManager = API.g_manager.getManager(dom, template);
  }
  //----------------------------------------------------------------------------
  templateRender(name) {
    this.$_renderTempName = name;
    this.$_slotEvents = {};
    //-----------------------
    let tempManager = $template[name] || null;

    if(tempManager != null){

      let config = {};
      tempManager.render(dom, data, config);
    }

    //-----------------------
    this.$_renderTempName = null;
    this.$_slotEvents = null;
  }
  //----------------------------------------------------------------------------
  $$$callCompute(name, args){

    if(typeof this.$compute[name] != 'function'){
      throw new Error();
    }
    let fun = this.$compute[name];
    let value = fun.call(this, args);
    return value;
  }
  //----------------------------------------------------------------------------
  $$$callSlot(id, args = {}) {
    const funName = 'slot_' + id;

    if (typeof this[funName] != 'function') {
      return null;
    }

    let slotTemplate = this.$_slotTemplate[id] || null;

    let info = {
      id,
      template: slotTemplate
    }

    let {
      vnode,
      event
    } = this[funName].call(this, args, info);

    if (this.$_slotEvents != null) {
      Object.assign(this.$_slotEvents);
    }

    return vnode;
  }
  //----------------------------------------------------------------------------
  render() {

  }
}
