class SampleView {
  $template = {};

  $compute = {};

  // 記錄正在 render 的 templateName
  $_operateTempName;

  // 記錄正在 render 的 templateName
  // 呼叫到的 slot
  $_tempSlotEvents = {};

  $_slotTemplate = {};

  // 避免巢狀多層
  $_callSlotTimes = 0;

  //----------------------------------------------------------------------------
  constructor() {

  }

  _init() {

  }



  get $template(name) {

  }
  //----------------------------------------------------------------------------
  // 註冊 template
  registTemplate(template, name) {

  }  
  // 註冊 template 並連接 dom
  linkTemplate(dom, template, name) {

  }
  //----------------------------------------------------------------------------
  // main API
  // render template
  templateRender(name, data, events) {
    this.$_operateTempName = name;
    this.$_slotEvents = {};
    //-----------------------
    let tempManager = $template[name] || null;

    if (tempManager != null) {
      this.$_tempSlotEvents[name] = {};
      let config = {};


      // 執行 template
      tempManager.render(dom, data, config);
    }

    //-----------------------
    delete this.$_tempSlotEvents[operateTempName];
    this.$_operateTempName = null;
    this.$_slotEvents = null;
  }
  //----------------------------------------------------------------------------
  // call compute
  $$$callCompute(name, args) {

    if (typeof this.$compute[name] != 'function') {
      throw new Error();
    }
    let fun = this.$compute[name];
    let value = fun.call(this, args);
    return value;
  }
  //----------------------------------------------------------------------------
  // call slot
  $$$callSlot(slotName, args = {}) {

    // 避免多層次
    // slot 只允許一層
    ++this.$_callSlotTimes;

    let res = (() => {

      if (this.$_callSlotTimes > 1) {
        // 禁止 slot 巢狀呼叫
        return null;
      }
      const funName = 'slot_' + slotName;
      if (typeof this[funName] != 'function') {
        return null;
      }
      //------------------
      // 現在操做中的 template.name
      const operateTempName = this.$_operateTempName;

      // 取得現在運作的 template
      const template = this.$template[operateTempName];

      // innerTemplate
      let innerTemplate = null;
      // 是否有所屬該 slot 的 factory
      let slotFactory = template.getSlotTemplate(slotName);
      if (slotFactory != null) {
        innerTemplate = {};
        innerTemplate['render'] = slotFactory.makeRender({ view: this });
      }

      // 要給使用者的訊息
      let e = {
        templateName: operateTempName,
        innerTemplate,
      }

      // 執行
      // 使用者要返回的資料
      let res = this[funName].call(this, args, e);

      let {
        vnode,
        event
      } = res;

      // slot 要登錄的 dom.event
      let slotTempEvent = this.$_tempSlotEvents[operateTempName];
      if (slotTempEvent == null) {
        slotTempEvent = {};
      }
      slotTempEvent[slotName] = event;

      if (typeof vnode == 'string') {
        // vnode 需要編譯
        // vnode 需要編譯
        // vnode 需要編譯
        // vnode 需要編譯
      }

      return vnode;
    })();

    --this.$_callSlotTimes;

    return res;
  }
  //----------------------------------------------------------------------------
  render() {

  }
}
