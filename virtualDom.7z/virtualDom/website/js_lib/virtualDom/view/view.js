import $GM from '../g_module.js';


//==============================================================================
class View {

  static create(config = {}) {

  }

  static extend(props = {}) {

  }
}

export {
  View
};
//==============================================================================
class SampleView {

  // 一般 temp
  $templates = {};

  // slot 用的 temp
  $comps = {};

  $compute = {};

  // 記錄正在 render 的 templateName
  $_o_tempName;

  // 正在運行的 temp
  $_o_tempM;

  // 記錄現在操作的 slot
  // {}
  $_o_slot = null;

  // 記錄正在 render 的 templateName
  // 呼叫到的 slot
  // $_tempSlotData = {};

  // $_slotTemplate = {};

  // 萬一 slot 返回 string
  // 用字數當 key
  $_stringTemplateCache = {};

  //----------------------------------------------------------------------------
  constructor() {

  }

  _init() {

  }
  //----------------------------------------------------------------------------
  // 註冊 template
  registTemplate(template, name) {

  }
  // slot 用的 template
  registComp() {

  }
  //----------------------------------------------------------------------------
  // slot 內使用
  compRender(name, data) {

    let slotInfo = this.$_o_slot;

    if (slotInfo == null) {
      throw new Error('...');
    }

    let {
      slotID
    } = slotInfo;

    // renderFactory
    // get vnode

    let factory;
    let render = getCompRender(this, factory, slotID);

    return render(data);
  }
  //----------------------------------------------------------------------------
  // main API
  // render template
  templateRender(dom, name, data, events) {
    //-----------------------
    let temp = $template[name] || null;

    if (temp == null) {
      // 沒有相對應的模板
      throw new Error(`no this template ${name}`);
    }
    this.$_o_tempName = name;
    this.$_o_temp = temp;

    const API = $GM.get('API');

    let config = {
      view: this,
    };

    // render
    this.$_o_tempM = API.render(dom, temp, data, config);
    //------------------

    //-----------------------
    this.$_o_tempName = null;
    this.$_o_tempM = null;


  }
  //----------------------------------------------------------------------------
  // call compute
  $$$callCompute(name, args) {

    if (typeof this.$compute[name] != 'function') {
      throw new Error();
    }
    let fun = this.$compute[name];
    let value = fun.call(this, args);
    return value;
  }
  //----------------------------------------------------------------------------
  // call slot
  // 麻煩的地方
  $$$callSlot(slotID, slotName, args = {}) {

    // 避免多層次
    // slot 只允許一層
    this.$_o_slot = {
      id: slotID,
      name: slotName
    };

    let vnode = null;

    job: {
      const funName = 'slot_' + slotName;
      if (typeof this[funName] != 'function') {
        break job;
      }
      //------------------
      // 現在操做中的 template.name
      const operateTempName = this.$_o_tempName;
      // 取得現在運作的 template
      const temp = this.$_o_tempM.getFactory();
      //-----------------------
      // innerTemplate
      let innerTemplate = null;

      // 是否有所屬該 slot 的 factory
      let slotFactory = temp.getSlotTemplate(slotName);


      if (slotFactory != null) {
        let keepName = slotID + '_' + slotFactory.id + '_';
        let config = {
          view: this
        };

        innerTemplate = {
          render: getCompRender(this, slotFactory, slotID);
        };
      }
      //-----------------------
      // 要給使用者的訊息
      let e = {
        templateName: operateTempName,
        innerTemplate,
      }

      // 執行 slot_fun
      // 使用者要返回的資料
      let res = this[funName].call(this, args, e);
      res = Object.assign({}, res);

      let {
        vnode,
        events
      } = res;

      if (events != null) {
        // 記錄 slotEvent
        this.$_o_tempM.addSlotEvents(slotID, events);
      }

      if (typeof vnode == 'string') {
        // vnode 需要編譯
        // vnode 需要編譯
        // vnode 需要編譯
        // vnode 需要編譯
      }
    };

    this.$_o_slot = null;

    return vnode;
  }
  //----------------------------------------------------------------------------
  render() {

  }
}
//==============================================================================


// 針對 slot
function getCompRender(view, factory, slotID) {

  let factryID = factory.id;
  let headName = slotID + '_' + factryID + '_';
  let config = {
    view
  };

  return function render(data) {
    // 通知 factory 將以 slot 模式 render
    factory.isSlot(headName);
    // render
    let vnode = factory.render(data, config);

    /*
    // 設定 vnode.static
    let tempList = [vnode];

    let index = 0;
    let v;

    while(null != (v = tempList[index++])){
      v.isStatic = false;
      if(v.keepAll != null){
        continue;
      }
      let childs = v.childs;
      if(childs.length > 0){
        tempList = tempList.concat(childs);
      }
    }
    */

    return vnode;
  };

}
