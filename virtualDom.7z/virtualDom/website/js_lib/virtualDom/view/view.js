import $GM from '../g_module.js';


class SampleView {

  // 一般 temp
  $templates = {};

  // slot 用的 temp
  $comps = {};

  $compute = {};

  // 正在運行的 temp
  $_currentR_temp;

  $_current_slotID;

  $_stringTemplateCache = {};

  //----------------------------------------------------------------------------
  constructor(config={}) {

  }
  //----------------------------------------------------------------------------
  // 註冊 template
  registTemplate(name, template) {

  }
  // slot 用的 template
  registComp(name, template) {

  }
  //----------------------------------------------------------------------------
  // slot 內使用
  compRender(name, data) {

    let factory;

    let render = getCompRender(this, factory, this.$_current_slotID);
    let vnode = render(data);
    return vnode;
  }
  //----------------------------------------------------------------------------
  // main API
  // render template
  templateRender(dom, name, data, events) {

    let temp = $template[name] || null;

    if (temp == null) {
      // 沒有相對應的模板
      throw new Error(`no this template ${name}`);
    }
    // 記錄
    $_currentR_temp = {name, temp};

    const API = $GM.get('API');

    let config = {
      view: this,
    };

    // render
    API.render(dom, temp, data, config);
    //------------------

    //------------------
    $_currentR_temp = null;
  }
  //----------------------------------------------------------------------------
  // call compute
  $$$callCompute(name, args) {

    if (typeof this.$compute[name] != 'function') {
      throw new Error();
    }
    let fun = this.$compute[name];
    let value = fun.call(this, args);
    return value;
  }
  //----------------------------------------------------------------------------
  // call slot
  // 麻煩的地方
  $$$callSlot(slotID, slotName, args = {}) {

    if ($_current_slotID != null) {
      return null;
    }

    this.$_current_slotID = slotID;

    let vnode = null;

    job: {
      const funName = 'slot_' + slotName;
      if (typeof this[funName] != 'function') {
        break job;
      }
      //------------------
      // 現在操做中的 template.name
      const operateTempName = this.$_o_tempName;
      // 取得現在運作的 template
      const temp = this.$_o_tempM.getFactory();
      //-----------------------
      // innerTemplate
      let innerTemplate = null;

      // 是否有所屬該 slot 的 factory
      let slotFactory = temp.getSlotTemplate(slotName);


      if (slotFactory != null) {
        let keepName = slotID + '_' + slotFactory.id + '_';
        let config = {
          view: this
        };

        innerTemplate = {
          render: getCompRender(this, slotFactory, slotID),
        };
      }
      //-----------------------
      // 要給使用者的訊息
      let e = {
        templateName: operateTempName,
        innerTemplate,
      }

      // 執行 slot_fun
      // 使用者要返回的資料
      let res = this[funName].call(this, args, e);
      res = Object.assign({}, res);

      let {vnode, events} = res;

      //-----------------------
      if (typeof vnode == 'string') {
        // vnode 需要編譯
        // vnode 需要編譯
        // vnode 需要編譯
        // vnode 需要編譯
      }
    }

    this.$_current_slotID = null;

    return {id: slotID, render: vnode, events};
  }
  //----------------------------------------------------------------------------
  render() {

  }
}

export { SampleView as View };
//==============================================================================


// 針對 slot
function getCompRender(view, factory, slotID) {

  let factryID = factory.id;
  let headName = slotID + '_' + factryID + '_';
  let config = {view};

  return function render(data) {
    // 通知 factory 將以 slot 模式 render
    factory.isSlot(headName);
    // render
    let vnode = factory.render(data, config);

    return vnode;
  };

}
