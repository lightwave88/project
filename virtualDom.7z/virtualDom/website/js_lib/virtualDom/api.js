import $GM from './g_module.js';

const $api = {
  templateList: new Map(),
};
export default $api;
//------------------------------------------------------------------------------
// 取得 template
$api.getTemplate = function (key) {
  if (!this.templateList.has(key)) {
    return null;
  }
  return this.templateList.get(key);
};
//------------------------------------------------------------------------------
// 從 dom 取得渲染函式
$api.templateByDom = function (name, dom) {
  debugger;

  if (dom == null) {
    dom = name;
    name = null;
  }

  if (dom == null) {
    throw new Error('no dom');
  }

  let parentDom = dom;

  dom = mergeTemplate(parentDom);

  // 先把模板移除，未來才能渲染新的內容
  // dom = dom.cloneNode(true);
  //------------------
  const $Compile = $GM.get('Compile');
  let compile = new $Compile();

  // 產生 vnode  
  let render = compile.byDom(dom);

  // 返回與 dom 綁定的 render_fun
  render.bind = function (dom) {
    return bindTemplate(render, dom);
  };

  if (name) {
    templateList.set(name, render);
  }
  return render;
};
//------------------------------------------------------------------------------
// 把 render 與 dom 綁定，以後只需要更新 data 即可
function bindTemplate(render, dom, optios = {}) {

  // 管理者
  let manager = getManager();

  let prev_vnode = null;
  let prev_rootDom = null;
  //------------------
  return function _render(data = {}) {
    debugger;

    // 渲染模板得到 dom 藍圖
    let node = render(data);

    debugger
    if (prev_vnode == null) {
      // 試圖取得舊的 vnode
      let child = getFirstChild_tag(dom);
      prev_vnode = (child == null ? null : $api.getVnode(child));
    }

    let oldNode = prev_vnode;
    let root = null;

    if (oldNode == null) {
      // 第一次建構，沒有上次的 vnode 記錄

      dom.innerHTML = '';
      // 線頭
      root = dom;
    }

    // 建構 dom
    let rootDom = $patch(oldNode, node, root);

    //------------------
    // manager 檢查

    // 

    //------------------
    // 更新記錄
    prev_vnode = node;
    prev_rootDom = rootDom;
  }

}
//------------------------------------------------------------------------------

$api.getVnode = function (dom) {
  const Vnode = $GM.get('Vnode');
  return Vnode.getVnodeByDom(dom);
}
//------------------------------------------------------------------------------

function $patch(oldNode, node, parentDom) {
  const $modifyDom = $GM.get('modifyDom');
  $modifyDom.patch(oldNode, node, parentDom);
};
//------------------------------------------------------------------------------
// 取得 dom 的第一個孩子（不包含 text）
function getFirstChild_tag(dom) {
  let childs = Array.from(dom.children);
  if (!childs.length) {
    return null;
  }
  return childs.shift();
}
//------------------------------------------------------------------------------
// 模板背後的管理者
function getManager() {
  return {};
}
//------------------------------------------------------------------------------
// 去除 <template>
function mergeTemplate(rootDom) {

  let judge = /^TEMPLATE$/i;

  if (rootDom == null || judge.test(rootDom.tagName)) {
    throw new Error('...');
  }

  let root = rootDom;

  while (root != null) {

    let childs;

    if (judge.test(root.tagName)) {
      let p = root.parent || null;
      if (p != null) {
        p.removeChild(root);
      }
      childs = Array.from(root.content.children);

    } else {
      childs = Array.from(root.childNodes);

      childs = childs.filter((c) => {
        root.removeChild(c);
        if (c.tagName != null) {
          return true;
        }
        return false;
      });
    }

    if (childs.length !== 1) {
      throw new Error('must just has one tag in root');
    }

    root = childs[0] || null;

    if (!judge.test(root.tagName)) {
      break;
    }
  }
  //------------------
  while (true) {
    let temp = root.querySelector('template');
    if (temp == null) {
      break;
    }

    let parent = temp.parentNode || null;
    let next = temp.nextSibling || null;
    let frag = temp.content;

    if (parent != null) {
      parent.removeChild(_temp);
      parent.insertBefore(frag, next);
    }
  }

  return root;
}



