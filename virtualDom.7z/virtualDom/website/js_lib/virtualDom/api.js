import $GM from './g_module.js';

const $api = {
  templateList: new Map(),
};
export default $api;

// 取得 template
$api.getTemplate = function (key) {
  if (!this.templateList.has(key)) {
    return null;
  }
  return this.templateList.get(key);
};

// 返回渲染函式
// include: virtualDom 是否要包含 dom
$api.templateByDom = function (...args) {
  debugger;

  let [name, dom, include] = args;

  let arg_length = args.length;

  if (arg_length == 2) {
    include = dom;
    dom = name;
    name = null;
  }

  include = (include == null ? true : include);

  if (!include) {
    let childs = Array.from(dom.children);
    if (childs.length > 1) {
      throw new Error('childdren must only 1');
    }
    dom = childs.pop();
  }

  if (dom == null) {
    return;
  }
  debugger;

  let parentDom = dom.parentNode;

  // 先把模板移除，未來才能渲染新的內容
  dom = dom.cloneNode(true);
  parentDom.innerHTML = '';
  //------------------
  const $Compile = $GM.get('Compile');
  let compile = new $Compile();

  // 產生 vnode  
  let render = compile.byDom(dom);

  debugger;
  // 建構的線頭
  let _parentDom = !include ? parentDom : dom;
  render = getRender(render, _parentDom);

  if (name) {
    templateList.set(name, render);
  }

  return render;
};



function $patch(oldNode, node, parentDom) {
  const $modifyDom = $GM.get('modifyDom');
  $modifyDom.patch(oldNode, node, parentDom);
};


$api.getVnode = function (dom) {

}

// parent 線頭
function getRender(_render, parent) {
  let prev_vnode;
  return function render(data = {}) {
    debugger;

    // 渲染模板得到 dom 藍圖
    let node = _render(data);

    debugger
    let oldNode = prev_vnode;
    let root = null;

    if (oldNode == null) {
      // 第一次建構

      const Vnode = $GM.get('Vnode');
      // 線頭
      root = parent;
      oldNode = Vnode.getInstance();
    }
    debugger;

    // 建構 dom
    $patch(oldNode, node, root);

    // 更新記錄
    prev_vnode = node;
  }
}

