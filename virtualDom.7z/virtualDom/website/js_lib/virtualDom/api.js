import $GM from './g_module.js';

class API {

  // 取得註冊的 component
  static getTemplate(key) {

  }
  //----------------------------------------------------------------------------
  // 從 dom 取得 component
  // config.include: 模板內容是否包含 dom
  static getByDom(name, dom, config = {}) {
    debugger;

    const $util = $GM.get('util');

    if (typeof name != 'string') {
      config = dom;
      dom = name;
      name = null;
    }

    config = Object.assign({}, config);
    let { include } = config;
    //------------------
    let includeDom = (include == null ? true : include);

    // 會是 documentFragment 節點
    let rootDom = document.createDocumentFragment();
    let rootList = [];
    if (includeDom) {
      rootList.push(dom);
    } else {
      rootList = $util.clear2SideEmptyDom(dom);
    }

    rootList.forEach(d => {
      rootDom.appendChild(d);
    });

    debugger;
    // 去除 <template>
    // mergeTemplate(rootDom);
    //------------------
    const $Compile = $GM.get('Compile');
    let compile = new $Compile();

    // 建造產生 vnode 的工廠函式
    let vnodeTemplate = compile.byDom(rootDom);

    if (vnodeTemplate == null) {
      // 建立 render_fun 失敗
      return null;
    }

    if (name) {
      // 登錄
      vnodeTemplate.name = name;
      API.g_manager.setTemplate(name, vnodeTemplate);
    }

    return vnodeTemplate;
  }
  //----------------------------------------------------------------------------
  static getByText() {

  }
  //----------------------------------------------------------------------------
  // 用非同步的方式取得 component
  static getByAsync() {

  }
  //----------------------------------------------------------------------------
  // 把 component 掛上指定 dom
  static render(dom, temp, data, config = {}) {

    let m = API.g_manager.getManager(dom, temp);

    m.render(data, config);
  }
  //----------------------------------------------------------------------------
  static get g_manager() {
    const GlobalManager = $GM.get('GlobalManager');
    return GlobalManager.getInstance();
  }

}

export { API };
//==============================================================================



