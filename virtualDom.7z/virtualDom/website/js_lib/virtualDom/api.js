import $GM from './g_module.js';

class API {

  // 取得註冊的 component
  static getTemplate(key) {

  }
  //----------------------------------------------------------------------------
  // 從 dom 取得 component
  // config.include: 模板內容是否包含 dom
  static getByDom(name, dom, config = {}) {
    debugger;

    if (typeof name != 'string') {
      config = dom;
      dom = name;
      name = null;
    }

    config = Object.assign({}, config);
    let { include } = config;
    //------------------
    let includeDom = (include == null ? true : include);

    // 會是 documentFragment 節點
    let rootDom = getRootDom(dom, includeDom);

    // 去除 <template>
    // mergeTemplate(rootDom);
    //------------------
    const $Compile = $GM.get('Compile');
    let compile = new $Compile();

    // 建造產生 vnode 的工廠函式
    let vnodeTemplate = compile.byDom(rootDom);

    if (vnodeTemplate == null) {
      // 建立 render_fun 失敗
      return null;
    }

    if (name) {
      // 登錄
      vnodeTemplate.name = name;
      API.g_manager.setTemplate(name, vnodeTemplate);
    }

    return vnodeTemplate;
  }
  //----------------------------------------------------------------------------
  static getByText() {

  }
  //----------------------------------------------------------------------------
  // 用非同步的方式取得 component
  static getByAsync() {

  }
  //----------------------------------------------------------------------------
  // 把 component 掛上指定 dom
  static render(dom, temp, data, config = {}) {

    let m = API.g_manager.getManager(dom, temp);

    m.render(data, config);
  }
  //----------------------------------------------------------------------------
  static get g_manager() {
    const GlobalManager = $GM.get('GlobalManager');
    return GlobalManager.getInstance();
  }

}

export { API };
//==============================================================================
// 抓出模板的 root
function getRootDom(topDom, includeTop) {
  debugger;

  const frag = document.createDocumentFragment;

  if (includeTop) {
    frag.appendChild(topDom);
  } else {
    let domList = Array.from(topDom.childNodes);

    // 去除兩端無用的 text
    for (let i = 0; i < domList.length; i++) {
      let d = domList[i];
      let remove = isEmptyText(d);
      if (remove) {
        domList[i] = null;
      } else {
        break;
      }
    }

    for (let i = domList.length; i > 0; i--) {
      let j = i - 1;
      let d = domList[j];
      let remove = isEmptyText(d);
      if (remove) {
        domList[j] = null;
      } else {
        break;
      }
    }

    domList.forEach((node) => {
      if (node == null) {
        return;
      }
      frag.appendChild(node);
    });

    topDom.innerHTML = '';
  } // endIf

  return frag;
}
//------------------------------------------------------------------------------
// 是否是空內容的文字節點
function isEmptyText(node) {

  let remove = false;
  let is_tag = (node.tagName == null ? false : true);

  if (!is_tag) {
    let text = node.nodeValue;
    text = text.trim();
    if (text.length == 0) {
      remove = true;
    }
  }
  return remove;
}
//------------------------------------------------------------------------------

