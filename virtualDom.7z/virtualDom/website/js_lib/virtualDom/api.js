import $GM from './g_module.js';

const $api = {
  templateList: new Map(),
};
export default $api;

// 取得 template
$api.getTemplate = function (key) {
  if (!this.templateList.has(key)) {
    return null;
  }
  return this.templateList.get(key);
};

// 返回渲染函式
$api.templateByDom = function (name, dom) {
  debugger;

  if (dom == null) {
    dom = name;
    name = null;
  }
  let parentDom = dom;

  let childs = Array.from(dom.children);
  if (childs.length > 1) {
    // 只能有一個 child
    throw new Error('childdren must only 1');
  }
  dom = childs.pop();

  if (dom == null) {
    return;
  }
  debugger;

  // 先把模板移除，未來才能渲染新的內容
  dom = dom.cloneNode(true);
  parentDom.innerHTML = '';
  //------------------
  const $Compile = $GM.get('Compile');
  let compile = new $Compile();

  // 產生 vnode  
  let render = compile.byDom(dom);

  // 返回與 dom 綁定的 render_fun
  render.bind = function (dom) {
    return bindTemplate(render, dom);
  };

  if (name) {
    templateList.set(name, render);
  }
  return render;
};

// 把 render 與 dom 綁定
function bindTemplate(render, dom) {
  let prev_vnode = null;

  dom.innerHTML = '';

  return function _render(data = {}) {
    debugger;

    // 渲染模板得到 dom 藍圖
    let node = render(data);

    debugger
    let oldNode = prev_vnode;
    let root = null;

    if (oldNode == null) {
      // 第一次建構

      const Vnode = $GM.get('Vnode');
      // 線頭
      root = dom;

      // 建立空的 vnode
      oldNode = Vnode.getInstance();
    }
    debugger;

    // 建構 dom
    $patch(oldNode, node, root);

    // 更新記錄
    prev_vnode = node;
  }

}


function $patch(oldNode, node, parentDom) {
  const $modifyDom = $GM.get('modifyDom');
  $modifyDom.patch(oldNode, node, parentDom);
};


$api.getVnode = function (dom) {

}



