import $GM from './g_module.js';

const $api = {};
export default $api;

// 返回渲染函式
$api.compileFromDom = function (dom) {
  debugger;
  const $Compile = $GM.get('Compile');
  let compile = new $Compile(); 
  let render_fun = compile.byDom(dom);
  return render_fun;
};

$api.patch = function(oldNode, node) {
  const $modifyDom = $GM.get('modifyDom');
  $modifyDom.patch(oldNode, node);
};

