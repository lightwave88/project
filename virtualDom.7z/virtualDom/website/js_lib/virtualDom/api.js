'use strict';

import $GM from './g_module.js';

class API {

  // 取得註冊的 component
  static getTemplate(key) {

  }

  static setTemplate() {

  }
  //----------------------------------------------------------------------------
  // API
  // 從 dom 取得 component
  // config.include: 模板內容是否包含 dom
  static getByDom(name, dom, config) {
    // debugger;

    if (typeof name != 'string') {
      config = dom;
      dom = name;
      name = null;
    }

    dom = dom || null;
    config = Object.assign({}, config);
    let { include } = config;
    //------------------
    let includeDom = (include == null ? true : include);

    // 會是 documentFragment 節點
    let rootDom = document.createDocumentFragment();

    if (dom != null) {
      let rootList;
      if (includeDom) {
        rootList = [];
        rootList.push(dom);
      } else {
        rootList = Array.from(dom.childNodes);
      }

      rootList.forEach(d => {
        rootDom.appendChild(d);
      });
    }
    //------------------
    const $Compile = $GM.get('Compile');
    let compile = new $Compile();

    // 建造產生 vnode 的工廠函式
    let vnodeFactory = compile.byDom(rootDom);

    if (name) {
      // 登錄
      vnodeFactory.name = name;
      API.g_manager.setTemplate(name, vnodeFactory);
    }

    return vnodeFactory;
  }
  //----------------------------------------------------------------------------
  // API
  static getByText() {

  }
  //----------------------------------------------------------------------------
  // API
  // 用非同步的方式取得 component
  static getByAsync() {

  }
  //----------------------------------------------------------------------------
  // API
  // 把 component 掛上指定 dom
  static render(job) {
    debugger;

    const $util = $GM.get('util');

    let dom = job.getDom();
    let temp = job.getTemplate() || null;

    // 先把 dom 與 template 連接
    let domData = $util.getDomData(dom, true);

    let { vManagerList } = domData;

    let tempID = (temp != null) ? temp.id : '*';

    let manager = vManagerList[tempID];
    if (manager == null) {
      const TemplateManager = $GM.get('TemplateManager');
      manager = new TemplateManager(dom, temp);
      vManagerList[tempID] = manager;
    }

    manager.render(job);
  }
  //----------------------------------------------------------------------------
  static job(dom) {
    const RenderJob = $GM.get('RenderJob');
    return new RenderJob(dom);
  }
  //----------------------------------------------------------------------------
  static view(config = {}) {
    const View = $GM.get('View');
    let view = new View(config);
    return view;
  }
  //----------------------------------------------------------------------------
  static getGlobalManager() {
    const GlobalManager = $GM.get('GlobalManager');
    return GlobalManager.getInstance();
  }
  //----------------------------------------------------------------------------


}

export { API };
//==============================================================================
{
  const $G_DATA = new Map();
  // 全局
  API.G = {
    set(){
      
    },
    get(){
      
    }
  };
}
