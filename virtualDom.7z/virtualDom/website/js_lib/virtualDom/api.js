import $GM from './g_module.js';

const $api = {
  templateList: new Map(),
};
export default $api;
//------------------------------------------------------------------------------
// 取得 template
$api.getTemplate = function (key) {
  if (!this.templateList.has(key)) {
    return null;
  }
  return this.templateList.get(key);
};
//------------------------------------------------------------------------------
// 從 dom 取得渲染函式
$api.templateByDom = function (name, dom) {
  debugger;

  if (dom == null) {
    dom = name;
    name = null;
  }

  if(dom ==null){
    throw new Error('no dom');
  }

  let parentDom = dom;

  let childs = Array.from(dom.children);
  if (childs.length > 1) {
    // 只能有一個 child
    throw new Error('childdren must only 1');
  }
  dom = childs.shift();

  if (dom == null) {
    return;
  }
  debugger;

  // 先把模板移除，未來才能渲染新的內容
  dom = dom.cloneNode(true);
  parentDom.innerHTML = '';
  //------------------
  const $Compile = $GM.get('Compile');
  let compile = new $Compile();

  // 產生 vnode  
  let render = compile.byDom(dom);

  // 返回與 dom 綁定的 render_fun
  render.bind = function (dom) {
    return bindTemplate(render, dom);
  };

  if (name) {
    templateList.set(name, render);
  }
  return render;
};
//------------------------------------------------------------------------------
// 把 render 與 dom 綁定，以後只需要更新 data 即可
function bindTemplate(render, dom) {
  let prev_vnode = null;
  //-------------
  return function _render(data = {}) {
    debugger;

    // 渲染模板得到 dom 藍圖
    let node = render(data);

    debugger
    if (prev_vnode == null) {
      // 試圖取得舊的 vnode
      let child = getFirstChild(dom);
      prev_vnode = (child == null ? null : $api.getVnode(child));
    }

    let oldNode = prev_vnode;
    let root = null;

    if (oldNode == null) {
      // 第一次建構，沒有上次的 vnode 記錄

      dom.innerHTML = '';
      // 線頭
      root = dom;
    }

    // 建構 dom
    $patch(oldNode, node, root);

    // 更新記錄
    prev_vnode = node;
  }

}
//------------------------------------------------------------------------------

$api.getVnode = function (dom) {
  const Vnode = $GM.get('Vnode');
  return Vnode.getVnodeByDom(dom);
}


function $patch(oldNode, node, parentDom) {
  const $modifyDom = $GM.get('modifyDom');
  $modifyDom.patch(oldNode, node, parentDom);
};

function getFirstChild(dom) {
  let childs = Array.from(dom.children);
  if (!childs.length) {
    return null;
  }
  return childs.shift();
}

