import $GM from './g_module.js';

const $api = {
  templateList: new Map(),
};

export default $api;
export { $api as api };

const $reg_1 = /^TEMPLATE$/i;
//------------------------------------------------------------------------------
// 取得 template
$api.getTemplate = function (key) {
  if (!this.templateList.has(key)) {
    return null;
  }
  return this.templateList.get(key);
};
//------------------------------------------------------------------------------
// 從 dom 取得渲染函式
$api.getByDom = function (name, dom, options = {}) {

  if (typeof name != 'string') {
    options = dom;
    dom = name;
    name = null;
  }

  options = Object.assign({}, options);
  let { include } = options;
  //------------------
  let includeDom = (include == null ? true : include);

  let rootDom = findRootDom(dom, includeDom);

  // 去除 <template>
  mergeTemplate(rootDom);
  //------------------
  const $Compile = $GM.get('Compile');
  let compile = new $Compile();

  // 建造產生 vnode 的工廠函式
  let templateObj = compile.byDom(dom);

  if (templateObj == null) {
    // 建立 render_fun 失敗
    return null;
  }

  // 返回與 dom 綁定的 render_fun
  templateObj.bind = function (dom) {
    return bindTemplate(templateObj, dom);
  };

  if (name) {
    templateList.set(name, templateObj);
  }
  return templateObj;
};
//------------------------------------------------------------------------------
$api.getByText = function () {

};
//------------------------------------------------------------------------------
// 把 render 與 dom 綁定，以後只需要更新 data 即可
function bindTemplate(render, dom, optios = {}) {

  // 管理者
  const $manager = getManager();

  const $container = dom;
  let prev_vnode = null;
  let prev_rootDom = null;
  //------------------
  return function _render(data = {}) {
    debugger;

    // 渲染模板得到 dom 藍圖
    let node = render(data) || null;

    console.log('create vnode');
    console.dir(node);
    console.log('----------');

    debugger
    if (prev_vnode == null) {
      // 試圖取得舊的 vnode
      let child = getFirstChild_tag(dom);
      prev_vnode = (child == null ? null : $api.getVnode(child));
    }

    if (prev_vnode == null) {
      // 沒有 vnode 表示沒有 html 內容
      let dom_childs = Array.from($container.childNodes);
      if (dom_childs.length > 0) {
        $container.innerHTML = '';
      }
    }

    // 建構 dom
    $patch(prev_vnode, node, $container);

    //------------------
    // manager 檢查

    // 

    //------------------
    // 更新記錄
    prev_vnode = node;

    if (node == null) {
      prev_rootDom = null;
    } else {
      prev_rootDom = node.dom;
    }
  }

}
//------------------------------------------------------------------------------

$api.getVnode = function (dom) {
  const Vnode = $GM.get('Vnode');
  return Vnode.getVnodeByDom(dom);
}
//------------------------------------------------------------------------------

function $patch(oldNode, node, parentDom) {
  const ModifyDom = $GM.get('ModifyDom');
  const $modifyDom = new ModifyDom();

  let dom = $modifyDom.patch(oldNode, node, parentDom);
  return dom;
};
//------------------------------------------------------------------------------
// 取得 dom 的第一個孩子（不包含 text）
function getFirstChild_tag(dom) {
  let childs = Array.from(dom.children);
  if (!childs.length) {
    return null;
  }
  return childs.shift();
}
//------------------------------------------------------------------------------
// 模板背後的管理者
function getManager() {
  return {};
}
//------------------------------------------------------------------------------
function findRootDom(topDom, includeTop) {
  debugger;
  let rootDom;

  if (includeTop) {
    let parent = topDom.parentNode;
    parent.removeChild(topDom);
    rootDom = topDom;
  } else {
    rootDom = getFirstChild_tag(topDom);
    topDom.removeChild(rootDom);
  }

  // 若遇到 <template> 或 <template> 套嵌
  while (rootDom != null && rootDom.content != null) {
    let p = rootDom.content;
    rootDom = getFirstChild_tag(p);
  }

  if (rootDom == null || rootDom.tagName == null) {
    throw new Error('......');
  }

  if (rootDom.parent != null) {
    rootDom.parent.removeChild(rootDom);
  }

  // check rootDom
  // 必須是實體 tag
  return rootDom;
}
//------------------------------------------------------------------------------
// 去除 <template>
function mergeTemplate(rootDom) {
  debugger;

  while (true) {
    let temp = rootDom.querySelector('template');
    if (temp == null) {
      break;
    }

    let parent = temp.parentNode || null;
    let next = temp.nextSibling || null;
    let frag = temp.content;

    if (parent != null) {
      parent.removeChild(temp);
      parent.insertBefore(frag, next);
    }
  }
}



