import $GM from '../g_module.js';


let $global_manager;

class API {

  // 取得註冊的 component
  static getTemplate(key) {

  }
  //----------------------------------------------------------------------------
  // 從 dom 取得 component
  static getByDom(name, dom, options = {}) {

    if (typeof name != 'string') {
      options = dom;
      dom = name;
      name = null;
    }

    options = Object.assign({}, options);
    let { include } = options;
    //------------------
    let includeDom = (include == null ? true : include);

    // 會是 documentFragment 節點
    let rootDom = getRootDom(dom, includeDom);

    // 去除 <template>
    mergeTemplate(rootDom);
    //------------------
    const $Compile = $GM.get('Compile');
    let compile = new $Compile();

    // 建造產生 vnode 的工廠函式
    let vnodeTemplate = compile.byDom(rootDom);

    if (vnodeTemplate == null) {
      // 建立 render_fun 失敗
      return null;
    }

    if (name) {
      // 登錄
      vnodeTemplate.name = name;    
      this.manager.setTemplate(name, vnodeTemplate);
    }

    return vnodeTemplate;
  }
  //----------------------------------------------------------------------------
  static getByText() {

  }
  //----------------------------------------------------------------------------
  // 用非同步的方式取得 component
  static getByAsync() {

  }
  //----------------------------------------------------------------------------
  // 把 component 掛上指定 dom
  static render(dom, temp, data, options) {

  }
  //----------------------------------------------------------------------------
  static get manager() {
    const GlobalManager = $GM.get('GlobalManager');

    if ($global_manager == null) {
      $global_manager = new GlobalManager();
    }
    return $global_manager;
  }

}

export { API };
//==============================================================================

const $REG_1 = /^#text$/i;

function getRootDom(topDom, includeTop) {
  debugger;

  const frag = document.createDocumentFragment;

  if (includeTop) {
    frag.appendChild(topDom);
  } else {
    let domList = Array.from(topDom.childNodes);

    domList.forEach(node => {

      let keep = (() => {
        if (child.tagName == null) {
          if (!$REG_1.test(node.nodeName)) {
            // 非文字節點
            return false;
          }
          let text = child.nodeValue;
          text = text.trim();

          // 是否是空文字節點
          if (text.length) {
            return true;
          }
          return false;
        }
        return true;
      })();

      if (keep) {
        frag.appendChild(node);
      } else {
        topDom.removeChild(node);
      }
    }); // endForEach
  } // endIf

  return frag;
}

// 去除 <template>
function mergeTemplate(rootDom) {
  debugger;

  while (true) {
    let temp = rootDom.querySelector('template');
    if (temp == null) {
      break;
    }

    let parent = temp.parentNode || null;
    let next = temp.nextSibling || null;
    let frag = temp.content;

    if (parent != null) {
      parent.removeChild(temp);
      parent.insertBefore(frag, next);
    }
  }
}
