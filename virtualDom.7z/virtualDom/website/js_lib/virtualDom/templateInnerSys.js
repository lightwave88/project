import $GM from './g_module.js';

// template 內部的系統($_GLOBAL)
class TemplateInnerSys {

    $data = {};

    $view;

    $context;

    $slotsMap = {};

    // Set()
    $slotNameList = new Set();
    //--------------------------------------------------------------------------
    constructor(config = {}) {

        let { context, view, template } = config;
        if (context != null) {
            this.$context = context;
        }

        if(view != null){
            this.$view = view;
        }

        // 取得模板自帶訊息
    }
    //--------------------------------------------------------------------------
    setData(data = {}) {
        Object.assign(this.$data, data);
    }

    // 來自使用者設定
    setSlot(slots = {}) {
        Object.assign(this.$slotsMap, slots);
    }
    //--------------------------------------------------------------------------

    setSlotNameList(list) {
        list = Array.from(list);

        list.forEach((name) => {
            this.$slotName.add(name);
        });

    }
    //--------------------------------------------------------------------------
    // return vnodeList
    callSlot(name, args) {
        let vnodeList;

        if (this.$view != null) {
            vnodeList = this.$view.$$$callSlot(name, args);
        }

        vnodeList = (Array.isArray(vnodeList)) ? vnodeList : [];

        return vnodeList;
    }
    //--------------------------------------------------------------------------
    callCompute(name, args) {
        if (this.$view != null) {
            vnodeList = this.$view.$$$callCompute(name, args);
        }
    }
    //--------------------------------------------------------------------------
    getTemplateSelf() {

        if (true) {

        } else {

        }
    }
}

export { TemplateInnerSys };
export default TemplateInnerSys;
