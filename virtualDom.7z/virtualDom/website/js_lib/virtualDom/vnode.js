import $GM from './g_module.js';

// style
const $reg_1 = /^([^]*?):([^]*)/;
const VNODE_VARNAME = '$$$vnode';

class Vnode {


    //--------------------------------------------------------------------------
    static getVnodeByDom(dom) {
        if (dom.hasOwnProperty(VNODE_VARNAME)) {
            return dom[VNODE_VARNAME];
        }
        return null;
    }
    //--------------------------------------------------------------------------
    static getInstance(nodeName, tagName, parent) {
        return new Vnode(nodeName, tagName, parent);
    }
    //--------------------------------------------------------------------------
    static is_vnode(obj) {
        if (obj == null || (typeof obj != 'object')) {
            return false;
        }
        return (obj instanceof Vnode);
    }
    //--------------------------------------------------------------------------
    constructor(nodeName, tagName, parent) {

        // 與所映射的 dom.nodeName 相同
        this.nodeName;

        // 判別是否是 tag
        this.tagName = null;

        // 非標準標籤節點
        this.text;

        // 代表的 dom
        this.dom;
        //------------------
        this.parent = parent || null;

        // 子節點(vnode)
        this.childs = [];
        //------------------
        // dom.id
        this.id;

        // dom.className
        this.classList = [];

        // 供比較兩 vnode 是否相同
        this.classString = '';

        // dom.style
        this.style = {};

        // dom.attrs
        this.attrs = new Map();
        //------------------

        // 記錄是否有含計算的 attr
        this.com_attrs = new Set();

        // 關於事件
        this.events = new Map();

        // 靜態 dom 不由 data 所控制
        // 若在 command 之間就不是
        // 表示使用者將用 command 控制
        this.is_static = true;

        this._init(nodeName, tagName);
    }
    //--------------------------------------------------------------------------
    _init(nodeName, tagName) {

        if (tagName != null) {
            this.tagName = tagName;
        }
        this.nodeName = nodeName || tagName || null;

        if (typeof this.nodeName == 'string') {
            this.nodeName = this.nodeName.toLowerCase();
        }

        if (this.parent) {
            this.appendTo(this.parent);

            if (!this.parent.is_static) {
                this.is_static = false;
            }
        }
    }
    //--------------------------------------------------------------------------
    setStatic(judge) {
        this.is_static = judge;
    }
    //--------------------------------------------------------------------------
    appendTo(parent) {
        parent.childs.push(this);
    }
    //--------------------------------------------------------------------------
    append(child = []) {
        let childs;

        if (Array.isArray(child)) {
            childs = child;
        } else {
            childs = [child];
        }

        childs.forEach(el => {
            this.childs.push(el);
        });
    }
    //--------------------------------------------------------------------------
    removeChild(vnode, clear = false) {
        // console.log('removeChild');
        // console.dir(this.childs);
        // console.dir(vnode);


        let index = this.childs.findIndex((v) => {
            return (v === vnode);
        });
        if (index < 0) {
            return;
        }
        this.childs.splice(index, 1);

        if (clear === true && !this.childs.length) {
            // console.log('this.childs = null');
            this.childs = null;
        }
    }
    //--------------------------------------------------------------------------
    detach(clear) {
        if (this.parent == null) {
            return;
        }
        this.parent.removeChild(this, clear);
    }
    //--------------------------------------------------------------------------
    setId(id) {
        this.id = id;
    }
    //--------------------------------------------------------------------------
    // computer:class 是否由 data 所控制
    setClass(computer = false, ...args) {
        if (computer == true) {
            this.com_attrs.add('class');
        }

        args.forEach(arg => {
            let list;
            if (Array.isArray(arg)) {
                list = arg;
            } else if (arg == null || typeof arg == "object") {
                list = [];
            } else {
                // 轉爲文字
                let _class = '' + arg;

                // 處理空白
                list = _class.split(/\s+/);
            }

            list.forEach((e) => {
                if (!e.length) {
                    return;
                }
                this.classList.push(e);
            });
        });
    }
    //--------------------------------------------------------------------------
    // computer:style 是否由 data 所控制
    setStyle(computer = false, ...args) {
        if (computer == true) {
            this.com_attrs.add('style');
        }

        argss.forEach(arg => {
            let style;

            if (arg == null) {
                return;
            } else if (typeof arg == 'object') {
                style = arg;
            } else {
                arg = "" + arg;
                let list = arg.split(/;/);

                list.forEach(el => {
                    let j = $reg_1.exec(el);

                    let k, v;

                    if (j == null) {
                        k = el.trim();
                    } else {
                        let [match, g1, g2] = j;
                        k = g1.trim();
                        v = g2.trim();
                    }
                    style[k] = v;
                });
            } // endif

            Object.assign(this.style, style);

        });
    }
    //--------------------------------------------------------------------------
    // computer:attr 是否由 data 所控制
    setAttr(computer = false, key, ...args) {
        if (computer == true) {
            this.com_attrs.add('key');
        }

        args = args.map((arg) => {
            let res;

            if (typeof arg == 'string') {
                res = arg;
            } else if (arg == null) {
                res = '';
            } else if (typeof arg != 'string') {
                try {
                    res = JSON.stringify(arg);
                } catch (er) {
                    res = er.toString();
                }
            }
            return res;
        });


        let value = args.join('');
        this.attrs.set(key, value);
    }
    //--------------------------------------------------------------------------
    // computer:文字內容 是否由 data 所控制
    setText(computer = false, ...args) {
        // debugger;
        this.is_static = !computer;

        args = args.map((arg) => {
            let res;
            if (typeof arg == 'string') {
                res = arg;
            } else if (arg == null) {
                res = '';
            } else if (typeof arg != 'string') {
                try {
                    res = JSON.stringify(arg);
                } catch (er) {
                    res = er.toString();
                }
            }
            return res;
        });
        this.text = args.join('');
    }
    //--------------------------------------------------------------------------
    setDom(dom) {
        this.dom = dom;

        let that = this;

        let oldVnode = dom[VNODE_VARNAME] || null;

        if (oldVnode === this) {
            return;
        }

        delete dom[VNODE_VARNAME];

        Object.defineProperty(dom, VNODE_VARNAME, {
            configurable: true,
            value: that
        });
    }
    //--------------------------------------------------------------------------
    // 與 dom 脫鉤
    unlinkDom() {
        let dom = this.dom;
        this.dom = null;

        let oldVnode = dom[VNODE_VARNAME] || null;
        if (oldVnode !== this) {
            return;
        }

        delete dom[VNODE_VARNAME];
    }
    //--------------------------------------------------------------------------
    // 設定結束
    end() {
        // 排序
        if (this.classList.length) {
            this.classList.sort();
        }

        this.classString = JSON.stringify(this.classList);
    }

    //--------------------------------------------------------------------------
    // 釋放資源
    destroy() {
        debugger;

        if (this.dom == null) {
            // 空節點
            return;
        }

        if (this.dom.hasOwnProperty(VNODE_VARNAME)) {
            if (this.dom[VNODE_VARNAME] === this) {
                delete this.dom[VNODE_VARNAME];
            }
        }

        this.detach(true);
        this.parent = null;

        this.nodeName = null;
        this.tagName = null;
        this.text = null;
        this.id = null;

        this.classList.length = 0;
        this.classList = null;

        this.attrs.clear();
        this.attrs = null;

        for (var k in this.style) {
            delete this.style[k];
        }

        this.style = null;

        this.com_attrs.clear();
        this.com_attrs = null;

        this.is_static = null;

        // 事件
        this.events.clear();
        this.events = null;

        this.unlinkDom();

        console.log('vnode.destroy');
        console.dir(this);
    }

}

export { Vnode };