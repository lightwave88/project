import $GM from './g_module.js';

// style
const $reg_1 = /^([^]*?):([^]*)/;
const VNODE_VARNAME = '$$$vnode';

class Vnode {

    //--------------------------------------------------------------------------
    static getVnodeByDom(dom) {
        if (dom.hasOwnProperty(VNODE_VARNAME)) {
            return dom[VNODE_VARNAME];
        }
        return null;
    }
    //--------------------------------------------------------------------------
    static is_vnode(obj) {
        if (obj == null || (typeof obj != 'object')) {
            return false;
        }
        return (obj instanceof Vnode);
    }
    //--------------------------------------------------------------------------
    constructor(nodeName, tagName, parent = null) {

        this.index = 0;

        // 與所映射的 dom.nodeName 相同
        this.nodeName;

        // 判別是否是 tag
        this.tagName = null;

        // 非標準標籤節點
        this.text;

        // 代表的 dom
        this.dom;
        //------------------
        this.$$parent;

        // 子節點(vnode)
        this.childs = [];
        //------------------
        // dom.id
        this.id;

        // dom.className
        this.classList = [];

        // 供比較兩 vnode 是否相同
        this.classString = '';

        // dom.style
        this.style = {};

        // dom.attrs
        this.attrs = new Map();
        //------------------

        // 記錄是否有含計算的 attr
        this.compute_attrs = new Set();

        // 關於事件
        this.events = new Map();   
        
        this.events_cb = {};

        // 關於 keepAlive
        this.keepAlive_id = null;

        // 一些會被繼承的訊息
        this.inherit_info = {
            // 是否由 data 所控制
            static: true,

            keepAlive: false,
        };

        this._init(nodeName, tagName, parent);
    }
    //-----------------------------------------------------
    _init(nodeName, tagName, parnet) {

        // 會自動連接一些資訊
        this.parent = parnet;

        if (tagName != null) {
            this.tagName = tagName;
        }
        this.nodeName = nodeName.toLowerCase();

        if (this.parent) {
            this.appendTo(this.parent);
        }
    }
    //-----------------------------------------------------
    set parent(parent) {
        // debugger;
        this.$$parent = parent;
        if (this.$$parent == null) {
            return;
        }
        const p_info = this.$$parent.inherit_info;
        const info = this.inherit_info;

        // 繼承資訊
        if (info.static && p_info.static === false) {
            info.static = p_info.static;
        }

        if (p_info.keepAlive != null) {
            info.keepAlive = p_info.keepAlive;
        }
    }
    //-----------------------------------------------------
    get parent() {
        return this.$$parent;
    }
    //-----------------------------------------------------
    setStatic(judge) {
        this.inherit_info.static = judge;
    }
    //-----------------------------------------------------
    appendTo(parent) {

        if (this.$$parent == null) {
            this.$$parent = parent;
        }

        this.index = parent.childs.length;
        parent.childs.push(this);
    }
    //-----------------------------------------------------
    append(child = []) {

        if (!Array.isArray(child)) {
            child = [child];
        }

        child.forEach(el => {
            el.appendTo(this);
        });
    }
    //-----------------------------------------------------
    setId(id) {
        this.id = id;
    }
    //-----------------------------------------------------
    // computer:class 是否由 data 所控制
    setClass(computer = false, ...args) {
        // debugger;
        if (computer == true) {
            this.compute_attrs.add('class');
        }

        args.forEach(arg => {
            let list;
            if (Array.isArray(arg)) {
                list = arg;
            } else if (arg == null || typeof arg == "object") {
                list = [];
            } else {
                // 轉爲文字
                let _class = '' + arg;

                // 處理空白
                list = _class.split(/\s+/);
            }

            list.forEach((e) => {
                // debugger;
                if (e.length === 0) {
                    return;
                }
                this.classList.push(e);
            });
        });
    }
    //-----------------------------------------------------
    // computer:style 是否由 data 所控制
    setStyle(computer = false, ...args) {
        if (computer == true) {
            this.compute_attrs.add('style');
        }

        argss.forEach(arg => {
            let style;

            if (arg == null) {
                return;
            } else if (typeof arg == 'object') {
                style = arg;
            } else {
                arg = "" + arg;
                let list = arg.split(/;/);

                list.forEach(el => {
                    let j = $reg_1.exec(el);

                    let k, v;

                    if (j == null) {
                        k = el.trim();
                    } else {
                        let [match, g1, g2] = j;
                        k = g1.trim();
                        v = g2.trim();
                    }
                    style[k] = v;
                });
            } // endif

            Object.assign(this.style, style);

        });
    }
    //-----------------------------------------------------
    // computer:attr 是否由 data 所控制
    setAttr(computer = false, key, ...args) {
        if (computer == true) {
            this.compute_attrs.add('key');
        }

        args = args.map((arg) => {
            let res;

            if (typeof arg == 'string') {
                res = arg;
            } else if (arg == null) {
                res = '';
            } else if (typeof arg != 'string') {
                try {
                    res = JSON.stringify(arg);
                } catch (er) {
                    res = er.toString();
                }
            }
            return res;
        });


        let value = args.join('');
        this.attrs.set(key, value);
    }
    //-----------------------------------------------------
    // computer:文字內容 是否由 data 所控制
    setText(computer = false, ...args) {
        // debugger;

        if (computer) {
            this.is_static = false;
        }

        args = args.map((arg) => {
            let res;
            if (typeof arg == 'string') {
                res = arg;
            } else if (arg == null) {
                res = '';
            } else if (typeof arg != 'string') {
                try {
                    res = JSON.stringify(arg);
                } catch (er) {
                    res = er.toString();
                }
            }
            return res;
        });
        this.text = args.join('');
    }
    //-----------------------------------------------------
    setDom(dom) {
        this.dom = dom;

        let that = this;

        let oldVnode = dom[VNODE_VARNAME] || null;

        if (oldVnode != null) {

            if (oldVnode === this) {
                return;
            } else {
                delete dom[VNODE_VARNAME];

            }
        }

        Object.defineProperty(dom, VNODE_VARNAME, {
            configurable: true,
            value: that
        });
    }
    //-----------------------------------------------------
    // 與 dom 脫鉤
    unlinkDom() {
        let dom = this.dom;

        let oldVnode = dom[VNODE_VARNAME] || null;
        if (oldVnode == null || oldVnode !== this) {
            return;
        }

        delete dom[VNODE_VARNAME];
        // 清除綁定事件
    }
    //-----------------------------------------------------
    // 設定結束
    end() {
        // 排序
        if (this.classList.length) {
            this.classList.sort();
        }

        this.classString = JSON.stringify(this.classList);
    }
    //-----------------------------------------------------
    clearChilds() {
        this.childs.length = 0;
    }

    // 當 dom 易主時
    clearEvent(eventName = null) {

    }

    addEvent(eventName) {

    }
    //-----------------------------------------------------
    // 釋放資源
    destroy() {
        debugger;

        return;

        if (this.dom == null) {
            // 空節點
            return;
        }

        if (this.dom.hasOwnProperty(VNODE_VARNAME)) {
            if (this.dom[VNODE_VARNAME] === this) {
                delete this.dom[VNODE_VARNAME];
            }
        }

        // this.detach(true);
        // this.parent = null;

        this.nodeName = null;
        this.tagName = null;
        this.text = null;
        this.id = null;

        this.classList.length = 0;
        this.classList = null;

        this.attrs.clear();
        this.attrs = null;

        for (var k in this.style) {
            delete this.style[k];
        }

        this.style = null;

        this.compute_attrs.clear();
        this.compute_attrs = null;

        // this.is_static = null;

        this.unlinkDom();

        console.log('vnode.destroy');
        console.dir(this);
    }
    //-----------------------------------------------------
    get is_static() {
        return this.inherit_info.static;
    }
    //-----------------------------------------------------
    set is_static(_static) {

        if (_static != null) {
            this.inherit_info.static = !!_static;
        } else {
            this.inherit_info.static = _static;
        }
    }
    //-----------------------------------------------------



}

export { Vnode };