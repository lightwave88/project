import $GM from './g_module.js';

// style
const $reg_1 = /^([^]*?):([^]*)/;
const VNODE_VARNAME = '$$$b_vnode';
const CALLBACK_ID = '$vnodeEvent';

class Vnode {

    index = null;

    // 與所映射的 dom.nodeName 相同
    nodeName = null;

    // 判別是否是 tag
    tagName = null;

    // 非標準標籤節點
    text;

    // 代表的 dom
    dom;
    //------------------
    // vnode
    parent = null;

    // 子節點(vnode)
    childs = [];
    //------------------

    // <b-slot> 的 parent
    // 一個 node 可以有多個 slot
    // []
    slotParents;
    //------------------
    keep;
    keepAll;
    //------------------
    // dom.id
    dom_id;

    // dom.className
    classList = [];

    // 供比較兩 vnode 是否相同
    classString = '';

    // dom.style
    style = {};

    // dom.attrs
    attrs = new Map();
    //------------------

    // 記錄是否有含計算的 attr
    compute_attrs = new Set();

    // 關於事件
    events = {};

    events_cb = {};
    //------------------

    isStatic = true;

    // 模板內的系統
    tempSys;
    //--------------------------------------------------------------------------
    static createVnode(nodeName, tagName, parent, sys) {
        return new Vnode(nodeName, tagName, parent, sys);
    }

    //--------------------------------------------------------------------------
    static getVnodeByDom(dom) {
        if (dom.hasOwnProperty(VNODE_VARNAME)) {
            return dom[VNODE_VARNAME];
        }
        return null;
    }
    //--------------------------------------------------------------------------
    static is_vnode(obj) {
        if (obj == null || (typeof obj != 'object')) {
            return false;
        }
        return (obj instanceof Vnode);
    }
    //--------------------------------------------------------------------------
    static is_emptyNode(obj) {
        if (!(obj instanceof Vnode)) {
            throw new Error('...');
        }
        return (this.nodeName == null && this.tagName == null);
    }
    //--------------------------------------------------------------------------
    // 從 domNode 轉接資訊
    constructor(nodeName, tagName, parent = null, sys) {

        this.tempSys = sys;

        if (tagName != null) {
            this.tagName = tagName;
        }

        if (nodeName != null) {
            this.nodeName = nodeName;
        }

        if (parent != null) {
            // this.parent = parent;
            this.appendTo(parent);
        }
    }
    //--------------------------------------------------------------------------
    setStatic(judge) {
        this.isStatic = judge;
    }
    //--------------------------------------------------------------------------
    appendTo(parent) {
        if (this.parent != null) {
            throw new Error('...');
        }
        this.parent = parent;

        this.index = parent.childs.length;
        parent.childs.push(this);
    }
    //--------------------------------------------------------------------------
    // <b-slot>
    append(child) {

        child = child || [];

        if (!Array.isArray(child)) {
            child = [child];
        }

        child.forEach(el => {
            el.appendTo(this);
        });
    }
    //--------------------------------------------------------------------------
    // <b-slot>
    removeAllChild() {
        let childs = this.childs.slice();
        this.childs.length = 0;

        childs.forEach((child) => {
            child.parent = null;
            child.index = null;
        });

        return childs;
    }
    //--------------------------------------------------------------------------
    setId(id) {
        this.id = id;
    }
    //--------------------------------------------------------------------------
    // computer:class 是否由 data 所控制
    setClass(computer = false, ...args) {
        // debugger;
        if (computer == true) {
            this.compute_attrs.add('class');
        }

        args.forEach(arg => {
            let list;
            if (Array.isArray(arg)) {
                list = arg;
            } else if (arg == null || typeof arg == "object") {
                list = [];
            } else {
                // 轉爲文字
                let _class = '' + arg;

                // 處理空白
                list = _class.split(/\s+/);
            }

            list.forEach((e) => {
                // debugger;
                if (e.length === 0) {
                    return;
                }
                this.classList.push(e);
            });
        });
    }
    //--------------------------------------------------------------------------
    // computer:style 是否由 data 所控制
    setStyle(computer = false, ...args) {
        if (computer == true) {
            this.compute_attrs.add('style');
        }

        argss.forEach(arg => {
            let style;

            if (arg == null) {
                return;
            } else if (typeof arg == 'object') {
                style = arg;
            } else {
                arg = "" + arg;
                let list = arg.split(/;/);

                list.forEach(el => {
                    let j = $reg_1.exec(el);

                    let k, v;

                    if (j == null) {
                        k = el.trim();
                    } else {
                        let [match, g1, g2] = j;
                        k = g1.trim();
                        v = g2.trim();
                    }
                    style[k] = v;
                });
            } // endif

            Object.assign(this.style, style);

        });
    }
    //--------------------------------------------------------------------------
    // computer:attr 是否由 data 所控制
    setAttr(computer = false, key, ...args) {
        if (computer == true) {
            this.compute_attrs.add('key');
        }

        args = args.map((arg) => {
            let res;

            if (typeof arg == 'string') {
                res = arg;
            } else if (arg == null) {
                res = '';
            } else if (typeof arg != 'string') {
                try {
                    res = JSON.stringify(arg);
                } catch (er) {
                    res = er.toString();
                }
            }
            return res;
        });

        let value = args.join('');
        this.attrs.set(key, value);
    }
    //--------------------------------------------------------------------------
    // computer:文字內容 是否由 data 所控制
    setText(computer = false, ...args) {
        // debugger;

        if (computer) {
            this.is_static = false;
        }

        args = args.map((arg) => {
            let res;
            if (typeof arg == 'string') {
                res = arg;
            } else if (arg == null) {
                res = '';
            } else if (typeof arg != 'string') {
                try {
                    res = JSON.stringify(arg);
                } catch (er) {
                    res = er.toString();
                }
            }
            return res;
        });
        this.text = args.join('');
    }
    //--------------------------------------------------------------------------
    linkDom(dom) {
        this.dom = dom;

        let that = this;

        let oldVnode = dom[VNODE_VARNAME] || null;

        if (oldVnode != null) {

            if (oldVnode === this) {
                return null;
            } else {
                // dom.vnode 轉移時，要清除事件綁定
                oldVnode.removeEvent();
                delete dom[VNODE_VARNAME];
            }
        }

        Object.defineProperty(dom, VNODE_VARNAME, {
            configurable: true,
            value: that
        });

        return oldVnode;
    }
    //--------------------------------------------------------------------------
    // 與 dom 脫鉤
    unlinkDom() {
        let dom = this.dom;

        let oldVnode = dom[VNODE_VARNAME] || null;
        if (oldVnode == null || oldVnode !== this) {
            return;
        }

        delete dom[VNODE_VARNAME];
        // 清除綁定事件
    }
    //--------------------------------------------------------------------------
    // 設定結束
    end() {
        if (this.index == null) {
            this.index = 0;
        }

        // 檢查 static
        if (typeof this.isStatic != 'boolean') {
            throw new Error(`vnode.isStatic no set`);
        }

        if (this.keep != null) {
            // slot.keep 必須重命名
            this.tempSys.addKeep(this.keep, this);
        }
        if (this.keepAll != null) {
            // slot.keep 必須重命名
            this.tempSys.addKeep(this.keep, this);
        }
        //------------------
        // class

        // 排序
        if (this.classList.length) {
            this.classList.sort();
        }

        this.classString = JSON.stringify(this.classList);
        //------------------
        if (this.slotParents != null) {
            this.slotParents.forEach(id => {
                // 告訴管理者那些 slotID 與那些 vnode 有關
                this.tempSys.setSlotParent(id, this);
            });
        }
    }
    //--------------------------------------------------------------------------
    clearChilds() {
        this.childs.length = 0;
    }

    setKeep(name, isAll = false) {
        if (isAll) {
            this.keepAll = name;
        } else {
            this.keep = name;
        }
    }
    //--------------------------------------------------------------------------
    // 若帶有 <b-slot> 子節點
    // factory 執行時 vnode 呼叫
    setSlotParent(list = []) {
        // 包含那些 slotID
        if (this.slotParents == null) {
            this.slotParents = [];
        }
        this.slotParents = this.slotParents.concat(list);
    }

    //--------------------------------------------------------------------------
    // 當 dom 易主時
    removeEvent(eventName = null, callback = null) {
        callback = (typeof callback == 'function') ? callback : null;
        eventName = eventName || null;

        if (callback != null && callback[CALLBACK_ID] == null) {
            return;
        }

        let keyList = [];

        if (eventName != null) {
            if (eventName in this.events) {
                keyList = [eventName];
            }
        } else {
            keyList = Object.keys(this.events);
        }

        keyList.forEach((name) => {

            if (callback == null) {
                this.events[name].length = 0;
            } else {

                let callbackList = this.events[name];
                let i = 0;
                while (i < callbackList.length) {
                    let j = i++;
                    let fn = callbackList[j]

                    if (callback[CALLBACK_ID] === fn[CALLBACK_ID]) {
                        callbackList.splice(j, 1);
                        i = j;
                    }
                }
            }

            if (this.events[name].length == 0) {
                delete this.events[name];
                if (!(name in this.events_cb)) {
                    return;
                }
                let callback_1 = this.events_cb[name];
                delete this.events_cb[name];
                this.dom.removeEventListener(name, callback_1, { capture: true });
            }

        });
    }
    // dom 事件
    addEvent(eventName, callback) {
        if (!(eventName in this.events_cb)) {
            // 初始化
            this.events_cb[eventName] = this._getEventCallback(eventName);
            this.dom.addEventListener(this.events_cb[eventName], { capture: true });
            this.events[eventName] = [];
        }
        const eventList = this.events[eventName];

        if (callback[CALLBACK_ID] == null) {

        }

        eventList.push(callback);
    }
    //--------------------------------------------------------------------------
    getDom() {

    }
    //--------------------------------------------------------------------------
    // 釋放資源
    destroy() {
        debugger;

        return;

        if (this.dom == null) {
            // 空節點
            return;
        }

        if (this.dom.hasOwnProperty(VNODE_VARNAME)) {
            if (this.dom[VNODE_VARNAME] === this) {
                delete this.dom[VNODE_VARNAME];
            }
        }

        // this.detach(true);
        // this.parent = null;

        this.nodeName = null;
        this.tagName = null;
        this.text = null;
        this.id = null;

        this.classList.length = 0;
        this.classList = null;

        this.attrs.clear();
        this.attrs = null;

        for (var k in this.style) {
            delete this.style[k];
        }

        this.style = null;

        this.compute_attrs.clear();
        this.compute_attrs = null;

        // this.is_static = null;

        this.unlinkDom();

        console.log('vnode.destroy');
        console.dir(this);
    }
    //--------------------------------------------------------------------------
    _getEventCallback(eventName) {

        const callback = function (e) {
            let eventList = this.events[eventName];
            let copy_eventList = eventList.slice();

            let i = 0;

            while (i < copy_eventList.length) {
                let j = i++;
                let fn = copy_eventList[j];

                // 避免某個事件 callback 突然被移除
                let is_include = eventList.some((_fn) => {
                    if (_fn[CALLBACK_ID] === fn[CALLBACK_ID]) {
                        return true;
                    }
                });

                if (!is_include) {
                    // 事件 callback 不在了
                    return;
                }

                // context 未來要指定
                fn.call(null, e);
            }

        } // endFun

        return callback;
    }

}

export { Vnode };
