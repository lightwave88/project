import $GM from '../g_module.js';

// 專門處理 tag.attr
import { general } from './attrs/general.js';
import { classList } from './attrs/classList.js';
import { style } from './attrs/style.js';

let $checkList;
let $checkMap;

function getCheckList() {
  if ($checkList == null) {
    // 手動指定
    $checkList = [classList, style];
  }
  return $checkList;
}

function getCheckMap() {
  // debugger;
  if ($checkMap == null) {
    $checkMap = {};
    $checkList = getCheckList();
    $checkList.forEach(o => {
      let { attrName } = o;
      $checkMap[attrName] = o;
    });
  }
  return $checkMap;
}
//------------------------------------------------------------------------------
// API
const $attr = {
  attrSS: attrSS,
  setVnodeAttr: setVnodeAttr,
  createDom: createDom,
  updateDom: updateDom,
};

export { $attr as attr };


//------------------------------------------------------------------------------
function attrSS() {

}
//------------------------------------------------------------------------------
// vnode.attr 的設定方式
function setVnodeAttr(vnode, computer, attrName, attrValue) {
  // debugger;

  if (computer == true) {
    vnode.compute_attrs.add(attrName);
  }

  let checkList = getCheckList();
  let fn;

  checkList.some(it => {
    if (it.attrName == attrName && typeof it.toVnodeAttr == 'function') {
      fn = it.toVnodeAttr;
      return true
    }
  });

  if (fn == null) {
    fn = general.toVnodeAttr;
  }

  fn(vnode, attrName, attrValue);
}
//------------------------------------------------------------------------------
function createDom(dom, vnode) {
  debugger;
  let checkMap = getCheckMap();
  let fn;

  if (attrName in checkMap) {
    ({ createDom: fn } = checkMap[attrName]);
  } else {
    ({ createDom: fn } = checkMap["*"]);
  }
  fn(dom, vnode);
}
//------------------------------------------------------------------------------
// fix here
// 複雜地方
function updateDom(dom, oldVnode, vnode, isStatic = null) {
  debugger;
  let checkMap = getCheckMap();
  let fn;

  if (attrName in checkMap) {
    ({ updateDom: fn } = checkMap[attrName]);
  } else {
    ({ updateDom: fn } = checkMap["*"]);
  }

  fn(dom, oldVnode, vnode);
}
