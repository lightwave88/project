// 專門處理 tag.attr
import { general } from './attrs/general.js';
import { classList } from './attrs/classList.js';
import { style } from './attrs/style.js';

let $checkList;
let $checkMap = {};

function getCheckList() {
  if ($checkList == null) {
    // 手動指定
    $checkList = [classList, style, general];
    $checkList.forEach(o => {
      let { attrName } = o.attrName;
      $checkMap[attrName] = o;
    });
  }
  return { list: $checkList, map: $checkMap };
}
//------------------------------------------------------------------------------
const $attr = {
  printAttr: printAttr,
  setVnodeAttr: setVnodeAttr,
  createDom: createDom,
  updateDom: updateDom,
};

export { $attr as attr };
//------------------------------------------------------------------------------
// domNode 的輸出
function printAttr(node, printSpace = true) {
  debugger;
  let a_lines = [];

  let dom = node.dom;
  let { list } = getCheckList();
  list.forEach(it => {
    debugger;
    if (!it.hasAttr(dom)) {
      return;
    }
    debugger;
    let lines = it.print(node, printSpace);
    a_lines = a_lines.concat(lines);
  });
  return a_lines;
}
//------------------------------------------------------------------------------
// vnode.attr 的設定方式 
function setVnodeAttr(...args) {
  debugger;
  let attrName = args[1];

  let { map } = getCheckList();
  let fn;

  if (attrName in map) {
    ({ toVnodeAttr: fn } = map[attrName]);
  } else {
    ({ toVnodeAttr: fn } = map["*"]);
  }
  fn.apply(null, args);
}
//------------------------------------------------------------------------------
function createDom(dom, vnode) {
  debugger;
  let { map } = getCheckList();
  let fn;

  if (attrName in map) {
    ({ createDom: fn } = map[attrName]);
  } else {
    ({ createDom: fn } = map["*"]);
  }
  fn(dom, vnode);
}
//------------------------------------------------------------------------------
// fix here
// 複雜地方
function updateDom(dom, oldVnode, vnode, isStatic = null) {
  debugger;
  let { map } = getCheckList();
  let fn;

  if (attrName in map) {
    ({ updateDom: fn } = map[attrName]);
  } else {
    ({ updateDom: fn } = map["*"]);
  }

  fn(dom, oldVnode, vnode);
}