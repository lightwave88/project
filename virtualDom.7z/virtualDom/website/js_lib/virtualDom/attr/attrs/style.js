import $GM from '../../g_module.js';

// 針對 dom.class 的設定
const style = {
  attrName: 'style',
  isAttr: isAttr,
  toVnodeAttr: toVnodeAttr,
  createDom: createDom,
  updateDom: updateDom,
  attrSS: attrSS,
};

export { style };
//------------------------------------------------------------------------------

function isAttr(attrName) {
  debugger;
  const sysConfig = $GM.get('sysConfig');
  const attrComputeHead = sysConfig.attrComputeHead;
  let attrName_1 = 'style';
  let attrName_2 = attrComputeHead + 'style';

  if (attrName_1.localeCompare(attrName) == 0 || attrName_2.localeCompare(attrName) == 0) {
    return true;
  }
  return false;
}
//------------------------------------------------------------------------------
const $reg_1 = /[:]/;

function toVnodeAttr(vnode, computer, attrName, args) {
  debugger;
  const $util = $GM.get('util');
  const attrs = vnode.attrs;

  if (!attrs.has('style')) {
    attrs.set('style', {});
  }

  let styles = attrs.get('style');


  argss.forEach(arg => {
    debugger;

    if (arg == null) {
      return;
    } else if (typeof arg == 'object') {

      let type = $util.getType(arg);

      if(!/^object$/i.test(type)){
        throw new TypeError(`typeError(${type}) when set style`);
      }
      Object.assign(style, arg);

    } else {

      arg = "" + arg;
      let list = arg.split(/;/);

      list.forEach(el => {
        let j = $reg_1.exec(el);

        // fix
        // fix

        let k, v;

        if (j == null) {
          k = el.trim();
        } else {
          let [match, g1, g2] = j;
          k = g1.trim();
          v = g2.trim();
        }
        styles[k] = v;
      });
    }

  }); // endForEach
}
//------------------------------------------------------------------------------
function createDom(dom, vnode) {

  let style = vnode.style;

  let list = [];

  let keys = Object.keys(style);

  keys.forEach(key => {
    let value = ('' + style[key]) || '';
    list.push(`${key}:${value}`);
  });

}
//------------------------------------------------------------------------------
function updateDom(dom, oldVnode, vnode) {
  let $style = dom.style;

  let oldKeys = Object.keys(oldVnode.style);
  let keys = Object.keys(vnode.style);
  let styleSetting = vnode.style;

  // 移除沒設定的 style
  oldKeys.forEach((k) => {
    if (k in styleSetting) {
      return;
    }
    $style.removeAttribute(k);
  });

  keys.forEach((k) => {
    let value = styleSetting[k] + '';
    $style.setAttribute(k, v);
  });
}
