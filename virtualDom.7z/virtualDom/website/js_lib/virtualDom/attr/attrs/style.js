import $GM from '../../g_module.js';

// 針對 dom.class 的設定
const style = {
  attrName: 'style',
  hasAttr: hasAttr,
  print: print,
  toVnodeAttr: toVnodeAttr,
  createDom: createDom,
  updateDom: updateDom,
};

export { style };
//------------------------------------------------------------------------------

function hasAttr(dom) {
  return dom.hasAttribute('style');
}
//------------------------------------------------------------------------------

function print(node, printSpace = true) {
  debugger;

  const dom = node.dom;
  let lines = [];

  const sysConfig = $GM.get('sysConfig');
  const DomNode = $GM.get('DomNode');

  const {
    var_root,
    var_parentNode,
    var_vnode,
    var_createVnode,
  } = sysConfig.tempSysVarName;

  const attrComputeHead = sysConfig.attrComputeHead;

  const space = printSpace ? node._space() : '';

  if (dom.hasAttribute('style')) {
    let style = dom.getAttribute('style');

    let v = JSON.stringify(style);
    lines.push(`${space}${var_vnode}.setAttr("style", false, ${v});\n`);
    dom.removeAttribute('style');
  }

  let attrName = attrComputeHead + 'style';
  if (dom.hasAttribute(attrName)) {
    // computer
    let style = dom.getAttribute(attrName);
    let v = DomNode._ss(style, 'style');

    lines.push(`${space}${var_vnode}.setAttr("style", true, ${v});\n`);
    dom.removeAttribute(attrName);
  }
}
//------------------------------------------------------------------------------
function toVnode(vnode, key, computer = false, ...args) {
  if (computer == true) {
    vnode.compute_attrs.add('style');
  }

  let styles = {};

  argss.forEach(arg => {
    let style;

    if (arg == null) {
      return;
    } else if (typeof arg == 'object') {
      style = arg;
    } else {
      arg = "" + arg;
      let list = arg.split(/;/);

      list.forEach(el => {
        let j = $reg_1.exec(el);
        let k, v;

        if (j == null) {
          k = el.trim();
        } else {
          let [match, g1, g2] = j;
          k = g1.trim();
          v = g2.trim();
        }
        style[k] = v;
      });
    } // endif

    Object.assign(styles, style);
  });

  vnode.attrs.set('style', styles);
}
//------------------------------------------------------------------------------
function createDom(dom, vnode) {

  let style = vnode.style;

  let list = [];

  let keys = Object.keys(style);

  keys.forEach(key => {
    let value = ('' + style[key]) || '';
    list.push(`${key}:${value}`);
  });

}
//------------------------------------------------------------------------------
function updateDom(dom, oldVnode, vnode) {
  let $style = dom.style;

  let oldKeys = Object.keys(oldVnode.style);
  let keys = Object.keys(vnode.style);
  let styleSetting = vnode.style;

  // 移除沒設定的 style
  oldKeys.forEach((k) => {
    if (k in styleSetting) {
      return;
    }
    $style.removeAttribute(k);
  });

  keys.forEach((k) => {
    let value = styleSetting[k] + '';
    $style.setAttribute(k, v);
  });
}
