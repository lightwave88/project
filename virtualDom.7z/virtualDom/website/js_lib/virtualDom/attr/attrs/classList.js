import $GM from '../../g_module.js';

// 針對 dom.class 的設定
const classList = {
  attrName: 'class',
  hasAttr: hasAttr,
  print: print,
  toVnodeAttr: toVnodeAttr,
  createDom: createDom,
  updateDom: updateDom,
};

export { classList };
//------------------------------------------------------------------------------

function hasAttr(dom) {
  return dom.hasAttribute('class');
}
//------------------------------------------------------------------------------

// 如何把 dom.attr 化爲指令
function print(node, printSpace = true) {
  debugger;
  const dom = node.dom;
  let lines = [];

  const sysConfig = $GM.get('sysConfig');
  const DomNode = $GM.get('DomNode');
  
  const $util = $GM.get('util');

  const {
    var_root,
    var_parentNode,
    var_vnode,
    var_createVnode,
  } = sysConfig.tempSysVarName;

  const attrComputeHead = sysConfig.attrComputeHead;

  const space = printSpace ? node._space() : '';

  if (dom.hasAttribute('class')) {
    let classList = Array.from(dom.classList);
    classList = JSON.stringify(classList);

    lines.push(`${space}${var_vnode}.setAttr("class", false, ${classList});\n`);
    dom.removeAttribute('class');
  }

  let attrName = attrComputeHead + 'class';
  if (dom.hasAttribute(attrName)) {
    // calss 有計算屬性
    let classData = dom.getAttribute(attrName);
    let v = $util.ss(classData, 'class');
    lines.push(`${space}${var_vnode}.setAttr("class", true, ${v});\n`);
    dom.removeAttribute(attrName);
  }

  return lines;
};

//------------------------------------------------------------------------------
// vnode 的設定
function toVnodeAttr(vnode, key, computer = false, ...args) {
  debugger;

  if (computer == true) {
    vnode.compute_attrs.add('class');
  }

  let classList = [];

  args.forEach(arg => {
    let list;
    if (Array.isArray(arg)) {
      list = arg;
    } else if (arg == null) {
      list = null;
    } else if (typeof arg == "object") {
      throw new TypeError('class must be [simpleData|[]}');
    } else {
      // 轉爲文字
      let _class = '' + arg;

      // 處理空白
      list = _class.split(/\s+/);
    }

    if(list == null){
      return;
    }
    //-------------
    list.forEach(it => {
      // debugger;      
      classList.push(it);
    });
  });

  vnode.attrs.set('calss', classList);
}
//------------------------------------------------------------------------------
function createDom(dom, vnode) {
  let classList = vnode.classList;

  classList.forEach(el => {
    dom.classList.add(el);
  });
}
//------------------------------------------------------------------------------
function updateDom(dom, oldVnode, vnode) {
  // check dom
  let old_list = Array.from(dom.classList);
  let list = vnode.classList;

  if (old_list.length == 0 && list.length == 0) {
    return;
  }

  old_list = new Set(old_list);
  list = new Set(list);

  old_list.forEach(el => {
    if (list.has(el)) {
      old_list.delete(el);
      list.delete(el);
    }
  });

  old_list.forEach(el => {
    dom.classList.remove(el);
  });

  list.forEach(el => {
    dom.classList.add(el);
  });
}
