import $GM from '../../g_module.js';

// 一般 dom.attr 的設定
const general = {
  attrName: '*',
  hasAttr: hasAttr,
  print: print,
  toVnodeAttr: toVnodeAttr,
  createDom: createDom,
  updateDom: updateDom,
};

export { general };

//------------------------------------------------------------------------------
function hasAttr() {
  return true;
}
//------------------------------------------------------------------------------

function print(node, printSpace = true) {
  debugger;

  let lines = [];
  const dom = node.dom;
  const sysConfig = $GM.get('sysConfig');
  const $util = $GM.get('util');

  const {
    var_root,
    var_parentNode,
    var_vnode,
    var_createVnode,
  } = sysConfig.tempSysVarName;

  const space = printSpace ? node._space() : '';

  let attrMap = Array.from(dom.attributes);

  attrMap.forEach((attr) => {
    let key = attr.nodeName;
    let value = attr.nodeValue;

    key = JSON.stringify(key);

    let v;

    if ($util.hasComputeAttr(value)) {
      // 計算屬性
      v = $util.ss(value, key);
      lines.push(`${space}${var_vnode}.setAttr(${key}, true, ${v});\n`);
    } else {
      v = JSON.stringify(value);
      lines.push(`${space}${var_vnode}.setAttr(${key}, false, ${v});\n`);
    }
  });

  return lines;
}
//------------------------------------------------------------------------------
function toVnodeAttr(vnode, key, computer = false, ...args) {
  if (computer == true) {
    vnode.compute_attrs.add('key');
  }

  args = args.map((arg) => {
    let res;

    if (typeof arg == 'string') {
      res = arg;
    } else if (arg == null) {
      res = '';
    } else {
      try {
        res = JSON.stringify(arg);
      } catch (er) {
        res = er.toString();
      }
    }
    return res;
  });

  let value = args.join('');
  vnode.attrs.set(key, value);
}
//------------------------------------------------------------------------------
function createDom(dom, vnode) {

  let attrs = new Map(vnode.attrs);

  attrs.forEach((v, attr) => {
    v = '' + v;
    dom.setAttribute(attr, v);
  });
}
//------------------------------------------------------------------------------
function updateDom(dom, oldVnode, vnode) {

}
