import $GM from '../../g_module.js';

// 一般 dom.attr 的設定
const general = {
  attrName: '*',
  isAttr: isAttr,
  toVnodeAttr: toVnodeAttr,
  createDom: createDom,
  updateDom: updateDom,
  attrSS: attrSS,
};

export { general };

//------------------------------------------------------------------------------
function isAttr() {
  return true;
}

//------------------------------------------------------------------------------
// 將變數文字化
function attrSS(attrName, attrValue) {
  let value = '';

  if (!attrValue == null) {
    if (typeof attrValue == 'object') {
      throw new TypeError(`error type(${typeof attrValue})`);
    } else {
      value = value + attrValue;
    }
  }
  return value;
}
//------------------------------------------------------------------------------
function toVnodeAttr(vnode, computer, attrName, value) {
  debugger;
  // 採用覆寫策略


  vnode.attrs.set(attrName, value);
}

//------------------------------------------------------------------------------

function createDom(dom, vnode) {

  let attrs = new Map(vnode.attrs);

  attrs.forEach((v, attr) => {
    v = '' + v;
    dom.setAttribute(attr, v);
  });
}
//------------------------------------------------------------------------------
function updateDom(dom, oldVnode, vnode) {

}
