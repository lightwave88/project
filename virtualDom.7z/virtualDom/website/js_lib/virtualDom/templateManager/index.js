import { Manager_a } from './manager_a.js';

const classMap = {
  'Manager_a': Manager_a,
};

export default classMap;