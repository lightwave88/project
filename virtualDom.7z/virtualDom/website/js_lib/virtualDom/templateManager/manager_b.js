import $GM from '../g_module.js';


// 針對 controller 綁定 
// 從 controller 取得設定資訊
class Manager_b {
  constructor() {

  }
}