import $GM from '../g_module.js';


// 針對簡單 dom 綁定 
class Manager_a {

  constructor(options = {}) {

    this.prev_vnode = null;
    this.dom_prevRoot = null;

    // 上下文
    this.executeContext = null;

    this.event_setting = {};

    this.slots = {};

    // 模板
    this.templateObj;
    // 與模板綁定的 dom
    this.dom_container;

    this._init(options);
  }
  //----------------------------------------------------------
  _init(options) {
    let { dom, template } = options;

    this.dom_container = dom;
    this.templateObj = template;

    // 告訴管理者，template 裏有幾個 slot
    Object.assign(this.slots, this.templateObj.slots);
  }
  //----------------------------------------------------------
  setSlot(name, fn) {

  }
  //----------------------------------------------------------
  setExecuteContext(context) {
    this.executeContext = context;

    if(!this.executeContext){
      this.executeContext = null;
    }
  }
  //----------------------------------------------------------
  // 模板的 dom 事件綁定
  on() {

  }
  //----------------------------------------------------------
  off() {

  }
  //----------------------------------------------------------
  render(data = {}) {
    debugger;

    let node = this.templateObj.render(data, this.slots, this.executeContext);
    node = node || null;

    if (this.prev_vnode == null) {
      // 沒有 vnode 表示沒有 html 內容
      let innerHTML = this.dom_container.innerHTML;
      if (innerHTML.length > 0) {
        this.dom_container.innerHTML = '';
      }
    }

    // 建構 dom
    $patch(this.prev_vnode, node, this.dom_container);

    //------------------
    // 事件綁定

    // 

    //------------------
    // 更新記錄
    this.prev_vnode = node;
    this.dom_prevRoot = (this.prev_vnode == null ? null : this.prev_vnode.dom);

  }
}


export { Manager_a };
//------------------------------------------------------------------------------

function $patch(oldNode, node, parentDom) {
  const ModifyDom = $GM.get('ModifyDom');
  const $modifyDom = new ModifyDom();

  let dom = $modifyDom.patch(oldNode, node, parentDom);
  return dom;
};