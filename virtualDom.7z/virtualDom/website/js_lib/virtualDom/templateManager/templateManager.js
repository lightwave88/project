import $GM from '../g_module.js';

class TemplateManager {

  static getInstance(options) {
    let ins = new TemplateManager(options);
    ins.init();
    return ins;
  }

  constructor(options) {
    this.options = Object.assign({}, options);

    this.name = null;

    this.prev_vnode = null;
    this.prevRoot_dom = null;

    // 上下文
    this.executeContext = null;

    this.keepAlives = {};

    this.event_setting = {};

    this.slots = {};

    // 模板
    this.templateObj;
    // 與模板綁定的 dom
    this.container_dom;
  }
  //----------------------------------------------------------
  init() {
    let { dom, template } = this.options;

    this.container_dom = dom;
    this.templateObj = template;

    if (this.templateObj.name != null) {
      this.name = this.templateObj.name;
    }

    // 告訴管理者，template 裏有幾個 slot
    Object.assign(this.slots, this.templateObj.slots);

    this.options = null;
  }

  setSlot(name, fn) {

  }
  //----------------------------------------------------------
  setExecuteContext(context) {
    this.executeContext = context;

    if (!this.executeContext) {
      this.executeContext = null;
    }
  }
  //----------------------------------------------------------
  // 模板的 dom 事件綁定
  on() {

  }
  //----------------------------------------------------------
  off() {

  }
  //----------------------------------------------------------
  _render(data = {}) {
    debugger;

    let node = this.templateObj.render(data, this.slots, this.executeContext);
    node = node || null;

    if (this.prev_vnode == null) {
      // 沒有 vnode 表示沒有 html 內容
      let innerHTML = this.container_dom.innerHTML;
      if (innerHTML.length > 0) {
        this.container_dom.innerHTML = '';
      }
    }

    // 建構 dom
    $patch(this.prev_vnode, node, this.container_dom);

    //------------------
    // 事件綁定



    //------------------
    // 更新記錄
    this.prev_vnode = node;
    this.prevRoot_dom = (this.prev_vnode == null ? null : this.prev_vnode.dom);

  }

  // 避免 render 的上下文改變
  get render() {
    return this._render.bind(this);
  }
}

export { TemplateManager };
export default TemplateManager;
//------------------------------------------------------------------------------
function $patch(oldNode, node, parentDom) {
  const ModifyDom = $GM.get('ModifyDom');
  const $modifyDom = new ModifyDom();

  let dom = $modifyDom.patch(oldNode, node, parentDom);
  return dom;
};