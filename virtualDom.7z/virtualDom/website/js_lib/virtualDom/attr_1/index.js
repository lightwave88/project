import $GM from '../g_module.js';
import { _general } from './_general/index.js';

// 特殊解
const $tagSolutions = [];
// 一般解
const $gSolution = _general;

let $instance;

class Attr {
  
  tagSolutionMap = {};
  //----------------------------------------------------------------------------
  static getInstance() {
    if ($instance == null) {
      $instance = new Attr();
    }
    return $instance;
  }
  //----------------------------------------------------------------------------
  constructor() {
    this.tagSolutionMap['*'] = $gSolution;

    $tagSolutions.forEach(s => {
      let { attrName } = s;
      this.tagSolutionMap[attrName] = s;
    });
  }
  //----------------------------------------------------------------------------
  // API
  setVnodeAttr(vnode, computer, attrName, attrValue) {
    debugger;    

    let solution = this._getSolution_1(vnode, attrName);

    debugger;

    if (computer == true) {
      vnode.compute_attrs.add(attrName);
    }

    // debugger;
    solution.setVnodeAttr(vnode, attrName, attrValue);
  }
  //----------------------------------------------------------------------------
  // API
  initDom(dom, vnode) {
    debugger;

    if (!_useAttr()) {
      // for test
      return;
    }

    const attrs = new Map(vnode.attrs);

    attrs.forEach((value, attrName) => {
      let solution = this._getSolution_2(vnode, attrName);
      debugger;
      solution.initDom(dom, vnode, attrName);
    });
  }
  //----------------------------------------------------------------------------
  // API
  updateDom(dom, oldVnode, vnode, isSameDom) {
    debugger;

    if (!_useAttr()) {
      // for test
      return;
    }
    //------------------

    if (isSameDom == null) {
      throw new Error('...');
    }    
    //-----------------------
    let attrs;
    const compute_attrs = vnode.compute_attrs;

    if (isSameDom) {

      attrs = new Map();
      // 保留舊有的
      // 更新計算屬性
      compute_attrs.forEach(k => {
        attrs.set(k, vnode.attrs.get(k));
      });

    } else {
      debugger;

      attrs = new Map(vnode.attrs);

      // 舊有的全不要
      const dom_attrs = Array.from(dom.attributes);
      dom_attrs.forEach(node => {
        let { nodeName: name } = node;

        if (!attrs.has(name)) {
          dom.removeAttribute(name);
        }
      });
    }
    //-----------------------
    debugger;

    // 更新 attr
    attrs.forEach((value, attrName) => {
      debugger;

      // 針對 tag.attr 提出解法
      let solution = this._getSolution_2(vnode, attrName);
      debugger;
      solution.updateDom(dom, oldVnode, vnode, attrName);
    });

  }
  //----------------------------------------------------------------------------
  _getSolution_1(vnode, attrName) {
    // debugger;
    const tagName = vnode.tagName;    

    let solution = null;
    let tag_solution = this.tagSolutionMap[tagName] || null;

    if (tag_solution) {
      solution = tag_solution.hasSolutuon_1(vnode, attrName);
    }

    if (!solution) {
      // 使用萬用解
      tag_solution = this.tagSolutionMap['*'];
      solution = tag_solution.hasSolutuon_1(vnode, attrName);;
    }
    return solution;
  }
  //----------------------------------------------------------------------------
  _getSolution_2(vnode, attrName) {
    // debugger;
    
    const tagName = vnode.tagName;
    
    let solution = null;
    let tag_solution = this.tagSolutionMap[tagName] || null;

    if (tag_solution) {
      solution = tag_solution.hasSolutuon_2(vnode, attrName);
    }

    if (!solution) {
      // 使用萬用解
      tag_solution = this.tagSolutionMap['*'];
      solution = tag_solution.hasSolutuon_2(vnode, attrName);;
    }
    return solution;
  }
}

export { Attr };

// for test
function _useAttr() {
  const $sysConfig = $GM.get('sysConfig');
  return !!$sysConfig.updateAttr;
}

