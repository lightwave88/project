import $GM from '../g_module.js';
import { _general } from './_general/index.js';

// 特殊解
const $tagSolutions = [];
// 一般解
const $gSolution = _general;

let $instance;

class Attr {
  cache = {};
  tagSolutionMap = {};
  //----------------------------------------------------------------------------
  static getInstance() {
    if ($instance == null) {
      $instance = new Attr();
    }
    return $instance;
  }
  //----------------------------------------------------------------------------
  constructor() {
    this.tagSolutionMap['*'] = $gSolution;

    $tagSolutions.forEach(s => {
      let { attrName } = s;
      this.tagSolutionMap[attrName] = s;
    });
  }
  //----------------------------------------------------------------------------
  // API
  setVnodeAttr(vnode, computer, attrName, attrValue) {

    let tagName = vnode.tagName;

    let solution = this._getSolution(tagName, attrName);

    // debugger;

    if (computer == true) {
      vnode.compute_attrs.add(attrName);
    }

    // debugger;
    solution.setVnodeAttr(vnode, attrName, attrValue);
  }
  //----------------------------------------------------------------------------
  // API
  initDom(dom, vnode) {
    debugger;

    if (!_useAttr()) {
      // for test
      return;
    }
    //------------------
    let tagName = dom.tagName;

    if (tagName == null) {
      throw new Error('...');
    } else {
      tagName = tagName.toLowerCase();
    }

    const attrs = new Map(vnode.attrs);

    attrs.forEach((value, attrName) => {
      debugger;
      let solution = this._getSolution(tagName, attrName);
      solution.initDom(dom, vnode, attrName);
    });
  }
  //----------------------------------------------------------------------------
  // API
  updateDom(dom, oldVnode, vnode, isSameDom) {
    debugger;

    if (!_useAttr()) {
      // for test
      return;
    }
    //------------------

    if (isSameDom == null) {
      throw new Error('...');
    }

    let tagName = dom.tagName;

    if (tagName == null) {
      throw new Error('...');
    } else {
      tagName = tagName.toLowerCase();
    }
    //-----------------------
    let attrs;
    const compute_attrs = vnode.compute_attrs;

    if (isSameDom) {

      attrs = new Map();
      // 保留舊有的
      // 更新計算屬性
      compute_attrs.forEach(k => {
        attrs.set(k, vnode.attrs.get(k));
      });

    } else {
      debugger;

      _check_1(dom);

      attrs = new Map(vnode.attrs);

      // 舊有的全不要
      const dom_attrs = Array.from(dom.attributes);
      dom_attrs.forEach(node => {
        let { nodeName: name } = node;

        if (!attrs.has(name)) {
          dom.removeAttribute(name);
        }
      });
    }
    //-----------------------
    debugger;

    // 更新 attr
    attrs.forEach((value, attrName) => {
      debugger;

      // 針對 tag.attr 提出解法
      let solution = this._getSolution(tagName, attrName);
      solution.updateDom(dom, oldVnode, vnode, attrName);
    });

  }
  //----------------------------------------------------------------------------
  _getSolution(tagName, attrName) {
    // debugger;

    let solution = (() => {
      // debugger;
      // getCache
      let cache = this.cache;

      if (cache[tagName] == null) {
        return null;
      }

      return cache[tagName][attrName] || null;
    })();
    //------------------
    // debugger;
    if (solution == null) {
      // no cache
      let tag_solution = this.tagSolutionMap[tagName];

      if (tag_solution != null && null != tag_solution.getSolutuon(attrName)) {
        solution = tag_solution.getSolutuon(attrName)
      } else {
        tag_solution = this.tagSolutionMap['*'];
        solution = tag_solution.getSolutuon(attrName);
      }

      (() => {
        // debugger;
        //更新 cache
        this.cache[tagName] = this.cache[tagName] || {};
        this.cache[tagName][attrName] = solution;
      })();
    }

    return solution;
  }
  //----------------------------------------------------------------------------

}

export { Attr };


function _useAttr() {
  const $sysConfig = $GM.get('sysConfig');

  return !!$sysConfig.updateAttr;

}

function _check_1(dom) {
  // input.value 必須重置
}