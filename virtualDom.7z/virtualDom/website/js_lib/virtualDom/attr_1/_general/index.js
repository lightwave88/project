'use strict';

import { _general } from './attrs/_general.js';
import { className } from './attrs/className.js';
import { style } from './attrs/style.js';

const $attrList = [className, style];
const $generalAttr = _general;

// 適用於一般 tag
const $general_tag = {
  attrMap: {},
  tagName: '*',
  getSolutuon(attrName) {
    // debugger;

    let solution = (attrName in this.attrMap) ? this.attrMap[attrName] : this.attrMap['*'];
    return solution;
  }
};

export { $general_tag as _general };
export default $general_tag;
//------------------------------------------------------------------------------

(function () {
  $attrList.forEach(s => {
    let attrName = s.attrName;
    $general_tag.attrMap[attrName] = s;
  });

  $general_tag.attrMap['*'] = $generalAttr;
})();
