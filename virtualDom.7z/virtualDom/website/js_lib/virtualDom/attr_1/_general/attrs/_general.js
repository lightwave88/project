'use strict';

import $GM from '../../../g_module.js';

// 一般 tag, 一般 attr 的設定
const general = {
  attrName: '*',
  setVnodeAttr: setVnodeAttr,
  createDom: createDom,
  updateDom: updateDom,
};

export { general as _general };

// 空白文字
const $reg_1 = /^(?:|\s+)$/;
//------------------------------------------------------------------------------
function setVnodeAttr(vnode, attrName, args) {
  // debugger;
  let list = [];

  args.forEach(v => {
    debugger;
    let value;

    if (v == null) {
      value = '';
    } else if (typeof v == 'object') {
      try {
        value = JSON.stringify(v);
      } catch (error) {
        value = error.toStirng();
      }
    } else {
      value = '' + v;
    }
    list.push(value);
  });

  let res = list.join('');

  // debugger;
  vnode.attrs.set(attrName, res);
}

//------------------------------------------------------------------------------

function createDom(dom, vnode, attrName) {

  let value = vnode.attrs.get(attrName);

  if (typeof value == 'string') {
    if ($reg_1.test(value)) {
      value = null;
    }
  }

  dom.setAttribute(attr, value);
}
//------------------------------------------------------------------------------
function updateDom(dom, oldVnode, vnode, attrName) {
  let value = vnode.attrs.get(attrName);

  if (typeof value == 'string') {
    if ($reg_1.test(value)) {
      value = null;
    }
  }

  dom.setAttribute(attr, value);

}
