import $GM from '../../../g_module.js';

// 針對 dom.class 的設定
const className = {
  attrName: 'class',
  isTag: isTag,
  isAttr: isAttr,
  setVnodeAttr: setVnodeAttr,
  createDom: createDom,
  updateDom: updateDom,
};

export { className };
//------------------------------------------------------------------------------
// 是否針對特殊 tag
function isTag(tagName) {
  return true;
}
//------------------------------------------------------------------------------
function isAttr(attrName) {
  // debugger;
  const sysConfig = $GM.get('sysConfig');
  const attrComputeHead = sysConfig.attrComputeHead;
  let attrName_1 = 'class';
  let attrName_2 = attrComputeHead + 'class';

  if (attrName_1.localeCompare(attrName) == 0 || attrName_2.localeCompare(attrName) == 0) {
    return true;
  }
  return false;
}

//------------------------------------------------------------------------------
// vnode 的設定
function setVnodeAttr(vnode, attrName, args = []) {
  debugger;

  const attrs = vnode.attrs;

  if (!attrs.has('class')) {
    attrs.set('class', []);
  }

  const classList = attrs.get('class');
  //-------------
  // class 的分割方式是 " "
  args.forEach(arg => {
    debugger;

    let list;
    if (Array.isArray(arg)) {
      list = arg;
    } else if (arg == null) {
      list = null;
    } else if (typeof arg == "object") {
      throw new TypeError('class must be [simpleData|[]}');
    } else {
      // 轉爲文字
      let _class = '' + arg;

      // class 的分割方式
      list = _class.split(/\s+/);
    }

    if (list == null) {
      return;
    }
    //-------------
    list.forEach(it => {
      if (it.length) {
        classList.push(it);
      }
    });
  });

}
//------------------------------------------------------------------------------

function createDom(dom, vnode) {
  let classList = vnode.classList;

  classList.forEach(el => {
    dom.classList.add(el);
  });
}
//------------------------------------------------------------------------------
function updateDom(dom, oldVnode, vnode, attrName) {
  // check dom
  let old_list = Array.from(dom.classList);
  let list = vnode.classList;

  if (old_list.length == 0 && list.length == 0) {
    return;
  }

  old_list.forEach(el => {
    if (!list.includes(el)) {
      // 去除舊的不需要的 class
      dom.classList.remove(el);
    }
  });

  list.forEach(el => {
    if (!old_list.includes(el)) {
      // 新增沒有的 className
      dom.classList.add(el);
    }
  });
}
