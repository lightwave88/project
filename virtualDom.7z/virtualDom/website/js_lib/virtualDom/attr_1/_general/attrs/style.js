'use strict';

import $GM from '../../../g_module.js';

// 針對 dom.class 的設定
const style = {
  attrName: 'style',
  isTag: isTag,
  isAttr: isAttr,
  setVnodeAttr: setVnodeAttr,
  initDom: initDom,
  updateDom: updateDom,
};

export { style };

const $reg_1 = /^([^]*?)[:]([^]*)/;
const $reg_2 = /[;]/;
const $reg_3 = /^(?:|\s+)$/;
//------------------------------------------------------------------------------
// 是否針對特殊 tag
function isTag(tagName) {
  return true;
}
//------------------------------------------------------------------------------
function isAttr(attrName) {
  // debugger;
  const sysConfig = $GM.get('sysConfig');
  const attrComputeHead = sysConfig.attrComputeHead;
  let attrName_1 = 'style';
  let attrName_2 = attrComputeHead + 'style';

  if (attrName_1.localeCompare(attrName) == 0 || attrName_2.localeCompare(attrName) == 0) {
    return true;
  }
  return false;
}
//------------------------------------------------------------------------------

function setVnodeAttr(vnode, attrName, args = []) {
  debugger;
  const $util = $GM.get('util');
  const attrs = vnode.attrs;

  if (!attrs.has('style')) {
    attrs.set('style', {});
  }

  let $styles = attrs.get('style');
  //------------------

  let stringList = [];
  let tempList = [];

  // debugger;

  args.forEach(arg => {
    debugger;
    if (arg == null) {
      return;
    } else if (typeof arg == 'object') {


      if (tempList.length) {
        stringList.push(tempList.join(''));
        tempList.length = 0;
      }
      //------------------
      let type = $util.getType(arg);
      if (!/^object$/i.test(type)) {
        throw new TypeError(`typeError(${type}) when set style`);
      }
      Object.assign($styles, arg);
    } else {
      tempList.push('' + arg);
    }
  }); // endForEach

  if (tempList.length) {
    stringList.push(tempList.join(''));
    tempList.length = 0;
  }

  //------------------
  // 拆解文字
  stringList.forEach(arg => {
    debugger;
    
    // style 的分割方式(;)
    let list = arg.split($reg_2);

    list.forEach(el => {
      debugger;

      if ($reg_3.test(el)) {
        return;
      }

      let res = $reg_1.exec(el);

      let k, v;

      if (res == null) {
        throw new TypeError(`(${el}) typeError, when set style`);
      }

      let [match, g1, g2] = res;
      k = g1.trim();
      v = g2.trim();

      $styles[k] = v;
    });
  });
  //------------------
}
//------------------------------------------------------------------------------
function initDom(dom, vnode) {
  debugger;

  let style = vnode.attrs.get('style') || {};

  let keys = Object.keys(style);

  keys.forEach(key => {
    let value = style[key];
    value = _getStyleValue(value);

    dom.style.setProperty(key, value);
  });

}
//------------------------------------------------------------------------------
function updateDom(dom, oldVnode, vnode, attrName) {
  debugger;

  let style = vnode.attrs.get('style') || {};
  
  // 清除舊設定
  dom.style.cssText = '';

  let keys = Object.keys(style);

  keys.forEach(key => {
    let value = style[key];
    value = _getStyleValue(value);

    dom.style.setProperty(key, value);
  });
}
//------------------------------------------------------------------------------



function _getStyleValue(value) {
  if (value == null) {
    value = null;
  } else if (typeof value != 'object') {
    value = '' + value;
  }
  return value;
}
