'use strict';

import $GM from '../../../g_module.js';

const selected = {
  attrName: 'selected',
  isAttr_1: isAttr_1,
  setVnodeAttr: setVnodeAttr,
  isAttr_2: isAttr_2,
  initDom: initDom,
  updateDom: updateDom,
};

export { selected };


const $reg_1 = /\bselected\b/i;
const $reg_2 = /\b(?:true|selected)\b/;
//------------------------------------------------------------------------------
// data 格式是 []
function isAttr_1(vnode, attrName) {
  return $reg_1.test(attrName);
}

function setVnodeAttr(vnode, attrName, args = []) {
  debugger;

  let value;

  args.forEach(v => {
    if (typeof v == 'string') {
      v = v.trim();
      if (!v.length) {
        return;
      }
    }
    value = v;
  });

  debugger;
  vnode.attrs.set(attrName, value);
}

//------------------------------------------------------------------------------
function isAttr_2(vnode, attrName) {
  return $reg_1.test(attrName);
}
//------------------------------------------------------------------------------
function initDom(dom, vnode) {
  _updateDom_1(dom, vnode);
}
//------------------------------------------------------------------------------
function updateDom(dom, oldVnode, vnode, attrName) {
  _updateDom_1(dom, vnode);
}
//------------------------------------------------------------------------------
function _updateDom_1(dom, vnode) {
  debugger;

  let value = vnode.attrs.get('selected');
  if ($reg_2.test(value)) {
    dom.setAttribute('selected', 'selected');
  } else {
    if (dom.hasAttribute('selected')) {
      dom.removeAttribute('selected');
    }
  }
}

function _updateDom_2(dom, vnode) {
  debugger;
  let value = vnode.attrs.get('selected');
  try {
    dom.selected = (value) ? true : false;
  } catch (error) {
    console.log(error);
  }
}