import $GM from './g_module.js';

const util = {};

export default util;


util.next = function (...args) {
  
  let [callback, context] = args;
  if (args.length >= 2) {
    callback = callback.bind(context);
  }

  Promise.resolve().then(() => {
    try {
      callback();
    } catch (error) {
      console.log(error);
    }
  });
};