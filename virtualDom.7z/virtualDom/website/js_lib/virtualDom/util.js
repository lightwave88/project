import $GM from './g_module.js';
const util = {};
export default util;

util.nextStep = function (callback, heightLevel = false) {

  heightLevel = !!heightLevel;

  if (heightLevel) {
    Promise.resolve().then(e => {
      try {
        callback();
      } catch (error) {
        console.log(error);
      }
    });
  } else {
    setTimeout(() => {
      callback();
    }, 0);
}
};
//----------------------------------------------------------
util.getType = function (o) {
  debugger;
  const reg = /\[[^]*?\s([^]*?)\]/;
  const toString = Object.prototype.toString;
  let type = toString.call(o);
  let res = reg.exec(type);

  if (res == null) {
    return res;
  }

  let [m, g1] = res;
  return g1;
}
//----------------------------------------------------------
// 在二者之間都有
// 交集
util.intersection = function (a, b) {
  let a_type = util.getType(a);
  let b_type = util.getType(b);

  if (a_type != b_type) {
    throw new TypeError('intersection must same type');
  }

  let type = 0;

  switch (a_type) {
    case 'Set':
      a = Array.from(a);
      b = Array.from(b);
      break;
    case 'Array':
      type++;
      break;
    default:
      throw new TypeError('only Set, Array');
      break;
  }

  let samll = a;
  let large = b;

  if (a.length > b.length) {
    samll = b;
    large = a;
  }

  let res = samll.filter((v) => {
    return (large.includes(v));
  });

  if (type == 0) {
    res = new Set(res);
  }

  return res;
};
//----------------------------------------------------------
// 聯集
util.union = function (a, b) {

  let a_type = util.getType(a);
  let b_type = util.getType(b);

  if (a_type != b_type) {
    throw new TypeError('intersection must same type');
  }

  let type = 0;

  switch (a_type) {
    case 'Set':
      a = Array.from(a);
      b = Array.from(b);
      break;
    case 'Array':
      type++;
      break;
    default:
      throw new TypeError('only Set, Array');
      break;
  }
  a = a.concat(b)

  let res = new Set(a);

  if (type > 0) {
    res = Array.from(res);
  }
  return res;
};
//----------------------------------------------------------
{
// 是否是空內容的文字節點
  function isEmptyText(node) {

    let remove = false;
    let is_tag = (node.tagName == null ? false : true);

    if (!is_tag) {
      let text = node.nodeValue;
      text = text.trim();
      if (text.length == 0) {
        remove = true;
      }
    }
    return remove;
  }
  //------------------
  // 抓出模板的 root
  util.clear2SideEmptyDom = function (topDom) {
    // debugger;

    let domList = Array.from(topDom.childNodes);
    
    if(domList.length == 0){
      return domList;
    }

    // 去除兩端無用的 text
    for (let i = 0; i < domList.length; i++) {
      let d = domList[i];
      let remove = isEmptyText(d);
      if (remove) {
        topDom.removeChild(d);
        domList[i] = null;
      } else {
        break;
      }
    }

    for (let i = domList.length; i > 0; i--) {
      let j = i - 1;
      let d = domList[j];

      if(d == null){
        break;
      }

      let remove = isEmptyText(d);
      if (remove) {
        topDom.removeChild(d);
      } else {
        break;
      }
    }

    // 更新
    domList = Array.from(topDom.childNodes);
    // debugger;
    return domList;
  }
}