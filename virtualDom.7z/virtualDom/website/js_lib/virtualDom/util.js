import $GM from './g_module.js';

const util = {};

export default util;


util.next = function (...args) {
  
  let has_context = false;
  
  let [callback, context] = args;
  if (args.length >= 2) {
      has_context = true;
      context = context || null;
  }
  
  setTimeout(()=>{
    if(has_context){
      callback.call(context);
    }else{
      callback();
    }
  }, 0);
};