import $GM from './g_module.js';

const util = {};

export default util;
    
