import $GM from './g_module.js';
const util = {};
export default util;
util.nextStep = function (callback, heightLevel = false) {

    heightLevel = !!heightLevel;

    if (heightLevel) {
        Promise.resolve().then(e => {
            try {
                callback();                
            } catch (error) {
                console.log(error);
            }
        });
    } else {
        setTimeout(() => {
            callback();
        }, 0);
    }
};