'use strict';

// 各種設定

const config = {
    // 模板內的系統變數
    tempSysVarName: {
        var_parentNode: '$_PARENT',
        var_vnode: '$_VNODE',
        var_sys: '$_SYS',
        var_loopData: '$_LOOPDATA',
        var_createVnode: '$_SYS.C',
    },
    // 計算標籤的符號
    attrComputeHead: ':',
    // factory 是否要 format
    format: true,
    formatSpace: 2,
    // dom 要綁定的變數
    domVarname: {
        vnode: '$$$b_vnode',
        domData: '$$$b_data',
    },
};

export default config;

