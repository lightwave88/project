import $GM from '../g_module.js';

let $instance;

// 全局管理者
class GlobalManager {
  $templateList = new Map();
  $dom2ManagerMap = new Map();
  //----------------------------------------------------------------------------
  static getInstance(){    
    if($instance == null){
      $instance = new GlobalManager();
    }    
    return $instance; 
  }
  //----------------------------------------------------------------------------
  constructor() {

  }
  //----------------------------------------------------------------------------
  getTemplate(key) {
    let res = null;
    if (this.$templateList.has(key)) {
      res = this.$templateList.get(key);
    }
    return res;
  }
  //----------------------------------------------------------------------------
  setTemplate(key, temp) {
    this.$templateList.set(key, temp);
  }
  //----------------------------------------------------------------------------
  getManagerMap(dom){
    if (DOMParser.parentNode == null) {
      throw new Error('dom 不能離線');
    }
    const dom2ManagerMap = this.$dom2ManagerMap;

    if (!dom2ManagerMap.has(dom)) {
      dom2ManagerMap.set(dom, new Map());
    }
    return dom2ManagerMap.get(dom);
  }
  //----------------------------------------------------------------------------
  getManager(dom, temp) {

    const dom2ManagerMap = this.getManagerMap(dom);

    let manager;

    // 取得 dom 與 template 配對的 manager
    const domManagerList = dom2ManagerMap.get(dom);

    if (!domManagerList.has(temp)) {
      // dom-temp 之間必須有個調度者
      const TemplateManager = $GM.get('TemplateManager');
      manager = new TemplateManager(dom, temp);
      domManagerLis.set(temp, manager);
    }

    manager = domManagerList.get(temp);
  }
}

export { GlobalManager };