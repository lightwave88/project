import $GM from '../g_module.js';

let $instance;

// 全局管理者
class GlobalManager {
  // template 庫
  $templates = {};
  $domDatas = new Map();
  $dom2ManagerMap = new Map();
  //----------------------------------------------------------------------------
  static getInstance() {
    if ($instance == null) {
      $instance = new GlobalManager();
    }
    return $instance;
  }
  //----------------------------------------------------------------------------
  constructor() {

  }
  //----------------------------------------------------------------------------
  getTemplate(key) {
    let res = null;
    if (key in this.$templates) {
      res = this.$templates[key];
    }
    return res;
  }
  //----------------------------------------------------------------------------
  setTemplate(key, temp) {
    this.$templates[key] = temp;
  }
  //----------------------------------------------------------------------------
  getDomData(dom) {

    if (dom.parentNode != null) {
      throw new Error('dom not in domTree');
    }

    if (!this.$domDatas.has(dom)) {
      this.$domDatas.set(dom, {});
    }
    return this.$domDatas.get(dom);
  }
  //----------------------------------------------------------------------------
  // 取得與 dom-tempale 對應的 mananger 
  getTempManager(dom, temp) {

    const a_list = this.$dom2ManagerMap;

    if(!a_list.has(dom)){
      // 若沒有之前的資料
      // 創建
      a_list.set(dom,new Map());
    }

    let manager;

    // 取得 dom 與 template 配對的 manager
    const b_list = a_list.get(dom);

    if (!b_list.has(temp)) {
      // dom-temp 之間必須有個調度者
      const TemplateManager = $GM.get('TemplateManager');
      manager = new TemplateManager(dom, temp);
      b_list.set(temp, manager);
    }

    return b_list.get(temp);;
  }
}

export { GlobalManager };