import $GM from './g_module.js';

let $instance;

// 全局管理者
class GlobalManager {
  // template 庫
  $templates = {};

  //----------------------------------------------------------------------------
  static getInstance() {
    if ($instance == null) {
      $instance = new GlobalManager();
    }
    return $instance;
  }
  //----------------------------------------------------------------------------
  constructor() {

  }
  //----------------------------------------------------------------------------
  getTemplate(key) {
    let res = null;
    if (key in this.$templates) {
      res = this.$templates[key];
    }
    return res;
  }
  //----------------------------------------------------------------------------
  setTemplate(key, temp) {
    this.$templates[key] = temp;
  }
}

export { GlobalManager };