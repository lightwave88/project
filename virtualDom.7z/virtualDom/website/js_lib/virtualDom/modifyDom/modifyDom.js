// 根據 vnode 建構 old_dom
import $GM from '../g_module.js';

let $domApi;
let $util;
let $Vnode;

(async () => {
  // 延時注入模組

  await Promise.resolve();
  // debugger;

  try {
    $domApi = $GM.get('domApi');
    $util = $GM.get('util');
    $Vnode = $GM.get('Vnode');
  } catch (er) {
    console.log(er);
  }
})();
//------------------------------------------------------------------------------


class ModifyDom {
  constructor(options = {}) {
    this.keepAliveMap = {};
  }
  //-----------------------------------------------------
  // start here
  patch(oldVnode, vnode, parentDom) {

    this._travelAllVnode(oldVnode, vnode, parentDom);

    let root_dom = (vnode == null ? null : vnode.dom);

    // 要返回 rootDom, keepAliveMap

    return root_dom;
  }
  //-----------------------------------------------------
  _travelAllVnode(oldVnode, vnode, parentDom) {
    let rootVnode = vnode;

    let travelList = [];
    travelList.push({
      o: oldVnode,
      n: vnode,
      p: parentDom,
      sameType: null
    });
    //-----------------------
    // dom 不用任何改變
    let domNoChangeList = [];

    // dom 需進行 attr 變化
    let sameTypeNodeList = [];

    // dom 需要重建
    let diffNodeList = [];

    // 有被保留的 dom
    let keepAliveList = [];
    //-----------------------
    let index = 0;


    while (true) {
      debugger;

      let i = index++;
      let data = travelList[i];
      if (data == null) {
        break;
      }

      let { o, n, p, sameType = null } = data;

      if (sameType == null) {
        sameType = this._is_sameTypeVnode(o, n);
      }

      if (sameType) {
        console.log('sameNode');

        if (n.is_static != o.is_static) {
          throw new Error('two vnode not same static');
        }

        if (n.is_static) {

          let judge_1 = (n.compute_attrs.size == 0 && o.compute_attrs.size == 0);

          if (judge_1) {
            console.log('static');
            // 完全靜態 node
            // 沒事作
            domNoChangeList.push({ o, n, p });

          } else {

            console.log('static, attr not static');
            // 靜態 node，但有部分動態 attr
            sameTypeNodeList.push({ o, n, p });
          }
        } else {
          console.log('not static');
          sameTypeNodeList.push({ o, n, p });
        }

      } else {

        if (o != null || n != null) {
          console.log('diff node');
          diffNodeList.push({ o, n, p });
        }
        travelList.splice(i, 1);
        index = i;
        continue;
      }
      //------------------
      debugger;

      // 繼續往下拜訪
      // 並試圖匹配相同的 child
      let list = this._matchChilds(o, n);

      while (list.length) {
        let data = list.shift();
        travelList.push(data);
      }
    } // endWhile

    //-----------------------
    debugger;
    this.aboutDomNochange(domNoChangeList);

    this.aboutDiffNodes(diffNodeList);

    this.aboutSameTypeNodes(sameTypeNodeList);

    this.aboutKeepAlive(keepAliveList);
  }
  //-----------------------------------------------------
  // 比較兩個 vnode 性質是否相同
  _is_sameTypeVnode(a, b) {
    // debugger;

    if (a == null || b == null) {
      return false;
    }

    // 比較 nodeName
    if (a.nodeName !== b.nodeName) {
      return false;
    }

    const a_attrs = a.attrs;
    const b_attrs = b.attrs;

    // old_dom.type 不同就視爲不同
    // old_dom 必須重建 不然可能有問題
    // <input> 尤其嚴重
    let a_type = (a_attrs.has('type') ? a_attrs.get('type') : null);
    let b_type = (b_attrs.has('type') ? b_attrs.get('type') : null);



    if (a_type !== b_type) {
      return false;
    }

    // 比較 old_dom.id
    if ((a.id != null || b.id != null) && a.id !== b.id) {
      return false;
    }

    // 比較 old_dom.class
    // if (a.classList.length != b.classList.length) {
    //   return false;
    // }

    // if (a.classString != b.classString) {
    //   return false;
    // }

    return true;
  }
  //-----------------------------------------------------
  aboutDomNochange(list = []) {
    while (list.length) {
      let { o, n } = list.pop();
      let dom = o.dom
      n.setDom(dom);
    }
  }
  //-----------------------------------------------------
  aboutSameTypeNodes(list) {
    const $attrsUpdate = $GM.get('attrsUpdate');

    while (list.length) {
      let { o, n, p } = list.pop();


      let dom = o.dom;

      console.log('-----------\n');
      console.log('update old_dom(%s)', o.nodeName);
      console.dir(o.dom);
      console.log('-----------\n');


      if (dom.tagName != null) {
        // 標籤 old_dom
        $attrsUpdate.update(o, n);
      } else {
        // 非標籤 old_dom
        $domApi.setTextContent(dom, n.text);
      }
      n.setDom(dom);
    }
  }
  //-----------------------------------------------------
  aboutKeepAlive(list = []) {
    // 更新 this.keepAliveMap


  }
  //-----------------------------------------------------
  aboutDiffNodes(list = []) {

    while (list.length) {

      let { o, n, p } = list.shift();


      let dom;
      let dom_next = null;

      if (o != null) {
        dom = o.dom;
        dom_next = dom.nextSibling || null;

        this._removeChildVnodes(o);
      }
      debugger;
      // 建立一棵新的 domThree
      let new_dom = this._createElm(n);

      if (new_dom != null) {
        $domApi.insertBefore(p, new_dom, dom_next);
      }
    }
  }
  //-----------------------------------------------------
  _removeChildVnodes(vnodes = []) {
    // debugger;

    if (vnodes == null) {
      return;
    }

    if (!Array.isArray(vnodes)) {
      vnodes = [vnodes];
    }

    let tempList = [];

    vnodes.forEach(v => {
      // 先脫鉤第一層 old_dom

      tempList.push(v);

      // 有可能碰到 空 vnode
      let old_dom = v.dom || null;

      if (old_dom == null) {
        return;
      }

      let parent = old_dom.parentNode;

      if (parent != null) {
        $domApi.removeChild(parent, old_dom);
      }
    });

    $util.nextStep(() => {
      this._clearVnodeTree(tempList);
    });

  }
  //-----------------------------------------------------
  _clearVnodeTree(list) {
    let index = 0;
    while (true) {
      // debugger;
      let i = index++;

      let vnode = list[i];
      if (vnode == null) {
        break;
      }
      // destroy vnode 
      vnode.destroy();

      let childs = vnode.childs;

      childs.forEach((child) => {
        list.push(child);
      });
    } // endwhile

  }
  //-----------------------------------------------------
  _createElm(rootVnode) {
    // debugger;

    if (rootVnode == null) {
      return null;
    }

    const $attrsUpdate = $GM.get('attrsUpdate');

    // 要處理的列表
    let tempList = [rootVnode];
    let parentMap = {};

    let new_dom;

    let i = 0;
    //-----------------------
    while (true) {
      // debugger;

      let vnode = tempList[i];
      if (vnode == null) {
        break;
      }
      let nodeName = vnode.nodeName;

      if (vnode.tagName == null) {
        // 不是 tag  

        new_dom = this._createDom(null, nodeName, vnode.text);
        vnode.setDom(new_dom);

        console.log('create new_dom(%s)', new_dom.nodeName);

        if (i in parentMap) {
          let parent_dom = parentMap[i];
          delete parentMap[i];
          $domApi.appendChild(parent_dom, new_dom);
        }

      } else {
        // tag
        new_dom = this._createDom(vnode.tagName);
        vnode.setDom(new_dom);

        console.log('create new_dom(%s)', new_dom.nodeName);

        // 處理 attrs
        $attrsUpdate.create(vnode);

        if (i in parentMap) {
          let parent_dom = parentMap[i];
          delete parentMap[i];
          $domApi.appendChild(parent_dom, new_dom);
        }

        let childList = vnode.childs;
        if (!Array.isArray(childList)) {
          return;
        }

        childList.forEach((vnode) => {
          let j = tempList.length;
          tempList.push(vnode);
          parentMap[j] = new_dom;
        });

      } // endif

      i++;
    } // end while

    return rootVnode.dom;
  }
  //-----------------------------------------------------
  _createDom(tagName, nodeName, text) {
    let dom;

    if (tagName == null) {
      switch (nodeName) {
        case '#comment':
          dom = $domApi.createComment(text);
          break;
        case '#text':
          dom = $domApi.createTextNode(text);
          break;
        default:
          console.dir(vnode);
          throw new Error(`no deal with this domType(${nodeName})`);
          break;
      }
    } else {
      dom = $domApi.createElement(tagName);
    }
    return dom;
  }
  //-----------------------------------------------------
  // 試圖匹配相同的 child
  // 只移動 oldVnode.childs
  _matchChilds(oldvnode, vnode) {
    debugger;

    const parentDom = oldvnode.dom;

    const childList = [];

    let o_list = oldvnode.childs;
    let n_list = vnode.childs;
    let o_length = o_list.length;
    let n_length = n_list.length;
    let length = (o_length > n_length ? o_length : n_length);

    // 記錄已經匹配過
    let hasMatch = new Set();

    let i = 0;

    // hasMatch.size == o_length (oldVnode.childs 都被配對完了
    while (i < length) {
      debugger;

      let j = i++;
      let o = o_list[j] || null;
      let n = n_list[j] || null;
      //-----------------------
      // needFindMatch

      if (n != null && hasMatch.size < o_length) {



        let sameType = null;
        // 尋找匹配
        let res = this._findTarget(n, o_list, hasMatch);
        debugger;

        if (res == null) {
          // 沒有找到
          sameType = false;
        } else {
          // 有找到

          let index = res.index;
          sameType = res.sameType;

          hasMatch.add(j);

          console.log("j=%s, index=%s", j, index);
          console.dir(n);
          console.dir(o_list);
          console.dir(n_list);

          if (j != index) {
            // 需要移動 dom
            o = o_list[index];
            let s = o_list[j] || null;


            if (s == null) {
              // n_list 超過 o_list
              // problem

            }

            let t_dom = o.dom;

            let s_dom = s.dom;

            let next_dom = t_dom.nextSibling || null;
            // 交換 dom

            if (t_dom.parentNode !== s_dom.parentNode) {
              throw new Error('parent diff');
            }
            // $domApi.removeChild(parentDom, t_dom);
            $domApi.insertBefore(parentDom, t_dom, s_dom);
            $domApi.insertBefore(parentDom, s_dom, next_dom);

            // 交換 vnode
            o_list[index] = s;
            o_list[j] = o;
          }
          //------------------
          childList.push({
            o,
            n,
            p: parentDom,
            sameType
          });
        }
      } else {
        childList.push({
          o,
          n,
          p: parentDom,
          sameType: false
        });
      }
    } // endWhile
    return childList;
  }
  //-----------------------------------------------------
  // 在 list 中找尋
  // 搜尋策略
  _findTarget(vnode, list, hasMatch) {
    debugger;

    // 找尋 sameType, childs.length 相同
    // 找尋 sameType

    let find = null;

    list.some((oldVnode, i) => {
      debugger;
      let sameType = null;

      if (oldVnode == null) {
        return;
      }

      if (hasMatch.has(i)) {
        // 這個位置已經被標定
        return;
      }

      //------------------
      if (vnode.is_static != oldVnode.is_static) {
        // import
        // static 的立意
        return;
      }

      sameType = this._is_sameTypeVnode(vnode, oldVnode);
      if (sameType) {
        find = find || { index: i, sameType };
      } else {
        return;
      }
      //------------------
      if (vnode.childs.length == oldVnode.childs.length) {
        // 兩個子結構數量相同
        // 猜測有很大可能有相同的結構
        // 再細談索下去會耗費時間
        find = { index: i, sameType };
        return true;
      }
    }); // endSome

    return find;

  }
}

export default ModifyDom;

