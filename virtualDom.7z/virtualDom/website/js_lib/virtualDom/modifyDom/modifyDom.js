'use strict';

// 根據 vnode 建構 old_dom
import $GM from '../g_module.js';

const $reg_1 = /^template$/i;

class ModifyDom {

  // manager
  manager = {
    c: null,
    p: null,
  };

  module;

  travelList = [];
  dom_container;

  keeps = {};
  keepAlls = {};

  rootVnode = {
    o: null,
    n: null
  };

  keepAllList = [];

  // 影響 vnode。search 的策略
  isManagerDiff = false;
  //----------------------------------------------------------------------------
  constructor(preManager, manager) {
    this.manager.p = preManager;
    this.manager.c = manager;

    if (preManager == null || preManager.id != manager.id) {
      this.isManagerDiff = true;
    }

    this.module = new Proxy({}, {
      set() {
        return false;
      },
      get(key) {
        if (!$GM.has(key)) {
          throw new Error(`no this module(${key})`);
        }
        return $GM.get(key);
      }
    });
  }
  //----------------------------------------------------------------------------
  // start here
  patch(oldVnode, vnode, parentDom) {

    const {
      c: manager,
      p: p_manager
    } = this.manager.c;
    // 初始化

    this.dom_container = parentDom;
    //------------------

    this._aboutRootNode(oldVnode, vnode);

    this._travelAllVnode();

    const Vnode = this.module['Vnode'];
    Vnode.linkDom(parentDom, vnode);

    // 要檢查 keeps, keepAlls
    // this._checkPreManagerKeepNodes();

  }
  //-----------------------------------------------------
  // rootVnode 是空節點
  _aboutRootNode(oldVnode, vnode) {

    this.rootVnode['o'] = oldVnode;
    this.rootVnode['n'] = vnode;

    let list = this._matchChilds(oldVnode, vnode, this.dom_container);

    this.travelList = this.travelList.concat(list);
  }
  //-----------------------------------------------------
  // 片歷所有樹節點
  _travelAllVnode() {
    debugger;

    const $domApi = this.module['domApi'];

    // dom 不用任何改變
    const staticNodeList = [];

    // dom 需進行 attr 變化
    const sameTypeNodeList = [];

    // dom 需要重建
    const diffNodeList = [];

    let travelList = this.travelList;
    //-----------------------
    let index = 0;

    while (true) {
      debugger;

      let i = index++;
      let data = travelList[i];
      if (data == null) {
        break;
      }
      //------------------
      let { o, n, sameType } = data;

      debugger;
      if (sameType) {
        console.log('sameTypeNode');
        //------------------
        if (n.isStatic && !this.isManagerDiff) {

          console.log('static');

          staticNodeList.push({ o, n });

        } else {
          // not static
          // sameType

          console.log('not static');
          sameTypeNodeList.push({ o, n });

        }
      } else {

        console.log('diff node');

        if (o != null) {
          dom = o.dom;
          $domApi.detach(dom);
        }
        diffNodeList.push({ o, n });
        continue;
      }
      //----------------------------
      // childs
      // 並試圖匹配相同的 child
      let list = this._matchChilds(o, n);

      debugger;
      if (list.length) {
        travelList = travelList.concat(list);
      }

    } // endWhile

    //-----------------------
    debugger;
    this._aboutDiffNodes(diffNodeList);

    this._aboutSameTypeNodes(sameTypeNodeList);

    this._staticNodes(staticNodeList);

    // 順序不能變
    this._aboutKeepAllList(this.keepAllList);

    debugger;
    console.dir(this.destroyVnodeList);

    this._removeChildVnodes();
  }
  //-----------------------------------------------------
  // 位置固定的節點
  _staticNodes(list = []) {
    debugger;

    const $attr = this.module['attr'];

    while (list.length) {
      let { o, n } = list.shift();

      let dom = o.dom;
      let parentDom = dom.parentNode;

      // 與 vnode 對應的 dom 的位置可能不對
      // 處理 dom 的位置
      fixDomPosition(parentDom, dom, n);

      if (n.tagName != null) {
        // 若是 tag

        // 若有計算 attr
        // 必須檢查 attr，並轉移
        // $attr.updateDom(dom, o, n, true);
      }

      let old = n.setDom(dom);

      if (old) {
        this.destroyVnodeList.push(old);
      }
    }
  }
  //-----------------------------------------------------
  _aboutSameTypeNodes(list) {
    debugger;

    const $attr = this.module['attr'];

    while (list.length) {
      let { o, n } = list.shift();
      let dom = o.getDom();

      console.log('-----------\n');
      console.log('update old_dom(%s)', o.nodeName);
      console.dir(o.dom);
      console.log('-----------\n');

      let parentDom = dom.parentNode;

      // 與 vnode 對應的 dom 的位置可能不對
      // 處理 dom 的位置
      fixDomPosition(parentDom, dom, n);
      //-------------
      if (dom.tagName != null) {
        // 標籤 old_dom

        let keep;
        if (n.keep != null && null != (keep = this._findKeep(n))) {

          // 置換 keepVnode 的 dom
          o.dom = keep;

          Array.from(dom.childNodes).forEach(d => {
            // 轉移子節點
            $domApi.appendChild(keep, d);
          });

          $domApi.replaceChild(dom.parentNode, keep, dom);
          dom = keep;
        }

        let _static = (keep != null) ? true : false;
        // $attr.updateDom(dom, o, n, _static);

      } else {
        // 非標籤 old_dom
        $domApi.setTextContent(dom, n.text);
      }
      //-------------
      let old = n.setDom(dom);

      if (old) {
        this.destroyVnodeList.push(old);
      }
    }
  }
  //-----------------------------------------------------
  _aboutKeepAllList(list = []) {
    // 更新 this.keepAliveMap

    while (list.length) {
      debugger;
      let { o, n } = list.shift();

      this._checkKeepAllTree(o, n);
    } // endWhile
  }
  //-----------------------------------------------------
  _checkKeepAllTree(oldNode, node) {
    debugger;
    const $attr = this.module['attr'];

    let tList = [];
    tList.push({ o: oldNode, n: node });

    while (tList.length) {
      let data = tList.shift();

      let { o, n } = data;

      let dom = o.getDom();
      // $attr.updateDom(dom, o, n, true);

      oldNode.childs.forEach((o, i) => {
        let _n = n.childs[i];
        tList.push({ o, n: _n });
      });
    }

  }
  //----------------------------------------------------------------------------
  _aboutDiffNodes(list = []) {
    debugger;

    const $domApi = this.module['domApi'];

    while (list.length) {
      debugger;

      const { o, n } = list.shift();

      if (o != null) {
        this.destroyVnodeList.push(o);
      }
      //------------------
      if (n != null) {
        debugger;

        const p = o.getDom();

        // 建立一棵新的 domThree
        this._createDomTree(n);

        let dom_new = n.getDom();
        let index = n.index;

        let dom_next = p.childNodes[index] || null;

        if (dom_next != null && isTemplateTag(dom_next)) {
          // 遇到佔位用的 <template>
          $domApi.replaceChild(p, dom_new, dom_next);
        } else {
          $domApi.insertBefore(p, dom_new, dom_next);
        }

      }
    } // endWhile
  }
  //----------------------------------------------------------------------------
  // 銷毀無用的 vnode
  _removeChildVnodes() {
    debugger;

    return;

    const destroyVnodeList = this.destroyVnodeList;

    function job() {

      destroyVnodeList.forEach((node) => {

        const vnodeList = [node];

        let index = 0;

        while (true) {
          // debugger;
          let i = index++;

          let vnode = vnodeList[i];
          if (vnode == null) {
            break;
          }
          let childs = vnode.childs.slice();

          // destroy vnode
          vnode.destroy();

          while (childs.length) {
            let c = childs.shift();
            vnodeList.push(c);
          }
        }
      });

      destroyVnodeList.length = 0;
    } // endJob


    $util.nextStep(job);
  }
  //----------------------------------------------------------------------------
  // 創建新的節點樹
  _createDomTree(rootVnode) {
    debugger;

    const $attr = this.module['attr'];

    // 要處理的列表
    let tempList = [rootVnode, null];

    let new_dom;

    let i = 0;
    //-----------------------
    while (true) {
      debugger;
      let j = i++;

      if (tempList[j] == null) {
        break;
      }
      const [vnode, parentVnode] = tempList[i];

      let nodeName = vnode.nodeName;
      let oldVnode;


      if (vnode.tagName == null) {
        // not tag
        // not tag
        // not tag

        new_dom = this._createDom(null, nodeName, vnode.text);
        oldVnode = vnode.setDom(new_dom);

        console.log('create new_dom(%s)', new_dom.nodeName);

        if (parentVnode) {
          let parentDom = parentVnode.getDom();
          $domApi.appendChild(parentDom, new_dom);
        }

      } else {
        // tag
        // tag
        // tag

        debugger;

        let keepAll;

        action_1: {

          if (vnode.keepAll != null) {
            // keepAll

            let keepAll = this._findKeepAll(vnode);
            if (keepAll) {

              new_dom = keepAll.getDom();
              // $attr.updateDom(new_dom, keepAll, vnode, true);

              break action_1;
            }
          } else if (vnode.keep != null) {
            // keep

            let keep = this._findKeep(n);

            if (keep != null) {

              new_dom = keep;
              // $attr.updateDom(new_dom, null, vnode, true);

              console.log('create new_dom(%s) but find keep', new_dom.nodeName);
              break action_1;
            }
            console.log('create new_dom(%s) no find keep', new_dom.nodeName);
          }
          //------------------

          console.log('create new_dom(%s)', new_dom.nodeName);
          new_dom = this._createDom(vnode.tagName);
          $attr.createDom(new_dom, vnode);
        } // action_1

        oldVnode = vnode.setDom(new_dom);

        if (parentVnode) {
          let parentDom = parentVnode.getDom();
          $domApi.appendChild(parentDom, new_dom);
        }

        if (keepAll != null) {
          this.KeepAllList.push({
            n: vnode,
            o: keepAll,
          });

          continue;
        }
        //----------------------------
        // child

        let childList = vnode.childs;
        if (!Array.isArray(childList)) {
          return;
        }

        childList.forEach((node) => {
          tempList.push([node, vnode]);
        });

      } // endif
      //------------------
      if (oldVnode) {
        this.destroyVnodeList.push(oldVnode);
      }

      tempList[j].length = 0;
      tempList[j] = null;
    } // end while

    tempList.length = 0;
    tempList = null;

    return rootVnode.dom;
  }
  //-----------------------------------------------------
  _createDom(tagName, nodeName, text) {
    let dom;

    if (tagName == null) {
      switch (nodeName) {
        case '#comment':
          dom = $domApi.createComment(text);
          break;
        case '#text':
          dom = $domApi.createTextNode(text);
          break;
        default:
          console.dir(vnode);
          throw new Error(`no deal with this domType(${nodeName})`);
          break;
      }
    } else {
      dom = $domApi.createElement(tagName);
    }
    return dom;
  }
  //----------------------------------------------------------------------------
  // important
  // 試圖匹配相同的 child
  // 只移動 oldVnode.childs
  _matchChilds(oldvnode, vnode, parentDom) {
    debugger;

    parentDom = parentDom || oldvnode.dom || null;

    if (parentDom == null) {
      throw new Error('...');
    }

    let o_list = oldvnode.childs;
    let n_list = vnode.childs;
    let n_length = n_list.length;

    //-----------------------
    // 先過濾出 vnode.static, vnode.no_static

    let matchList = Array(n_length).fill(null);
    let searchList = o_list.map(n => {
      return {
        node: n
      };
    });

    // oldvnode.clearChilds();
    //-----------------------

    let i = 0;

    while (i < n_length) {
      // debugger;

      let j = i++;
      let n = n_list[j];

      if (n.keepAll != null) {
        // 重要
        continue;
      }

      // 找可配對的 vnode
      let findMatchNode = this._findTarget(n, searchList);

      if (findMatchNode != null) {
        matchList[j] = findMatchNode;
      }

    } // endWhile
    //----------------------------
    // 處理剩下沒匹配的

    searchList.forEach(d => {
      let {
        node
      } = d;

      if (node == null) {
        // 已經被匹配走了
        return;
      }
      let dom = node.dom;
      $domApi.detach(dom);

      this.destroyVnodeList.push(node);
    });
    //------------------
    // 需要往下探索
    let childList = matchList.map((match, i) => {
      let sameType = (match == null ? false : true);
      let node = n_list[i];

      return {
        o: match,
        n: node,
        sameType,
      };
    });

    return childList;
  }
  //----------------------------------------------------------------------------
  _findTarget(vnode, searchList) {
    let node;

    if (this.isManagerDiff) {
      // 當 vfactory 不同
      node = this._findTarget_1(vnode, searchList);
    } else {
      // 當 vfactory 相同
      node = this._findTarget_2(vnode, searchList);
    }
    return node;
  }
  //----------------------------------------------------------------------------

  // 搜尋策略
  // 當 vfactory 不同
  _findTarget_1(vnode, searchList) {
    // debugger;

    let find = null;
    let findIndex = null;

    searchList.some((d, i) => {
      debugger;

      let { node: targetNode } = d;

      if (targetNode == null) {
        // 已經被人取走
        return;
      }
      //------------------
      let sameType = is_sameTypeVnode(targetNode, vnode, this.isManagerDiff);
      if (sameType) {
        findIndex = i;
        return true;
      }
    }); // endSome
    //------------------   
    debugger;
    
    if (findIndex != null) {
      find = (searchList[findIndex]).node;
      // 標記已被指定
      (searchList[findIndex]).node = null;
    }

    return find;
  }
  //----------------------------------------------------------------------------
  // 當 vfactory 相同
  _findTarget_2(vnode, searchList) {
    debugger;

    let find = null;
    let findIndex = null;

    if (vnode.isStatic) {
      // 靜態的搜尋方法
      searchList.some((d, i) => {
        debugger;

        let { node: targetNode } = d;

        let sameType = advanCompareChilds_2(targetNode, vnode);

        if (sameType) {
          findIndex = i;
          return true;
        }
      });

      if (!findIndex) {
        // 理論不會找不到
        throw new Error('......');
      }

    } else {
      // 匹配動態節點
      searchList.some((d, i) => {
        debugger;

        let { node: targetNode } = d;

        // 第一個匹配條件
        let sameType = is_sameTypeVnode(targetNode, vnode, this.isManagerDiff);
        if (sameType) {
          findIndex = (findIndex != null ? findIndex : i);
        } else {
          return;
        }
        //------------------
        // 第二個匹配條件
        if (advanCompareChilds_1(targetNode, vnode)) {
          findIndex = i;
          return true;
        }

      });
    }
    //------------------
    debugger;
    if (findIndex != null) {
      find = (searchList[findIndex]).node;
      // 標記已被指定
      (searchList[findIndex]).node = null;
    }

    return find;
  }
  //----------------------------------------------------------------------------
  // 找 keep, keepAll 之前是否有 cache
  _findKeep(node) {
    // this._updateKeepNode(node);

    let manager = this.manager.c;

    let name = node.keep;
    let dom = manager.getKeep(name);

    return dom;
  }
  //----------------------------------------------------------------------------
  _findKeepAll(node) {
    // this._updateKeepNode(node);

    let manager = this.manager.c;

    let name = node.keep;
    let node = manager.getKeepAll(name);

    if (node) {

      let dom = node.getDom();
      if (dom.parentNode != null) {
        dom.parentNode.removeChild(dom);
      }
      node.parent = null;
    }

    return node;
  }
  //----------------------------------------------------------------------------
  // 更新 keep 記錄
  _updateKeepNode(node) {
    let isAll = (node.keep == null ? true : false);
    let name;

    if (isAll) {
      name = node.keepAll;
      this.keepAlls[name] = node;
    } else {
      name = node.keep;
      this.keeps[name] = node;
    }
  }
  //----------------------------------------------------------------------------
  // 注意這邊
  // 確定前 manager.keeps keepAlls 的狀態
  _checkPreManagerKeepNodes() {
    // 斷去沒用到的 keep, keepAll
    let list = [this.preManager, this.manager];
    list.forEach(m => {
      if (m == null) {
        return;
      }

      let a = m.getKeep();
      let b = m.getKeepAll();
      let nodeMap = Object.assign({}, a, b);

      for (let k in nodeMap) {
        let vnode = nodeMap[k];
        let dom = vnode.getDom();

        debugger;
        // 斷去 vnode, dom 連接
        if (vnode.parent == null) {
          continue;
        }

        if (this.dom_container.contains(dom)) {
          // dom 還在線上
          continue;
        }
        // 解除 dom, vnode 的連接
        vnode.parent.removeChild(vnode);
      }
    })
    //-----------------------
    // 更新有用到的 keep, keepAll
    if (this.manager != null) {
      let m = this.manager;
      // 更新 keep, keepAll
      for (let k in this.keeps) {
        m.setKeep(k, this.keeps[k]);
      }
      for (let k in this.keepAlls) {
        m.setKeepAll(k, this.keepAlls[k]);
      }
    }
  }
  //----------------------------------------------------------------------------

}

export default ModifyDom;

//==============================================================================

function isTemplateTag(dom) {

  if (dom == null) {
    return false;
  }

  if (dom.tagName != null && !$reg_1.test(dom.tagName)) {
    return false;
  }

  return true;
}
//------------------------------------------------------------------------------
// 非常重要的規則
// 找尋相似度高的兩 vnode
// 比較兩個 vnode 性質是否相同
function is_sameTypeVnode(o, n, isManagerDiff) {
  // debugger;
  const o_attrs = o.attrs;
  const n_attrs = n.attrs;

  if (n == null) {
    return false;
  }

  if (!isManagerDiff) {
    // static
    if (o.isStatic != n.isStatic) {
      return false;
    }
  }
  //----------------------------
  // keep, keepAll
  if (o.keep != null) {
    // return false;
  }

  if (o.keepAll != null) {
    return false;
  }
  //----------------------------
  // 比較 nodeName
  if (o.nodeName !== n.nodeName) {
    return false;
  }
  //----------------------------
  // id
  if (!isManagerDiff) {
    let o_id = o_attrs.has('id') ? o_attrs.get('id') : null;
    let n_id = n_attrs.has('id') ? n_attrs.get('id') : null;

    // 比較 old_dom.id
    if ((o_id != null || n_id != null) && o_id !== n_id) {
      return false;
    }
  }
  //----------------------------
  // 細節比較

  if (o_attrs.has('type') || n_attrs.has('type')) {

    // old_dom.type 不同就視爲不同
    // old_dom 必須重建 不然可能有問題
    // <input> 尤其嚴重
    let a_type = o_attrs.get('type') || null;
    let b_type = n_attrs.get('type') || null;

    if (a_type !== b_type) {
      return false;
    }
  }
  //----------------------------
  return true;
}
//------------------------------------------------------------------------------
// dom 已經在 domTree 上
// 但位置可能不對，需校正
function fixDomPosition(parentDom, dom, vnode) {
  const $domApi = $module.get('domApi');

  if (dom.parentNode == null) {
    // keep, keepAll
    if (vnode.keep == null && vnode.keepAll == null) {
      console.dir(vnode);
      throw new Error('dom no parent');
    }
  }

  let index = vnode.index;
  let childList = parentDom.childNodes;
  let j = childList.length;

  //------------------
  if (childList[index] === dom) {
    return;
  }

  if (index >= j) {
    for (let i = j; i <= index; i++) {
      // 先用 <template> 佔位
      let dom_temp = document.createElement('template');
      $domApi.appendChild(parentDom, dom_temp);
    }
  }

  $domApi.removeChild(parentDom, dom);
  let dom_target = childList[index] || null;

  $domApi.insertBefore(parentDom, dom, dom_target);

}
//------------------------------------------------------------------------------
// 動態節點進階比對方式
function advanCompareChilds_1(o, n) {
  debugger;

  let list_1 = o.childs
  let list_2 = n.childs;
  if (list_1.length != list_2.length) {
    return false;
  }
  return true;
}
//------------------------------------------------------------------------------
// 靜態節點的比對
function advanCompareChilds_2(o, n) {
  debugger;

  if (o.isStatic != n.isStatic) {
    return false;
  }

  if (o.factoryId != n.factoryId) {
    return false;
  }

  if (o.staticIndex != n.staticIndex) {
    return false;
  }

  if (o.level != n.level) {
    return false;
  }

  return true;
}
