// 根據 vnode 建構 old_dom
import $GM from '../g_module.js';

let $domApi;
let $util;
let $Vnode;

(async () => {
  // 延時注入模組

  await Promise.resolve();
  // debugger;

  try {
    $domApi = $GM.get('domApi');
    $util = $GM.get('util');
    $Vnode = $GM.get('Vnode');
  } catch (er) {
    console.log(er);
  }
})();
//------------------------------------------------------------------------------


class ModifyDom {
  constructor(options = {}) {
    this.keepAliveMap = {};
  }
  //-----------------------------------------------------
  // start here
  patch(oldVnode, vnode, parentDom) {

    this._travelAllVnode(oldVnode, vnode, parentDom);

    let root_dom = (vnode == null ? null : vnode.dom);

    // 要返回 rootDom, keepAliveMap

    return root_dom;
  }
  //-----------------------------------------------------
  _travelAllVnode(oldVnode, vnode, parentDom) {
    let rootVnode = vnode;

    let travelList = [];
    travelList.push({
      o: oldVnode,
      n: vnode,
      p: parentDom,
      sameType: null
    });

    let index = 0;
    while (true) {
      debugger;

      let i = index++;
      let data = travelList[i];

      if (data == null) {
        break;
      }

      let { o, n, p, same: sameType } = data;

      if (sameType == null) {
        sameType = _is_sameVnode(o, n);
      }

      if (sameType) {

      } else {
        continue;
      }
    } // endWhile

    //------------------
    debugger;
    // 繼續往下拜訪
    // 並試圖匹配相同的 child


    let list = thiis._matchChilds(_oldVnode, _vnode, p);

    while (list.length) {
      let data = sameList.shift();
      travelList.push(data);
    }

    //-----------------------

  }
  //-----------------------------------------------------
  // 比較兩個 vnode 性質是否相同
  _is_sameVnode(a, b) {
    // debugger;

    if (a == null || b == null) {
      return false;
    }

    // 比較 nodeName
    if (a.nodeName !== b.nodeName) {
      return false;
    }

    const a_attrs = a.attrs;
    const b_attrs = b.attrs;

    // old_dom.type 不同就視爲不同
    // old_dom 必須重建 不然可能有問題
    // <input> 尤其嚴重
    let a_type = (a_attrs.has('type') ? a_attrs.get('type') : null);
    let b_type = (b_attrs.has('type') ? b_attrs.get('type') : null);

    if (a_type !== b_type) {
      return false;
    }

    // 比較 old_dom.id
    if ((a.id != null || b.id != null) && a.id !== b.id) {
      return false;
    }

    // 比較 old_dom.class
    // if (a.classList.length != b.classList.length) {
    //   return false;
    // }

    // if (a.classString != b.classString) {
    //   return false;
    // }

    return true;
  }
  //-----------------------------------------------------
  aboutDomNochange(list = []) {
    while (list.length) {
      let d = list.pop();
      let [vnode, old_dom] = d;
      vnode.setDom(old_dom);
    }
  }
  //-----------------------------------------------------
  aboutSameTypeNodes(list) {
    const $attrsUpdate = $GM.get('attrsUpdate');

    while (list.length) {
      let data = list.pop();

      let [oldNode, node] = data;
      let old_dom = oldNode.dom;

      console.log('-----------\n');
      console.log('update old_dom(%s)', old_dom.nodeName);
      console.dir(oldNode.dom);
      console.log('-----------\n');


      if (old_dom.tagName != null) {
        // 標籤 old_dom
        $attrsUpdate.update(oldNode, node);
      } else {
        // 非標籤 old_dom
        $domApi.setTextContent(old_dom, node.text);
      }
      node.setDom(old_dom);
    }
  }
  //-----------------------------------------------------
  aboutKeepAlive(list = []) {
    // 更新 this.keepAliveMap


  }
  //-----------------------------------------------------
  aboutDiffNodes(list = []) {

    while (list.length) {

      let data = list.shift();

      let [oldVnode, vnode, parentDom] = data;
      let old_dom;
      let dom_next = null;

      if (oldVnode != null) {
        old_dom = oldVnode.dom;
        dom_next = old_dom.nextSibling || null;

        this._removeChildVnodes(oldVnode);
      }
      debugger;
      // 建立一棵新的 domThree
      let new_dom = this._createElm(vnode);

      if (new_dom != null) {
        $domApi.insertBefore(parentDom, new_dom, dom_next);
      }
    }
  }
  //-----------------------------------------------------
  _removeChildVnodes(vnodes = []) {
    // debugger;

    if (vnodes == null) {
      return;
    }

    if (!Array.isArray(vnodes)) {
      vnodes = [vnodes];
    }

    let tempList = [];

    vnodes.forEach(v => {
      // 先脫鉤第一層 old_dom

      tempList.push(v);

      // 有可能碰到 空 vnode
      let old_dom = v.dom || null;

      if (old_dom == null) {
        return;
      }

      let parent = old_dom.parentNode;

      if (parent != null) {
        $domApi.removeChild(parent, old_dom);
      }
    });

    $util.nextStep(() => {
      this._clearVnodeTree(tempList);
    });

  }
  //-----------------------------------------------------
  _clearVnodeTree(list) {
    let index = 0;
    while (true) {
      // debugger;
      let i = index++;

      let vnode = list[i];
      if (vnode == null) {
        break;
      }
      // destroy vnode 
      vnode.destroy();

      let childs = vnode.childs;

      childs.forEach((child) => {
        list.push(child);
      });
    } // endwhile

  }
  //-----------------------------------------------------
  _createElm(rootVnode) {
    // debugger;

    if (rootVnode == null) {
      return null;
    }

    const $attrsUpdate = $GM.get('attrsUpdate');

    // 要處理的列表
    let tempList = [rootVnode];
    let parentMap = {};

    let new_dom;

    let i = 0;
    //-----------------------
    while (true) {
      // debugger;

      let vnode = tempList[i];
      if (vnode == null) {
        break;
      }
      let nodeName = vnode.nodeName;

      if (vnode.tagName == null) {
        // 不是 tag  

        new_dom = this._createDom(null, nodeName, vnode.text);
        vnode.setDom(new_dom);

        console.log('create new_dom(%s)', new_dom.nodeName);

        if (i in parentMap) {
          let parent_dom = parentMap[i];
          delete parentMap[i];
          $domApi.appendChild(parent_dom, new_dom);
        }

      } else {
        // tag
        new_dom = this._createDom(vnode.tagName);
        vnode.setDom(new_dom);

        console.log('create new_dom(%s)', new_dom.nodeName);

        // 處理 attrs
        $attrsUpdate.create(vnode);

        if (i in parentMap) {
          let parent_dom = parentMap[i];
          delete parentMap[i];
          $domApi.appendChild(parent_dom, new_dom);
        }

        let childList = vnode.childs;
        if (!Array.isArray(childList)) {
          return;
        }

        childList.forEach((vnode) => {
          let j = tempList.length;
          tempList.push(vnode);
          parentMap[j] = new_dom;
        });

      } // endif

      i++;
    } // end while

    return rootVnode.dom;
  }
  //-----------------------------------------------------
  _createDom(tagName, nodeName, text) {
    let dom;

    if (tagName == null) {
      switch (nodeName) {
        case '#comment':
          dom = $domApi.createComment(text);
          break;
        case '#text':
          dom = $domApi.createTextNode(text);
          break;
        default:
          console.dir(vnode);
          throw new Error(`no deal with this domType(${nodeName})`);
          break;
      }
    } else {
      dom = $domApi.createElement(tagName);
    }
    return dom;
  }
  //-----------------------------------------------------
  _matchChilds(oldvnode, vnode, parentDom, sameType) {

    const childList = [];

    let o_list = oldvnode.childs;
    let n_list = vnode.childs;
    let oldCh_length = o_list.length;
    let ch_length = n_list.length;
    let length = (oldCh_length > ch_length ? oldCh_length : ch_length);

    // 記錄已經比對過
    let hasMatch = new Set();

    let i = 0;

    while (i < length) {
      let j = i++;
      let o = o_list[j] || null;
      let n = n_list[j] || null;
      //-----------------------
      // needFindMatch

      if (n == null || o == null) {
        childList.push({
          o,
          n,
          p: parentDom,
          sameType: false
        });
      } else {

        let index = this._findTarget(n, o_list, hasMatch);

        if (index != null) {
          // 有找到

          hasMatch.add(j);

          if (j != index) {
            o = o_list[index];
            let s = o_list[j];

            let target_dom = o.dom;
            let s_dom = s.dom;
            let next_dom = o.dom.nextSibling || null;
            // 交換 dom
            $domApi.insertBefore(parentDom, target_dom, s_dom);
            $domApi.insertBefore(parentDom, s_dom, next_dom);

            // 交換 vnode
            o_list[index] = s;
            o_list[j] = o;
          }
          childList.push({
            o,
            n,
            p: parentDom,
            sameType
          });
        }

      }
    } // endWhile
    return childList;
  }

  // 在 list 中找尋
  _findTarget(vnode, list, hasMatch) {

  }
}

export default ModifyDom;

