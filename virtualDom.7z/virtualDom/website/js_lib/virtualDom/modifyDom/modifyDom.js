// 根據 vnode 建構 old_dom
import $GM from '../g_module.js';

let $domApi;
let $util;
let $Vnode;

(async () => {
  // 延時注入模組

  await Promise.resolve();
  // debugger;

  try {
    $domApi = $GM.get('domApi');
    $util = $GM.get('util');
    $Vnode = $GM.get('Vnode');
  } catch (er) {
    console.log(er);
  }
})();
//------------------------------------------------------------------------------


class ModifyDom {
  constructor(options = {}) {
    this.keepAliveMap = {};
    this.destroyVnodeList = [];
  }
  //-----------------------------------------------------
  // start here
  patch(oldVnode, vnode, parentDom) {

    this._travelAllVnode(oldVnode, vnode, parentDom);

    let root_dom = (vnode == null ? null : vnode.dom);

    // 要返回 rootDom, keepAliveMap

    return root_dom;
  }
  //-----------------------------------------------------
  _travelAllVnode(oldVnode, vnode, parentDom) {
    let rootVnode = vnode;

    let travelList = [];

    travelList.push({
      o: oldVnode,
      n: vnode,
      p: parentDom,
      sameType: null,
    });
    //-----------------------
    // dom 不用任何改變
    let domNoChangeList = [];

    // dom 需進行 attr 變化
    let sameTypeNodeList = [];

    // dom 需要重建
    let diffNodeList = [];

    // 有被保留的 dom
    let keepAliveList = [];
    //-----------------------
    let index = 0;

    while (true) {
      debugger;

      let i = index++;
      let data = travelList[i];
      if (data == null) {
        break;
      }

      let { o, n, p, sameType = null } = data;

      if (sameType == null) {
        sameType = this._is_sameTypeVnode(o, n);
      }

      if (sameType) {
        console.log('sameNode');        

        if (n.is_static) {

          let judge_1 = (n.compute_attrs.size == 0 && o.compute_attrs.size == 0);

          if (judge_1) {
            console.log('static');
            // 完全靜態 node
            // 沒事作
            domNoChangeList.push({ o, n, p });

          } else {

            console.log('static, attr not static');
            // 靜態 node，但有部分動態 attr
            sameTypeNodeList.push({ o, n, p });
          }
        } else {
          console.log('not static');
          sameTypeNodeList.push({ o, n, p });
        }

      } else {

        if (o != null) {
          dom = o.dom;
          $domApi.detach(dom);          
        }

        diffNodeList.push({ o, n, p });
        continue;
      }
      //------------------
      debugger;

      // 繼續往下拜訪
      // 並試圖匹配相同的 child
      let list = this.matchChilds(o, n);

      travelList = travelList.concat(list);
    } // endWhile

    //-----------------------
    debugger;
    this.aboutDiffNodes(diffNodeList);

    this.aboutSameTypeNodes(sameTypeNodeList);
    
    this.aboutDomNochange(domNoChangeList);

    this.aboutKeepAlive(keepAliveList);

    this.removeChildVnodes();
  }
  //-----------------------------------------------------
  // 比較兩個 vnode 性質是否相同
  _is_sameTypeVnode(a, b) {
    // debugger;

    if (a == null || b == null) {
      return false;
    }

    // 比較 nodeName
    if (a.nodeName !== b.nodeName) {
      return false;
    }

    if(a.is_static != b.is_static){
      return false;
    }

    const a_attrs = a.attrs;
    const b_attrs = b.attrs;

    // old_dom.type 不同就視爲不同
    // old_dom 必須重建 不然可能有問題
    // <input> 尤其嚴重
    let a_type = (a_attrs.has('type') ? a_attrs.get('type') : null);
    let b_type = (b_attrs.has('type') ? b_attrs.get('type') : null);



    if (a_type !== b_type) {
      return false;
    }

    // 比較 old_dom.id
    if ((a.id != null || b.id != null) && a.id !== b.id) {
      return false;
    }

    // 比較 old_dom.class
    // if (a.classList.length != b.classList.length) {
    //   return false;
    // }

    // if (a.classString != b.classString) {
    //   return false;
    // }

    return true;
  }
  //-----------------------------------------------------
  aboutDomNochange(list = []) {
    while (list.length) {
      let { o, n } = list.pop();
      let dom = o.dom;
      n.setDom(dom);
      this.destroyVnodeList.push(o);
    }
  }
  //-----------------------------------------------------
  aboutSameTypeNodes(list) {
    const $attrsUpdate = $GM.get('attrsUpdate');

    while (list.length) {
      let { o, n, p } = list.pop();


      let dom = o.dom;

      console.log('-----------\n');
      console.log('update old_dom(%s)', o.nodeName);
      console.dir(o.dom);
      console.log('-----------\n');


      if (dom.tagName != null) {
        // 標籤 old_dom
        $attrsUpdate.update(o, n);
      } else {
        // 非標籤 old_dom
        $domApi.setTextContent(dom, n.text);
      }
      n.setDom(dom);

      this.destroyVnodeList.push(o);
    }
  }
  //-----------------------------------------------------
  aboutKeepAlive(list = []) {
    // 更新 this.keepAliveMap


  }
  //-----------------------------------------------------
  aboutDiffNodes(list = []) {

    while (list.length) {

      let { o, n = null, p = null } = list.shift();

      if (o != null) {
        this.destroyVnodeList.push(o);
      }

      if (n != null) {
        debugger;
        // 建立一棵新的 domThree
        let dom_new = this._createElm(n);

        if (dom_new != null) {
          let index = n.index;
          let dom_next = this._getDomChildByIndex(p, index);
          $domApi.insertBefore(p, dom_new, dom_next);
        }
      }
    } // endWhile
  }
  //-----------------------------------------------------
  removeChildVnodes() {
    // debugger;

    destroyVnodeList = this.destroyVnodeList;

    function job() {

      destroyVnodeList.forEach((node) => {

        const vnodeList = [node];

        let index = 0;

        while (true) {
          // debugger;
          let i = index++;

          let vnode = vnodeList[i];
          if (vnode == null) {
            break;
          }
          let childs = vnode.childs.slice();

          // destroy vnode 
          vnode.destroy();

          while (childs.length) {
            let c = childs.shift();
            vnodeList.push(c);
          }
        }
      });

      destroyVnodeList.length = 0;

    } // endJob


    $util.nextStep(job);
  }
  //-----------------------------------------------------
  _createElm(rootVnode) {
    // debugger;

    if (rootVnode == null) {
      return null;
    }

    const $attrsUpdate = $GM.get('attrsUpdate');

    // 要處理的列表
    let tempList = [rootVnode];
    let parentMap = {};

    let new_dom;

    let i = 0;
    //-----------------------
    while (true) {
      // debugger;

      let vnode = tempList[i];
      if (vnode == null) {
        break;
      }
      let nodeName = vnode.nodeName;

      if (vnode.tagName == null) {
        // 不是 tag  

        new_dom = this._createDom(null, nodeName, vnode.text);
        vnode.setDom(new_dom);

        console.log('create new_dom(%s)', new_dom.nodeName);

        if (i in parentMap) {
          let parent_dom = parentMap[i];
          delete parentMap[i];
          $domApi.appendChild(parent_dom, new_dom);
        }

      } else {
        // tag
        new_dom = this._createDom(vnode.tagName);
        vnode.setDom(new_dom);

        console.log('create new_dom(%s)', new_dom.nodeName);

        // 處理 attrs
        $attrsUpdate.create(vnode);

        if (i in parentMap) {
          let parent_dom = parentMap[i];
          delete parentMap[i];
          $domApi.appendChild(parent_dom, new_dom);
        }

        let childList = vnode.childs;
        if (!Array.isArray(childList)) {
          return;
        }

        childList.forEach((vnode) => {
          let j = tempList.length;
          tempList.push(vnode);
          parentMap[j] = new_dom;
        });

      } // endif

      i++;
    } // end while

    return rootVnode.dom;
  }
  //-----------------------------------------------------
  _createDom(tagName, nodeName, text) {
    let dom;

    if (tagName == null) {
      switch (nodeName) {
        case '#comment':
          dom = $domApi.createComment(text);
          break;
        case '#text':
          dom = $domApi.createTextNode(text);
          break;
        default:
          console.dir(vnode);
          throw new Error(`no deal with this domType(${nodeName})`);
          break;
      }
    } else {
      dom = $domApi.createElement(tagName);
    }
    return dom;
  }
  //-----------------------------------------------------
  // 試圖匹配相同的 child
  // 只移動 oldVnode.childs
  matchChilds(oldvnode, vnode) {
    debugger;

    const parentDom = oldvnode.dom;

    let o_list = oldvnode.childs;
    o_list = o_list.slice();
    let n_list = vnode.childs;
    // let o_length = o_list.length;
    let n_length = n_list.length;
    // let length = (o_length > n_length ? o_length : n_length);

    oldvnode.clearChilds();

    let matchList = Array(n_length).fill(null);

    let i = 0;

    // hasMatch.size == o_length (oldVnode.childs 都被配對完了
    while (i < n_length) {
      debugger;

      let j = i++;
      let n = n_list[j];
      //-----------------------
      // needFindMatch

      let findIndex = _findTarget(n, o_list);

      if (findIndex != null) {
        let o = o_list[findIndex];

        matchList[j] = o;

        // 這個位置已被標走
        o_list[findIndex] = null;
      }

      if (findIndex != j) {
        // dom 先脫鉤，以後要移至他位
        let dom = o.dom;
        $domApi.detach(dom);
      }

    } // endWhile
    //------------------
    o_list.forEach((node) => {
      // 剩下沒匹配的 

      if (node == null) {
        return;
      }
      let dom = node.dom;
      $domApi.detach(dom);

      this.destroyVnodeList.push(o);
    });
    //------------------
    // 需要往下探索
    let childList = matchList.map((match, i) => {
      let sameType = (match == null ? false : true);

      return {
        o: match,
        n: (n_list[i]),
        p: parentDom,
        sameType,
      };
    });

    return childList;
  }
  //-----------------------------------------------------
  // 在 list 中找尋
  // 搜尋策略
  _findTarget(vnode, list) {
    debugger;

    // 找尋 sameType, childs.length 相同
    // 找尋 sameType

    let find = null;

    list.some((oldVnode, i) => {
      debugger;

      if (oldVnode == null) {
        // 已經被人取走
        return;
      }
      //------------------
      if (vnode.is_static != oldVnode.is_static) {
        // import
        // static 的立意
        return;
      }

      let sameType = this._is_sameTypeVnode(vnode, oldVnode);
      if (sameType) {
        find = find || { index: i };
      } else {
        return;
      }
      //------------------
      if (vnode.childs.length == oldVnode.childs.length) {
        // 兩個子結構數量相同
        // 猜測有很大可能有相同的結構
        // 再細談索下去會耗費時間
        find = { index: i };
        return true;
      }
    }); // endSome

    return find;

  }

  _getDomChildByIndex(p_dom, index) {
    let list = Array.from(p_dom.childNodes);

    if (index >= list.length) {
      return null;
    }

    return list[index];
  }
}

export default ModifyDom;

