'use strict';

// 根據 vnode 建構 old_dom
import $GM from '../g_module.js';

const $reg_1 = /^template$/i;

class ModifyDom {

  // manager
  manager = {
    c: null,
    p: null,
  };

  module;

  travelList = [];
  dom_container;

  keeps = {};
  keepAlls = {};

  rootVnode = {
    o: null,
    n: null
  };

  keepAllList = [];

  // 影響 vnode。search 的策略
  isManagerDiff = false;

  destroyVnodeList = [];
  //----------------------------------------------------------------------------
  constructor(preManager, manager) {
    this.manager.p = preManager;
    this.manager.c = manager;

    try {
      if (preManager.id == manager.id) {
        this.isManagerDiff = false;
      }
    } catch (e) {
      this.isManagerDiff = true;
    }

    this.module = new Proxy({}, {
      set() {
        return false;
      },
      get(o, key) {
        if (!$GM.has(key)) {
          throw new Error(`no this module(${key})`);
        }
        return $GM.get(key);
      }
    });
  }
  //----------------------------------------------------------------------------
  // start here
  patch(oldVnode, vnode, parentDom) {

    const {
      c: manager,
      p: p_manager
    } = this.manager;
    // 初始化

    this.dom_container = parentDom;
    //------------------

    this._aboutRootNode(oldVnode, vnode);

    this._travelAllVnode();

    const Vnode = this.module['Vnode'];
    Vnode.linkDom(parentDom, vnode);

    // 要檢查 keeps, keepAlls
    // this._checkPreManagerKeepNodes();

  }
  //-----------------------------------------------------
  // rootVnode 是空節點
  _aboutRootNode(oldVnode, vnode) {
    debugger;

    this.rootVnode['o'] = oldVnode;
    this.rootVnode['n'] = vnode;

    if (oldVnode == null || !oldVnode.childs.length) {
      if (this.dom_container.childNodes.length) {
        this.dom_container.innerHTML = '';
      }
    }

    let list = this._matchChilds(oldVnode, vnode, this.dom_container);

    this.travelList = this.travelList.concat(list);
  }
  //-----------------------------------------------------
  // 片歷所有樹節點
  _travelAllVnode() {
    debugger;

    const $domApi = this.module['domApi'];

    // dom 不用任何改變
    const staticNodeList = [];

    // dom 需進行 attr 變化
    const sameTypeNodeList = [];

    const diffNodeList = [];

    let travelList = this.travelList;
    //-----------------------
    let index = 0;

    while (true) {
      debugger;

      let i = index++;
      let data = travelList[i];
      if (data == null) {
        break;
      }
      //------------------
      let { o, n, sameType, p } = data;

      debugger;
      if (sameType) {
        console.log('sameTypeNode');
        //------------------
        const judge_1 = this._isStaticVnode(o, n);

        if (judge_1) {
          // static vnode
          console.log('static');
          staticNodeList.push({ o, n });

        } else {
          // not static
          // sameType

          console.log('not static');
          sameTypeNodeList.push({ o, n });

        }
      } else {

        console.log('diff node');

        if (o != null) {
          dom = o.dom;
          $domApi.detach(dom);
        }
        diffNodeList.push({ n, p });
        continue;
      }
      //----------------------------
      // childs
      // 並試圖匹配相同的 child
      let list = this._matchChilds(o, n);

      debugger;
      if (list.length) {
        travelList = travelList.concat(list);
      }

    } // endWhile

    //-----------------------
    debugger;
    this.$aboutDiffNodes(diffNodeList);

    this.$aboutSameTypeNodes(sameTypeNodeList);

    this.$aboutStaticNodes(staticNodeList);

    // 順序不能變
    this.$aboutKeepAllList(this.keepAllList);

    this._removeOldVnodes();
  }
  //----------------------------------------------------------------------------
  // 位置固定的節點
  $aboutStaticNodes(list = []) {
    debugger;

    while (list.length) {
      let { o, n } = list.shift();

      let dom = o.dom;
      let parentDom = dom.parentNode;

      // 與 vnode 對應的 dom 的位置可能不對
      // 處理 dom 的位置
      fixDomPosition(parentDom, dom, n);

      if (n.tagName != null) {
        // 若是 tag

        // 若有計算 attr
        // 必須檢查 attr，並轉移
        this._updateDomAttr(dom, o, n, true);
      }

      let old = n.linkDom(dom);

      this._destroyVnode(old);
    }
  }
  //----------------------------------------------------------------------------
  $aboutSameTypeNodes(list) {
    debugger;


    const $domApi = this.module['domApi'];

    while (list.length) {
      let { o, n } = list.shift();
      let dom = o.dom;

      console.log('-----------\n');
      console.log('update old_dom(%s)', o.nodeName);
      console.dir(o.dom);
      console.log('-----------\n');

      let parentDom = dom.parentNode;

      // 與 vnode 對應的 dom 的位置可能不對
      // 處理 dom 的位置
      fixDomPosition(parentDom, dom, n);
      //-------------
      debugger;

      if (dom.tagName != null) {
        // 標籤 old_dom

        // 某些 dom.prop 必須重置
        // 譬如 input.value
        // resetDomProps(dom);

        this._updateDomAttr(dom, o, n, false);

      } else {
        // 非標籤 old_dom
        $domApi.setTextContent(dom, n.text);
      }
      //-------------
      let old = n.linkDom(dom);

      this._destroyVnode(old);
    }
  }
  //----------------------------------------------------------------------------
  $aboutDiffNodes(list = []) {
    debugger;

    const $domApi = this.module['domApi'];

    while (list.length) {
      debugger;

      let data = list.shift();
      const { n, p } = data;

      debugger;

      // 建立一棵新的 domThree
      this._createDomTree(n);

      debugger;

      let dom_new = n.dom;
      let index = n.index;

      let dom_next = p.childNodes[index] || null;

      if (dom_next != null && isTemplateTag(dom_next)) {
        // 遇到佔位用的 <template>
        $domApi.replaceChild(p, dom_new, dom_next);
      } else {
        $domApi.insertBefore(p, dom_new, dom_next);
      }
    } // endWhile
  }

  //----------------------------------------------------------------------------
  // 創建新的節點樹
  _createDomTree(rootVnode) {
    debugger;

    const $domApi = this.module['domApi'];

    // 要處理的列表
    let tempList = [];
    tempList.push({ n: rootVnode, p: null });

    let i = 0;
    //-----------------------
    while (true) {
      debugger;

      let new_dom;
      let j = i++;

      let data = tempList[j];
      if (data == null) {
        break;
      }
      const { n: vnode, p: parentVnode } = data;

      let nodeName = vnode.nodeName;
      let oldVnode;
      //-----------------------

      if (vnode.tagName == null) {
        // not tag
        // not tag
        // not tag

        new_dom = this._createDom(null, nodeName, vnode.text);
        oldVnode = vnode.linkDom(new_dom);

        console.log('create new_dom(%s)', new_dom.nodeName);

        if (parentVnode) {
          let parentDom = parentVnode.dom;
          $domApi.appendChild(parentDom, new_dom);
        }

      } else {
        // tag
        // tag
        // tag

        debugger;

        if (vnode.keepAll != null) {
          // keepAll

          let _oldVnode = this._findKeepAll(vnode);
          if (_oldVnode) {

            this.KeepAllList.push({ o: _oldVnode, n: vnode, p: parentVnode });
            continue;
          }
        } else if (vnode.keep != null) {
          // keep

          new_dom = this._findKeep(n);

          if (new_dom) {
            this._updateDomAttr(new_dom, null, vnode, true);

            console.log('create new_dom(%s) but find keep', new_dom.nodeName);

          } else {
            console.log('no find keep');
          }
        }
        //------------------
        if (new_dom == null) {
          new_dom = this._createDom(vnode.tagName);
          this._initDomAttr(new_dom, vnode);

          console.log('create new_dom(%s)', new_dom.nodeName);
        }

        oldVnode = vnode.linkDom(new_dom);

        if (parentVnode) {
          let parentDom = parentVnode.dom;
          $domApi.appendChild(parentDom, new_dom);
        }
        //----------------------------
        // child

        let childList = vnode.childs;
        if (!Array.isArray(childList)) {
          return;
        }

        childList.forEach((node) => {
          tempList.push({ n: node, p: vnode });
        });

      } // endif
      //------------------

      this._destroyVnode(oldVnode);

    } // end while


    return rootVnode.dom;
  }
  //----------------------------------------------------------------------------
  $aboutKeepAllList(list = []) {
    // 更新 this.keepAliveMap

    const $domApi = this.module['domApi'];

    while (list.length) {
      debugger;
      let data = list.shift();

      const { o, n, p } = data;

      this._checkKeepAllTree(data);
      //------------------

      if (p) {
        let parentDom = p.dom;
        let index = n.index;
        let dom = n.dom;

        let targetDom = parentDom.childNodes[index] || null;

        $domApi.insertBefore(parentDom, dom, targetDom);
      }

    } // endWhile
  }
  //-----------------------------------------------------
  _checkKeepAllTree(data) {
    debugger;

    const { o, n } = data;

    let tList = [];
    tList.push({ o, n });

    let index = 0;

    while (true) {
      let data = tList[index++];
      if (data == null) {
        break;
      }

      let { o, n } = data;

      let dom = o.dom;

      // 重點
      this._updateDomAttr(dom, o, n, true);
      n.linkDom(dom);

      this._destroyVnode(o);

      oldNode.childs.forEach((o, i) => {
        let _n = n.childs[i];
        tList.push({ o, n: _n });
      });
    }
  }
  //----------------------------------------------------------------------------
  // 銷毀無用的 vnode
  _removeOldVnodes() {
    debugger;

    return;

    const destroyVnodeList = this.destroyVnodeList;

    function job() {

      destroyVnodeList.forEach((node) => {

        const vnodeList = [node];

        let index = 0;

        while (true) {
          // debugger;
          let i = index++;

          let vnode = vnodeList[i];
          if (vnode == null) {
            break;
          }
          let childs = vnode.childs.slice();

          // destroy vnode
          vnode.destroy();

          while (childs.length) {
            let c = childs.shift();
            vnodeList.push(c);
          }
        }
      });

      destroyVnodeList.length = 0;
    } // endJob


    $util.nextStep(job);
  }
  //----------------------------------------------------------------------------
  _createDom(tagName, nodeName, text) {
    const $domApi = this.module['domApi'];

    let dom;

    if (tagName == null) {
      switch (nodeName) {
        case '#comment':
          dom = $domApi.createComment(text);
          break;
        case '#text':
          dom = $domApi.createTextNode(text);
          break;
        default:
          console.dir(vnode);
          throw new Error(`no deal with this domType(${nodeName})`);
          break;
      }
    } else {
      dom = $domApi.createElement(tagName);
    }
    return dom;
  }
  //----------------------------------------------------------------------------
  // important
  // 試圖匹配相同的 child
  // 只移動 oldVnode.childs
  _matchChilds(oldvnode, vnode, parentDom) {
    debugger;

    parentDom = parentDom || oldvnode.dom || null;

    if (parentDom == null) {
      throw new Error('...');
    }

    let o_list = oldvnode.childs;
    let n_list = vnode.childs;
    let n_length = n_list.length;

    //-----------------------
    // 先過濾出 vnode.static, vnode.no_static

    let matchList = Array(n_length).fill(null);
    let searchList = o_list.map(n => {
      return {
        node: n
      };
    });

    // oldvnode.clearChilds();
    //-----------------------

    let i = 0;

    while (i < n_length) {
      // debugger;

      let j = i++;
      let n = n_list[j];

      if (n.keepAll != null) {
        // 重要
        continue;
      }

      // 找可配對的 vnode
      let findMatchNode = this._findTarget(n, searchList);

      if (findMatchNode != null) {
        matchList[j] = findMatchNode;
      }

    } // endWhile
    //----------------------------
    // 處理剩下沒匹配的

    searchList.forEach(d => {
      let {
        node
      } = d;

      if (node == null) {
        // 已經被匹配走了
        return;
      }
      let dom = node.dom;
      $domApi.detach(dom);

      this._destroyVnode(node);
    });
    //------------------
    // 需要往下探索
    let childList = matchList.map((match, i) => {
      let sameType = (match == null ? false : true);
      let node = n_list[i];

      return {
        o: match,
        n: node,
        sameType,
        p: parentDom,
      };
    });

    return childList;
  }
  //----------------------------------------------------------------------------
  _findTarget(vnode, searchList) {
    let node;

    if (this.isManagerDiff) {
      // 當 vfactory 不同
      node = this._findTarget_1(vnode, searchList);
    } else {
      // 當 vfactory 相同
      node = this._findTarget_2(vnode, searchList);
    }
    return node;
  }
  //----------------------------------------------------------------------------

  // 搜尋策略
  // 當 vfactory 不同
  _findTarget_1(vnode, searchList) {
    // debugger;

    let find = null;
    let findIndex = null;

    searchList.some((d, i) => {
      debugger;

      let { node: targetNode } = d;

      if (targetNode == null) {
        // 已經被人取走
        return;
      }
      //------------------
      let sameType = is_sameTypeVnode(targetNode, vnode, this.isManagerDiff);
      if (sameType) {
        findIndex = i;
        return true;
      }
    }); // endSome
    //------------------   
    debugger;

    if (findIndex != null) {
      find = (searchList[findIndex]).node;
      // 標記已被指定
      (searchList[findIndex]).node = null;
    }

    return find;
  }
  //----------------------------------------------------------------------------
  // 當 vfactory 相同
  _findTarget_2(vnode, searchList) {
    debugger;

    let find = null;
    let findIndex = null;

    if (vnode.isStatic) {
      // 靜態的搜尋方法
      searchList.some((d, i) => {
        debugger;

        let { node: targetNode } = d;
        if (targetNode == null) {
          // 已經被人取走
          return;
        }

        let sameType = advanCompareChilds_2(targetNode, vnode);

        if (sameType) {
          findIndex = i;
          return true;
        }
      });

      if (findIndex == null) {
        // 理論不會找不到
        throw new Error('......');
      }

    } else {
      // 匹配動態節點
      searchList.some((d, i) => {
        debugger;

        let { node: targetNode } = d;
        if (targetNode == null) {
          // 已經被人取走
          return;
        }

        // 第一個匹配條件
        let sameType = is_sameTypeVnode(targetNode, vnode, this.isManagerDiff);
        if (sameType) {
          findIndex = (findIndex != null ? findIndex : i);
        } else {
          return;
        }
        //------------------
        // 第二個匹配條件
        if (vnode.tagName == null) {
          return true;
        }


        if (advanCompareChilds_1(targetNode, vnode)) {
          findIndex = i;
          return true;
        }

      });
    }
    //------------------
    debugger;
    if (findIndex != null) {
      find = (searchList[findIndex]).node;
      // 標記已被指定
      (searchList[findIndex]).node = null;
    }

    return find;
  }
  //----------------------------------------------------------------------------
  // 找 keep, keepAll 之前是否有 cache
  _findKeep(node) {
    // this._updateKeepNode(node);

    const manager = this.manager.c;

    let name = node.keep;
    let dom = manager.getKeep(name);

    return dom;
  }
  //----------------------------------------------------------------------------
  _findKeepAll(node) {
    // this._updateKeepNode(node);

    let manager = this.manager.c;

    let name = node.keepAll;
    let find = manager.getKeepAll(name) || null;

    if (find) {
      let dom = find.dom;
      if (dom.parentNode != null) {
        dom.parentNode.removeChild(dom);
      }
      find.parent = null;
    }

    return find;
  }
  //----------------------------------------------------------------------------
  // 更新 keep 記錄
  _updateKeepNode(node) {
    let isAll = (node.keep == null ? true : false);
    let name;

    if (isAll) {
      name = node.keepAll;
      this.keepAlls[name] = node;
    } else {
      name = node.keep;
      this.keeps[name] = node;
    }
  }
  //----------------------------------------------------------------------------
  // 注意這邊
  // 確定前 manager.keeps keepAlls 的狀態
  _checkPreManagerKeepNodes() {
    // 斷去沒用到的 keep, keepAll
    let list = [this.preManager, this.manager];
    list.forEach(m => {
      if (m == null) {
        return;
      }

      let a = m.getKeep();
      let b = m.getKeepAll();
      let nodeMap = Object.assign({}, a, b);

      for (let k in nodeMap) {
        let vnode = nodeMap[k];
        let dom = vnode.dom;

        debugger;
        // 斷去 vnode, dom 連接
        if (vnode.parent == null) {
          continue;
        }

        if (this.dom_container.contains(dom)) {
          // dom 還在線上
          continue;
        }
        // 解除 dom, vnode 的連接
        vnode.parent.removeChild(vnode);
      }
    })
    //-----------------------
    // 更新有用到的 keep, keepAll
    if (this.manager != null) {
      let m = this.manager;
      // 更新 keep, keepAll
      for (let k in this.keeps) {
        m.setKeep(k, this.keeps[k]);
      }
      for (let k in this.keepAlls) {
        m.setKeepAll(k, this.keepAlls[k]);
      }
    }
  }
  //----------------------------------------------------------------------------
  _destroyVnode(vnode) {
    if (vnode == null) {
      return;
    }
    this.destroyVnodeList.push(vnode);
  }
  //----------------------------------------------------------------------------
  _isStaticVnode(oldNode, vnode) {

    const $domApi = this.module['domApi'];
    const dom = oldNode.dom;

    if (this.isManagerDiff) {
      // 當 vfactory 不同後
      // 全部的節點都不是靜態結構
      return false;
    }
    let isStatic = vnode.isStatic;
    //------------------
    // keep
    if (vnode.keep != null) {
      let keepDom = this._findKeep(vnode);

      if (keepDom == null) {
        isStatic = false;
      } else {
        isStatic = true;

        // 把 dom 轉移成 keepDom

        Array.from(dom.childNodes).forEach(d => {
          // 轉移子節點
          $domApi.appendChild(keepDom, d);
        });
        $domApi.replaceChild(dom.parentNode, keepDom, dom);

        oldNode.linkDom(keepDom);
      }
    }
    //------------------
    if (!isStatic) {
      return false;
    }

    return true;
  }

  //----------------------------------------------------------------------------
  _initDomAttr(dom, vnode) {
    const $attr = this.module['attr'];

    // 找出特殊的 attr 如 select.value
    // 過濾出 events
    $attr.initDom(dom, vnode);
  }

  _updateDomAttr(dom, o, n, isSameDom) {
    const $attr = this.module['attr'];

    // 找出特殊的 attr 如 select.value
    // 過濾出 events
    $attr.updateDom(dom, o, n, isSameDom);
  }
}

export default ModifyDom;

////////////////////////////////////////////////////////////////////////////////

function isTemplateTag(dom) {

  if (dom == null) {
    return false;
  }

  if (dom.tagName != null && !$reg_1.test(dom.tagName)) {
    return false;
  }

  return true;
}
//------------------------------------------------------------------------------
// 非常重要的規則
// 找尋相似度高的兩 vnode
// 比較兩個 vnode 性質是否相同
function is_sameTypeVnode(o, n, isManagerDiff) {
  // debugger;

  const dom = o.dom;

  if (is_specDom(n, dom)) {
    // 有些 dom 不要採用 dom 置換
    return false;
  }

  const o_attrs = o.attrs;
  const n_attrs = n.attrs;

  if (n == null) {
    return false;
  }

  if (!isManagerDiff) {
    // static
    if (o.isStatic != n.isStatic) {
      return false;
    }
  }
  //----------------------------
  // keep, keepAll
  if (o.keep != null) {
    // return false;
  }

  if (o.keepAll != null) {
    return false;
  }
  //----------------------------
  // 比較 nodeName
  if (o.nodeName !== n.nodeName) {
    return false;
  }
  //----------------------------
  // id
  if (!isManagerDiff) {
    let o_id = o_attrs.has('id') ? o_attrs.get('id') : null;
    let n_id = n_attrs.has('id') ? n_attrs.get('id') : null;

    // 比較 old_dom.id
    if (o_id !== n_id) {
      return false;
    }
  }
  //----------------------------
  return true;
}
//------------------------------------------------------------------------------
// dom 已經在 domTree 上
// 但位置可能不對，需校正
function fixDomPosition(parentDom, dom, vnode) {
  const $domApi = $GM.get('domApi');

  if (dom.parentNode == null) {
    // keep, keepAll
    if (vnode.keep == null && vnode.keepAll == null) {
      console.dir(vnode);
      throw new Error('dom no parent');
    }
  }

  let index = vnode.index;
  let childList = parentDom.childNodes;
  let j = childList.length;

  //------------------
  if (childList[index] === dom) {
    return;
  }

  if (index >= j) {
    for (let i = j; i <= index; i++) {
      // 先用 <template> 佔位
      let dom_temp = document.createElement('template');
      $domApi.appendChild(parentDom, dom_temp);
    }
  }

  $domApi.removeChild(parentDom, dom);
  let dom_target = childList[index] || null;

  $domApi.insertBefore(parentDom, dom, dom_target);

}
//------------------------------------------------------------------------------
// 動態節點進階比對方式
function advanCompareChilds_1(o, n) {
  debugger;

  let list_1 = o.childs
  let list_2 = n.childs;
  if (list_1.length != list_2.length) {
    return false;
  }
  return true;
}
//------------------------------------------------------------------------------
// 靜態節點的比對
function advanCompareChilds_2(o, n) {
  debugger;

  if (o.isStatic != n.isStatic) {
    return false;
  }

  if (o.factoryId != n.factoryId) {
    return false;
  }

  if (o.staticIndex != n.staticIndex) {
    return false;
  }

  if (o.level != n.level) {
    return false;
  }

  return true;
}
//------------------------------------------------------------------------------
// 當要置換相同類型 dom 時要注意的事項
// 譬如 <input>
function resetDomProps(dom) {
  let tagName = dom.tagName || '';
  tagName = tagName.toLowerCase();

  switch (tagName) {
    case 'input':
      dom.value = null;
      break;
    default:
      break;
  }
}