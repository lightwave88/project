import $GM from '../g_module.js';
import api from './htmldomapi.js';

const $modifyDom = {
  patch
};

export default $modifyDom;
//------------------------------------------------------------------------------
function patch(oldVnode, vnode, parentDom) {
  debugger;
  const Vnode = $GM.get('Vnode');

  let dom_root;

  let judg_1 = (oldVnode == null || !(oldVnode instanceof Vnode));


  if (false && !judg_1 && sameVnode(oldVnode, vnode)) {
    // 若兩個 vnode 性質相同
    // 不用重建 vnode，只要轉移 attr
    dom_root = oldVnode;

  } else {
    // 兩個 vnode 性質差太多
    // dom 必須重建

    if (judg_1) {
      // 製造一個空的 vnode
      oldVnode = emptyVnode();
    }

    let dom = oldVnode.dom || null;
    let dom_next;

    if (dom != null) {
      parentDom = dom.parentNode;
      dom_next = dom.nextSibling;
    }

    let new_dom = createElm(vnode);
    dom_root = new_dom;

    if (dom != null) {
      // 移除舊有的 domTree
      removeChildDoms(dom);
    }

    if (dom_next != null) {
      api.insertBefore(dom_parent, new_dom, dom_next);
    } else {
      api.appendChild(parentDom, new_dom);
    }
  }
  return dom_root;
}
//------------------------------------------------------------------------------
function createElm(rootVnode) {

  if (rootVnode == null) {
    return null;
  }
  // 要處理的列表
  let tempList = [rootVnode];
  let parentMap = {};

  let dom;

  let i = 0;
  //-----------------------
  while (true) {
    // debugger;

    let vnode = tempList[i];
    if (vnode == null) {
      break;
    }
    let nodeName = vnode.nodeName;

    if (vnode.tagName == null) {
      // 不是 tag
      let text = vnode.text;

      switch (nodeName) {
        case '#comment':
          dom = api.createComment(text);
          break;
        case '#text':
          dom = api.createTextNode(text);
          break;
        default:
          throw new Error(`no deal with this domType(${nodeName})`);
          break;
      }
      vnode.setDom(dom);

      if (i in parentMap) {
        let parent_dom = parentMap[i];
        delete parentMap[i];
        api.appendChild(parent_dom, dom);
      }

    } else {
      // tag
      dom = api.createElement(vnode.tagName);
      vnode.setDom(dom);

      if (i in parentMap) {
        let parent_dom = parentMap[i];
        delete parentMap[i];
        api.appendChild(parent_dom, dom);
      }

      let childList = vnode.childs;
      if (!Array.isArray(childList)) {
        return;
      }

      childList.forEach((vnode) => {
        let j = tempList.length;
        tempList.push(vnode);
        parentMap[j] = dom;
      });

    } // endif

    i++;
  } // end while

  return rootVnode.dom;
}
//------------------------------------------------------------------------------
// 若新的 vnode 與 oldVnode 是同類型
// 只要轉移 attr 資料，不用重建 dom
function patchNode(oldVnode, vnode) {
  if (oldVnode === vnode) {
    return;
  }

  let oldCh = oldVnode.childs;
  let ch = vnode.childs;

  // 資料轉換


  
  //------------------
  if(oldCh.length > 0 && ch.length > 0){

  }else if(!oldCh.length && ch.length > 0){

  }else if(oldCh.length > 0 && !ch.length){

  }else{

  }

}

//------------------------------------------------------------------------------

function emptyVnode() {
  const Vnode = $GM.get('Vnode');
  return Vnode.getInstance();
}
//------------------------------------------------------------------------------
// 比較兩個 vnode 性質是否相同
function sameVnode(a, b) {
  const a_attrs = a.attrs;
  const b_attrs = b.attrs;

  // dom.type 不同就視爲不同
  // dom 必須重建 不然可能有問題
  // <input> 尤其嚴重
  a_type = (a_attrs.has('type') ? a_attrs.get('type') : null);
  b_type = (b_attrs.has('type') ? b_attrs.get('type') : null);

  if (a_type !== b_type) {
    return false;
  }
  // 比較 nodeName
  if (a.nodeName !== b.nodeName) {
    return false;
  }

  // 比較 dom.id
  if (a.id !== b.id) {
    return false;
  }

  // 比較 dom.class
  if (a.classList.length != b.classList.length) {
    return false;
  }

  if (a.classString != b.classString) {
    return false;
  }

  return true;
}
//------------------------------------------------------------------------------
// 移除 dom 並清除以下的 vnode
// 釋放不用的記憶體
function removeChildDoms(dom = []) {
  const Vnode = $GM.get('Vnode');
  const $util = $GM.get('util');

  let tempList = Array.isArray(dom) ? dom : [dom];

  let root_length = tempList.length;

  let index = 0;
  while (true) {
    debugger;

    let dom = tempList[index];

    // console.dir(dom);

    if (dom == null) {
      break;
    }
    let dom_childs = Array.from(dom.childNodes);

    if (index < root_length) {
      // 只需對最上層作 dom 移除
      let parentDom = dom.parentNode;
      api.removeChild(parentDom, dom);
    }
    //-----------------------
    let vnode = Vnode.getVnodeByDom(dom);

    if (vnode != null) {

      // 釋放記憶體
      // vnode.clear();
      $util.next(() => {
        //   debugger;
        vnode.clear();
      });
    }
    //-----------------------
    dom_childs.forEach((child) => {
      tempList.push(child);
    });

    index++;
  }
}