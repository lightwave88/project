import $GM from '../g_module.js';
import api from './htmldomapi.js';

const $modifyDom = {
  patch
};

export default $modifyDom;
//------------------------------------------------------------------------------
function patch(oldVnode, vnode, parentDom) {
  debugger;
  const Vnode = $GM.get('Vnode');

  let dom_root;

  if (Vnode.is_vnode(oldVnode)) {
    // 製造一個空的 vnode
    oldVnode = emptyVnode();
  }

  if (Vnode.is_vnode(vnode)) {
    // 製造一個空的 vnode
    vnode = emptyVnode();
  }
  //------------------
  if (sameVnode(oldVnode, vnode)) {
    // 若兩個 vnode 性質相同
    // 不用重建 vnode，只要轉移 attr

    dom_root = patchNode(oldVnode, vnode);
  } else {
    // 兩個 vnode 性質差太多
    // dom 必須重建    

    let dom = oldVnode.dom || null;
    let dom_next;

    if (dom != null) {
      parentDom = dom.parentNode;
      dom_next = dom.nextSibling || null;
    }

    let new_dom = createElm(vnode);
    dom_root = new_dom;

    // 移除舊有的 domTree
    removeChildDoms(dom);

    if (new_dom != null) {
      api.insertBefore(parentDom, new_dom, dom_next);
    }
  }
  return dom_root;
}
//------------------------------------------------------------------------------
function createElm(rootVnode) {

  if (rootVnode == null) {
    return null;
  }

  const $attrsUpdate = $GM.get('attrsUpdate');

  // 要處理的列表
  let tempList = [rootVnode];
  let parentMap = {};

  let dom;

  let i = 0;
  //-----------------------
  while (true) {
    // debugger;

    let vnode = tempList[i];
    if (vnode == null) {
      break;
    }
    let nodeName = vnode.nodeName;

    if (vnode.tagName == null) {
      // 不是 tag
      let text = vnode.text;

      switch (nodeName) {
        case '#comment':
          dom = api.createComment(text);
          break;
        case '#text':
          dom = api.createTextNode(text);
          break;
        default:
          throw new Error(`no deal with this domType(${nodeName})`);
          break;
      }
      vnode.setDom(dom);

      if (i in parentMap) {
        let parent_dom = parentMap[i];
        delete parentMap[i];
        api.appendChild(parent_dom, dom);
      }

    } else {
      // tag
      dom = api.createElement(vnode.tagName);
      vnode.setDom(dom);

      // 處理 attrs
      $attrsUpdate.create(vnode);

      if (i in parentMap) {
        let parent_dom = parentMap[i];
        delete parentMap[i];
        api.appendChild(parent_dom, dom);
      }

      let childList = vnode.childs;
      if (!Array.isArray(childList)) {
        return;
      }

      childList.forEach((vnode) => {
        let j = tempList.length;
        tempList.push(vnode);
        parentMap[j] = dom;
      });

    } // endif

    i++;
  } // end while

  return rootVnode.dom;
}
//------------------------------------------------------------------------------

function patchNode(oldVnode, vnode) {

  if (oldVnode.nodeName == null) {
    // 兩個是空節點，不能相互轉換
    return null;
  }

  if (oldVnode === vnode) {
    return vnode.dom;
  }

  let old_clist = oldVnode.childs;
  let clist = vnode.childs;


  let index = 0;

  while (true) {
    let i = index++;

    while (old_clist.length <= clist.length) {
      let node = old_clist.pop();
      
    }


    if (clist[i] == null) {
      break;
    }

    let oldNode = old_clist[i] || null;
    let node = clist[i];

    if (sameVnode()) {

    }

  }




  let oldCh = oldVnode.childs;
  let ch = vnode.childs;

  // 資料轉換



}


// 若新的 vnode 與 oldVnode 是同類型
// 只要轉移 attr 資料，不用重建 dom
function _patchNode(oldVnode, vnode) {

  if (oldVnode.nodeName == null) {
    // 兩個是空節點，不能相互轉換
  }

  if (oldVnode === vnode) {
    return;
  }

  let oldCh = oldVnode.childs;
  let ch = vnode.childs;

  // 資料轉換



  //------------------
  if (oldCh.length > 0 && ch.length > 0) {

  } else if (!oldCh.length && ch.length > 0) {

  } else if (oldCh.length > 0 && !ch.length) {

  } else {

  }

}

//------------------------------------------------------------------------------

function emptyVnode() {
  const Vnode = $GM.get('Vnode');
  return Vnode.getInstance();
}
//------------------------------------------------------------------------------
// 比較兩個 vnode 性質是否相同
function sameVnode(a, b) {
  debugger;

  const a_attrs = a.attrs;
  const b_attrs = b.attrs;

  // dom.type 不同就視爲不同
  // dom 必須重建 不然可能有問題
  // <input> 尤其嚴重
  a_type = (a_attrs.has('type') ? a_attrs.get('type') : null);
  b_type = (b_attrs.has('type') ? b_attrs.get('type') : null);

  if (a_type !== b_type) {
    return false;
  }
  // 比較 nodeName
  if (a.nodeName !== b.nodeName) {
    return false;
  }

  // 比較 dom.id
  if (a.id !== b.id) {
    return false;
  }

  // 比較 dom.class
  if (a.classList.length != b.classList.length) {
    return false;
  }

  if (a.classString != b.classString) {
    return false;
  }

  return true;
}
//------------------------------------------------------------------------------
// 移除 dom 並清除以下的 vnode
// 釋放不用的記憶體
function removeChildDoms(dom = []) {
  const Vnode = $GM.get('Vnode');
  const $util = $GM.get('util');

  if (dom == null) {
    return;
  }

  if (!Array.isArray(dom)) {
    dom = [dom];
  }

  let tempList = dom.map((d) => {
    if (d == null) {
      return;
    }

    let vnode = Vnode.getVnodeByDom(d);
    let parent = d.parentNode;
    if (parent) {
      parent.remove(d);
    }
    return vnode;
  });

  tempList = tempList.filter((v) => {
    return (v != null);
  });

  if (!tempList.length) {
    return;
  }

  $util.nextStep(callback);

  // 延時任務
  function callback() {
    let index = 0;
    while (true) {
      debugger;
      let i = index++;

      let vnode = tempList[i];
      if (vnode == null) {
        break;
      }
      // destroy vnode 
      vnode.destroy();

      let childs = vnode.childs.slice();

      childs.forEach((child) => {
        tempList.push(child);
      });
    } // endwhile
    tempList.length = 0;
    tempList = null;

  };
}
//------------------------------------------------------------------------------