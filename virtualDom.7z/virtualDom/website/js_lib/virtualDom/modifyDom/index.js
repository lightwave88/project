import $GM from '../g_module.js';
import api from './htmldomapi.js';

const $modifyDom = {
  patch
};

export default $modifyDom;
//------------------------------------------------------------------------------
function patch(oldNode, node, parentDom) {
  debugger;
  const Vnode = $GM.get('Vnode');

  if (oldNode == null) {
    // 製造一個空的 vnode
    oldNode = Vnode.getInstance();
  }

  // fix here
  
  
  let new_dom = createElm(node);
  api.appendChild(parentDom, new_dom);
}
//------------------------------------------------------------------------------
function createElm(rootVnode) {
  let tempList = [rootVnode];
  let parentMap = {};

  let dom;

  let i = 0;

  while (true) {
    debugger;

    let vnode = tempList[i];
    if (vnode == null) {
      break;
    }
    let type = vnode.type;

    if (vnode.tagName == null) {
      let text = vnode.text;

      switch (type) {
        case '#comment':
          dom = api.createComment(text);
          break;
        case '#text':
          dom = api.createTextNode(text);
          break;
        default:
          throw new Error(`no deal with this domType(${type})`);
          break;
      }
      vnode.setDom(dom);

      if (i in parentMap) {
        let parent_dom = parentMap[i];
        delete parentMap[i];
        api.appendChild(parent_dom, dom);
      }

    } else {

      dom = api.createElement(vnode.tagName);
      vnode.setDom(dom);

      if (i in parentMap) {
        let parent_dom = parentMap[i];
        delete parentMap[i];
        api.appendChild(parent_dom, dom);
      }

      let childList = vnode.childs;
      if (!Array.isArray(childList)) {
        return;
      }

      childList.forEach((vnode) => {
        let j = tempList.length;
        tempList.push(vnode);
        parentMap[j] = dom;
      });

    } // endif

    i++;
  } // end

  return rootVnode.dom;
}
