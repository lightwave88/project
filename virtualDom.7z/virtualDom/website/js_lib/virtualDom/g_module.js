// debugger;
// module 管理
const $g_module = new Map();

import util from './util.js';
$g_module.set('util', util);

import { DomNode } from './compile/domNode.js';
$g_module.set('DomNode', DomNode);

import { Vnode } from './vnode.js';
$g_module.set('Vnode', Vnode);

import { attrsUpdate } from './attrsUpdate/index.js';
$g_module.set('vnode2Dom', attrsUpdate);

import Compile from './compile/compile.js';
$g_module.set('Compile', Compile);

import modifyDom from './modifyDom/index.js';
$g_module.set('modifyDom', modifyDom);

import api from './api.js';
$g_module.set('api', api);

export default $g_module;