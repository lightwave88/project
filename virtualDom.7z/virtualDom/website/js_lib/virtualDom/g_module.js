// debugger;
// module 管理
const $g_module = new Map();

import util from './util.js';
$g_module.set('util', util);


//-----------------------
// compile
debugger;

import { template_varNames } from './compile/compile_config.js';
$g_module.set('template_varNames', template_varNames);

import { Compile } from './compile/compile.js';
$g_module.set('Compile', Compile);

import { Vnode } from './vnode.js';
$g_module.set('Vnode', Vnode);

//-----------------------

import { TemplateManager } from './templateManager.js';
$g_module.set('TemplateManager', TemplateManager);



// import { attrsUpdate } from './attrsUpdate/index.js';
// $g_module.set('attrsUpdate', attrsUpdate);


// import domApi from './modifyDom/htmldomapi.js';
// $g_module.set('domApi', domApi);

// import ModifyDom from './modifyDom/modifyDom.js';
// $g_module.set('ModifyDom', ModifyDom);


// import { TemplateManager } from './templateManager.js';
// $g_module.set('TemplateManager', TemplateManager);

import { API } from './api.js';
$g_module.set('API', API);

export default $g_module;
