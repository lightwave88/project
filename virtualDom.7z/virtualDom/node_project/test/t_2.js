try {
	console.dir(global);
} catch (e) {
	
}
