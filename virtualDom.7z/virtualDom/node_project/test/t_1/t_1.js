debugger;
try {
  console.dir(global);
} catch (e) {
  console.log(e);
}