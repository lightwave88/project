'use strict';


console.log('x '+ true);
