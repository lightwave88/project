'use strict';

let data = {
  name: "gg"
};

function a() {
  let y;
  ({name: y} = data);

  console.log(y);
  console.log(name);
}

a();