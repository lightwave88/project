const $path = require('path');

let list = ['/a','./a'];

let root = __dirname;

list.forEach((p)=>{
  debugger;
  console.log($path.resolve(p));

  console.log($path.resolve(root, p));
});

require('./a/t_1.js');

