'use strict';

let a = {
    name: 'a',
    nickName: (()=>{
        debugger;
        
        return 'c_' + a.name;
    })(),
};

console.dir(a);
