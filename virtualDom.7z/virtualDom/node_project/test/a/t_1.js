let data = [0, 1, 2];

let removes = data.splice(1, 1);

debugger;

console.dir(data);

console.dir(removes);