debugger;

const $_C = createVnode;
const $_SYS = $system;
const $compute = compute;
const $data = data;
let $_VNODE = null;
//------------------
data = null;
$system = null;
compute = null;
createVnode = null;

debugger;
//------------------

$_VNODE = $_C(null, null, null);
$_VNODE.end();
const $_ROOT = $_VNODE;
//-------
{
    const $_PARENT = $_VNODE;
    $_VNODE = $_C("div", "div", $_PARENT);
    // level(1), index(0)
    $_VNODE.end();
    //-------
    {
        const $_PARENT = $_VNODE;
        $_VNODE = $_C("#text", null, $_PARENT);
        // level(2), index(0)
        $_VNODE.setText(false, "\n      div_1\n    ");
        $_VNODE.end();
    }
    if ($_SYS.getBooleanVal(undefined)) {
        $_VNODE = $_C("#text", null, $_PARENT);
        // level(2), index(0)
        $_VNODE.setStatic(false);
        $_VNODE.setText(false, "\n      ");
        $_VNODE.end();
        $_VNODE = $_C("div", "div", $_PARENT);
        // level(2), index(1)
        $_VNODE.setStatic(false);
        $_VNODE.end();
        //-------
        {
            const $_PARENT = $_VNODE;
            $_VNODE = $_C("#text", null, $_PARENT);
            // level(3), index(0)
            $_VNODE.setStatic(false);
            $_VNODE.setText(false, "\n        div_2\n      ");
            $_VNODE.end();
        }
        $_VNODE = $_C("#text", null, $_PARENT);
        // level(2), index(2)
        $_VNODE.setStatic(false);
        $_VNODE.setText(false, "\n    ");
        $_VNODE.end();
    }
    else {

        $_VNODE = $_C("#text", null, $_PARENT);ㄋ
        // level(2), index(0)
        $_VNODE.setStatic(false);
        $_VNODE.setText(false, "\n      ");
        $_VNODE.end();
        $_VNODE = $_C("div", "div", $_PARENT);
        // level(2), index(1)
        $_VNODE.setStatic(false);
        $_VNODE.end();
        //-------
        {
            const $_PARENT = $_VNODE;
            $_VNODE = $_C("#text", null, $_PARENT);
            // level(3), index(0)
            $_VNODE.setStatic(false);
            $_VNODE.setText(false, "\n        div_3\n      ");
            $_VNODE.end();
        }
        $_VNODE = $_C("#text", null, $_PARENT);
        // level(2), index(2)
        $_VNODE.setStatic(false);
        $_VNODE.setText(false, "\n    ");
        $_VNODE.end();
    }
    $_VNODE = $_C("#text", null, $_PARENT);
    // level(1), index(3)
    $_VNODE.setText(false, "\n  ");
    $_VNODE.end();
}


return (typeof $_ROOT == "undefined" ? null : $_ROOT);