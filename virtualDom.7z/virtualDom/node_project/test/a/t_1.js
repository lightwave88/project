let data = [2, 1, 0];

data.forEach(d => {
    t_1(d);
});

function t_1(key) {
    debugger;
    switch (key) {
        case 0:
            console.log('0');
            break;
        case 1:
            console.log('1');
            break;
        default:
            console.log('other');
            break;
    }
}