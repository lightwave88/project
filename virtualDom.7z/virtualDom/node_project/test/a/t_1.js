const $path = require('path');

let list = ['/a','./a'];

list.forEach((p)=>{
  debugger;
  console.log($path.resolve(p));
});