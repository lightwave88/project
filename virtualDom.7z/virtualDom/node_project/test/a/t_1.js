debugger;
		
		const $_SYS = $system;
		const $compute = $system.compute.bind($system);
		const $data = data;
		let $_VNODE = null;
		//------------------
		data = null;
		$system = null;
		compute = null;
		createVnode = null;

		debugger;
		//------------------
		
$_VNODE = $_SYS.C(null, null, null);
$_VNODE.end();
$_SYS.setRootVnode($_VNODE);//-------
{
  const $_PARENT = $_VNODE;
  $_VNODE = $_SYS.C("div", "div", $_PARENT);
  // level(1), index(0)
  $_VNODE.setClass(true, $data.a);
  $_VNODE.end();
//-------
  {
    const $_PARENT = $_VNODE;
    $_VNODE = $_SYS.C("#text", null, $_PARENT);
    // level(2), index(0)
    $_VNODE.setStatic(false);
    $_VNODE.setText(true, "\n        data= ",$data.a,"\n      ");
    $_VNODE.end();
  }
}