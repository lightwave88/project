let i = 0;

while(i++ < 1){
  debugger;
  a:{
    console.log('a');
    break b;
    console.log('b');
  }

  b:{
    console.log('c');
  }

  

}