let data = [
  '',
  '  ',
  `
`,
  '   2  '
];

let reg = /^(?:|\s+)$/;

data.forEach((d, i) => {
  debugger;

  console.log('%s => %s', i, reg.test(d));
});


