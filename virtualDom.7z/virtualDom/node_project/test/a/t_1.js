const reg_1 = /^\s*(?:(\([^]*?\))|(\S*))\s+in\s+(\S*)\s*$/;

let data = [' (index, key) in $data ', ' key  in {{$data}}'];

data.forEach(d => {
    debugger;
    let res = reg_1.exec(d);
    console.dir(res);
})

