const $reg_1 = /^([^]*?)[:]([^]*)/;
const $reg_2 = /[;]/;
const $reg_3 = /^(?:|\s+)$/;


function setVnodeAttr(args = []) {
  debugger;


  let $styles = {};
  //------------------

  let stringList = [];
  let tempList = [];

  debugger;

  args.forEach(arg => {
    debugger;
    if (arg == null) {
      return;
    } else if (typeof arg == 'object') {

      //------------------
      if(tempList.length){
        stringList.push(tempList.join(''));
        tempList.length = 0;
      }
      
      //------------------
      let type = getType(arg);
      if (!/^object$/i.test(type)) {
        throw new TypeError(`typeError(${type}) when set style`);
      }
      Object.assign($styles, arg);
    } else {
      tempList.push('' + arg);
    }
  }); // endForEach

  if(tempList.length){
    stringList.push(tempList.join(''));
    tempList.length = 0;
  }

  //------------------
  // 拆解文字
  stringList.forEach(arg => {
    // style 的分割方式(;)
    let list = arg.split($reg_2);

    list.forEach(el => {
      debugger;

      if ($reg_3.test(el)) {
        return;
      }

      let res = $reg_1.exec(el);

      let k, v;

      if (res == null) {
        throw new TypeError(`(${el}) typeError, when set style`);
      }

      let [match, g1, g2] = res;
      k = g1.trim();
      v = g2.trim();

      $styles[k] = v;
    });
  });

  return $styles;
}

//------------------------------------------------------------------------------


function getType(o) {
  debugger;
  const reg = /\[[^]*?\s([^]*?)\]/;
  const toString = Object.prototype.toString;
  let type = toString.call(o);
  let res = reg.exec(type);

  if (res == null) {
    return res;
  }

  let [m, g1] = res;
  return g1;
}

let data = ['width:', 5, 'px;', { coloe: '#F00' }, ';height:', 10, 'px'];

setVnodeAttr(data);