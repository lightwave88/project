const $GM = require('./tools');

const $tool = $GM['tool'];

const $fs = require('fs');
const $buffer = require('buffer');
const $http = require('http');
const $url = require('url');
const $path = require('path');

const $require = require;


const $mime = require('mime');

class Server {
    // root 根目錄
    constructor(root, options = {}) {

        if (root && (typeof (root) === 'object')) {
            options = root;
            root = null;
        }

        options = Object.assign({}, options);
        //------------------
        this.$req;
        this.$res;

        // resolve() doesn't normalize (to lowercase) drive letters on Windows
        this.$root = $path.resolve(root || '.');

        this.$options = {
            headers: {},
            indexFile: "",
            cache: null,
        };

        this.$cache = 3600;
        this.$indexFile = "index.html";

        // 預設標頭設定
        this.$defaultHeaders = {};
        this.$headers = {};
        this.$contentType;
        //------------------
        // 攜帶的資料
        this.$post = {};
        this.$get = {};
        //------------------

        this._init(options);
    }
    //----------------------------------------------------------------------------
    _init(options) {

        Object.assign(this.$options, options);

        this.$root = $path.normalize(this.$root);
        this.$root = $path.resolve(this.$root);

        let set_cache = this.$options['cache'];

        if (set_cache != null) {
            if (typeof (this.$options.cache) === 'number') {
                this.$cache = this.$options.cache;
                this.$defaultHeaders['cache-control'] = 'max-age=' + this.$cache;
            } else if (set_cache == false) {
                this.$cache = false;
            }
        }

        // cache
        if (!this.$cache) {
            this.$cache = false;
        }

        // headers
        Object.assign(this.$headers, this.$defaultHeaders, this.$options.headers);

        // indexFile
        // 預設的網頁
        if (this.$options.indexFile) {
            this.$options.indexFile = this.$options.indexFile;
        }

        this.$options = null;
        options = null;
    }
    //----------------------------------------------------------------------------

    // API
    // 從這裏開始
    serve(req, res) {
        debugger;

        this.$req = req;
        this.$res = res;


        // 要求的路徑
        let pathname;

        try {
            let url_obj = $url.parse(req.url);
            pathname = decodeURI(url_obj.pathname);
        } catch (e) {
            this._finish(400);
        }
        //------------------
        // 下一步
        // 檢查網址的指向

        pathname = $path.join(this.root, pathname);
        this._servePath(pathname);

        //------------------        
    }

    redirect(pathname, status = null, headers = {}) {
        this._servePath(pathname);
    }

    redirectUrl() {

    }
    //--------------------------------------------------------------------------
    // 檔案系統的測試
    test(pathname, root) {
        debugger;

        root = root || '.';
        root = $path.resolve(root);

        if (!$path.isAbsolute(pathname)) {
            pathname = $path.resolve(root, pathname);
        }

        $fs.stat(pathname, (e, stat) => {
            debugger;

            if (e) {
                // 網址沒有檔案
                this._finish(404);
            } else if (stat.isFile()) {
                // 網址有相應的檔案
                // Stream a single file.
                this._respondFile(pathname, stat);
            } else if (stat.isDirectory()) {
                // 網址是目錄
                // Stream a directory of files.
                this._serveDir(pathname, stat);
            } else {
                // 網址沒有檔案
                this._finish(400);
            }
        });
    }

    //--------------------------------------------------------------------------
    // 檢查網址的指向
    _servePath(pathname) {
        debugger;

        if (pathname.indexOf(this.$root) === 0) {
            // Make sure we're not trying to access a
            // file outside of the root.
            $fs.stat(pathname, (e, stat) => {
                debugger;

                if (e) {
                    // 網址沒有檔案
                    this._finish(404);
                } else if (stat.isFile()) {
                    // 網址有相應的檔案
                    // Stream a single file.
                    this._respondFile(pathname, stat);
                } else if (stat.isDirectory()) {
                    // 網址是目錄
                    // Stream a directory of files.
                    this._serveDir(pathname);
                } else {
                    // 網址沒有檔案
                    this._finish(400);
                }
            });
        } else {
            // Forbidden
            this._finish(403);
        }
    }
    //--------------------------------------------------------------------------
    // 結束
    _finish(status, st) {
        debugger;
        let headers = this.$headers;

        this.$res.writeHead(status, headers);


        this.$res.on('end', () => {
            this._reset();
        });

        if (st) {
            st.pipe(this.$res);
        } else {
            this.$res.end(this.$content);
        }
        //------------------
    }

    _reset() {
        this.$req = null;
        this.$res = null;
    }
    //--------------------------------------------------------------------------
    // 若網址指向目錄
    _serveDir(pathname) {
        debugger;

        var htmlIndex = path.join(pathname, this.$options.indexFile);
    }
    //--------------------------------------------------------------------------
    // 針對檔案顯示
    // stat: 檔案資訊
    _respondFile(pathname, stat) {
        debugger;

        let fileName = $path.basename(pathname);

        this.$contentType = this.$headers['Content-Type'] || $mime.lookup(fileName) ||
            'application/octet-stream';

        this._respondNoGzip(pathname, stat);

    }
    //--------------------------------------------------------------------------
    // 輸出檔案內容(noGzip)
    _respondNoGzip = function (pathname, stat) {
        debugger;

        let mtime = Date.parse(stat.mtime);
        let headers = this.$headers || {};

        let clientETag = this.$req.headers['if-none-match'];
        let clientMTime = Date.parse(this.$req.headers['if-modified-since']);
        let startByte = 0;
        let length = stat.size;
        let byteRange = parseByteRange(this.$req, stat);

        /* Handle byte ranges */
        if (byteRange.valid) {
            if (byteRange.to < length) {

                // Note: HTTP Range param is inclusive
                startByte = byteRange.from;
                length = byteRange.to - byteRange.from + 1;
                status = 206;

                // Set Content-Range response header (we advertise initial resource size on server here (stat.size))
                headers['Content-Range'] = 'bytes ' + byteRange.from + '-' + byteRange.to + '/' + stat.size;

            } else {
                byteRange.valid = false;
                console.warn("Range request exceeds file boundaries, goes until byte no", byteRange.to, "against file size of",
                    length, "bytes");
            }
        }

        /* In any case, check for unhandled byte range headers */
        if (!byteRange.valid && this.$req.headers['range']) {
            console.error(new Error("Range request present but invalid, might serve whole file instead"));
        }

        headers['Etag'] = JSON.stringify([stat.ino, stat.size, mtime].join('-'));
        headers['Date'] = new (Date)().toUTCString();
        headers['Last-Modified'] = new (Date)(stat.mtime).toUTCString();
        headers['Content-Type'] = contentType;
        headers['Content-Length'] = length;

        // Conditional GET
        // If the "If-Modified-Since" or "If-None-Match" headers
        // match the conditions, send a 304 Not Modified.
        if ((clientMTime || clientETag) &&
            (!clientETag || clientETag === headers['Etag']) &&
            (!clientMTime || clientMTime >= mtime)) {
            // 304 response should not contain entity headers
            ['Content-Encoding',
                'Content-Language',
                'Content-Length',
                'Content-Location',
                'Content-MD5',
                'Content-Range',
                'Content-Type',
                'Expires',
                'Last-Modified'
            ].forEach(function (entityHeader) {
                delete headers[entityHeader];
            });

            // return console.log('end');
            this.finish(304);
        } else {
            debugger;

            // return console.log('end');

            let res = this._stream(pathname, length, startByte);

            if (res instanceof Promise) {
                res.then((data) => {

                    this.$content = this._templateCompile(data);

                    this.finish(200);
                }, (er) => {
                    return this.finish(500);
                });
            } else {
                // stream
                this._finish(200, res);
            }
        }
    }
    //--------------------------------------------------------------------------
    _gzipOk = function (req, contentType) {
        var enable = this.options.gzip;
        if (enable &&
            (typeof enable === 'boolean' ||
                (contentType && (enable instanceof RegExp) && enable.test(contentType)))) {
            var acceptEncoding = req.headers['accept-encoding'];
            return acceptEncoding && acceptEncoding.indexOf("gzip") >= 0;
        }
        return false;
    }
    //--------------------------------------------------------------------------
    _stream(pathname, length, startByte) {
        debugger;

        const def = $tool.deferred();
        let is_text = /^text[\\/]/.test(this.$contentType);
        let is_html = /.htm[l]?$/.test(pathname);


        // Stream the file to the client
        const st = $fs.createReadStream(pathname, {
            flags: 'r',
            // mode: 0666,
            start: startByte,
            end: startByte + (length ? length - 1 : 0)
        });

        if (!is_text) {
            st.setEncoding('hex');
        } else {
            st.setEncoding('utf8');
        }

        if (!is_html) {
            return st;
        }
        //------------------
        // html file
        let content = [];
        const def = $tool.deferred();

        st.on('data', function (chunk) {
            content.push(chunk);
        });

        st.on('close', function () {
            def.resolve(content.join(''));
        });

        st.on('error', (err) => {
            def.reject(err)
        });

        return def.promise;
    }
    //--------------------------------------------------------------------------
    // 編譯模板
    _templateCompile(text) {
        let res;

        const $ejs = $tool['ejs'];

        let g = {
            "$get":null,
            "$post":null,
            "require": $require
        };

        // 
        res = $ejs.render(text, g);

        return res;
    }
}
//--------------------------------------------------------------------------
function parseByteRange(req, stat) {
    var byteRange = {
        from: 0,
        to: 0,
        valid: false
    }

    var rangeHeader = req.headers['range'];
    var flavor = 'bytes=';

    if (rangeHeader) {
        if (rangeHeader.indexOf(flavor) == 0 && rangeHeader.indexOf(',') == -1) {
            /* Parse */
            rangeHeader = rangeHeader.substr(flavor.length).split('-');
            byteRange.from = parseInt(rangeHeader[0]);
            byteRange.to = parseInt(rangeHeader[1]);

            /* Replace empty fields of differential requests by absolute values */
            if (isNaN(byteRange.from) && !isNaN(byteRange.to)) {
                byteRange.from = stat.size - byteRange.to;
                byteRange.to = stat.size ? stat.size - 1 : 0;
            } else if (!isNaN(byteRange.from) && isNaN(byteRange.to)) {
                byteRange.to = stat.size ? stat.size - 1 : 0;
            }

            /* General byte range validation */
            if (!isNaN(byteRange.from) && !!byteRange.to && 0 <= byteRange.from && byteRange.from < byteRange.to) {
                byteRange.valid = true;
            } else {
                console.warn("Request contains invalid range header: ", rangeHeader);
            }
        } else {
            console.warn("Request contains unsupported range header: ", rangeHeader);
        }
    }
    return byteRange;
}


// Exports
module.exports = {
    Server,
    mime: $mime
};
