const $fs = require('fs');
const $events = require('events');
const $buffer = require('buffer');
const $http = require('http');
const $url = require('url');
const $path = require('path');


const mime = require('mime');
//   , util   = require('./node-static/util');

class Server {
    // root 根目錄
    constructor(root, options = {}) {

        if (root && (typeof (root) === 'object')) {
            options = root;
            root = null;
        }

        options = Object.assign({}, options);
        //------------------
        this.$req;
        this.$res;
        // resolve() doesn't normalize (to lowercase) drive letters on Windows
        this.$root = path.normalize(path.resolve(root || '.'));

        this.$options = {
            headers: {},
            indexFile: "",
            cache: null,
        };

        this.$cache = 3600;
        this.$defaultHeaders = {};
        //------------------

        Object.assign(this.$options, options);

        this._init();
    }
    //----------------------------------------------------------------------------
    _init() {
        this.$options.headers = Object.assign({}, this.$options.headers);
        this.$options.indexFile = this.$options.indexFile || "index.html";

        if (this.$options['cache'] != null) {
            if (typeof (this.$options.cache) === 'number') {
                this.$cache = this.$options.cache;
            } else if (this.$options.cache == false) {
                this.$cache = false;
            }
        }

        if (this.$cache) {
            this.$defaultHeaders['cache-control'] = 'max-age=' + this.$cache;
        }

        for (var k in this.$defaultHeaders) {
            this.$options.headers[k] = this.$options.headers[k] ||
                this.$defaultHeaders[k];
        }
    }
    //----------------------------------------------------------------------------
    // API
    // 從這裏開始
    serve(req, res, callback) {
        debugger;

        this.$req = req;
        this.$res = res;
        let pathname;

        try {
            pathname = decodeURI($url.parse(req.url).pathname);
        } catch (e) {
            this._finish(400, {});
        }
        //------------------
        // 下一步
        // 檢查網址的指向
        this._servePath(pathname, 200, {});

        //------------------
        const event = new ($events.EventEmitter);

        event.on('success', function (result) {
            event.emit('success', result);
        }).on('error', function (err) {
            event.emit('error');
        });

        if (!callback) {
            return event;
        }
    }

    redirect(pathname, status, headers = {}) {
        this._servePath(pathname, status, headers);
    }

    redirectUrl() {

    }

    //--------------------------------------------------------------------------
    // 檢查網址的指向
    _servePath(pathname, status, headers) {

        pathname = this._resolve(pathname);

        if (pathname.indexOf(this.$root) === 0) {
            // Make sure we're not trying to access a
            // file outside of the root.
            fs.stat(pathname, (e, stat) => {
                if (e) {
                    // 網址沒有檔案
                    this._finish(404, {});
                } else if (stat.isFile()) {
                    // 網址有相應的檔案
                    // Stream a single file.
                    this._respond(null, status, headers, [pathname], stat);
                } else if (stat.isDirectory()) {
                    // 網址是目錄
                    // Stream a directory of files.
                    this._serveDir(pathname);
                } else {
                    // 網址沒有檔案
                    this._finish(400, {});
                }
            });
        } else {
            // Forbidden
            this._finish(403, {});
        }
    }
    //--------------------------------------------------------------------------
    // 結束
    _finish(status, headers) {
        debugger;

        if (!status || status >= 400) {
            this.$res.writeHead(status, headers);
            this.$res.end();
        } else {
            // Don't end the request here, if we're streaming;
            // it's taken care of in `prototype.stream`.
            if (status !== 200 || this.$req.method !== 'GET') {
                this.$res.writeHead(status, headers);
                this.$res.end();
            }
        }
        //------------------
        this.$req = null;
        this.$res = null;
    }
    //--------------------------------------------------------------------------
    // 若網址指向目錄
    _serveDir(pathname) {
        debugger;

        var htmlIndex = path.join(pathname, this.$options.indexFile);

        fs.stat(htmlIndex, function (e, stat) {
            debugger;
            if (!e) {
                var status = 200;
                var headers = {};
                var originalPathname = decodeURI(url.parse(this.$req.url).pathname);

                if (originalPathname.length && originalPathname.charAt(originalPathname.length - 1) !== '/') {
                    return this.finish(301, {
                        'Location': originalPathname + '/'
                    });
                } else {
                    this.respond(null, status, headers, [htmlIndex], stat);
                }
            } else {
                // error
                // Stream a directory of files as a single file.
                let path = $path.join(pathname, 'index.json');
                fs.readFile(path, (e, contents) => {
                    debugger;
                    if (e) {
                        return this.finish(404, {});
                    }
                    var index = JSON.parse(contents);

                    // external_fun
                    streamFiles(index.files);
                });
            }
        });
    }
    //--------------------------------------------------------------------------
    // 針對檔案顯示
    _respond(pathname, status, _headers, files = [], stat) {
        let contentType = _headers['Content-Type'] || mime.lookup(files[0]) ||
            'application/octet-stream';

        if (this.$options.gzip) {
            this.respondGzip(pathname, status, contentType, _headers, files, stat);
        } else {
            this.respondNoGzip(pathname, status, contentType, _headers, files, stat);
        }
    }
    //--------------------------------------------------------------------------
    respondGzip = function (pathname, status, contentType, _headers, files, stat, req, res, finish) {

        if (files.length == 1 && this.gzipOk(req, contentType)) {
            var gzFile = files[0] + ".gz";
            fs.stat(gzFile, function (e, gzStat) {
                if (!e && gzStat.isFile()) {
                    var vary = _headers['Vary'];
                    _headers['Vary'] = (vary && vary != 'Accept-Encoding' ? vary + ', ' : '') + 'Accept-Encoding';
                    _headers['Content-Encoding'] = 'gzip';
                    stat.size = gzStat.size;
                    files = [gzFile];
                }
                this.respondNoGzip(pathname, status, contentType, _headers, files, stat, req, res, finish);
            });
        } else {
            // Client doesn't want gzip or we're sending multiple files
            this.respondNoGzip(pathname, status, contentType, _headers, files, stat, req, res, finish);
        }
    }
    //--------------------------------------------------------------------------
    // 輸出檔案內容(noGzip)
    respondNoGzip = function (pathname, status, contentType, _headers, files, stat) {
        var mtime = Date.parse(stat.mtime),
            key = pathname || files[0],
            headers = {},
            clientETag = this.$req.headers['if-none-match'],
            clientMTime = Date.parse(this.$req.headers['if-modified-since']),
            startByte = 0,
            length = stat.size,
            byteRange = parseByteRange(this.$req, stat);

        /* Handle byte ranges */
        if (files.length == 1 && byteRange.valid) {
            if (byteRange.to < length) {

                // Note: HTTP Range param is inclusive
                startByte = byteRange.from;
                length = byteRange.to - byteRange.from + 1;
                status = 206;

                // Set Content-Range response header (we advertise initial resource size on server here (stat.size))
                headers['Content-Range'] = 'bytes ' + byteRange.from + '-' + byteRange.to + '/' + stat.size;

            } else {
                byteRange.valid = false;
                console.warn("Range request exceeds file boundaries, goes until byte no", byteRange.to, "against file size of",
                    length, "bytes");
            }
        }

        /* In any case, check for unhandled byte range headers */
        if (!byteRange.valid && this.$req.headers['range']) {
            console.error(new Error("Range request present but invalid, might serve whole file instead"));
        }

        // Copy default headers
        for (var k in this.options.headers) {
            headers[k] = this.options.headers[k]
        }
        // Copy custom headers
        for (var k in _headers) {
            headers[k] = _headers[k]
        }

        headers['Etag'] = JSON.stringify([stat.ino, stat.size, mtime].join('-'));
        headers['Date'] = new (Date)().toUTCString();
        headers['Last-Modified'] = new (Date)(stat.mtime).toUTCString();
        headers['Content-Type'] = contentType;
        headers['Content-Length'] = length;

        for (var k in _headers) {
            headers[k] = _headers[k]
        }

        debugger;

        // Conditional GET
        // If the "If-Modified-Since" or "If-None-Match" headers
        // match the conditions, send a 304 Not Modified.
        if ((clientMTime || clientETag) &&
            (!clientETag || clientETag === headers['Etag']) &&
            (!clientMTime || clientMTime >= mtime)) {
            // 304 response should not contain entity headers
            ['Content-Encoding',
                'Content-Language',
                'Content-Length',
                'Content-Location',
                'Content-MD5',
                'Content-Range',
                'Content-Type',
                'Expires',
                'Last-Modified'
            ].forEach(function (entityHeader) {
                delete headers[entityHeader];
            });

            this.finish(304, headers);
        } else {
            debugger;

            this.$res.writeHead(status, headers);

            this._stream(key, files, length, startByte, (e) => {
                if (e) {
                    return this.finish(500, {})
                }
                this.finish(status, headers);
            });
        }
    }
    //--------------------------------------------------------------------------
    gzipOk = function (req, contentType) {
        var enable = this.options.gzip;
        if (enable &&
            (typeof enable === 'boolean' ||
                (contentType && (enable instanceof RegExp) && enable.test(contentType)))) {
            var acceptEncoding = req.headers['accept-encoding'];
            return acceptEncoding && acceptEncoding.indexOf("gzip") >= 0;
        }
        return false;
    }
    //--------------------------------------------------------------------------
    _stream(pathname, files, length, startByte, status, headers) {
        debugger;

        (function streamFile(files, offset) {
            var file = files.shift();

            if (file) {
                // is stream
                file = path.resolve(file) === path.normalize(file) ? file : path.join(pathname || '.', file);

                // Stream the file to the client
                fs.createReadStream(file, {
                    flags: 'r',
                    mode: 0666,
                    start: startByte,
                    end: startByte + (length ? length - 1 : 0)
                }).on('data', function (chunk) {
                    // Bounds check the incoming chunk and offset, as copying
                    // a buffer from an invalid offset will throw an error and crash
                    if (chunk.length && offset < length && offset >= 0) {
                        offset += chunk.length;
                    }
                }).on('close', function () {
                    streamFile(files, offset);
                }).on('error', (err) => {
                    this.finish(500, {});
                    console.error(err);
                }).pipe(this.$res, {
                    end: false
                });
            } else {
                debugger;
                // not stream out
                // this.$res.end();
                this._finish(status, headers);
            }
        })(files.slice(0), 0);
    }
    //--------------------------------------------------------------------------
    _resolve(pathname) {
        debugger;
        let t = $path.join(this.root, pathname);
        t = $path.resolve(t);
        return t;
    }

}
//--------------------------------------------------------------------------
function streamFiles(files) {
    util.mstat(pathname, files, function (e, stat) {
        if (e) {
            return finish(404, {})
        }
        this.respond(pathname, 200, {}, files, stat);
    });
}
//--------------------------------------------------------------------------
function parseByteRange(req, stat) {
    var byteRange = {
        from: 0,
        to: 0,
        valid: false
    }

    var rangeHeader = req.headers['range'];
    var flavor = 'bytes=';

    if (rangeHeader) {
        if (rangeHeader.indexOf(flavor) == 0 && rangeHeader.indexOf(',') == -1) {
            /* Parse */
            rangeHeader = rangeHeader.substr(flavor.length).split('-');
            byteRange.from = parseInt(rangeHeader[0]);
            byteRange.to = parseInt(rangeHeader[1]);

            /* Replace empty fields of differential requests by absolute values */
            if (isNaN(byteRange.from) && !isNaN(byteRange.to)) {
                byteRange.from = stat.size - byteRange.to;
                byteRange.to = stat.size ? stat.size - 1 : 0;
            } else if (!isNaN(byteRange.from) && isNaN(byteRange.to)) {
                byteRange.to = stat.size ? stat.size - 1 : 0;
            }

            /* General byte range validation */
            if (!isNaN(byteRange.from) && !!byteRange.to && 0 <= byteRange.from && byteRange.from < byteRange.to) {
                byteRange.valid = true;
            } else {
                console.warn("Request contains invalid range header: ", rangeHeader);
            }
        } else {
            console.warn("Request contains unsupported range header: ", rangeHeader);
        }
    }
    return byteRange;
}




// Exports
exports.Server = Server;
exports.version = version;
exports.mime = mime;
