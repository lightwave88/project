const $g_moudle = {};

$g_moudle['ejs'] = require('./ejs');
$g_moudle['tool'] = require('./tools.js');

module.exports = $g_moudle;