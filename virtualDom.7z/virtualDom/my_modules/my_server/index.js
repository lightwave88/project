require('./tools.js');

module.exports = require('./static.js');

