const $path = require('path');
const $fs = require('fs');
const $url = require('url');

const $tool = {};

module.exports = $tool;
//------------------------------------------------------------------------------

{
    // 檢查要檢視的檔案是否存在
    // 或是想顯示檔案列表
    $tool.is_showFileList = function (options = {}) {
        // debugger;

        let {
            request,
            root_dir,
            base_url = ""
        } = options;

        const url_data = $url.parse(request.url, true);
        let request_url = url_data.pathname;

        // 取得副檔名
        let extname = $path.extname(request_url);

        if (extname.length) {
            return null;
        }
        //------------------

        let url = $path.normalize(request_url);
        url = url.replace(/\\$/, '');
        let target_path = root_dir + url;

        const dirList = [];
        const fileList = [];

        let p = (async function () {
            debugger;

            let files = await (new Promise(($res, $rej) => {
                $fs.readdir(target_path, (er, _res) => {
                    debugger;
                    if (er) {
                        $rej(er);
                        return;
                    }
                    $res(_res);
                });
            }));
            //-----------------------
            debugger;

            let prev_url_data = getPrevURLData(url);
            if (prev_url_data != null) {
                dirList.push(prev_url_data);
            }

            // 取得檔案資訊
            for (let i = 0, file; i < files.length; i++) {
                let fileName = files[i];
                let dir = root_dir + url;

                let path = dir + '\\' + fileName;

                let {
                    stat
                } = await $tool.fileInfo(path);

                let _url = url + "\\" + fileName;

                if (stat.isFile()) {
                    let ext = $path.extname(_url);
                    fileList.push({
                        url: _url,
                        fileName,
                        ext
                    });
                } else if (stat.isDirectory()) {
                    dirList.push({
                        url: _url,
                        fileName,
                        ext: null
                    });
                }
            }
        })();

        //----------------------------
        p = p.then(() => {
            // 產生形成文本的 factory
            // debugger;
            let content_list = [];

            dirList.forEach((d) => {
                let content = `<p class="dir">
                    <a href="${base_url}${d.url}">${d.fileName}</a>
                </p>`;
                content_list.push(content);
            });
            fileList.forEach((d) => {
                let content = `<p class="file">
                    <a href="${base_url}${d.url}">${d.fileName}</a>
                </p>`;
                content_list.push(content);
            });

            let content = content_list.join('\n');

            console.log(content);

            return content;
        });

        return p;
    }

    function getPrevURLData(url) {
        // debugger;
        let prev_url = (() => {
            debugger;
            if (url == '\\') {
                // 根目錄不能再回溯了
                return null;
            }

            let url_list = url.split('\\');
            url_list.pop();

            let res = url_list.join('\\');

            if (!res.length) {
                res = '/';
            }
            return res;
        })();

        if (prev_url != null) {
            return {
                url: prev_url,
                fileName: '..',
                ext: null
            };
        }
        return null;
    }
}
//------------------------------------------------------------------------------
{
    // 取得 post
    $tool.getPostData = function ($request) {

        if (!/^post$/i.test($request.method)) {
            return null;
        }

        const $qs = require('querystring');
        let body = '';

        let $res, $rej;

        let p = new Promise((res, rej) => {
            $res = res;
            $rej = rej;
        });


        $request.on('data', function (data) {
            body += data;
            // Too much POST data, kill the connection!
            // 1e6 === 1 * Math.pow(10, 6) === 1 * 1000000 ~~~ 1MB
            if (body.length > 1e6) {
                $request.connection.destroy();
            }
        });

        $request.on('end', function () {
            let postData = $qs.parse(body);
            $res(postData);

        });

        return p;
    }
}
//------------------------------------------------------------------------------

{
    $tool.is_fileExists = function (options = {}) {
        // debugger;

        let { root_dir, pathname } = options;

        let path = root_dir + pathname;

        return new Promise(($res, $rej) => {
            $fs.access(path, $fs.F_OK, (err) => {
                // debugger;
                if (err) {
                    $res(false);
                    return
                }
                $res(true);
            })
        });
    };
}
//------------------------------------------------------------------------------
{


    $tool.showFileList = function (root_dir, url) {
        debugger;

        url = $path.normalize(url);
        url = url.replace(/\\$/, '');
        let target_path = root_dir + url;

        const dirList = [];
        const fileList = [];

        let p = (async function () {
            debugger;

            let files = await (new Promise(($res, $rej) => {
                $fs.readdir(target_path, (er, _res) => {
                    debugger;
                    if (er) {
                        $rej(er);
                        return;
                    }
                    $res(_res);
                });
            }));
            //-----------------------
            debugger;

            let prev_url_data = getPrevURLData(url);
            if (prev_url_data != null) {
                dirList.push(prev_url_data);
            }

            // 取得檔案資訊
            for (let i = 0, file; i < files.length; i++) {
                let fileName = files[i];
                let dir = root_dir + url;

                let path = dir + '\\' + fileName;

                let {
                    stat
                } = await $tool.fileInfo(path);

                let _url = url + "\\" + fileName;

                if (stat.isFile()) {
                    let ext = $path.extname(_url);
                    fileList.push({
                        url: _url,
                        fileName,
                        ext
                    });
                } else if (stat.isDirectory()) {
                    dirList.push({
                        url: _url,
                        fileName,
                        ext: null
                    });
                }
            }
        })();

        //----------------------------
        p = p.then(() => {
            // 產生形成文本的 factory
            debugger;
            let content_list = [];

            dirList.forEach((d) => {
                let content = `'<p class="dir"><a href="'+ baseUrl + ` + JSON.stringify(d.url);
                content += `+'">${d.fileName}</a>'`;
                content = `content_list.push(${content})`;
                content_list.push(content);
            });
            fileList.forEach((d) => {
                let content = `'<p class="file"><a href="'+ baseUrl + ` + JSON.stringify(d.url);
                content += `+'">${d.fileName}</a>'`;
                content = `content_list.push(${content})`;
                content_list.push(content);
            });

            let content = content_list.join('\n');

            let factory_content =
                `
                debugger;
                baseUrl = baseUrl.replace(/\\\\|\\/$/, "");
                let content_list = [];
                
                ${content}
                
                return  content_list.join('');
            `;

            debugger;
            console.log(factory_content);

            return new Function('baseUrl', factory_content);
        });


        return p;
    };

    function getPrevURLData(url) {
        debugger;
        let prev_url = (() => {
            debugger;
            if (url == '\\') {
                // 根目錄不能再回溯了
                return null;
            }

            let url_list = url.split('\\');
            url_list.pop();

            let res = url_list.join('\\');

            if (!res.length) {
                res = '/';
            }
            return res;
        })();

        if (prev_url != null) {
            return {
                url: prev_url,
                fileName: '..',
                ext: null
            };
        }
        return null;
    }
}
//------------------------------------------------------------------------------
$tool.fileInfo = function (path, info = {}) {
    return new Promise(($res, $rej) => {
        $fs.stat(path, (err, data) => {
            if (err) {
                $rej(err);
                return;
            }
            let res = {
                stat: data
            };
            Object.assign(res, info);
            $res(res);
        });
    });
};
//------------------------------------------------------------------------------
{

    // 引入要的模組并執行
    $tool.has_action = function (options = {}) {

        let {
            request,
            dir = "action",
            actionName = 'action',
            redirectName = 'redirect'
        } = options;

        const url_data = $url.parse(request.url, true);
        let get_params = url_data.query;
    }
}
//------------------------------------------------------------------------------