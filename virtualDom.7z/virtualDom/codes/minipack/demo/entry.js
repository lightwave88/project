import sayHi from './hi';

sayHi('Jack');
