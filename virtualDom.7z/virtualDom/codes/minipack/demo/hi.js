import message from './msg';

export default function sayHi(who) {
    console.log(`> ${message} ${who}!`);
}
