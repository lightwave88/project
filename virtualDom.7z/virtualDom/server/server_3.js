const $http = require('http');
const $path = require('path');

let path = $path.resolve('./my_modules/my_server');

const { Server: $Server } = require(path);
const $server = $Server.getInstance();

$http.createServer(function ($req, $res) {
  debugger;
  $server.serve($req, $res);

}).listen(8080);