const $http = require('http');
const $path = require('path');
const $domain = require('domain');

const t_domain = $domain.create();

let path = $path.resolve('./my_modules/my_server');

const { Server: $Server } = require(path);
const $server = $Server.getInstance(null,{cache:false});

$http.createServer(function ($req, $res) {
  debugger; 

  try {
    $server.createRequest($req, $res);    
  } catch (error) {
    _error($res, error);
  }

}).listen(8082);


function _error(res, info) {
  console.log(info);

    res.writeHead(200, { 'Content-Type': 'text/html' });
    info = `<div>${info}</div>`;

    res.end(info);
}