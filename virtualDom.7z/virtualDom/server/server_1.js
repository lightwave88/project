const $http = require('http');
const $url = require('url');
const $qs = require('querystring');
const $path = require('path');
const $fs = require('fs');

const root_dir = $path.resolve('.');

let m_path = $path.resolve(root_dir, './my_modules/server/index.js');

const $server = require(m_path);

const file_dir = $path.resolve(root_dir, './files');

const baseUrl = 'localhost';
const basePort = 8082;

const error_page = null;
//------------------------------------------------------------------------------
$http.createServer(async function ($req, $res) {
  debugger;

  try {
    const url_data = $url.parse($req.url, true);
    let get_params = url_data.query;
    let url_pathname = url_data.pathname;

    const params = {
      get: get_params
    };

    debugger;
    // console.dir(url_data);
    // console.log('(%s),request(%s)', url, method);
    console.log('get=%s', JSON.stringify(get_params));

    let p = $server.getPostData($req);

    if (p != null) {
      let post_params = await p;
      params.post = post_params;
      console.log('post=%s', JSON.stringify(post_params));
    }
    //-----------------------
    p = $server.is_showFileList({
      request: $req,
      root_dir,
      base_url: ""
    });

    if (p != null) {
      // 沒有要顯示檔案
      // 顯示檔案列表
      debugger;

      let htmlContent = await p;
      showFileList($res, htmlContent)

      return;
    }
    //-----------------------
    // action
    // 要執行的命令
    let redirectPage;

    if (redirectPage != null) {
      $req.url = redirectPage;
    }
    //-----------------------
    // 檢查要顯示的頁面是否存在

    let file_exists = await $server.is_fileExists({
      "root_dir": root_dir,
      pathname: url_pathname
    });

    if (!file_exists) {
      let msg = `(${url_pathname})no exists`;
      console.log(msg);
      _error($res, msg);
      return;
    }
    //-----------------------

    showFile($req, $res);

  } catch (error) {
    console.log(error);
    _error($res, error);
  }

}).listen(basePort, baseUrl);
//------------------------------------------------------------------------------
function showFileList($res, htmlContent) {
  $res.writeHead(200, { 'Content-Type': 'text/html' });

  htmlContent = `            
            <div>${htmlContent}</div>
            <style>
            p.dir {
                background-color: #FF0;
            }
            </style>`;

  $res.end(htmlContent);
}
//--------------------------------------
function showFile(req, res) {
  debugger;
  $server.server(req, res);
}
//--------------------------------------
function _error(res, err) {

  if (err instanceof Error) {
    err = err.toString();
  }
  res.writeHead(200, { 'Content-Type': 'text/html' });
  let content = "<h4>error</h4><p>" + err + "</p>";
  res.end(content);
}
//--------------------------------------