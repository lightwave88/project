const $path = require('path');

debugger;

let path = $path.resolve('./my_modules/my_server');

const { Server } = require(path);
const $s = new Server();

debugger;
$s.test('./images/118474444_3137093429741150_8056725548272496010_o.jpg');