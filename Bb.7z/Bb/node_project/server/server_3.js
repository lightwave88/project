debugger;

const $http = require('http');
const $path = require('path');

let path = $path.resolve('./my_modules/my_server');
const { Server: My_Server, filters } = require(path);
const my_server = new My_Server();

my_server.addFilter(filters.rejectUrl);

//-----------------------


const server = $http.createServer().listen(8083);
//-----------------------

server.on('request', function ($req, $res) {
  debugger;


  let p = my_server.doRequest($req, $res);

  p.catch(error => {
    debugger;
		console.log('error: %s', error);
    $res.setHeader('content-Type', 'text/html');
    $res.end(error, 'utf8');
  });

});

