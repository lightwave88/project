const $path = require('path');
let path = $path.resolve('./my_modules/streamTest');
const {
	Rs,
	Ws
} = require(path);

let rs = new Rs(99999);
let ws = new Ws(10);


t_1();


function t_1() {
	rs.on('data', (chunk) => {
		console.log('data.....');

		let value = chunk.toString('utf8');
		let content = value + '|';

		let i = 0;
		while(i++ < 9999999){
			content += value;
		}

		if (!ws.write(content, 'utf8')) {
			console.log('reach limit >>>');
			rs.pause();
		}
	});

	ws.on('drain', () => {
		console.log('drain......');
		rs.resume();
	});


	rs.on('end', () => {
		ws.end();
	});
}
