const {
	Readable,
	Writable,
	Transform
} = require('stream');

class Rs extends Readable {

	count = 0;

	constructor() {
		super();
		this.setEncoding('utf8');

		this._max = 1;
		this._index = 0;
		console.log('readableHighWaterMark(%s)', this.readableHighWaterMark);
	}
	//----------------------------------------------------------------------------
	_read() {
		console.log('_read(%s)', this._index);

		const i = this._index++;

		if (i > this._max) {
			this.push(null);
		} else {

			let num = i % 10;
			this.push(`${num}`);
			console.log(`push ${num}`);
			this.push(`${num}`);
			console.log(`push ${num}`);
		}
		console.log('---------------');
	}
	//----------------------------------------------------------------------------
	_destory() {
		console.log('destory');
	}
}

let rs = new Rs({
	highWaterMark: 4
});

rs.on('end', () => {
	console.log('end');
});

rs.on('pause', () => {
	console.log('pause');
});

rs.on('resume', () => {
	console.log('resume');
});



rs.resume();
