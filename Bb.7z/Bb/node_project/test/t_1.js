const $path = require('path');

let path = $path.resolve('./my_modules/test');

require(path);
