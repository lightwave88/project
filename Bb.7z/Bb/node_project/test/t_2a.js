debugger;

let x = {};

let y = {
	get name(){
		return 'xyz';
	}
};


Object.assign(x, y);

console.log(x.name)