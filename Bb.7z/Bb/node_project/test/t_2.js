debugger;

const $path = require('path');

let path = $path.resolve('./my_modules/Chain');

const Chain = require(path);


let y = {
  index: 0,
  getCall() {

    const i = this.index++;

    return function call(next) {
      debugger;

      console.log(i);
      next();
      debugger;
      console.log(i);
    }
  }
};

let chain = new Chain();

debugger;
chain.add(y.getCall());
chain.add(y.getCall());

