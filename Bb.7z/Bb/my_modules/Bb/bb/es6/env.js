
let $Bb;

// 環境資訊
const $ENV = {
  // global
  root: null,
  env: null,
  isWorker: null,
  scriptPath: null,
};
////////////////////////////////////////////////////////////////////////////////

const { WebEnv, NodeJsEnv } = (() => {

  class Env {
    $Bb;
    constructor() {
    }
    //--------------------------------------
    // 屬於共同繼承
    sameProcess() {
      this.is_workerEnv();
    }
    //--------------------------------------
    is_workerEnv() {
      if (typeof (WorkerGlobalScope) != 'undefined') {
        $ENV.isWorker = true;
      } else {
        $ENV.isWorker = false;
      }
    }
  }
  //------------------------------------------------------------------------------
  class WebEnv extends Env {
    constructor() {
      super();
      let root = (typeof self == 'object' && self.self === self) ? self : null;
      $ENV.root = root;

      this.sameProcess();

      this.setGlobalVariable();
    }
    //----------------------------
    setGlobalVariable() {
      window['$bb'] = $Bb;
    }
    
  }
  //------------------------------------------------------------------------------
  class NodeJsEnv extends Env {
    constructor() {
      super($Bb);
      let root = (typeof global == 'object' && global.global === global) ? global : null;
      $ENV.root = root;

      this.sameProcess();
    }
  }


  return { WebEnv, NodeJsEnv };
})();
////////////////////////////////////////////////////////////////////////////////
function is_nodeJsEnv() {
  let res = false;
  try {
    let checkList = [process, require('fs')];
    res = checkList.every((obj) => {
      return (obj != null && typeof obj == 'object');
    });
  } catch (error) { }
  return res;
}
//---------------------------------
function is_browserEnv() {
  if (typeof window != 'undefined' && typeof document != 'undefined') {
    return true;
  }
  return false;
}
//---------------------------------
function getENV(Bb) {
  // debugger;

  $Bb = Bb;

  if (is_nodeJsEnv()) {
    $ENV.env = 'nodejs';
    new NodeJsEnv();
  } else if (is_browserEnv()) {
    $ENV.env = 'browser';
    new WebEnv();
  } else {
    $ENV.env = 'unknow';
  }
	
	return $ENV;
};

export default getENV;
export { getENV };
