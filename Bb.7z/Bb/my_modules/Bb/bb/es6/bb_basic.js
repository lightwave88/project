import { getENV } from './env.js';

// 工具集
const $BB = function () {

};

export default $BB;
export { $BB };
//------------------------------------------------------------------------------
const $extensionMap = {};
const $repeatFunctions = {};

const protoFun = {
  // 本身模組的擴增
  mixin(m) {
		// debugger;
		
    let { exports = null, extensions = null } = m($BB);

    if (exports != null) {

      for (const key in exports) {
        if (key in $BB) {
          throw new Error('has same attr');
        }

        let fn = exports[key];

        if (typeof fn != 'function') {
          return;
        }
        $BB[key] = fn;
      }
    }

    if (extensions != null) {
      Object.assign($extensionMap, extensions);
    }
  },
  //---------------------------------
  // 對外部的擴增
  extension(module, callback) {

    let moduleName = Object.keys($repeatFunctions).length;
    $repeatFunctions[moduleName] = [];

    let d_1 = $repeatFunctions[moduleName];

    for (const key in $extensionMap) {

      if (key in module) {
        // 記錄有哪些重複的 fun
        d_1.push(key);
        return;
      }

      let fn = $extensionMap[key];
      callback(key, fn);
    }
  },
  //---------------------------------
  // 可以知道有哪些 repeat 的 fun
  get repeatFunctions() {
    return $repeatFunctions;
  }
}
//------------------------------------------------------------------------------

Object.assign($BB, protoFun);

(() => {
  // debugger;
  // 注入功能
  $BB.ENV = getENV($BB);
})();