import $BB from './bb/es6/index.js';

import tools_1 from './tools/es6/index.js';
$BB.mixin(tools_1);


export default $BB;
export { $BB };