let uid = 0;

class EventHandle {
  id;
  callback;
  count = null;
  context = null;
  eventName;
  del = false;
  //-----------------------
  constructor(options = {}) {
    let {
      count = null,
      context,
      callback,
      eventName,
    } = options;

    this.callback = callback;
    this.eventName = eventName;
    // this.eventNameList = eventName.split(',');

    if (typeof count == 'number') {
      this.count = count;
    }

    if (context != null) {
      this.context = context;
    }

    this.id = uid++;
  }
}

class EventHandle_1 extends EventHandle {
  listener;
  listeningTo;
  //-----------------------
  constructor(options = {}) {
    super(options);

    let {
      listener,
      listeningTo
    } = options;
  }
}

const EventHandle_classes = {
  EventHandle,
  EventHandle_1
};

export { EventHandle_classes };

export default EventHandle_classes;
