const $modules = new Map();

// for ES6
const $g_moudle = {
  load(name, module, inject = false) {
    // debugger;

    if (isPlaineObj(name)) {
      let list = name;
      Object.keys(name).forEach(name => {
        // debugger;
        let arg = list[name];

        if (Array.isArray(arg)) {
          arg.unshift(name);
          this.load.apply(this, arg);
        } else {
          this.load(name, arg);
        }
      });
      return;
    }
    //------------------
    if (typeof module == 'function' && inject === true) {
      module = module(this);
    }
    // debugger;
    $modules.set(name, module);
  },
  //--------------------------------------
  get(name) {
    return ($modules.has(name) ? $modules.get(name) : null);
  },
  //--------------------------------------
  has(name) {
    return $modules.has(name);
  },
};

export default $g_moudle;
//------------------------------------------------------------------------------
function isPlaineObj(data) {
  if (data == null) {
    return false;
  }
  if (typeof data != 'object') {
    return false;
  }
  if (data.constructor != {}.constructor) {
    return false;
  }
  return true;
}
