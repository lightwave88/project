const $REG_1 = /[.][^]*$/;
const $REG_2 = /[.]/;
const $REG_3 = /^all[.]/;

let $GM;
let $UID = 0;


class Event {
  $id;

  // 記錄被誰監聽
  $listened = {};
  // 監聽者
  $listeningTo = {};

  $context;

  $events = {
    // 本身事件
    self: {},
    // 跨物件事件
    cross: {},
  };

  // 檢查用，檢查是否正在被引用
  locks = {};
  //----------------------------------------------------------------------------
  constructor() {
    this.$id = $UID++;
  }
  //-------------------------------------------
  emit(eventName, ...args) {
    debugger;

    this._checkEventName(eventName);

    const context = this._getContext();
    //------------------
    const firstName = this._getFirstName(eventName);

    let checks = ['self', 'cross'];

    let allList = [];
    //------------------
    checks.forEach((name, i) => {
      debugger;

      const eventMap = this.$events[name];

      let data = {
        name,
        eventListName: null,
      };

      if (firstName != 'all' && (firstName in eventMap)) {

        let data = {
          name,
          eventListName: firstName,
        };

        allList.push(data);
      }

      if ('all' in eventMap) {
        let list = eventMap['all'];

        let data = {
          name,
          eventListName: 'all',
        };

        allList.push(data);
      }
    });
    //------------------
    debugger;

    let options = {
      firstName,
      eventName,
      target: context,
    };

    allList.forEach((d) => {
      debugger;
      this._trigger(d, options, args);
    });
  }
  //-------------------------------------------
  emitAll(...args) {
    debugger;

    const context = this._getContext();
    //------------------
    const eventName = 'all';

    let checks = ['self', 'cross'];
    //------------------
    let list_1 = [];

    checks.forEach((name, i) => {
      debugger;

      const list = [];
      list_1.push(list);

      const eventMap = this.$events[name];

      for (let e in eventMap) {

        let data = {
          name,
          eventListName: null,
        };

        data.eventListName = e;

        if (e == 'all') {
          // all 放在後面
          list.unshift(data);
        } else {
          list.push(data);
        }
      }

      // 取保 all 在最後
      if (list.length > 1 && list[0].eventListName == 'all') {
        let data = list.shift();
        list.push(data);
      }
    });
    //------------------
    let allList = [];

    list_1.forEach((list) => {
      allList = allList.concat(list);
    });

    debugger;
    let options = {
      firstName: eventName,
      firtEventName: eventName,
      eventName,
      target: context,
    };
    //------------------
    allList.forEach((d) => {
      debugger;
      this._trigger(d, options, args);
    });
  }
  //-------------------------------------------
  on(eventName, listener) {
    debugger;

    if (typeof listener != 'function') {
      throw new Error('event.on no set listner');
    }

    this._checkEventName(eventName);

    const context = this._getContext();
    //------------------
    let list = this._initEvents('self', eventName);

    const { EventHandle } = $GM.get('EventHandle_classes');

    let event = new EventHandle({
      context,
      callback: listener,
      eventName
    });

    list.push(event);
  }
  //-------------------------------------------
  // on() 的別名
  addListener(eventName, listener) {
    return this.on(eventName, listener);
  }
  //-------------------------------------------
  once(eventName, listener) {
    if (typeof listener != 'function') {
      throw new Error('event.on no set listner');
    }

    this._checkEventName(eventName);

    const context = this._getContext();
    //------------------
    let list = this._initEvents('self', eventName);

    const { EventHandle } = $GM.get('EventHandle_classes');

    let event = new EventHandle({
      context,
      callback: listener,
      eventName,
      count: 1,
    });

    list.push(event);
  }
  //-------------------------------------------
  hasListen(eventName, listener) {
    this._checkEventName(eventName);
  }
  //-------------------------------------------
  off(eventName, listener) {

    this._checkEventName(eventName);

  }
  //-------------------------------------------
  // off 的別名
  removeListener(eventName, listener) {
    this._checkEventName(eventName);
  }
  //-------------------------------------------
  removeAllListeners(eventName) {
    this._checkEventName(eventName);
  }
  //-------------------------------------------
  // 返回已注册监听器的事件名数组
  eventNames(eventName) {

  }
  //-------------------------------------------
  // 返回正在监听的名为 eventName 的事件的监听器的数量
  listenerCount(eventName) {

  }
  //-------------------------------------------
  // 返回名为 eventName 的事件的监听器数组的副本
  listeners(eventName) {

  }
  //----------------------------------------------------------------------------
  listenTo(obj, eventName, listener) {

  }

  listenToOnce(obj, eventName, listener) {

  }

  hasListenTo(obj, eventName) {

  }
  removeListenTo(obj, eventName, listener) {

  }
  removeAllListenTo(obj, eventName) {

  }

  // 不再被另一個物件聆聽
  stopBylistening(obj, eventName, listener) {

  }

  stopAllBylistening(obj, eventName) {

  }


  //----------------------------------------------------------------------------
  // 因應 Events.mixin()
  _getContext() {
    let context = this;
    if (this.$context != null) {
      context = this.$context;
      this.$context = null;
    }
    return context;
  }

  _getFirstName(eventName) {
    return eventName.replace($REG_1, '');
  }
  //-------------------------------------------
  // 只負責執行適配的 listener
  _trigger(listData = {}, options_1 = {}, args) {
    debugger;

    const { name, eventListName } = listData;

    const events = this.$events[name][eventListName];

    const {
      // 事件的第一個名字
      firstName,
      // 完整的事件名稱
      eventName,
      target,
    } = options_1;

    //------------------
    // 上鎖
    /*
      最大的問題是在 emit(trigger)未結束前
      有可能動態的變動 eventList
      尤其以刪除影響最大

      1.emit 未結束卻清除 eventList
      2.emit 未結束又增加 listener
      3.emit 未結束但再次套嵌 emit
    */
    if (this.locks[name] == null) {
      this.locks[name] = {};
    }

    if (this.locks[name][eventListName] == null) {
      this.locks[name][eventListName] = 0;
    }
    ++this.locks[name][eventListName];
    //------------------
    let data = null;

    switch (args.length) {
      case 0:
        break;
      case 1:
        data = args[0];
        break;
      default:
        data = args;
        break;
    }

    const callback_arg = {
      data,
      target,
      trigger: eventName,
    };
    //------------------
    const isEmitAll = (eventName == 'all') ? true : false;

    debugger;
    events.forEach((handle, i) => {
      debugger;

      if (handle.del === true) {
        return;
      }

      if (!isEmitAll) {
        // checkNameSpace
        if (!this._checkNamespace(eventName, handle.eventName)) {
          return;
        }
      }

      if (typeof handle.count == 'number' && --handle.count <= 0) {
        // once
        handle.del = true;
      }
      //-------------
      let context = handle.context;

      let arg = Object.assign({
        eventName: handle.eventName
      }, callback_arg);

      if ('listener' in handle) {
        arg.listener = handle.listener;
      }

      // 執行 listener
      const callback = handle.callback;
      callback.call(context, arg);
    });
    //------------------
    // 解鎖
    if (--this.locks[name][eventListName] == 0) {
      delete this.locks[name][eventListName];

      // 只有一開始進來的 trigger 可以執行刪除
      this._clearHandle(events, name, eventListName);
    }


    if (!Object.keys(this.locks[name]).length) {
      delete this.locks[name];
    }
  }
  //-------------------------------------------
  _remove(list, options = {}) {
    let {
      remove,
      eventName,
      target,
      listener
    } = options;
  }
  //-------------------------------------------
  // click.a
  _checkNamespace(eventName, handle_eventName) {
    debugger;

    // eventName 不會是 'all'

    if (handle_eventName == 'all') {
      // 所有事件都 match
      return true;
    }

    // 處理 '.'
    const reg_1 = RegExp($REG_2, 'g');

    // 處理 a.b.c 裏的 '.'
    // 要化爲 RegExp
    let reg_string = eventName.replace(reg_1, (m) => {
      return `[${m}]`;
    });
    const reg_2 = RegExp(`^${reg_string}`);

    let res = reg_2.test(handle_eventName);

    return res;
  }
  //-------------------------------------------

  // 清除被標記要刪除的 handle
  _clearHandle(events, name, eventListName) {
    debugger;
    for (let i = 0; events[i] != null; i++) {
      debugger;
      let handle = events[i];

      if (handle.del === true) {
        events.splice(i, 1);
        i--;
      }
    }
    debugger;
    if (!events.length) {
      let eventMap = this.$events[name];
      delete (eventMap[eventListName]);
    }
  }
  //-------------------------------------------
  _initEvents(name, eventName) {
    const firstName = this._getFirstName(eventName);

    const eventMap = this.$events[name];

    if (!(firstName in eventMap)) {
      eventMap[firstName] = []
    }
    return eventMap[firstName];
  }
  //-------------------------------------------
  _checkEventName(eventName) {
    if ($REG_3.test(eventName)) {
      throw new Error('event all cant use namespace');
    }
  }
}
//------------------------------------------------------------------------------
function factory(gm) {
  $GM = gm;
  return Event;
}

export default factory;
