
import g_moudle from './g_loader.js';

import { EventHandle_classes } from './eventHandle.js';

import event from './event.js';

import events from './eventsAPI.js';

g_moudle.load({
  'EventHandle_classes': EventHandle_classes,
  Event: [event, true],
  Events: [events, true],
});

const Events = g_moudle.get('Events');


export { Events };