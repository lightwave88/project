let $GM;

// global event
let $g_event;

// 本體
function Events() {
  const event = new Event();
  return event;
}
//----------------------------
// 把 event 的功能拷貝到目標
Events.mixin = function () {

};
//----------------------------
// 把 event 的功能植入原型鍊裏
Events.extend = function () {

};
//----------------------------
// Events.global
Object.defineProperty(Events, 'global', {
  enumerable: true,
  get() {
    if ($g_event == null) {
      const Event = $GM.get('Event');
      $g_event = new Event();
    }
    return $g_event;
  },
  set() { }
});
//----------------------------
// Events.class
Object.defineProperty(Events, 'class', {
  enumerable: true,
  get() {
    return $GM.get('Event');
  },
  set() { }
});
////////////////////////////////////////////////////////////////////////////////


function mixin(obj, core) {
  debugger;

  if (!Object.hasOwnProperty('$bb_event')) {
    Object.defineProperty(obj, '$bb_event', {
      configurable: true,
      value: core,
      writable: true,
      enumerable: false,
    });
  }
  //------------------
  let proto = Object.getPrototypeOf(core);

  for (let key in proto) {
    if (typeof proto[key] == 'function' && (key.indexOf("_") != 0)) {
      obj[key] = function (...args) {
        core.$context = obj;
        core[key].apply(core, args);
      }
    }
  }
}

function factory(gm) {
  $GM = gm;
  return Events;
}

export default factory;
