class GenerateData {
	_callback_data;
	_callback_end;

	_process;
	_max = 999999;
	_pause = false;
	_index = 0;
	_data;
	_stop = false;
	//----------------------------------------------------------------------------
	constructor(max = null) {
		if (max != null) {
			this._max = max;
		}
		this._data = getData(this._max);
	}
	//----------------------------------------------------------------------------
	onData(callback) {
		this._callback_data = callback;
	}
	//----------------------------------------------------------------------------
	onEnd(callback) {
		this._callback_end = callback;
	}
	//----------------------------------------------------------------------------
	start() {
		if (this._process != null || this._stop) {
			return;
		}
		console.log('genData start >>>');


		this._process = setInterval(() => {
			this._job();
		}, 0);
	}
	//----------------------------------------------------------------------------
	_job() {

		if (this._pause) {
			return;
		}

		let {
			done,
			value
		} = this._data.next();

		let fn;
		if (done) {
			clearInterval(this._process);
			this._process = null;
			fn = this._callback_end;
			fn();
		} else {
			fn = this._callback_data;
			fn(value);
		}
	}
	//----------------------------------------------------------------------------
	pause() {
		console.log('genData pause>>>');
		if (this._process == null) {
			return;
		}
		this._pause = true;
	}
	//----------------------------------------------------------------------------
	stop() {
		if (this._process == null) {
			return;
		}
		
		this._stop = true;

		clearInterval(this._process);
		this._process = null;
	}
	//----------------------------------------------------------------------------
	resume() {
		console.log('genData resume>>>');

		if (!this._pause) {
			return;
		}
		this._pause = false;
	}
	//----------------------------------------------------------------------------
	get inProcess() {
		return (this._process != null)
	}

	get inPause() {
		return this._pause;
	}
}

module.exports = function(max) {
	return new GenerateData(max);
}

function* getData(max) {
	let i = 0;
	while (i < max) {
		yield i;
		i++;
	}
}
