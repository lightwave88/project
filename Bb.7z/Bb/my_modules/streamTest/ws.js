const {
	Readable,
	Writable,
	Transform
} = require('stream');

class Ws extends  Writable {

	_wait;
	constructor(wait = null) {
		super();
		this._wait = wait;
	}
	_write(chunk, encoding, callback) {

		let value = chunk.toString('utf8');

		// console.log(value);

		let head = value.replace(/\|\w+$/, '');

		console.log('ws _write => %s', head);

		if (this._wait != null) {
			setTimeout(() => {
				console.log('ws callback');
				callback();
			}, this._wait);
		} else {
			console.log('ws callback');
			callback();
		}

		console.log('------------------------');
	}
}

module.exports = Ws;
