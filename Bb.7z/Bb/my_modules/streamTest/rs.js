
const {
	Readable,
	Writable,
	Transform
} = require('stream');

const genData_factory = require('./generateData.js');

class Rs extends Readable {

	_source;
	_max = 999999999;
	_limit = null;
	_ok = true;
	//----------------------------------------------------------------------------
	constructor(max = null, limit = null) {
		super();


		if(max != null){
			this._max = max;
		}
		if (limit != null) {
			this._limit = limit;
		}

		this.setEncoding('utf8');

		this._source = genData_factory(this._max);

		this._source.onData((data) => {

			let value = `${data}`;
			console.log('push(%s)', value);
			this._ok = this.push(value);


			if (!this._ok) {
				console.log('<<< rs.....overflow pause....>>>');
				this._source.pause();
				
				this.emit('_pause');
			}

			if (this._limit != null && data > this._limit) {
				console.log('<<< rs.....limit....>>>');
				this._ok = false;
				
				this.emit('_pause');
			}
		});

		this._source.onEnd(() => {
			this.push(null);
		});

	}
	//----------------------------------------------------------------------------
	_read() {
		debugger;
		console.log('rs _read>>');

		let judge_1 = !this._ok && this._source.inProcess && !this._source.inPause;

		console.log('%s, %s, %s', this._ok, this._source.inProcess, this._source.inPause);

		if (judge_1) {
			this._source.pause();
			console.log('rs pause >>>');
			return;
		}

		if (!this._source.inProcess) {
			console.log('rs start >>>');
			this._source.start();
		} else if (this._source.inPause) {
			console.log('rs pause >>>');
			this._ok = true;
			this._source.resume();
		}
	}
	//----------------------------------------------------------------------------
	_destory() {
		console.log('rs destory');
	}
}

module.exports = Rs;


