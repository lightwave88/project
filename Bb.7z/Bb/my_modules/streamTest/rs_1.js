const {
	Readable,
	Writable,
	Transform
} = require('stream');

const genData_factory = require('./generateData.js');

class Rs extends Readable {

	_source;
	_max = 999999999;
	//----------------------------------------------------------------------------
	constructor(max = null, limit = null) {
		super();

		if (max != null) {
			this._max = max;
		}
		if (limit != null) {
			this._limit = limit;
		}

		this.setEncoding('utf8');

		this._source = genData_factory(this._max);

		this._source.onData((data) => {

			let value = `${data}`;

			console.log('push(%s)', value);

			let ok = this.push(value);
			if (!ok) {
				this._source.stop();
			}
		});

		this._source.onEnd(() => {
			this.push(null);
		});

	}
	//----------------------------------------------------------------------------
	_read() {
		debugger;
		console.log('rs _read>>');

		if (!this._source.inProcess) {
			console.log('rs start >>>');
			this._source.start();
		}
	}
	//----------------------------------------------------------------------------
	_destory() {
		console.log('rs destory');
	}
}

module.exports = Rs;
