'use strict';

let $GM;

// 設定參數
const $config = {
  listen: 8080,
  indexFile: "index.html",
  actionDir: [
    'actions'
  ],
  viewDir: [
    'view'
  ],
  viewNoRenderFileType: [
    'html', 'htm'
  ],
  staticDir: [],
  fileListStyle: null,
};

////////////////////////////////////////////////////////////////////////////////
// config 的設定
const $fun = {

  resetActionDir() {

  },
  //--------------------------------------
  resetViewDir() {

  },
  //--------------------------------------
  resetStaticDir() {

  },
  //--------------------------------------
  addActionDir() {

  },
  //--------------------------------------
  addViewDir() {

  },
  //--------------------------------------
  addStaticDir() {

  },
  //--------------------------------------
  // 覆寫檔案列表的內容輸出
  setGetFileListPageContent(fn) {
    if (typeof fn != ' function') {
      throw TypeError('fileListStyle must be function');
    }
    this.fileListStyle = fn;
  },
  //--------------------------------------
  // 負責檔案目錄列表內容的裝飾
  getFileListPageContent() {
    if (this.fileListStyle == null) {
      this.fileListStyle = fn_getFileListPageContent;
    }
    return this.fileListStyle;
  }
};

////////////////////////////////////////////////////////////////////////////////
let $$config = Object.assign({}, $config, $fun);


$$config = new Proxy($$config, {
  set: function (t, k, v) {
    debugger;
    if (!(k in $config)) {
      return false;
    }

    if ($config[k] != null) {
      if (typeof v != typeof t[k]) {
        return false;
      }
    }
    return true;
  },
  get: function (t, k) {
    debugger;
    return t[k];
  }
});

module.exports = function(gm) {
  debugger;
  $GM = gm;

  return $$config;
};
////////////////////////////////////////////////////////////////////////////////
// 負責檔案目錄列表內容的裝飾
function fn_getFileListPageContent(itemList) {
  debugger;
  let content = itemList.map((item) => {
    let {
      url,
      fileName,
      isDir
    } = item;

    let content = '';

    if (isDir) {
      content += `<p class="isDir">`;
    } else {
      content += `<p class="isFile">`;
    }
    content += `<a href="${url}">${fileName}</a></p>\n`;
    return content;
  });

  content = content.join('');

  let all_content = `
  <div>
    ${content}
  </div>
  `;

  return all_content;
}
//--------------------------------------
