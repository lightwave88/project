'use strict';

let $GM;

const $tools = {};
module.exports = function (gm) {
	$GM = gm;
	return $tools;
};
//------------------------------------------------------------------------------
// deferred
{
	class Def {
		$handle;
		$pr;
		constructor() {

			this.$pr = new Promise(($res, $rej) => {
				this.$handle = (function* () {
					let {
						error,
						data
					} = yield;

					if (error == null) {
						$res(data);
					} else {
						$rej(error);
					}
				})();
				this.$handle.next();
			});
		}
		//------------------------------------------------
		get promise() {
			return this.$pr;
		}
		//------------------------------------------------
		set promise(v) {
			throw new Error('cant set promise');
		}
		//------------------------------------------------
		resolve(data) {
			this.$handle.next({
				error: null,
				data
			});
		}
		//------------------------------------------------
		reject(er) {
			this.$handle.next({
				error: er,
				data: null
			});
		}
		//------------------------------------------------
	}
	//------------------
	$tools.deferred = function () {
		return new Def();
	};
}
//------------------------------------------------------------------------------
// 
$tools.fileStat = function (pathname) {
	const $fs = require('fs');
	const $path = require('path');

	const def = $tools.deferred();

	pathname = $path.normalize(pathname);

	$fs.stat(pathname, (e, stat) => {
		// debugger;
		if (e) {
			console.log(e);
			def.resolve(null);
		} else {
			def.resolve(stat);
		}
	});

	return def.promise;
}
//------------------------------------------------------------------------------
$tools.getFileExtname = function (filename) {
	const $path = require('path');
	return $path.extname(filename).replace(/^\./, '');
}
//------------------------------------------------------------------------------
// 返回上一層目錄的路徑
$tools.getTopLevelPath_url = function (path) {
	// debugger;

	const $path = require('path');
	path = $path.normalize(path);

	const seprator = $path.sep;

	if (seprator == path) {
		// 沒有上一層
		return null;
	}

	let dirs = path.split(seprator);
	dirs = dirs.filter(v => {
		if (!v.length) {
			return false;
		}
		return true;
	});

	if (!dirs.length) {
		// 沒有上一層
		return null;
	}

	dirs.pop();

	return dirs.join('/');
}