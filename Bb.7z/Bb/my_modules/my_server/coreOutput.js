'use strict';

const $fs = require('fs');
const $path = require('path');

let $GM;

// 核心輸出
class CoreOutput {
  $server;
  $sys_request
  $sys_response;
  $request;
  $url;
  $filters = [];
  //----------------------------------------------------------------------------
  constructor(server) {

    this.$server = server;
  }
  //----------------------------------------------------------------------------
  async main(req, res) {
    debugger;
    this.$sys_request = req;
    this.$sys_response = res;
    this.$url = this.$sys_request.url;

    await this.output();
  }
  //----------------------------------------------------------------------------

  async output() {

    const $tools = $GM['tools'];
    const $res = this.$sys_response;
    const $req = this.$sys_request;

    let url2filePath = this.$server.$rootPath + this.$url;
    url2filePath = $path.normalize(url2filePath);

    console.log('filePath(%s)', url2filePath);

    let stat = await $tools.fileStat(url2filePath);

    debugger;

    if (stat == null) {
      // error
      $res.write('error');
      return;
    } else if (stat.isDirectory()) {
      // 輸出目錄
      await this.printFileList(this.$url);
      return;
    } else {
      // 輸出指定檔案
      this.printFileContent(url2filePath);
      return;
    }
  }
  //----------------------------------------------------------------------------
  // 顯示檔案列表
  async printFileList(pathname) {
    const $res = this.$sys_response;

    $res.setHeader('content-Type', 'text/html');

    let pageContent;
    try {
      pageContent = await this._showFileList(pathname);
    } catch (e) {
      console.log(e);
      $res.write(e, 'utf8');
      return;
    }

    $res.write(pageContent, 'utf8');
  }
  //----------------------------------------------------------------------------
  // 列印出目錄結構
  async _showFileList(pathname) {
    // pathname = request.url
    debugger;

    let dirList = [];
    let fileList = [];

    const $tools = $GM['tools'];

    // 上一層目錄的路徑
    let topDir_relative = $tools.getTopLevelPath_url(pathname);

    console.log('%s => %s', pathname, topDir_relative);

    if (topDir_relative != null) {
      // 返回上一層
      dirList.push({
        fileName: '..',
        url: ('/' + topDir_relative),
        isDir: true
      });
    }
    //-----------------------
    // 讀取目錄下的結構
    const rootPath = this.$server.$rootPath;

    let dirPath = $path.join(rootPath, pathname);
    dirPath = $path.normalize(dirPath);

    let _fileList = await (new Promise(($res, $rej) => {
      $fs.readdir(dirPath, (er, _res) => {
        if (er) {
          $rej(er);
          return;
        }
        $res(_res);
      });
    }));
    //-----------------------
    // 整理資料

    for (let i = 0; i < _fileList.length; i++) {
      // debugger;
      let _fileName = _fileList[i];
      const index = i;

      let path = $path.join(dirPath, _fileName);
      let stat = await $tools.fileStat(path);

      let _pathname = (pathname == '/') ? '' : pathname;
      let _url = (_pathname + '/' + _fileName);

      let data = {
        index,
        url: _url,
      };

      if (stat.isDirectory()) {
        data.fileName = ('/' + _fileName);
        data.isDir = true;
        dirList.push(data);
      } else {
        data.fileName = _fileName;
        data.isDir = false;
        fileList.push(data);
      }
    }
    debugger;
    let itemList = dirList.concat(fileList);

    // 將資料變成文本
    const getFileListPageContent = this.$server.config.getFileListPageContent;
    return getFileListPageContent(itemList);
  }
  //----------------------------------------------------------------------------
  // 顯示檔案內容
  async printFileContent(filePath) {
		const $res = $sys_response;
    $res.setHeader('content-Type', 'text/html');
    $res.write(`<p>show file(${filePath})</p>`, 'utf8');
  }
}

module.exports = function (gm) {
  $GM = gm;
  return CoreOutput;
};