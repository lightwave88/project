'use strict';

const $fs = require('fs');
const $path = require('path');

let $GM;

class My_Server {

	$rootPath;
	$config;
	$filters = [];
	//----------------------------------------------------------------------------
	static getInstance() {
		return new My_Server();
	}

	//----------------------------------------------------------------------------
	constructor(req, res) {

		// debugger;
		this.$rootPath = $path.resolve('.');
		this.$rootPath = $path.normalize(this.$rootPath);
		this.$config = $GM['config'];
	}

	//----------------------------------------------------------------------------
	get config() {
		debugger;
		return this.$config;
	}

	set config(value) {

	}
	//----------------------------------------------------------------------------
	async doRequest(req, res) {
		debugger;

		console.log('request.url = %s', req.url);

		let FilterChain = $GM['FilterChain'];
		let filterChain = new FilterChain(this, this.$filters);
		let Output = $GM['CoreOutput'];
		let output = new Output(this);
		await filterChain.main(req, res, output);

		res.end();
	}
	//----------------------------------------------------------------------------
	addFilter(_class) {
		if (typeof _class != 'function') {
			throw new TypeError('...');
		}
		this.$filters.push(_class);
	}
	//----------------------------------------------------------------------------

}

module.exports = function (gm) {
	$GM = gm;
	return My_Server;
};





