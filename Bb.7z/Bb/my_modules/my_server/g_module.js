
const $g_moudle = {};

$g_moudle['mime'] = require('mime');
$g_moudle['ejs'] = require('./ejs/index.js');
$g_moudle['config'] = require('./config.js')($g_moudle);
$g_moudle['tools'] = require('./tools.js')($g_moudle);
$g_moudle['Request'] = require('./request.js')($g_moudle);
$g_moudle['FilterChain'] = require('./filterChain.js')($g_moudle);
$g_moudle['CoreOutput'] = require('./coreOutput.js')($g_moudle);
$g_moudle['Server'] = require('./my_server.js')($g_moudle);
$g_moudle['filters'] = require('./filters.js')($g_moudle);

module.exports = $g_moudle;