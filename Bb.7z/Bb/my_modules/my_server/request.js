'use strict';

const $util = require('util');
const $fs = require('fs');
const $url = require('url');
const $path = require('path');

let $GM;
////////////////////////////////////////////////////////////////////////////////
class Request {
	$core;

	constructor(req) {
		this.$core = new Request(req);
	}
	//----------------------------------------------------------------------------
	get promise() {
		return this.$core.promise;
	}
	//----------------------------------------------------------------------------
	getUrl() {
		return this.$core.$url;
	}

	getUrlQuery(name = null){
		const $get = Objec.assign({}, this.$core.$get);
		
		if(name == null){
			return $get;
		}else{
			return (name in $get)?$get[name]:null;
		}
	}
	//----------------------------------------------------------------------------
	getUrlPathname() {
		return this.$core.$url.pathname;
	}
	//----------------------------------------------------------------------------
	getRequest() {
		return this.$core.$request;
	}
	//----------------------------------------------------------------------------
	getHeader(name) {

	}
	//----------------------------------------------------------------------------
	getHeaders() {

	}
	//----------------------------------------------------------------------------
	getMethod() {

	}

	getParameterNames(name) {


	}

}
module.exports = function(gm) {
	$GM = gm;
	return Request;
}
////////////////////////////////////////////////////////////////////////////////

const POSTMETHOD_REG = /^post$i/;


class RequestCore {
	$request;
	$deferred;
	$tools;
	$url;
	$requestMethod;
	$href;

	$heads = {};
	$get = {};
	$post = {};
	//----------------------------------------------------------------------------
	constructor(req) {
		debugger;

		console.dir(req.headers);

		this.$tools = $GM['tools'];
		this.$request = req;
		this.$deferred = this.$tools.deferred();

		//------------------
		this._init_1();
		// this._init_2();
	}
	//----------------------------------------------------------------------------
	_init_1() {
		this.$heads = Object.assign({}, this.$request.heads)
		
		this.$href = this.$request.url;
		this.$href = $path.normalize(decodeURI(this.$href));

		this.$url = new URL(this.$href);

		// GET
		let searchParams = this.$url.searchParams;
		searchParams.forEach((value, name) => {
			this.$get[name] = value;
		});

		this.$requestMethod = this.$request.method;
	}
	//----------------------------------------------------------------------------
	_init_2() {
		if (POSTMETHOD_REG.test(this.$requestMethod)) {
			let postBody = "";
			const $req = this.$request;

			// post
			$req.on('data', (chunk) => {
				postBody += chunk;

				if (postBody.length > 1e6) {
					$req.connection.destroy();
				}
			});

			$req.on('end', () => {
				// debugger;
				console.log('postData: %s', postBody);
				this._finish();
			})
		} else {
			this._finish();
		}
	}
	//----------------------------------------------------------------------------
	get promise() {
		return this.$deferred.promise;
	}
	//----------------------------------------------------------------------------
	_error(er = null) {
		if (!(er instanceof Error)) {
			er = new Error(er);
		}
		this.$deferred.reject(er);
	}
	//----------------------------------------------------------------------------
	_finish() {
		this.$deferred.resolve();
	}

}


////////////////////////////////////////////////////////////////////////////////
