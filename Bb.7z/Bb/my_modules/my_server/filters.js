'use strict';

let $GM;

// 過濾器的設定
const $filters = {};
module.exports = function(gm) {
	$GM = gm;
	return $filters;
};

{
	// 過濾指定 url
	$filters.filterUrl = function(urlList = [], override = false) {

		let $urlList = [
			{
				url: '/favicon.ico',
				callback: function(req, res) {
					res.writeHeader(204);
				}
			}
		];

		if (urlList) {
			if (override) {
				$urlList = urlList.slice();
			} else {
				$urlList = $urlList.concat(urlList);
			}
		}
		//----------------------------
		return async function(filterChain) {
			debugger;

			let callback;
			const {request, response} = filterChain;
			let reject = $urlList.some((d) => {
				const {url, callback} = d;

			});

			if (reject) {
				callback(req, res);
			} else {
				// 繼續往下執行
				await filterChain.doFilter();
			}
	}
	}
}
