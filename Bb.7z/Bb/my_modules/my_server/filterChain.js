'use strict';

let $GM;

// filter chain
class FilterChain {
	$filterList = [];
	$request;
	$response;
	$index = 0;
	$is_end = false;
	$server;
	//----------------------------------------------------------------------------
	constructor(server, filters) {
		this.$server = server;

		filters.forEach(o => {
			this.$filterList.push(o);
		});
	}
	//----------------------------------------------------------------------------
	async main(req, res, output) {
		this.$request = req;
		this.$response = res;
		this.$output = output;

		await this._doFilter();
	}
	//----------------------------------------------------------------------------
	async _doFilter() {
		debugger;
		let index = this.$index++;
		if (index < this.$filterList.length) {
			// 執行 filters 

			for (let i = 0; i < this.$filterList.length; i++) {
				debugger;
				const filterChainObj = this._getFilterChainObj();
				const obj = this.$filterList[i];
				if (typeof obj == 'function') {
					await obj(this.$request, this.$response, filterChainObj);
				} else {

					let o = new obj();
					if (typeof o.doFilter != 'function') {
						throw new Error('no doFilter() function');
					}
					await o.doFilter(this.$request, this.$response, filterChainObj);
				}
			}

		} else {
			await this.$output.main(this.$request, this.$response);
			this.$is_end = true;
		}
	}
	//----------------------------------------------------------------------------
	_getFilterChainObj() {
		const that = this;

		let count = 0;
		return {
			getServer() {
				return that.$server;
			},
			async doFilter() {
				if(count++ > 1){
					throw new Error('doFilter() 呼叫超過兩次');
				}				
				await that._doFilter();
			}
		};
	}
}

module.exports = function (gm) {
	$GM = gm;
	return FilterChain;
}
