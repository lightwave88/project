const $GM = require('./g_module.js');

module.exports = {
  Server: $GM['Server'],
  filters: $GM['filters'],
};

