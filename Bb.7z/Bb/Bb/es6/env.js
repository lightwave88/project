'use strict';

let $Bb;

// 環境資訊
const $ENV = {
  root: null,
  env: null,
  isWorker: null,
  path: null,
};

export { $ENV as ENV };
//------------------------------------------------------------------------------
class Env {
  $Bb;
  constructor() {
  }
  //--------------------------------------
  sameProcess() {
    this.is_workerEnv();
  }
  //--------------------------------------
  is_workerEnv() {
    if (typeof (WorkerGlobalScope) != 'undefined') {
      $ENV.isWorker = true;
    } else {
      $ENV.isWorker = false;
    }
  }
}
//------------------------------------------------------------------------------
class WebEnv extends Env {
  constructor() {
    super();
    let root = (typeof self == 'object' && self.self === self) ? self : null;
    $ENV.root = root;

    this.sameProcess();
    this.setGlobalVariable();
    this.has_();
  }
  //--------------------------------------
  setGlobalVariable() {
    window['$Bb'] = $Bb;
  }
  //--------------------------------------
  has_() {
    debugger;
    if (typeof window._ == 'function' || typeof window._ == 'object') {
      $Bb.extension(window._, function (key, fn) {
        window._.mixin({ key: fn });
      });
    } else {
      window._ = $Bb;
    }
  }

}
//------------------------------------------------------------------------------
class NodeJsEnv extends Env {
  constructor() {
    super($Bb);
    let root = (typeof global == 'object' && global.global === global) ? global : null;
    $ENV.root = root;

    this.sameProcess();
  }
}
//------------------------------------------------------------------------------
function getENV(_$Bb) {
  debugger;

  $Bb = _$Bb;

  if (is_nodeJsEnv()) {
    $ENV.env = 'nodejs';
    new NodeJsEnv();
  } else if (is_browserEnv()) {
    $ENV.env = 'browser';
    new WebEnv();
  } else {
    $ENV.env = 'unknow';
    new Env();
  }
  //-----------------------

  function is_nodeJsEnv() {
    let res = false;
    try {
      let checkList = [process, require('fs')];
      res = checkList.every((obj) => {
        return (obj != null && typeof obj == 'object');
      });
    } catch (error) { }
    return res;
  }

  function is_browserEnv() {
    if (typeof window != 'undefined' && typeof document != 'undefined') {
      return true;
    }
    return false;
  }
};

export { getENV };
