'use strict';
import { getENV } from './env.js';
import $tools_1 from './tools_1.js';

// 工具集
const $Bb = function () {

};
debugger;
const $Bb_proto = Object.getPrototypeOf($Bb);

export default $Bb;
export { $Bb };
//------------------------------------------------------------------------------
const $extension = {
  map: new Map(),
  concat(map) {
    if (map == null) {
      return;
    }
    Object.keys(map).forEach(key => {
      const el = map[key];
      this.map.set(key, el);
    });
  },
};
//------------------------------------------------------------------------------
$Bb_proto.mixin = function (obj) {
  if (obj == null) {
    return;
  }
  Object.keys(obj).forEach(key => {
    let fn = obj[key];

    if (key in $Bb_proto) {
      throw new Error('has same attr');
    }

    if (typeof fn != 'function') {
      return;
    }
    $Bb_proto[key] = fn;
  });
};


// 可把 $Bb 的功能擴充到其他模組
$Bb_proto.extension = function (module, callback) {
  $extension.map.forEach((fn, key) => {
    if (key in module) {
      return;
    }
    callback(key, fn);
  });
};
//------------------------------------------------------------------------------

(() => {
  debugger;
  // 注入功能
  $Bb.ENV = getENV($Bb);

  $Bb.mixin($tools_1.exports);
  $extension.concat($tools_1.extensions);
})();