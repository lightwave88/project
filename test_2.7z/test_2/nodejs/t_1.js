const $path = require('path');

let root = $path.resolve('.');

require(`${root}/my_module/a`);