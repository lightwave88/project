const $path = require('path');
const $fs = require('fs');
const root_dir = process.cwd();

const $tool = require(root_dir + '/my_modules/tool_1');

debugger;
let p = $tool.showFileList(root_dir,'/images');
p.then((fn)=>{
    debugger;
    let cont = fn('localhost:8082');
    console.log(cont);
});






