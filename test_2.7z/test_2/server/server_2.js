const $http = require('http');
const $url = require('url');
const $qs = require('querystring');
const $path = require('path');

const baseUrl = 'localhost';
const basePort = 8082;

$http.createServer(function ($req, $res) {
    debugger;
    const url_data = $url.parse($req.url, true);
    let { pathname, path } = url_data;

    pathname = $path.normalize(pathname);
    path = $path.normalize(path);


    $res.writeHead(200, { 'Content-Type': 'text/html' });

    console.log(pathname);

    $res.end(`<h1>pathname = ${pathname}</h1>
    <p>path = ${JSON.stringify(url_data)}</p>`);

}).listen(basePort, baseUrl);