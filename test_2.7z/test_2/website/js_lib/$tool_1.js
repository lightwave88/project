(function(global) {
    const $tool = {};
    global['$tool'] = $tool;
    //-----------------------
    $tool.array_rand = function array_rand(list) {

        if (list == null || Array.isArray(list)) {
            throw new TypeError("must be array data");
        }
        //------------------
        list = list.slice();

        if(list.length < 2){
            return list;
        }

        // debugger;
        let res_list = new Array(list.length);
        //------------------
        function judge() {
            // debugger;
            let res = [];
            list.forEach(function(v, i) {
                if (v != null) {
                    res.push(i)
                }
            });
            return res;
        }
        //------------------
        function random(a, b) {
            let c = (b - a) + 1;
            let r = Math.random() * c;
            r = Math.floor(r);
            r = (a + r);
            r = (r > b) ? b : r;
            return r;
        }
        //------------------
        while (true) {
            // debugger;
            // console.log("array_rand()");

            let no_assignList = judge();
            let len = no_assignList.length;

            if (len == 0) {
                break;
            } else if (len == 1) {
                let key = no_assignList[0];
                res_list[key] = list[key];
                list[key] = undefined;
            } else {
                let k_1 = 0;
                let k_2 = 1;

                if (len > 2) {
                    k_1 = random(0, len - 1);
                    while (true) {
                        k_2 = random(0, len - 1);
                        if (k_1 != k_2) {
                            break;
                        }
                    }
                }

                let key_1 = no_assignList[k_1];
                let key_2 = no_assignList[k_2];

                res_list[key_1] = list[key_2];
                res_list[key_2] = list[key_1];

                list[key_2] = undefined;
                list[key_1] = undefined;
            }
        }

        return res_list;
    };

})(window || this);
