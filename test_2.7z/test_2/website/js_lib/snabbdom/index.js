// debugger;
import { snabbdomBuddle } from './src/export.js';

export { snabbdomBuddle };
export default snabbdomBuddle;

(() => {
  if (typeof window != 'object' || typeof document != 'object') {
    return;
  }
  window['$snabbdom'] = snabbdomBuddle;
})();