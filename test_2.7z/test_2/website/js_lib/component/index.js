// 預先載入所需模組
import $GM from './gmodule.js';

(function () {
    if (!(typeof window == 'object' && typeof document == "object")) {
        return;
    }
    window['$component'] = $GM.get('api');
    window['$template'] = $GM.get('template'); 
})();

export default api;


