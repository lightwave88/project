
import component from './api.js';

(function(){

    if(!(typeof window == 'object' && typeof document == "object")){
        return;
    }
    window['$component'] = component;
})();

export default component;


