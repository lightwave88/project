// debugger;

// 預先載入所需模組
import $GM from './gmodule.js';

(function () {
  // debugger;
    if (!(typeof window == 'object' && typeof document == "object")) {
        return;
    }
    const $customElements = window['customElements'];    
    const $CompContainer = $GM.get('CompContainer');
    
    // 初始化 <x-com>
    $customElements.define('x-com', $CompContainer);
    
    window['$component'] = $GM.get('api');
    window['$templates'] = $GM.get('templates'); 
})();

const api = $GM.get('api');
export default api;


