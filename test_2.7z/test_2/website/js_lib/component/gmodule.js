const GModule = new Map();
export default GModule;

import tool from './tool.js';
GModule.set('tool', tool);
