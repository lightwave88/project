const GModule = new Map();
export default GModule;
//------------------------------------------------------------------------------

import tool from './tool.js';
GModule.set('tool', tool);

import CompContainer from './compContainer.js';
GModule.set('CompContainer', CompContainer);

import renderEngine from './renderEngines.js';
GModule.set('renderEngine', renderEngine);

import TemplateItem from './templateItem.js';
GModule.set('TemplateItem', TemplateItem);

import templates from './templates.js'
GModule.set('templates', templates);

import {api} from './api.js';
GModule.set('api', api);

