const GModule = new Map();
export default GModule;
//------------------------------------------------------------------------------

import tool from './tool.js';
GModule.set('tool', tool);

import loadQueue from './loadQueue.js';
GModule.set('loadQueue', loadQueue);

import CompContainer from './compContainer.js';
GModule.set('CompContainer', CompContainer);

import renderEngines from './renderEngines.js';
GModule.set('renderEngines', renderEngines);

import TemplateItem from './templateItem.js';
GModule.set('TemplateItem', TemplateItem);

// template 內的 使用者設定
import { XComponent } from './XComponent.js';
GModule.set('XComponent', XComponent);

import ComponentSelf from './componentSelf.js';
GModule.set('ComponentSelf', ComponentSelf);

import templates from './templates.js'
GModule.set('templates', templates);

import { api } from './api.js';
GModule.set('api', api);

