// debugger;

import $GM from './gmodule.js';

import engine_1 from './engine/engine_1.js';
import engine_2 from './engine/engine_2.js';
import engine_3 from './engine/engine_3.js';

let $engineList = [engine_1,engine_2,engine_3];
//------------------------------------------------------------------------------
// engine 必須繼承[]
class EngineInterface {

	constructor(options = {}) {
		// engine 的選項
		this.options = Object.assign({}, options);
	}

	init() {
		throw new Error('need override init()');
	}
	// 設置 content
	setContent(content) {
		throw new Error('need override setContent()');
	}
	// 取得 render 後的內文
	render(dom, context) {
		throw new Error('need override render()');
	}
}
//------------------------------------------------------------------------------
let $renderEngines_instance;

// 管理 engine
class RenderEngines {

	static getInstance(){
		if($renderEngines_instance == null){
			$renderEngines_instance = new RenderEngines();
		}
		return $renderEngines_instance;
	}

	constructor() {
		this.engineList = new Map();
		//------------------
		this._init();
	}
	//----------------------------------------------------------------------------
	_init() {
		// 注入
		
		$engineList.forEach((en) => {
			// debugger;
			// 注入 EngineInterface
			let $class = en(EngineInterface);
			this.engineList.set($class.engineName, $class);
		});
	}
	//----------------------------------------------------------------------------
	set(name, factory) {
		debugger;

		let $class = factory(EngineInterface);

		if (this.engineList.has(name)) {
			throw new Error(`has engine(${name})`);
		}

		this.engineList.set(name, $class);
	}
	//----------------------------------------------------------------------------
	get(name, options) {
		debugger;
		
		if (!this.engineList.has(name)) {
			return null;
		}
		let $class = this.engineList.get(name);
		const o = new $class(options);
		o.init();
		return o;
	}
	//----------------------------------------------------------------------------

}

export default (function () {
	return RenderEngines.getInstance();
})();
