debugger;

import $GM from './gmodule.js';

import engine_1 from './engine/engine_1.js';
import engine_2 from './engine/engine_2.js';
import engine_3 from './engine/engine_3.js';
//------------------------------------------------------------------------------
class EngineInterface {
	init() {
		throw new Error('need override init()');
	}
	// 設置 content
	setContent(content, options = {}) {
		throw new Error('need override setContent()');
	}
	// set data
	setData(data = {}) {
		throw new Error('need override setData()');
	}
	// 取得 render 後的內文
	render() {
		throw new Error('need override render()');
	}
}
//------------------------------------------------------------------------------
// 管理 engine
class RenderEngines {
			
	constructor() {
		this.engineList = new Map();
		//------------------
		this._init();
	}

	_init() {
		// 注入
		let list = [engine_1];
		list.forEach((en) => {
			// 注入 EngineInterface
			let $class = en(EngineInterface);
			this.engineList.set($class.name, $class);
		});
	}

	set(name, factory) {

		let $class = factory(EngineInterface);

		if (this.engineList.has(name)) {
			throw new Error(`has engine(${name})`);
		}

		this.engineList.set(name, $class);
	}

	get(name) {
		if (!this.engineList.has(name)) {
			return null;
		}
		let $class = this.engineList.get(name);
		const o = new $class();
		o.init(); 
		return o;
	}
	
	has(name){
		
	}
}

export default (function(){
	return new RenderEngines();
})();
