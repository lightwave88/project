import $GM from './gmodule.js';

// XComponent 系統方法
class XComponent_core {
    constructor() {
        this.$$$parent;
    }

    //--------------------------------------------------------------------------
    $$$setParent(parent) {
        this.$$$parent = parent;
    }

    get $state() {

    }

    set $state() {

    }

    get $props() {

    }

    set $props() {

    }
    //--------------------------------------------------------------------------
    get $container() {

    }

    get $shadowDom() {

    }

    get $rootDom() {

    }
    //--------------------------------------------------------------------------
    // 對外發射資訊
    $emit() {
        let container = this.$contianer;
    }
}
//------------------------------------------------------------------------------


// 實例化的 comp
// 使用者必須繼承
class XComponent extends XComponent_core {

    constructor() {
        super();

        this.$requireState = [];

        this.$requireProps = [];

        this.$mixins = [];
    }
    //--------------------------------------------------------------------------
    $getDefaultProps() {

    }

    $getDefaultState() {

    }
    
    // 數值類型驗證
    $propsTypeValidate(){
        
    }
    
    // 數值類型驗證
    $stateTypeValidate(){
        
    }
    // 從內部更新 comp.state
    $setState(data = {}){
        // data 可以是 [{}|promise]
    }
    //--------------------------------------------------------------------------
    // callback
    $init() {

    }
    // callback
    $stateWillUpdate() {
        // 若資料爲非同步，會先呼叫
    }
    // callback
    $stateDidUpdate() {

    }
    // callback
    $willMount() {

    }
    // callback
    $didMount() {

    }
    // callback
    $willUnmout() {

    }
}

export {
    XComponent
};
