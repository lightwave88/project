// 預先載入所需模組
import $GM from './gmodule.js';

(() => {
    debugger;
    
    const $customElements = window['customElements'];

    const $CompContainer = $GM.get('CompContainer');
    $customElements.define('x-com', $CompContainer);
})();
//------------------------------------------------------------------------------
const $component = {};

export {$component as api};


// 取得 template 的内容
$component.getTemplateContent = function (input, options) {
    const $tool = $GM.get('tool');
    return $tool.getTemplateContent(input, options);
};
