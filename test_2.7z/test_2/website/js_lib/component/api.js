import $GM from './gmodule.js';


const $component = {};

export default $component;


// 取得 template 的内容
$component.getTemplateContent = function (input, options) {
    const $tool = $GM.get('tool');
    return $tool.getTemplateContent(input, options);
};



