// debugger;

import $GM from './gmodule.js';

let $HTMLElement;
(() => {
  // 取得 HTMLElement
  try {
    $HTMLElement = window['HTMLElement'];
  } catch (er) {
    console.log(er);
  }
})();

if (typeof $HTMLElement != "function") {
  throw new Error('HTMLElement is undefined');
}
//------------------------------------------------------------------------------
// container
// 包刮 container 的指令
class CompContainer extends $HTMLElement {

  constructor() {
    // debugger;
    super();
    const shadowRoot = this.attachShadow({
      mode: 'open'
    });

    const core = new ContainerCore(this, shadowRoot);

    Object.defineProperty(this, '$$$xcom', {
      value: core,
      configurable: false,
      writable: false,
    });
  }
}
//------------------------------------------------------------------------------
// container 本體
// 避免在 dom 上留下太多參數
class ContainerCore {

  constructor(dom, shadowRoot) {
    // 裝 comp 的袋子
    this.$dom = dom;
    this.$shadowRoot = shadowRoot;

    // comp 的實例
    this.$compBag = new Map();

    this.$mountComp;

    // 記錄 slot 標簽
    this.$slots = {};

    this._init();
  }
  //----------------------------------------------------------------------------
  _init() {
    this._getSlot();
  }
  //----------------------------------------------------------------------------
  // 取得 slot
  _getSlot() {
    // debugger
    let slots = this.$dom.querySelectorAll('[slot]');
    slots = Array.from(slots);

    slots.forEach((s) => {
      // debugger
      let slotName = s.getAttribute('slot');
      this.$slots[slotName] = s.cloneNode(true);
      s.parentNode.removeChild(s);
    });
  }
  //----------------------------------------------------------------------------
  // ?????
  // 事先指定 components
  // 可事先載入
  setComponents() {

  }

  mount(compItemName = '', data) {

    let comp;
    // data 可以是 [{}|promise]
    if (this.$compBag.has(compItemName)) {
      comp = this.$compBag.get(compItemName);
    } else {
      // 新增

    }
    
    comp.mount();
  }

  // 從外部更新 comp.state
  setData(data = {}) {
    // data 可以是 [{}|promise]
  }

  unmount() {

  }
  // UI 必須通知使用者要等待
  wait() {

  }
  // UI 必須通知使用者要等待
  didWait() {

  }

  // 對内部發射訊息
  emit() {

  }
}


export default CompContainer;
