import $GM from './gmodule.js';

// container
// 包刮 container 的指令
class CompContainer {
    constructor() {
        // 裝 comp 的袋子
        this.$bag = new Map();
        
        this.$mountComp;
        
        // 記錄初始 tag 的内容
        this.$initDomTree;
    }
    //--------------------------------------------------------------------------
    // ??
    // 事先指定 components
    // 可事先載入
    setComponents(){
        
    }
    
    mount(compItemName = '', data){
        // data 可以是 [{}|promise]
    }
    
    // 從外部更新 comp.state
    setState(data = {}){
        // data 可以是 [{}|promise]
    }
    
    unmount(){
        
    }
    //--------------------------------------------------------------------------
}

export default CompContainer;
