import $GM from './gmodule.js';

// 管理 comp 的 load 流量 
class LoadQueue {

    constructor() {
        this.limit = 2;
        this.queue = [];
    }

}

export default LoadQueue;
