// debugger;

import $GM from './gmodule.js'; 


// 裝載 comp 的列表
class Components {
    constructor() {
        this.$compMap = {};
    }


    // 從 dom 取得 comp 內文
    getCompContent(name, targetDom, options = {}) {
        const $CompItem = $GM.get('CompItem');
        (new $CompItem(name)).setJob(targetDom, options);
    }

    // 從外部通訊取得 comp 內文
    getCompContentAsync(name, options = {}) {
        const $CompItem = $GM.get('CompItem');
        (new $CompItem(name)).setJobAsync(options);
    }

    // 系統取得指定的 comp
    // return [comp|promise]
    $getComp(name){

        if(!(name in this.$compMap)){
            throw new Error(`no these comp(${name})`);
        }
        const compItem = this.$compMap[name];

        // 視同步狀態決定返回值
        // return [function|promise]
        return compItem.getRender();
    }

    $hasComp(name){

    }
}
