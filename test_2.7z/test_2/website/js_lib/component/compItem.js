import $GM from './gmodule.js';

// comp 的藍圖
class CompItem {
    constructor(name) {

        this.isAsync;

        this.immediately;

        this.job;

        this.name = name;
        //-----------------------
        // 着色函式
        this.render;
        //-----------------------
        this.time_handle;

        this.pr;
    }

    // 同步取得 content 的方式
    setJob(targetDom, options = {}, immediately = false) {

        if (this.isAsync != null) {
            // 已初始化
            return;
        }

        this.isAsync = false;

        this.immediately = !!immediately;

        this.job = () => {
            const $tool = $GM.get('tool');
            let content = $tool.getTemplateContent(targetDom, options);
            this._makeRender(content);
        };

        if (this.immediately) {
            this.job();
        }
    }

    // 非同步取得 content 的方式
    setJobAsync(options = {}, immediately = false) {

        if (this.isAsync != null) {
            // 已初始化
            return;
        }

        this.immediately = !!immediately;

        this.isAsync = true;

        //------------------
        this.pr = new Promise(($res, $rej) => {

            this.time_handle = (function* () {
                let { ok, data } = yield;
                if (ok) {
                    $res(data);
                } else {
                    $rej(data);
                }
            })();

            this.time_handle.next();
        });
        //------------------

        pr.then((content) => {
            debugger;
            this._makeRender(content);
            this.time_handle.next({
                ok: true,
                data: (this.render)
            });
        });

        pr.catch((er) => {
            this.time_handle.next({
                ok: false,
                data: er
            });
        });
    }

    _makeRender(content) {
        // 暫時
        // 未來可選擇 template 模組
        this.render = _.template(content);
    }

    // 視取得 content 的方式，決定返回值
    getRender() {
        if (this.pr == null) {
            return this.render;
        }
        return this.pr;
    }
}