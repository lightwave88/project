import $GM from './gmodule.js';

// 著色引擎
const $engine = {
    "_": function (content, options = {}) {
        // 預設模板解析引擎
        const _ = window['_'];
        return _.template(content, options);
    },
};
//------------------------------------------------------------------------------

// comp 的藍圖
class TemplateItem {

    static setEngine(name, callback) {
        $engine[name] = callback;
    }
    //--------------------------------------------------------------------------
    constructor(name) {

        this.name = name;

        // 已經設定過
        this.isSetted = false;

        this.defaultEngine = "_";

        this.options = {};

        this.engine;

        this.immediately;

        this.job;
        //-----------------------
        // 着色函式
        this.render;
        //-----------------------
        this.waitJob;

        this.deferred;

        this.pr;
    }
    //--------------------------------------------------------------------------
    setContent(content) {

    }
    //--------------------------------------------------------------------------
    // 非同步取得 content 的方式
    setJobAsync(job, options = {}) {

        if (this.isSetted) {
            // 已初始化
            return;
        }
        this.isSetted = true;

        let {
            immediately = true,
            engine = null
        } = options;

        // 是否有指定解析引擎
        this.engine = (engine && engine in $engine) ? engine : this.defaultEngine;

        // 馬上就要 load，不等掛上
        this.immediately = !!immediately;
        //------------------
        // this._makeDeferred();

        let pr;

        if (job instanceof Promise) {
            pr = job;
        } else {
            if (immediately) {
                pr = this._load(job);
            } else {
                this.waitJob = job;
                this.deferred = this._makeDeferred();
                pr = this.deferred.promise();
            }
        }
        this.pr = pr.then((content) => {
            // 解析 this.render
            this._makeRender(content);
            return this.render;
        });
    }
    //--------------------------------------------------------------------------

    _load(job) {
        const loadQueue = LoadQueue.getInstance();
        return loadQueue.add(job);
    }
    //--------------------------------------------------------------------------
    _makeDeferred() {
        let handle;
        let pr;

        const def = {
            promise(){
                return pr;
            },
            resolve(data) {
                handle.next({
                    error: null,
                    data
                });
            },
            reject(er) {
                handle.next({
                    error: er,
                    data: null
                });
            }
        };

        pr = new Promise(($res, $rej) => {
            handle = (function* () {
                let {er, data} = yield;
                handle = null;
                if (er == null) {
                    $res(data);
                } else {
                    $rej(data);
                }
            })();
            handle.next();
        });

        return def;
    }
    //--------------------------------------------------------------------------
    _makeRender(content) {
        let factory = $engine[this.engine];
        this.render = factory(content, this.options);
    }
    //--------------------------------------------------------------------------
    // 視取得 content 的方式，決定返回值
    getRender() {
        if (this.pr == null) {
            return Promise.resolve(this.render);
        }

        if (this.deferred != null) {
            // 尚未 load
            // 的掛上才 load

            // 加入 load 隊列
            let p = this._load(this.waitJob);

            p.then((content) => {
                this.deferred.resolve(content);
            },(er)=>{
                this.deferred.reject(er);
            });
        }
        return this.pr;
    }
}


export default TemplateItem;
//------------------------------------------------------------------------------   
let $queue;
let $uid = 0;

// 管理 comp 的 load 流量 
class LoadQueue {

    static getInstance() {
        if ($queue == null) {
            $queue = new LoadQueue();
        }
        return $queue;
    }

    constructor() {
        this.limit = 2;
        this.queue = [];
        this.busy = 0;
    }

    add(job) {
        let id;

        let def = _makeDeferred();
        let j = {
            id,
            job: () => {
                let p = job();

            },
        };


    }

    jobEnd() {

    }

    _makeDeferred() {

        let handle;
        let pr;

        const def = {
            promise(){
                return pr;
            },
            resolve(data) {
                handle.next({
                    error: null,
                    data
                });
            },
            reject(er) {
                handle.next({
                    error: er,
                    data: null
                });
            }
        };

        pr = new Promise(($res, $rej) => {
            handle = (function* () {
                let {er, data} = yield;
                handle = null;
                if (er == null) {
                    $res(data);
                } else {
                    $rej(data);
                }
            })();
            handle.next();
        });

        return def;
    }
}