// debugger;

import $GM from './gmodule.js';

// 著色引擎
const $engine = {
  "es6":function(content){
    
  },
  "_": function(content, options = {}) {
    debugger;
    // 預設模板解析引擎
    const _ = window['_'];
    if (_ == null) {
      throw new Error('no _ module');
    }
    return _.template(content, options);
  },
};
//------------------------------------------------------------------------------

// comp 的藍圖
class TemplateItem {

  static getInstance(name) {
    return new TemplateItem(name);
  }

  static setEngine(name, callback) {
    $engine[name] = callback;
  }
  //--------------------------------------------------------------------------
  constructor(name) {

    this.name = name;

    // 已經設定過
    this.isSetted = false;

    this.defaultEngine = "_";

    this.options = {};

    this.engine;

    this.immediately;

    this.job;
    //-----------------------
    // 着色函式
    this.render;
    //-----------------------
    this.waitJob;

    this.deferred;

    this.pr;
  }
  //--------------------------------------------------------------------------
  setContent(content) {
    this._makeRender(content);
  }
  //--------------------------------------------------------------------------
  // 非同步取得 content 的方式
  setJobAsync(job, options = {}) {
    debugger;

    if (this.isSetted) {
      // 已初始化
      return;
    }

    this.isSetted = true;

    let {
      immediately = true,
        engine = null
    } = options;

    // 是否有指定解析引擎
    if (engine != null) {

      if (!(engine in $engine)) {
        throw new Error(`no these render engine(${engine})`);
      }

      this.engine = engine;
    } else {
      this.engine = this.defaultEngine;
    }

    // 馬上就要 load，不等掛上
    this.immediately = !!immediately;
    //------------------
    // this._makeDeferred();

    let pr;
    debugger;
    if (job instanceof Promise || typeof job.then == "function") {
      pr = job;
    } else {
      // job is function
      if (immediately) {
        // 馬上取得 tempalte 內文
        pr = this._load(job);
      } else {
        // 等被取用時才取得 tempalte 內文
        const $tool = $GM.get('tool');

        this.waitJob = job;
        this.deferred = $tool.deferred();
        pr = this.deferred.promise();
      }
    }
    //-----------------------
    this.pr = pr.then((content) => {
      debugger;
      // 取得 template 的內文後
      // 解析 this.render
      this._makeRender(content);
      return this.render;
    });
  }
  //--------------------------------------------------------------------------
  // 用隊列方式取得 template.content
  _load(job) {
    const loadQueue = LoadQueue.getInstance();
    return loadQueue.add(job);
  }
  //--------------------------------------------------------------------------
  _makeRender(content) {
    debugger;
    
    if(typeof content != "string"){
      throw new Error('template.content not string');
    }
    
    console.log(content);
    let factory = $engine[this.engine];
    let render_fun;
    try {
      render_fun = factory(content, this.options);
    } catch (er) {
      console.log(er);
    }

    this.render = render_fun;
  }
  //--------------------------------------------------------------------------
  // 返回 promise
  getRender() {
    if (this.pr == null) {
      return Promise.resolve(this.render);
    }

    if (this.deferred != null) {
      // 尚未 load
      // 的掛上才 load

      // 加入 load 隊列
      let p = this._load(this.waitJob);

      p.then((content) => {
        this.deferred.resolve(content);
      }, (er) => {
        this.deferred.reject(er);
      });
    }
    
    // promise 返回 render_fun
    return this.pr;
  }
}


export default TemplateItem;
//------------------------------------------------------------------------------   
let $queue;

// 管理 comp 的 load 流量 
class LoadQueue {

  static getInstance() {
    if ($queue == null) {
      $queue = new LoadQueue();
    }
    return $queue;
  }

  constructor() {
    this.limit = 1;
    this.busy = 0;
    this.queue = [];
  }
  //----------------------------------------------------------------------------
  add(_job) {
    debugger;

    if (typeof _job != "function") {
      throw TypeError('LoadQueue add() must be function');
    }

    const $tool = $GM.get('tool');

    const $this = this;

    let def = $tool.deferred();

    const job = {
      doJob: function() {
        console.log('job start');
        $this.busy++;
        let p = _job();
        job.def.pipe(p);
      },
      def,
    };

    let p = def.promise();

    this.queue.push(job);

    this._check();

    let end = ()=>{
      // 通知有任務結束
      this.jobEnd();
    };

    p.then(end, end);

    return p;
  }
  //----------------------------------------------------------------------------
  jobEnd() {
    console.log('job end');
    this.busy--;
    this._check();
  }
  //----------------------------------------------------------------------------
  _check() {
    if (!this.queue.length) {
      return;
    }
    if (this.busy >= this.limit) {
      return;
    }
    const job = this.queue.shift();

    job.doJob();
  }
}
