// debugger;

import $GM from './gmodule.js';
//------------------------------------------------------------------------------

// comp 的藍圖
class TemplateItem {

  static getInstance(name) {
    return new TemplateItem(name);
  }

  static setEngine(name, callback) {
    $engine[name] = callback;
  }
  //--------------------------------------------------------------------------
  constructor(name) {

    this.name = name;

    // 已經設定過
    this.isSetted = false;

    this.defaultEngine = "none";

    this.options = {};

    this.job;
    //-----------------------
    // 着色函式
    this.renderEngine;
    
    this.renderEngineName;

    this.commandClass;
    
    this.engine_options = {};
    //-----------------------
    // template 是否馬上 load
    this.immediately;
    
    // 是否有等待的工作
    // 要等 tempalteItem 掛上後才執行
    this.waitJob;

    //-----------------------
    this.deferred;

    this.pr;
    //-----------------------

    this.divDom = document.createElement('div');
  }
  //--------------------------------------------------------------------------
  // 取得 content
  setContent(content) {
    this._compile(content);
  }
  //--------------------------------------------------------------------------
  // 取得 content
  // 非同步取得 content 的方式
  setJobAsync(job, options = {}) {
    debugger;

    if (this.isSetted) {
      // 已初始化
      return;
    }

    this.isSetted = true;

    let {
      immediately = true,
        engine = null
    } = options;

    // 是否有指定解析引擎
    if (engine != null) {

      if (!(engine in $engine)) {
        throw new Error(`no these render engine(${engine})`);
      }

      this.engine = engine;
    } else {
      this.engine = this.defaultEngine;
    }

    // 馬上就要 load，不等掛上
    this.immediately = !!immediately;
    //------------------
    // this._makeDeferred();

    let pr;
    debugger;
    if (job instanceof Promise || typeof job.then == "function") {
      pr = job;
    } else {
      // job is function
      if (immediately) {
        // 馬上取得 tempalte 內文
        pr = this._load(job);
      } else {
        // 等被取用時才取得 tempalte 內文
        const $tool = $GM.get('tool');

        this.waitJob = job;
        this.deferred = $tool.deferred();
        pr = this.deferred.promise();
      }
    }
    //-----------------------
    this.pr = pr.then((content) => {
      debugger;
      // 取得 template 的內文後
      // 解析 this.render
      this._compile(content);
      return this.renderEngine;
    });
  }
  //--------------------------------------------------------------------------
  // 用隊列方式取得 template.content
  _load(job) {
    const loadQueue = $GM.get('loadQueue');
    let p = loadQueue.add(job);
    return p;
  }
  //--------------------------------------------------------------------------
  // 編譯
  _compile(content) {
    debugger;

    if (typeof content != "string") {
      throw new Error('template.content not string');
    }
    
    const $tool = $GM.get('tool');
    const $XComponent = 

    // 先確定文本的 engine
    this.divDom.innerHTML = content;
    const engineTag = this.divDom.querySelector('templaye-engine');

    if (engineTag != null) {
      // 取得 engine 的相關設定
      let attrMap = $tool.getDomAttrs(engineTag);
      this.renderEngineName = engineTag.innerText.trim();
      Object.assign(this.engine_options, attrMap);
      this.divDom.removeChild(engineTag);
    }
    //-----------------------
    // 取出 commandClass
    
    let scriptTag;
    const scriptList = this.divDom.querySelectorAll('script');
    const $XComponent = $GM.get('XComponent');

    scriptList.some((node) => {
      if (node.hasAttribute('isCommand')) {
        scriptTag = node;
        return true;
      }
      return false;
    })

    if (scriptTag != null) {
      this.divDom.removeChild(scriptTag);
    }
    // 取出 commandClass 工廠的內文
    let funContent =
      `
      debugger;
      
      ${scriptTag.innerHTML}
      
      if(typeof getCommandClass === "function"){
        return getCommandClass();
      }else{
        return null
      }
    `;
    let factory = new Function('XComponent', funContent);
    
    let res = factory($XComponent);
    if (res != null) {
      this.commandClass = res;
    }

    //-----------------------
    // 確定 renderEngine 並初始化
    const $renderEngines = $GM.get('renderEngines');
    
    // 取得最後所需
    this.renderEngine = $renderEngines.get(this.renderEngineName, this.engine_options);
    
    if(this.renderEngine == null){
      throw new Error(`to this templateEngine(${this.renderEngineName})`);
    }
  }
  //--------------------------------------------------------------------------
  // 由 comp 呼叫
  // 返回 promise
  getRender() {
    if (this.pr == null) {
      return Promise.resolve(this.renderEngine);
    }

    if (this.deferred != null) {
      // 尚未 load
      // 的掛上才 load

      // 加入 load 隊列
      let p = this._load(this.waitJob);

      p.then((content) => {
        this.deferred.resolve(content);
      }, (er) => {
        this.deferred.reject(er);
      });
    }

    // promise 返回 renderEngine
    return this.pr;
  }
}


export default TemplateItem;
//------------------------------------------------------------------------------   

