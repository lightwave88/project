// debugger;

import $GM from './gmodule.js';
//------------------------------------------------------------------------------

// comp 的藍圖
class TemplateItem {

  static getInstance(name) {
    return new TemplateItem(name);
  }

  static setEngine(name, callback) {}

  //--------------------------------------------------------------------------
  constructor(name) {

    this.name = name;

    // 已經設定過
    this.isSetted = false;

    this.defaultEngine = "none";

    this.options = {};

    this.job;
    //-----------------------
    // 着色函式
    this.renderEngine;

    this.renderEngineName;
    this.default_renderEngineName = 'none';

    this.commandClass;

    this.engine_options = {};
    //-----------------------
    // template 是否馬上 load
    this.immediately;

    // 是否有等待的工作
    // 要等 tempalteItem 掛上後才執行
    this.waitJob;

    //-----------------------
    this.deferred;

    this.pr;
    //-----------------------

    this.divDom = document.createElement('div');
  }
  //--------------------------------------------------------------------------
  // 取得 content
  setContent(content) {
    this._compile(content);
  }

  setDom(dom) {
    this._compile(dom);
  }
  //--------------------------------------------------------------------------
  // 取得 content
  // 非同步取得 content 的方式
  setJobAsync(job, options = {}) {
    debugger;

    if (this.isSetted) {
      // 已初始化
      return;
    }

    this.isSetted = true;

    let {
      immediately = true,
    } = options;

    // 馬上就要 load，不等掛上
    this.immediately = !!immediately;
    //------------------
    let pr;
    debugger;
    if (job instanceof Promise || typeof job.then == "function") {
      immediately = true;
      pr = job;
    } else {
      // job is function
      if (immediately) {
        // 馬上取得 tempalte 內文
        pr = this._load(job);
      } else {
        // 等被取用時才取得 tempalte 內文
        const $tool = $GM.get('tool');

        this.waitJob = job;
        this.deferred = $tool.deferred();
        pr = this.deferred.promise();
      }
    }
    //-----------------------
    this.pr = pr.then((content) => {
      debugger;
      // 取得 template 的內文後
      // 解析 this.render
      this._compile(content);
    });
  }
  //--------------------------------------------------------------------------
  _getResult() {
    let renderEngine = this.renderEngine;
    let commandClass = this.commandClass;

    return {
      renderEngine,
      commandClass
    };
  }

  // 用隊列方式取得 template.content
  _load(job) {
    const loadQueue = $GM.get('loadQueue');
    let p = loadQueue.add(job);
    return p;
  }
  //--------------------------------------------------------------------------
  // 編譯
  _compile(content) {
    debugger;

    if (typeof content != "string") {
      throw new Error('template.content not string');
    }

    const $tool = $GM.get('tool');

    //-----------------------
    // 先確定文本的 engine
    this.divDom.innerHTML = content;
    const engineTag = this.divDom.querySelector('template-engine');

    if (engineTag != null) {
      // 取得 engine 的相關設定
      let attrMap = $tool.getDomAttrs(engineTag);
      this.renderEngineName = engineTag.innerText.trim();
      Object.assign(this.engine_options, attrMap);
      this.divDom.removeChild(engineTag);
    } else {
      this.renderEngineName = this.default_renderEngineName;
    }
    //-----------------------
    // 取出 commandClass

    let scriptTag;
    let scriptList = this.divDom.querySelectorAll('script');
    scriptList = Array.from(scriptList);

    scriptList.some((node) => {

      let judge = node.hasAttribute('isCommand') || node.hasAttribute('iscommand');

      if (judge) {
        scriptTag = node;
        node.parentNode.removeChild(node);
        return true;
      }
      return false;
    });

    debugger;

    // 篩選出 template.content
    let childList = Array.from(this.divDom.childNodes);

    this.divDom = null;

    childList.forEach((node) => {
      debugger;
      let parent = node.parentNode;
      parent.removeChild(node);

      if (this.divDom == null && ('innerHTML' in node)) {
        this.divDom = node;
        return;
      }
    });
    //-----------------------

    // 取出 commandClass 工廠的內文
    let funContent =
      `
      debugger;
      
      ${scriptTag.innerHTML}
      
      if(typeof getCommandClass === "function"){
        return getCommandClass();
      }else{
        return null
      }
    `;

    debugger;

    let factory = new Function('XComponent', funContent);

    const $XComponent = $GM.get('XComponent');

    let res = factory($XComponent);

    if (res != null) {
      this.commandClass = res;
    }

    //-----------------------
    // 確定 renderEngine 
    // 取得並初始化
    const $renderEngines = $GM.get('renderEngines');

    // 取得最後所需
    this.renderEngine = $renderEngines.get(this.renderEngineName, this.engine_options);

    if (this.renderEngine == null) {
      throw new Error(`to this templateEngine(${this.renderEngineName})`);
    }

    this.renderEngine.setContent(this.divDom.cloneNode(true));
  }
  //--------------------------------------------------------------------------
  // 由 comp 呼叫
  // 返回 promise
  $getRender() {
    let p;

    if (this.pr == null) {
      p = Promise.resolve(this._getResult());
      return p;
    }

    if (this.deferred != null) {
      // 尚未 load
      // 的掛上才 load

      // 加入 load 隊列
      p = this._load(this.waitJob);

      this.deferred.pipe(p);
    }

    // promise 返回 renderEngine
    p = this.pr.then(() => {
      debugger;
      return this._getResult();
    });

    return p;
  }
}


export default TemplateItem;
//------------------------------------------------------------------------------
