import $GM from './gmodule.js';

let $queue_instance;

// 管理 comp 的 load 流量 
class LoadQueue {

  static getInstance() {
    if ($queue_instance == null) {
      $queue_instance = new LoadQueue();
    }
    return $queue_instance;
  }

  constructor() {
    this.limit = 1;
    this.busy = 0;
    this.queue = [];
  }
  //----------------------------------------------------------------------------
  add(_job) {
    debugger;

    if (typeof _job != "function") {
      throw TypeError('LoadQueue add() must be function');
    }

    const $tool = $GM.get('tool');

    const $this = this;

    let def = $tool.deferred();

    const job = {
      doJob: function() {
        console.log('job start');
        $this.busy++;
        let p = _job();
        job.def.pipe(p);
      },
      def,
    };

    let p = def.promise();

    this.queue.push(job);

    this._check();

    let end = () => {
      // 通知有任務結束
      this.jobEnd();
    };

    p.then(end, end);

    return p;
  }
  //----------------------------------------------------------------------------
  jobEnd() {
    console.log('job end');
    this.busy--;
    this._check();
  }
  //----------------------------------------------------------------------------
  _check() {
    if (!this.queue.length) {
      return;
    }
    if (this.busy >= this.limit) {
      return;
    }
    const job = this.queue.shift();

    job.doJob();
  }
}

export default (()=>{
  return LoadQueue.getInstance();
})();