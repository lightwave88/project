import $GM from './gmodule.js';

let $queue_instance;

// 管理 comp 的 load 流量 
class LoadQueue {

  static getInstance() {
    if ($queue_instance == null) {
      $queue_instance = new LoadQueue();
    }
    return $queue_instance;
  }

  constructor() {
    this.limit = 1;
    this.busy = 0;
    this.queue = [];
  }
  //----------------------------------------------------------------------------
  add(_job) {
    debugger;

    if (typeof _job != "function") {
      throw TypeError('LoadQueue add() must be function');
    }

    const $tool = $GM.get('tool');    

    let def = $tool.deferred();
    //-----------------------
    // 組成任務
    const job = {
      doJob: () => {
        console.log('job start');
        this.busy++;
        let p;
        debugger;
        try {
          p = _job();
          if(!(p instanceof Promise)){
            throw new TypeError('job must return promise');
          }
        } catch (e) {
          p = Promise.reject(e);
        }
        debugger;
        p.then(job.end, job.end);

        job.def.pipe(p);
      },
      def,
      end: () => {
        this.jobEnd();
      }
    };
    //-----------------------
    // 把任務加入隊列
    this.queue.push(job);

    this._check();

    let p = def.promise();
    return p;
  }
  //----------------------------------------------------------------------------
  jobEnd() {
    console.log('job end');
    this.busy--;
    this._check();
  }
  //----------------------------------------------------------------------------
  _check() {
    if (!this.queue.length) {
      return;
    }
    if (this.busy >= this.limit) {
      return;
    }
    const job = this.queue.shift();

    job.doJob();
  }
}

export default (() => {
  return LoadQueue.getInstance();
})();
