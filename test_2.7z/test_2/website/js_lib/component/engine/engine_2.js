debugger;

const $name = '_';

export default function(Interface) {
	
	// _.template
	class Engine_2 extends Interface {
		constructor(options) {
			super(options);

			this._;
			this.data;
			this.renderFn;
		}
		init() {
			this._ = window['_'];
			if (this._ == null) {
				throw new Error('no _ module');
			}
		}
		// 設置 content
		setContent(domTree) {
			this.content = domTree.innerHTML;
			this.renderFn = _.template(this.content, this.options);
		}
		// set data
		setData(data = {}) {
			Object.assign(this.data, data);
		}
		// 
		render() {

		}
	}

	Engine_2.engineName = $name;

	return Engine_2;
};
