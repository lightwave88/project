debugger;

const $name = '_';

export default function(Interface) {
	
	// _.template
	class Engine_2 extends Interface {
		constructor() {
			this._;
			this.data;
			this.renderFn;
		}
		init() {
			this._ = window['_'];
			if (this._ == null) {
				throw new Error('no _ module');
			}
		}
		// 設置 content
		setContent(content, options = {}) {
			this.renderFn = _.template(content, options);
		}
		// set data
		setData(data = {}) {
			Object.assign(this.data, data);
		}
		// 
		render() {

		}
	}

	Engine_2.engineName = $name;

	return Engine_2;
};
