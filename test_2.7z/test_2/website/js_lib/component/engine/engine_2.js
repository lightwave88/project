// debugger;

const $name = '_';

function factory(Interface) {
	
	// _.template
	class Engine_2 extends Interface {
		constructor(options) {
			super(options);

			this._;
			this.data;
			this.renderFn;
		}
    //--------------------------------------------------------------------------
		init() {
			this._ = window['_'];
			if (this._ == null) {
				throw new Error('no _ module');
			}
		}
    //--------------------------------------------------------------------------
		// 設置 content
		setContent(domTree) {
			this.content = domTree.innerHTML;
			this.renderFn = _.template(this.content, this.options);
		}
		//-------------------------------------------------------------------------- 
		render(dom, context) {

		}
	}

	Engine_2.engineName = $name;

	return Engine_2;
}

export default factory;
