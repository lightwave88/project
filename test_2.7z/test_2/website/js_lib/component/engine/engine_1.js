// debugger;

const $name = 'none';

function factory(Interface) {

	// 不做任何處理
	class Engine_1 extends Interface {
		constructor(options) {
			super(options);

			this.content;
			this.rootDom = document.createDocumentFragment();
		}
    //--------------------------------------------------------------------------
		init() {
			this._ = window['_'];
			if (this._ == null) {
				throw new Error('no _ module');
			}
		}
    //--------------------------------------------------------------------------
		// 設置 content
		setContent(domTree) {
			let childList = domTree.childNodes();
			childList = Array.from(childList);

			childList.forEach((node) => {

			});
		}
		//-------------------------------------------------------------------------- 
		render(dom, context) {
			return this.rootDom.cloneNode(true);

		}
	}

	Engine_1.engineName = $name;

	return Engine_1;
};

export default factory;