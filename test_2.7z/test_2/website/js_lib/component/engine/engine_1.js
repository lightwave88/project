debugger;

const $name = 'default';

export default function(Interface) {
	
	// 不做任何處理
	class Engine_1 extends Interface {
		constructor() {
			this.content;
			this.rootDom = document.createDocumentFragment();
		}
		init() {
			this._ = window['_'];
			if (this._ == null) {
				throw new Error('no _ module');
			}
		}
		// 設置 content
		setContent(content) {
			this.rootDom.innerHTML = content;
		}
		// set data
		setData() {
			
		}
		// 
		render() {
				return this.rootDom.cloneNode(true);
				
		}
	}

	Engine_1.engineName = $name;

	return Engine_1;
};