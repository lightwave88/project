debugger;

const $name = 'es6';

export default function(Interface) {
	
	// _.template
	class Engine_3 extends Interface {
		constructor(options) {
			super(options);
			
			this.data;
			this.renderFn;
		}
		init() {
			
		}
		// 設置 content
		setContent(content, options = {}) {
			
		}
		// set data
		setData(data = {}) {
			Object.assign(this.data, data);
		}
		// 
		render() {

		}
	}

	Engine_3.engineName = $name;

	return Engine_3;
};