debugger;

const $name = 'es6';

export default function(Interface) {

	// _.template
	class Engine_3 extends Interface {
		constructor(options) {
			super(options);

			this.data;
			this.renderFn;

			this.reg = /<x-replace no="(\d+)" />/;

			this.rootDom;
			this.replaceMap = {};
		}
		init() {

		}
		// 設置 content
		setContent(domTree) {
			this.rootDom = domTree;

			let scriptList = document.querySelectorAll('script');
			scriptList = Array.from(scriptList);
			scriptList.forEach((node, i) => {
				this.replaceMap[i] = node.innerHTML;
				node.outerHTML = `<x-replace no="${i}" />`;
			});
			//------------------
			let content = this.rootDom.innerHTML;


		}
		// set data
		setData(data = {}) {
			Object.assign(this.data, data);
		}
		// 
		render() {

		}
	}

	Engine_3.engineName = $name;

	return Engine_3;
};
