// debugger;

const $name = 'es6';

function factory(Interface) {

	// _.template
	class Engine_3 extends Interface {
		constructor(options) {
			super(options);

			this.renderFn;

			this.reg_1 = /<x-script>(\d+)<\/x-script>/;
			this.reg_2 = /(^`)|([^]?)`/;

			this.rootDom;
			this.replaceMap = {};
		}
		//--------------------------------------------------------------------------
		init() {

		}
		//--------------------------------------------------------------------------
		// 設置 content
		setContent(domTree) {
			debugger;
			this.rootDom = domTree;

			let scriptList = domTree.querySelectorAll('script');
			scriptList = Array.from(scriptList);

			scriptList.forEach((node, i) => {
				debugger;
				let parent = node.parentNode;

				this.replaceMap[i] = node.innerHTML;
				let newNode = document.createElement('x-script');
				newNode.innerHTML = i;

				parent.replaceChild(newNode, node);
			});
			//------------------
			let content = this.rootDom.outerHTML;

			let list = [];
			let str = content;

			list.push(`
        debugger;
        const $$$out = [];
      `);

			while (str.length) {
				let res = this.reg_1.exec(str);

				if (res == null) {
					list.push(this._checkContent(str));
					break;
				}
				//-------------
				let {
					index
				} = res;

				let a = str.slice(0, index);
				list.push(this._checkContent(a));

				let b = res[0];
				list.push(this._checkContent(b, true, res[1]));

				let i = index + b.length;
				str = str.slice(i);
			}

			list.push(`        
        let $$$res = $$$out.join('');;
        $$$out.length = 0;
        return $$$res;
      `);
			debugger;
			let fnContent = list.join('\n');

			this.renderFn = new Function(fnContent);
		}
		//--------------------------------------------------------------------------
		render(dom, context) {
			context = context || null;
			let content = this.renderFn.call(context);
			dom.innerHTML = content;
		}
		//--------------------------------------------------------------------------
		_checkContent(content, isCommand, index) {
			isCommand = !!isCommand;

			if (isCommand) {
				index = parseInt(index, 10);
				return this.replaceMap[index]
			}

			let value = this._check_1(content)
			value = "$$$out.push(`" + value + "`);";
			return value;
		}
		//--------------------------------------------------------------------------
		_check_1(content) {
			// 為內文的 ` 脫衣
			let reg = RegExp(this.reg_2, 'g');

			let value = content.replace(reg, (m, g1, g2) => {
				if (g1 != null) {
					return "\\`"
				}
				if (g2 == '\\') {
					return m;
				}
				return (g2 + "\\`");
			});
			//------------------
			return value;
		}
	}

	Engine_3.engineName = $name;

	return Engine_3;
}

export default factory;
