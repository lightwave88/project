// debugger;

import $GM from './gmodule.js';

// comp 的本身
class ComponentSelf {

    constructor(templateName, data) {

        // xcomponent 的實例
        this.$compSetting;

        this.$userSetting;

        // template 內文
        this.$templateItem;
        
        // 從 templateItem 取得 render_fun
        // render_fun 可以返回三種模式
        // [dom|content|vnode]
        this.renderEngine;
        
        // 裝 unmount domTree 的容器
        this.temp_fragNode;;
        
        // 是否正在挂上中
        this.is_mount = false;
        
        
        //----------------------------
        // 資料
        this.$normal_data = {};



        // 會通知變動的資料
        // 讓資料直接與外部相連
        this.$reactive_data = {};
        //----------------------------

        this._init(templateName, data);
    }
    //--------------------------------------------------------------------------
    _init(){
      
    }
    
    //--------------------------------------------------------------------------
    setData() {

    }

    getData() {

    }


    bindData(){

    }

    emit(){
        
    }
    //--------------------------------------------------------------------------
    // 當使用 template 模式時
    renderTemplate(data) {

    }
    //--------------------------------------------------------------------------
    mount() {

    }

    $setState() {

    }
    //--------------------------------------------------------------------------
}
