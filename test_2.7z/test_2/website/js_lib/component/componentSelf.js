import $GM from './gmodule';

// comp 的本身
class ComponentSelf {

    constructor(templateName, data) {

        // xcomponent 的實例
        this.$compSetting;

        this.$userSetting;

        // 藍本
        this.$templateList = new Map();

        // 裝 unmount domTree 的容器
        this.temp_fragNode;;
        // 是否正在挂上中
        this.is_mount = false;
        //----------------------------
        // 資料
        this.$normal_data = {};

        // 會通知變動的資料
        // 讓資料直接與外部相連
        this.$reactive_data = {};
        //----------------------------

        this.$init(data);
    }
    //--------------------------------------------------------------------------
    setData() {

    }

    getData() {

    }


    bindData(){

    }

    emit(){
        
    }
    //--------------------------------------------------------------------------
    // 當使用 template 模式時
    renderTemplate(data) {

    }
    //--------------------------------------------------------------------------
    $mount() {

    }

    $setState() {

    }
    //--------------------------------------------------------------------------
}
