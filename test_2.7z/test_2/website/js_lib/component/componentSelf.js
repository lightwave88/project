import $GM from './gmodule';

// comp 的本身
class ComponentSelf {

    constructor(compItemName, data) {

        // xcomponent 的實例
        this.$compSetting;

        this.$userSetting;

        // 藍本
        this.$compItemName = compItemName;

        // 裝 unmount domTree 的容器
        this.temp_fragNode;;
        // 是否正在挂上中
        this.is_mount = false;

        // 資料
        this.$state = {};

        this.$props = {};

        this.$init(data);
    }
    //--------------------------------------------------------------------------
    setSate() {

    }

    getSate() {

    }

    //--------------------------------------------------------------------------
    // 當使用 template 模式時
    renderTemplate(data) {

    }
    //--------------------------------------------------------------------------
    $mount() {

    }

    $setState() {

    }
    //--------------------------------------------------------------------------
}
