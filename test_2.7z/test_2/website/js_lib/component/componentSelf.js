// debugger;

import $GM from './gmodule.js';

// comp 的本身
class ComponentSelf {

    constructor(options = {}, data) {
        this.$temp_data = {};
        this.$data = {};
        // 會通知變動的資料
        // 讓資料直接與外部相連
        this.$reactive_data = {};
        //----------------------------
        // xcomponent 的實例
        this.$command;
        this.$userSetting;

        this.$keepAlive = false;

        this.$container;
        //----------------------------
        // template 內文
        this.$templateItem;

        // 裝 unmount domTree 的容器
        this.$fragDom;
        this.$rootDom;
        this.$shadowRoot;

        // 是否正在挂上中
        this.$is_show = false;

        //----------------------------
        this.$renderEngine;
        this.$commandClass;
        //----------------------------
        this.$init_pr;
        this.$data_pr;

        // 記録有多少等待中的任務
        this.$wait_commandCount = 0;

        this._init(options, data);
    }
    //--------------------------------------------------------------------------
    _init(options, data = {}) {
        let {
            index,
            templateName,
            container
        } = options;

        this.$container = container;
        this.$keepAlive = this.$container.$keepAlive;
        //-----------------------
        Object.assign(this.$temp_data, data);


        this.$init_pr = (async function () {
            this.wait_commandCount++;

            const $Templates = $GM.get('Templates');
            const tempItem = $Templates.get(templateName);

            const { renderEngine, commandClass } = await tempItem.promise();

            this.$renderEngine = renderEngine;
            this.$commandClass = commandClass;

            this.$init_pr = null;
            this.wait_commandCount--;
        }).call(this);
        //-----------------------


    }

    //--------------------------------------------------------------------------
    get promise() {
        let checkList = [this.$init_pr, this.$data_pr];

        let pr_list = checkList.filter((pr) => {
            if (pr instanceof Promise) {
                return true;
            }
            return;
        });

        let pr;
        if (pr_list.length == 0) {
            pr = Promise.resolve();
        } else if (pr_list.length == 1) {
            pr = pr_list.pop();
        } else {
            pr = Promise.all(pr_list);
            pr = pr.then(() => { });
        }
        return pr;
    }

    // 是否完成初始化
    get $is_init() {
        return (this.$renderEngine != null);
    }

    get wait_commandCount() {
        return this.$wait_commandCount;
    }

    set wait_commandCount(count) {
        if (count < 0) {
            throw new Error('wait_commandCount < 0');
        }
        this.$wait_commandCount = count;
    }
    //--------------------------------------------------------------------------
    // 是否有命令正在處理中    
    get $is_inAction() {
        return this.$wait_commandCount > 0;
    }
    //--------------------------------------------------------------------------
    // 初始化綁定的資料
    initBindData(data) {

    }

    // 會先經過 user 的 callback
    // 不會先設定 $data
    setData(data) {
        if (this.$is_inAction) {
            // 正有命令在執行
            return;
        }

        // 是否有等待的事物
        let pr = this.promise;

        this.wait_commandCount++;

        if (data instanceof Promise) {
            this.$command.$dataWillUpdate();
        }

        pr = pr.then(() => {
            return data;
        });

        pr.then((data) => {
            this.$command.$dataUpdate(data);
            this.wait_commandCount--;
        });

        pr.catch(() => {
            this.wait_commandCount--;
        });
    }
    // 內部用
    _setData(k, v) {
        if (typeof k === 'string') {
            this.$data[k] = v;
            return;
        }
        Object.assign(this.$data, k);
    }
    //--------------------------------------------------------------------------
    getData(k, v) {
        if (k == null) {
            return this.$data;
        }
        return this.$data[k];
    }

    emit() {

    }
    //--------------------------------------------------------------------------
    // 當使用 template 模式時
    renderTemplate(data) {

    }
    //--------------------------------------------------------------------------
    _initMount(data) {

        let pr_1 = this.promise;
        let pr_2 = Promise.resolve(data);

        this.$data_pr = pr_2;

        // callback
        this.$command.$willMount();

        pr = Promise.all([pr_2, pr_1]);

        pr = pr.then((list) => {
            let d = Object.assign({}, this.$temp_data, list[0]);
            this.$temp_data = {};

            // callback
            this.$command.$initMount(d);

            this.$data_pr = null;
            this.wait_commandCount--;
        });
    }

    mount(data) {
        if (this.$is_inAction) {
            return;
        }

        this.wait_commandCount++;



        if (!this.$keepAlive || !this.$is_init) {
            // 沒有 cache
            this._initMount(data);
            return;
        }
        //----------------------------

        // 掛上 cache, visibility = hidden
        
        // 呼叫 command.mount()

        // visibility = show

    }

    unmout(data) {

    }


    //--------------------------------------------------------------------------
}

export default ComponentSelf;