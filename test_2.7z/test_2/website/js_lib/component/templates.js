import $GM from './gmodule';

const $templateMap = {};

let $loadQueue;

class Templates {

    static setEngine(name, callback) {
        const $TemplateItem = $GM.get('TemplateItem');
        $TemplateItem.setEngine(name, callback);

    }
    //--------------------------------------------------------------------------
    static fromContent(name, content, options = {}) {

        const $TemplateItem = $GM.get('TemplateItem');
        const tempItem = new $TemplateItem(name);
        tempItem.setContent(pr, options);

        $templateMap[name] = tempItem;
    }

    // 返回 render_fun
    static getfromContent(content, options = {}) {

    }
    //--------------------------------------------------------------------------
    static async fromAjax(name, options = {}) {

        const $TemplateItem = $GM.get('TemplateItem');
        const tempItem = new $TemplateItem(name);


        function callback() { 
            
         }

        tempItem.setJobAsync(callback, options);

        $templateMap[name] = tempItem;

    }

    static async getFromAjax(name, options = {}) {

    }
    //--------------------------------------------------------------------------
    // 從遠端取得內文
    static async fromAsync(name, pr, options = {}) {

        const $TemplateItem = $GM.get('TemplateItem');
        const tempItem = new $TemplateItem(name);
        tempItem.setJobAsync(pr, options);

        $templateMap[name] = tempItem;
    }

    static async getFromAsync(name, pr, options = {}) {

    }
    //--------------------------------------------------------------------------
    static fromDom(name, targetDom, options = {}) {
        let {
            // 模板内容是 jsp 格式
            jspformat = false,
            // 包含 parent 標簽
            outer = false,
            // 讀取 dom 模板内容后，是否要移除
            remove = true,
        } = options;

        if (typeof document == 'undefined') {
            throw new Error('not browser environment');
        }

        if (typeof targetDom == 'string') {
            targetDom = document.querySelector(targetDom);
            if (targetDom == null) {
                throw new Error("cant't find dom");
            }
        }

        if (!(targetDom instanceof Node)) {
            throw new TypeError('must be dom');
        }
        let sourceDom = targetDom;
        let content;
        while (true) {
            debugger;

            switch (sourceDom.nodeName) {
                case 'TEMPLATE':
                    sourceDom = sourceDom.content;
                    continue;
                    break;
                case '#document-fragment':
                    outer = false;
                    let root = document.createElement('div');
                    root.appendChild(sourceDom);
                    sourceDom = root;
                    root = null;
                    break;
                case 'SCRIPT':
                    outer = false;
                default:
                    if (!('innerHTML' in sourceDom)) {
                        throw new TypeError('no innerHTML attr');
                    }
                    break;
            } // end switch
            break;
        } //endWhile
        //-----------------------
        if (remove == true && targetDom.parentNode != null) {
            targetDom.parentNode.removeChild(targetDom);
        }

        content = (outer === true) ? sourceDom.outerHTML : sourceDom.innerHTML;
        if (jspformat) {
            content = Templates.checkJspFormat(content);
        }

        sourceDom.innerHTML = '';
        sourceDom = null;
        //-----------------------
        const $TemplateItem = $GM.get('TemplateItem');

        const tempItem = new $TemplateItem(name);
        tempItem.setContent(content, options);

        $templateMap[name] = tempItem;
    };

    static getFromDom(targetDom, options = {}) {
    }
    //--------------------------------------------------------------------------

    static checkJspFormat(content) {
        const reg = /\&lt;%([^]+?)%\&gt/g;
        content = content.replace(reg, (m, g1) => {
            return '<%' + g1 + '%>';
        });
        return content;
    };
    
    static $addLoadob(){
        
    }
}

export default Templates;


//------------------------------------------------------------------------------



// template load 的隊列
// 避免一次發出太多要求
class LoadQueue {

}




