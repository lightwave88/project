// debugger;

import $GM from './gmodule.js';

// 記録登陸的 template
let $templates_instance;

class Templates {

  static getInstance() {
    if ($templates_instance == null) {
      $templates_instance = new Templates();
    }
    return $templates_instance;
  }

  constructor() {
    this.$templateMap = {};
  }

  getTemplate(name) {
    if (!(name in this.$templateMap)) {
      return null;
    }
    return this.$templateMap[name];
  }

  setTempalte(name, template) {
    this.$templateMap[name] = template;
  }
  //----------------------------------------------------------------------------
  static setEngine(name, _class) {
    const $TemplateItem = $GM.get('TemplateItem');
    $TemplateItem.setEngine(name, _class);
  }
  //----------------------------------------------------------------------------
  // 取得 template
  static getTemplate(name) {
    return Templates.getInstance().getTemplate(name);
  }

  // 取得 template.render
  static getRender(name) {
    let template = Templates.getInstance().getTemplate(name);

    if (template == null) {
      return null;
    }
    let p = template.getRender();
    return p;
  }
  //----------------------------------------------------------------------------
  // api
  // 從內文取得 template
  static fromContent(name, content, options = {}) {
    const $TemplateItem = $GM.get('TemplateItem');
    const tempItem = $TemplateItem(name);
    tempItem.setContent(content, options);

    Templates.getInstance().setTempalte(name, tempItem);
  }

  // 返回 ??
  static getfromContent(content, options = {}) {

  }
  //----------------------------------------------------------------------------
  // api
  static fromAjax(name, options = {}) {
    debugger;

    const $tool = $GM.get('tool');
    let _ajax = $tool.getAjax(options);

    function job() {
      let p = _ajax.start().promise();
      return p;
    }

    const $TemplateItem = $GM.get('TemplateItem');
    const tempItem = new $TemplateItem(name);

    tempItem.setJobAsync(job, options);

    Templates.getInstance().setTempalte(name, tempItem);
  }

  static async getFromAjax(name, options = {}) {

  }
  //--------------------------------------------------------------------------
  // api
  // 從遠端取得內文
  static fromAsync(name, pr, options = {}) {

    const $TemplateItem = $GM.get('TemplateItem');
    const tempItem = new $TemplateItem(name);
    tempItem.setJobAsync(pr, options);

    Templates.getInstance().setTempalte(name, tempItem);
  }

  static async getFromAsync(name, pr, options = {}) {

  }
  //--------------------------------------------------------------------------
  static fromDom(name, targetDom, options = {}) {
    debugger;

    let {
      // 模板内容是 jsp 格式
      jspformat = false,
      // 讀取 dom 模板内容后，是否要移除
      remove = true,
    } = options;

    if (typeof document == 'undefined') {
      throw new Error('not browser environment');
    }

    if (typeof targetDom == 'string') {
      targetDom = document.querySelector(targetDom);
      if (targetDom == null) {
        throw new Error("cant't find dom");
      }
    }

    if (!(targetDom instanceof Node)) {
      throw new TypeError('must be dom');
    }
    let sourceDom = targetDom;
    let content;
    while (true) {
      debugger;

      switch (sourceDom.nodeName) {
        case 'TEMPLATE':
          sourceDom = sourceDom.content;
          continue;
          break;
        case '#document-fragment':

          let root = document.createElement('div');
          root.appendChild(sourceDom);
          sourceDom = root;
          root = null;
          break;
        case 'SCRIPT':

        default:
          if (!('innerHTML' in sourceDom)) {
            throw new TypeError('no innerHTML attr');
          }
          break;
      } // end switch
      break;
    } //endWhile
    //-----------------------
    debugger;

    if (remove == true && targetDom.parentNode != null) {
      targetDom.parentNode.removeChild(targetDom);
    }

    content = sourceDom.innerHTML;

    const $TemplateItem = $GM.get('TemplateItem');
    const tempItem = $TemplateItem.getInstance(name);

    if (jspformat) {
      content = Templates.checkJspFormat(content);
    }

    sourceDom.innerHTML = '';
    sourceDom = null;
    //-----------------------
    tempItem.setContent(content, options);
    Templates.getInstance().setTempalte(name, tempItem);
  };

  static getFromDom(targetDom, options = {}) { }
  //----------------------------------------------------------------------------

  static checkJspFormat(content) {
    const reg = /\&lt;%([^]+?)%\&gt/g;
    content = content.replace(reg, (m, g1) => {
      return '<%' + g1 + '%>';
    });
    return content;
  }

  static get(name) {
    let temps = Templates.getInstance();
    return temps.getTemplate(name);
  }

  // test
  static get templateList() {
    return Templates.getInstance().$templateMap;
  }
}

export default Templates;
