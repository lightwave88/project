// debugger;

import $GM from './gmodule.js';

// XComponent 系統方法
class XComponent_core {
    constructor() {
        this.$$$parent;
    }


    $$$setParent(parent) {
        this.$$$parent = parent;
    }

    //--------------------------------------------------------------------------
    $setData() {

    }

    $getData() {

    }

    // 與資料做綁定
    $bindData() {

    }

    // 内部命令
    // render 模板
    $templateRender(data = {}) {

    }

    // comp 内部 API
    $emit() {
        let container = this.$contianer;
    }
    //--------------------------------------------------------------------------
    // comp 内部 API
    get $data() {

    }

    // comp 内部 API
    set $data() {

    }

    // comp 内部 API
    get $container() {

    }

    // comp 内部 API
    get $shadowDom() {

    }
    // comp 内部 API
    get $rootDom() {

    }
}
//------------------------------------------------------------------------------


// 實例化的 comp
// 使用者必須繼承
class XComponent extends XComponent_core {

    constructor() {
        super();

        this.$requireData = [];

        this.$mixins = [];
    }
    //--------------------------------------------------------------------------

    // override
    $getDefaultData() {

    }

    // override    
    // 數值類型驗證
    $dataTypeValidate() {

    }

    //--------------------------------------------------------------------------
    // callback
    $init() {

    }
    // callback
    $stateWillUpdate() {
        // 若資料爲非同步，會先呼叫
    }
    // callback
    $stateDidUpdate() {

    }
    // callback
    $willMount() {

    }
    // callback
    $didMount() {

    }
    // callback
    $willUnmout() {

    }

    // UI 必須通知使用者要等待
    $wait() {

    }

    // UI 通知使用者等待結束
    $didWait() {

    }

}

export { XComponent };
