// debugger;

import $GM from './gmodule.js';

// XComponent 系統方法
class XComponent_core {
  constructor(options) {
    //------------------
    // 給使用者操作的屬性
    this.$container;
    this.$rootDom;
    this.$containerDom;    
    //------------------
    this.$$$wrap;

    this._$init(options);
  }

  _$init(initData) {
    let {
      container,
      containerDom,
      rootDom,
      wrap,
      slots,
      renderEngine,
    } = initData;
  }
  //--------------------------------------------------------------------------  

  // 與資料做綁定
  $observeData(keyList = []) {

  }
  
  $getSlot(name){
    
  }

  // 内部命令
  // render 模板
  $templateRender(data = {}) {

  }

  // comp 内部 API
  $emit() {
    
  }
  //----------------------------------------------------------------------------
  // comp 内部 API
  get $data() {
    return this.$$$wrap.getData();
  }
  
  set $data(){
      throw new Error("can't set $data");
  }

  // comp 内部 API
  get $container() {

  }

  // comp 内部 API
  get $shadowDom() {

  }
  // comp 内部 API
  get $rootDom() {

  }
  //---------------------------------------------------------------------------- 
  $setData(k, v){
      this.$$$wrap._setData(k, v);
  }
}
//------------------------------------------------------------------------------


// 實例化的 comp
// 使用者必須繼承
class XComponent extends XComponent_core {

  constructor(initData) {
    super(initData);

    this.$requireData = [];

    this.$mixins = [];
  }
  //----------------------------------------------------------------------------

  // override
  $getDefaultData() {
    return {};
  }

  // override    
  // 數值類型驗證
  $dataTypeValidate() {

  }

  //----------------------------------------------------------------------------
  
  // callback
  $dataWillUpdate() {
    // 若資料爲非同步，會先呼叫
  }
  // callback
  $dataUpdate(data = {}) {
    
  }
  // callback
  $willMount() {

  }
  // callback
  $mount(data) {

  }
  // callback
  // 第一次掛起
  $initMount(data) {
    
  }
  // callback
  $willUnmout() {

  }

  // UI 必須通知使用者要等待
  $wait() {

  }

  // UI 通知使用者等待結束
  $didWait() {

  }

}

export {
  XComponent
};
