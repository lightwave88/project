// debugger;

import $GM from './gmodule.js';

const $tool = {}
export default $tool;

// 檢查 <% %>
$tool.checkJspFormat = function (content) {
  const reg = /\&lt;%([^]+?)%\&gt/g;

  content = content.replace(reg, (m, g1) => {
    return '<%' + g1 + '%>';
  });
  return content;
};
//--------------------------------------------------------------------

// 取得 tempalte 的内文
$tool.deferred = function () {
  let handle;
  let pr;

  const def = {
    promise() {
      return pr;
    },
    resolve(data) {
      handle.next({
        error: null,
        data
      });
    },
    reject(er) {
      handle.next({
        error: er,
        data: null
      });
    },
    pipe(_pr) {

      if (typeof _pr.then != "function") {
        throw new TypeError('def must pipe promise')
      }

      _pr.then((data) => {
        debugger;
        this.resolve(data);
      }, (er) => {
        this.reject(er);
      });

      return pr;
    }
  };

  pr = new Promise(($res, $rej) => {
    handle = (function* () {
      let {
        er,
        data
      } = yield;
      handle = null;
      if (er == null) {
        $res(data);
      } else {
        $rej(data);
      }
    })();
    handle.next();
  });

  return def;
};
//------------------------------------------------------------------------------
// 取得 dom.attrMap
$tool.getDomAttrs = function (dom) {
  const attrMap = dom.attributes;
  const attrList = Object.values(attrMap);

  let data = {};
  attrList.forEach((attr) => {
    let key = attr.nodeName;
    data[key] = dom.getAttribute(key);
  });
  return data;
};
//------------------------------------------------------------------------------
$tool.getAjax = function (options = {}) {

  class A {
    constructor(options) {
      this.def = $tool.deferred();
      this.options = {
        method: 'GET'
      };
      this.req;
      this._checkOptions(options);
    }
    start() {
      debugger;

      this.req = new XMLHttpRequest();

      let {
        method,
        url
      } = this.options;

      let req = this.req;
      req.addEventListener("load", this._ok);
      req.addEventListener("error", this._error);
      req.open(method, url);
      req.send();

      return this;
    }
    promise() {
      return this.def.promise();
    }
    _ok(e) {
      // this error
      this._end();
      let data = e.currentTarget.responseText;
      this.def.resolve(data);
    }
    _error(e) {
      // this error
      this._end();
      this.def.reject('error');
    }
    _end() {
      this.req.removeListener('load', this._ok);
      this.req.removeListener('error', this._error);
    }
    _checkOptions(options) {
      Object.assign(this.options, options);

      let _options = this.options;

      _options.method = _options.method.toLocaleUpperCase();
      _options.url = this._checkUrl(_options.url);

      console.log('url=%s', _options.url);
    }
    _checkUrl(url) {
      let hash = "";
      let search = "";
      let baseUrl;

      url = url.replace(/#[^]*$/, (m) => {
        hash = m;
        return '';
      });

      baseUrl = url.replace(/\?([^]*)$/, (m, g1) => {
        search = g1.trim();
        return '';
      });

      search = search.length ? search.split('&') : [];

      let key = 'timestamp'
      let head = '$';

      // 找到沒有被設定的 key
      while (this._isUrlhasKey(search, key)) {
        key = head + key;
      }
      let time = (new Date()).getTime();
      search.push(`${key}=${time}`);

      let res = '';

      if (hash) {
        res += hash;
      }

      search = search.join('&');

      res = "?" + search + res;
      res = baseUrl + res;
      return res;
    }
    // queryString 裏是否有該 key
    _isUrlhasKey(list, key) {
      debugger;
      let reg = RegExp(key + "($|=, 'i')");
      return list.some((str) => {
        return reg.test(str);
      });
    }

  }
  return new A(options);
}
