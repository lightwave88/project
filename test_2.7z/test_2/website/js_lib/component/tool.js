const $tool = {}
export default $tool;

// 檢查 <% %>
$tool.checkJspFormat = function(content) {
    const reg = /\&lt;%([^]+?)%\&gt/g;

    content = content.replace(reg, (m, g1) => {
        return '<%' + g1 + '%>';
    });
    return content;
};
//--------------------------------------------------------------------

// 取得 tempalte 的内文
$tool.getTemplateContent = function(targetDom, options = {}) {
    debugger;

    let {
        // 模板内容是 jsp 格式
        jspformat = false,
            // 包含 parent 標簽
            outer = false,
            // 讀取 dom 模板内容后，是否要移除
            remove = true,
    } = options;

    if (typeof document == 'undefined') {
        throw new Error('not browser environment');
    }

    if (typeof targetDom == 'string') {
        targetDom = document.querySelector(targetDom);
        if (targetDom == null) {
            throw new Error("cant't find dom");
        }
    }

    if (!(targetDom instanceof Node)) {
        throw new TypeError('must be dom');
    }
    let sourceDom = targetDom;
    let content;
    while (true) {
        debugger;

        switch (sourceDom.nodeName) {
            case 'TEMPLATE':
                sourceDom = sourceDom.content;
                continue;
                break;
            case '#document-fragment':
                outer = false;
                let root = document.createElement('div');
                root.appendChild(sourceDom);
                sourceDom = root;
                root = null;
                break;
            case 'SCRIPT':
                outer = false;
            default:
                if (!('innerHTML' in sourceDom)) {
                    throw new TypeError('no innerHTML attr');
                }
                break;
        } // end switch

        content = (outer === true) ? sourceDom.outerHTML : sourceDom.innerHTML;

        if (remove == true) {
            let parentNode = targetDom.parentNode;

            if (parentNode != null) {
                parentNode.removeChild(targetDom)
            }
        }
        sourceDom.innerHTML = '';
        sourceDom = null;

        break;
    };

    return content;
};
