// debugger;

import $GM from './gmodule.js';

const $tool = {}
export default $tool;

// 檢查 <% %>
$tool.checkJspFormat = function (content) {
  const reg = /\&lt;%([^]+?)%\&gt/g;

  content = content.replace(reg, (m, g1) => {
    return '<%' + g1 + '%>';
  });
  return content;
};
//--------------------------------------------------------------------

// 取得 tempalte 的内文
$tool.deferred = function () {
  let handle;
  let pr;

  const def = {
    promise() {
      return pr;
    },
    resolve(data) {
      handle.next({
        error: null,
        data
      });
    },
    reject(er) {
      handle.next({
        error: er,
        data: null
      });
    },
    pipe(_pr) {

      if (typeof _pr.then != "function") {
        throw new TypeError('def must pipe promise')
      }

      _pr.then((data) => {
        debugger;
        this.resolve(data);
      }, (er) => {
        this.reject(er);
      });
      
      return pr;
    }
  };

  pr = new Promise(($res, $rej) => {
    handle = (function* () {
      let { er, data } = yield;
      handle = null;
      if (er == null) {
        $res(data);
      } else {
        $rej(data);
      }
    })();
    handle.next();
  });

  return def;
};

// 取得 dom.attrMap
$tool.getDomAttrs = function(dom){
  const attrMap = dom.attributes;
  const attrList = Object.values(attrMap);
  
  let data = {};
  attrList.forEach((attr)=>{
    let key = attr.nodeName;
    data[key] = dom.getAttribute(key);
  });
  return data;
}
