debugger;
import a from './a.js';

debugger;
try {
    console.dir(a);
} catch (error) {
    console.log(error);
}

let b = {
    test() {
        debugger;
        console.dir(a);
    }
};

export default b;