debugger;
import b from './b.js';

debugger;
try {
    console.dir(b);
} catch (error) {
    console.log(error);
}

let a = {
    test() {
        debugger;
        console.dir(b);
    },
    b
};

export default a;