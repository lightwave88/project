self.addEventListener('message', (e) => {
    debugger;
    console.dir(e);

    let fn = makeFun();

    debugger;
    fn(e.data);
});


function makeFun() {

    let content = `
        'use strict';
        debugger;

        let self = {
            age: 15
        };

        let addEventListener = {};

        console.dir(this);
        console.dir(self);

        return ((data) => {
            debugger;
           
            console.dir(this);
            console.dir(self);
            console.dir(data);

            try {
                postMessage(data);
                addEventListener('message', (e) => {
                    debugger;
                    console.dir(e);
                });
            } catch (error) {
                console.log(error);
            }

            
        });`

    let fun = new Function(content);
    return fun();
}