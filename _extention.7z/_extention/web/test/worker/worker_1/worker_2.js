

//--------------------------------------
let $_;
(() => {
    debugger;

    let int_error;
    try {
        self.onmessage = (e) => {
            debugger;
            let runtime_error;

            let data = e.data;

            if (data == null || typeof data != 'object') {
                throw new TypeError('postMessage(agrs) args must be {}');
            }

            try {
                _importScript(data);
                run(data);
            } catch (error) {
                runtime_error = error;
            } finally {
                if (runtime_error != null) {
                    error_msg(runtime_error);
                }
            }
        };
        //----------------------------
        // 通知已初始化完畢
        end_msg({
            initialized: true
        });

    } catch (error) {
        int_error = error;
    } finally {

        if (int_error != null) {
            error_msg(int_error);
            int_error = null;
        }
    }
})();

//------------------------------------------------------------------------------

function _importScript(data) {
    debugger;
    if ($_ != null) {
        return;
    }
    let { _path, id, importList, extensionPath } = data;

    if (_path != null && $_ == null) {

        // 引入 _ 並擴充    
        importScripts(_path);

        $_ = self['_'];

        if ($_ == null) {
            throw new Error(`cant't import _ by path(${_path})`);
        }
    }

    if (extensionPath != null) {
        try {
            importList(extensionPath);
        } catch (error) {
            throw new Error(`can't import _extension by path (${extensionPath})`);
        }
    }

    if (importList != null) {

        importList = importList.map((path) => {
            return JSON.stringify(path);
        });

        let path = importList.join(',');

        debugger;
        const importScripts_factory = new Function(`debugger;
        importScripts(${path});`);

        importScripts_factory();
    }
}
//------------------------------------------------------------------------------
function run(data) {
    debugger;

    let {
        // _命令
        command,
        // 參數
        args,
        // 那些參數是 fun
        funs,
        id,
    } = data;


    // 重建函式
    funs.forEach((index) => {
        // 是 function 的 args
        let fun_content = args[index];

        let fun_factory = getFunByString(fun_content);

        args[index] = fun_factory();
    });

    
    let fn;
    let fn_context = self;

    if (typeof args[0] == 'function') {
        // 使用者沒用 _ 的命令
        fn = args.shift();
    } else {
        if (!command && typeof $_[command] != 'function') {
            throw new TypeError(`_ no this function[${command}]`);
        }
        fn = $_[command];
    }
    let res = fn.apply(fn_context, args);
    //----------------------------
    if (res instanceof Promise) {
        res.then((d) => {
            end_msg(d);
        });
        res.catch((er) => {
            error_msg(er);
        });

    } else {
        end_msg(res);
    }
}
//------------------------------------------------------------------------------
function end_msg(res) {
    let msg = {
        res: null,
        error: null,
    };

    msg = Object.assign({}, msg, res);

    self.postMessage(msg);
}
//------------------------------------------------------------------------------
function error_msg(error) {
    let msg = {
        res: null,
        error: error,
    };
    self.postMessage(msg);
}
//------------------------------------------------------------------------------
function test(res) {
    setTimeout(() => {
        end_msg(res);
    }, 1000);
}
//------------------------------------------------------------------------------
function getFunByString(content = '') {
    let fun = new Function(`return (${fun_content});`);
    return fun();
}