
debugger;

self.onmessage = (e) => {
    debugger;
    let data = e.data || {};

    let { fun, path } = data;

    fun = get_fun_by_string(fun);

    debugger;
    fun(path);

    self.postMessage('finish');

    setTimeout(() => {
        debugger;

        throw new Error('hi');
    }, 1000);
}

function get_fun_by_string(content) {
    let fun = new Function(`return (${content})`);
    fun = fun().bind(self);

    return fun;
}