export { queryDom };

function queryDom(dom) {
    debugger;

    const query = QueryDom.getInstance();

    return query.query(dom);
};

class QueryDom {
    static getInstance() {
        return new QueryDom();
    }

    constructor() {
        this.levelList = [];

        // 查詢結果列表
        this.queryList = [];
    }

    query(dom) {

        let node;
        // let searchIndex;

        node = Node.getInstance({
            level: 0,
            dom: dom,
            levelList: (this.levelList)
        });

        while (true) {
            if (node == null) {
                break;
            }

            this.record(node);

            // 重點
            node = node.next();
        }

        return this.queryList;
    }

    record(node) {
        if (node.isChecked()) {
            return;
        }
        this.queryList.push(node.dom);
    }

    hasChild(node) {
        const dom = node.dom;

        const childNodes = dom.childNodes;
        if (childNodes != null && Array.isArray(childNodes) && childNodes.length) {
            return childNodes;
        }
        return null;
    }
}

class Node {

    static getInstance(dom, parent) {
        return new Node(dom, parent);
    }

    constructor(options) {
        const { level, dom, parent, levelList } = options;

        this.levelList = levelList;
        this.hasChecked = false;
        this.level = level;
        this.dom = dom;
        this.childNodes = [];
        this.parent = (parent instanceof Node) ? parent : null;

        // 檢查過的 child
        this.checkIndex = 0;

        this._init();
    }

    _init() {
        debugger;

        // 可記録階層多深
        this.levelList[this.level] = true;

        const parent = this;

        try {
            debugger;
            let childNodes = Array.from(this.dom.childNodes);
            childNodes.forEach((dom) => {
                
                const node = Node.getInstance({
                    level: (parent.level + 1),
                    dom: dom,
                    levelList: (parent.levelList),
                    parent: parent,
                });
                this.childNodes.push(node);
            });
        } catch (error) { }
    }

    isChecked() {
        const res = this.hasChecked;
        this.hasChecked = true;
        return res;
    }

    hasChild() {
        if (this.childNodes.length) {
            return this.childNodes;
        }
        return null;
    }
    // 重點
    next() {
        let node = this.childNodes.shift();

        if (node == null) {
            // 若沒子節點
            // 或所有子節點都拜訪完

            // 就往上一級
            node = this.parent;

        }
        return node;
    }
}