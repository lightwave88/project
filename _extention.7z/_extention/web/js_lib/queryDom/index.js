import { queryDom } from './main.js';

export { queryDom };
export default queryDom;