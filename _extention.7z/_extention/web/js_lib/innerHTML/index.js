 
export { innerHTML } from './module_2/main_1.js';
export { getInnerHTML } from './module_3/main_1.js'

