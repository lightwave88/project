export { getInnerHTML };

const $reg_1 = /&lt;%([\s\S]*?)%&gt;/;

function getInnerHTML(dom) {

    let reg = RegExp($reg_1, 'ug');

    let content = dom.innerHTML;
    content = content.replace(reg, (m, g1) => {
        return ("<%" + g1 + "%>");
    });

    return content;
}
