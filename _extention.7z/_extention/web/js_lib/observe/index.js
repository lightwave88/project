import $GM from './gmodule.js';

(function () {
    debugger;

    const $CheckSys = $GM.get('checkSystem');
    const $checkSys = $CheckSys.getInstance();
    $checkSys.check();
    //--------------------------------------------------------------------------
    const _ = $GM.get('_');
    const $api = $GM.get('api');

    const tool = $GM.get('tool');
    // test
    $api.tool = tool;

    _.mixin({
        "observe": $api
    });

})();
