import $GM from './gmodule.js';
export default { linkObserve };

//------------------------------------------------------------------------------
function linkObserve(data, parent = null) {
    debugger;
    const $tool = $GM.get('tool');
    if (!$tool.isCollect(data)) {
        return data;
    }
    //----------------------------
    const $Observe = $GM.get('observe');
    const augment = $tool.hasProto ? $tool.protoAugment : $tool.copyAugment;

    // 生成觀察者
    let observe;
    let res;
    if (!(data instanceof Proxy) || data["_@_ob_@_"] == null) {
        observe = new $Observe(data);
        // 可移到 JSONObserver.construct 裏
        $tool.defProperty(data, "_@_ob_@_", observe, false);

        if (Array.isArray(data)) {
            // 替換 [] 的原型方法
            augment(data, _getArrayProtoClone());
        }
    } else {
        observe = data["_@_ob_@_"];
    }

    if (parent != null) {
        observe.addParent(parent);
    }
    //----------------------------
    debugger;

    if (Array.isArray(data)) {
        _walkArray(data);
    } else {
        _walkPlainObject(data);
    }
    //----------------------------
    res = observe.$$proxy;
    return res;
}
//------------------------------------------------------------------------------

function _walkArray(data) {
    for (let i = 0, l = data.length; i < l; i++) {
        let child = data[i];
        data[i] = makeObserver(child, data);
    }
}
//------------------------------------------------------------------------------
function _walkPlainObject(obj) {
    for (let k in obj) {
        if (!obj.hasOwnProperty(k)) {
            continue;
        }
        let child = obj[k];
        obj[k] = makeObserver(child, obj);
    }
}
//------------------------------------------------------------------------------
function _getArrayProtoClone() {

    let arrayProtoClone = null;

    const arrayProto = Array.prototype;

    const arrayMethodsNameList = [
        'push',
        'pop',
        'shift',
        'unshift',
        'splice',
        'sort',
        'reverse'
    ];

    return (() => {

        if (arrayProtoClone == null) {
            const $tool = $GM.get('tool');
            const ob_key = $GM.get('config').get('ob_key');

            // 初始化 arrayProtoClone

            arrayProtoClone = Object.create(this.arrayProto);


            arrayMethodsNameList.forEach((method) => {

                // array 原始的方法
                let original = arrayProto[method];

                // 在 array.proto 寫下方法
                $tool.defProperty(arrayProtoClone, method, function arrayReact() {
                    debugger;

                    const preValue = $tool.cloneValue(this);

                    // 裡面會有 remove, add ,update
                    let args = Array.from(arguments);
                    //----------------------------

                    let ob = this[ob_key];
                    //ob.$$arrayMethod = method;

                    let result = original.apply(this, args);

                    let add = [];
                    let remove = [];

                    // debugger;

                    switch (method) {
                        case 'push':
                        case 'unshift':
                            add = args;
                            break;
                        case 'pop':
                        case 'shift':
                            remove = result;
                            break;
                        case 'splice':
                            add = args.slice(2);
                            remove = result;
                            break;
                    }

                    if (!Array.isArray(add)) {
                        add = (add === undefined ? [] : [add]);
                    }

                    if (!Array.isArray(remove)) {
                        remove = (remove === undefined ? [] : [remove]);
                    }
                    //----------------------------
                    const afterValue = $tool.cloneValue(this);

                    setTimeout(() => {
                        ob.notify_arrayMethod(method, preValue, afterValue);
                    }, 0);

                    return result;
                });
            });

        }


        return arrayProtoClone;
    })();
}






