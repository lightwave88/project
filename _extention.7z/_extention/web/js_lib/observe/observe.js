import $GM from './gmodule.js';

let $Observe_id = 0;

class Observe extends ObserveTool {

    constructor(value) {

        this.$$config = $GM.get('config');
        this.$$tool = $GM.get('tool');

        this.$$ob_key = this.$$config.get('ob_key');

        this.$$uid = $Observe_id++;
        //----------------------------
        this.$$proxy;

        // 只能是 collect
        this.$$value = value;
        //----------------------------
        // 紀錄有哪些 parent
        // 方便形成路徑
        this.$$parentsMap = {};


        //----------------------------
        // 針對 [] 的方法處理
        this.$$arrayMethod = '';

        // 記録 [] 有哪些 key 改變
        this.$$array_changekeyList = [];
        this.$$array_addList = [];
        this.$$array_removeList = [];

        // 協調者
        this.$$coordinator;

        // 動態記錄，是否已離開數據樹
        this.$$pathList = new Map();
        //----------------------------
        // 紀錄那些 key 有變動
        this.$$changeKeys = new Map();

        this._init();
    }

    _init() {
        if (!this.$$tool.isCollect(this.$$value)) {
            throw new TypeError('data must be {},[]');
        }

        if (this.$$value instanceof Proxy) {
            throw new TypeError('data cant be proxy');
        }

        if (Array.isArray(this.$$value)) {
            this._wrapArrayProxy();
        } else {
            this._wrapObjectProxy();
        }
    }
    //--------------------------------------------------------------------------
    _wrapArrayProxy() {

        const $self = this;
        const $tool = this.$$tool;
        const $linkObserve = $GM.get('linkObserve')['linkObserve'];
        const ob_key = this.$$ob_key;

        const p_data = new Proxy(this.$$value, {
            set(t, k, v){
                debugger;

                let ob = t[ob_key];
                let remove = null;
                let preValue = $tool.cloneValue(t[k]);
                let afterValue = $tool.cloneValue(v);

                try {
                    remove = t[k][ob_key];
                } catch (error) {
                    remove = null;
                    console.log(error);
                }

                // 修正關係
                if (remove != null) {
                    // 舊的需移除父子關係
                    remove.detatch(t);
                }
                //----------------------------
                debugger;

                // 是否來自 arraymethod()
                if (ob.$$arrayMethod != null) {
                    // 遇到 [].method();
                    t[k] = v;

                    recordKeyChange(k);

                    return true;
                }
                //----------------------------
                debugger;
                if (/^length$/i.test(k)) {
                    // length 改變，造成 delete
                    preValue = t.slice();

                    t[k] = v;

                    afterValue = t.slice();

                    setTimeout(() => {
                        ob.notify_lengthChange(preValue, afterValue);
                    }, 0);

                    return true;
                }
                //----------------------------

                // 新的，建立父子關係
                let _v = $linkObserve(v, t);
                t[k] = _v;
                //----------------------------
                ob.notify_valueChange(k, preValue, afterValue);

                return true;
            },
            deleteProperty(t, k) {
                debugger;

                let remove = null;
                const preValue = $tool.cloneValue(t[k]);
                let ob = t[ob_key];

                try {
                    remove = t[k][ob_key];
                } catch (error) {
                    remove = null;
                    console.log(error);
                }
                //----------------------------
                // 修正關係
                if (remove != null) {
                    // 舊的需移除父子關係
                    remove.detatch(t);
                }
                //----------------------------
                debugger;

                delete t[k];

                const afterValue = $tool.cloneValue(t[k]);

                ob.notify_valueChange(k, preValue, afterValue);

                return true;
            }
        });

        this.$$proxy = p_data;
    }
    //--------------------------------------------------------------------------
    _wrapObjectProxy() {
        const $self = this;
        const $tool = this.$$tool;
        const $linkObserve = $GM.get('linkObserve')['linkObserve'];
        const ob_key = this.$$ob_key;

        const p_data = new Proxy(this.$$value, {
            set(t, k, v) {
                debugger;

                let remove = null;
                let ob = t[ob_key];
                const preValue = $tool.cloneValue(t[k]);
                const afterValue = $tool.cloneValue(v);

                try {
                    remove = t[k][ob_key];
                } catch (error) {
                    remove = null;
                    console.log(error);
                }
                //----------------------------
                // 修正關係
                if (remove != null) {
                    // 舊的需移除父子關係
                    remove.detatch(t);
                }
                debugger;

                let _v = $linkObserve(v, t);
                t[k] = _v;
                //----------------------------
                ob.notify_valueChange(k, preValue, afterValue);

                return true;
            },
            deleteProperty(t, k) {
                debugger;

                let remove = null;
                let ob = t[ob_key];
                const preValue = $tool.cloneValue(t[k]);

                try {
                    remove = t[k][ob_key];
                } catch (error) {
                    remove = null;
                    console.log(error);
                }
                //----------------------------
                // 修正關係
                if (remove != null) {
                    // 舊的需移除父子關係
                    remove.detatch(t);
                }
                //----------------------------
                delete t[k];
                const afterValue = $tool.cloneValue(t[k]);

                ob.notify_valueChange(k, preValue, afterValue);

                return true;
            }
        });

        this.$$proxy = p_data;
    }
    //--------------------------------------------------------------------------
    notify_valueChange(key, preValue, currentValue) {
        debugger;
        console.log('notify_valueChange key(%s), value(%s|%s)', key, preValue, currentValue);
        console.log('----------------');
    }
    //--------------------------------------------------------------------------
    // 修改 [].length
    notify_lengthChange(preValue, curValue) {
        debugger;

        const ob_key = this.$$ob_key;

        if (curValue.length < preValue.length) {
            // [] 數據減少
            
            // 移除被移除的數據
            for (let i = curValue.length; i < preValue.length; i++) {
                const element = preValue[i];

                let ob;

                try {
                    ob = element[ob_key];
                } catch (er) {
                    console.log(er);
                }

                if(ob != null){
                    ob.detatch(this);
                }
            }
        }

        console.log('preValue: %s', JSON.stringify(preValue));
        console.log('curValue: %s', JSON.stringify(curValue));
        console.log('----------------');
    }
    //--------------------------------------------------------------------------
    notify_arrayMethod(preValue, curValue) {
        debugger;
        
        const changekeyList = this.$$array_changekeyList;
        const method = this.$$arrayMethod;

        this.afterArrayMethod();

        console.log('array_change method(%s) keyList(%s)', method, JSON.stringify(changekeyList));
        console.log('preValue: %s', JSON.stringify(preValue));
        console.log('curValue: %s', JSON.stringify(curValue));
        console.log('----------------');
    }
    //--------------------------------------------------------------------------
    addParent(parent) {
        const ob_key = this.$$ob_key;

        if (!(parent instanceof Observe)) {
            parent = parent[ob_key];
        }
        const parent_id = parent.$$uid;
        let data;

        if (!(parent in this.$$parentsMap)) {
            this.$X$parentsMap[parent_id] = {
                count: 0,
                ob: parent
            };
        }

        data = this.$$parentsMap[parent_id];
        data.count++;
    }
    //--------------------------------------------------------------------------
    // 與父親分離
    detatch(parent) {
        const ob_key = this.$$ob_key;

        if (!(parent instanceof Observe)) {
            parent = parent[ob_key];
        }

        const parent_id = parent.$$uid;

        if (parent_id in this.$$parentsMap) {
            let data = this.$$parentsMap[parent_id];

            if (--data.count == 0) {
                delete this.$$parentsMap[parent_id];
            }
        }
    }
    //--------------------------------------------------------------------------
    recordKeyChange(key) {
        if (!/^\d+$/.test(key)) {
            return;
        }
        this.$$array_changekeyList.push(key);
    }
    //--------------------------------------------------------------------------
    afterArrayMethod() {
        this.$$array_changekeyList.length = 0;
        this.$$arrayMethod = null;
    }
    //--------------------------------------------------------------------------
    findPath(target, pathList) {
    }
}

export default Observe;



