const $GModule = new Map();
export default $GModule;

import config from './config.js';
$GModule.set('config', config);

import tool from './tool.js';
$GModule.set('tool', tool);

import linkObserve from './link_observe.js';
$GModule.set('linkObserve', linkObserve);

import checkSystem from './checkSystem.js';
$GModule.set('checkSystem', checkSystem);

import api from './api.js';
$GModule.set('api', api);