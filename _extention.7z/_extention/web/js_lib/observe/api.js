import $GM from './gmodule.js';

const $api = function () {

};

export default $api;


$api.monitor = function (path, job, option) {

};

// array 專用，濾除 array.childs 的變化事件
// 專注結構的變化
$api.monitorSelf = function (path, job, option) {

};

$api.test = function (data) {
    debugger;
    
    const {linkObserve} = $GM.get("linkObserve");
    
    return linkObserve(data);
};





