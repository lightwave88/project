// debugger;

const GModule = new Map();
export default GModule;
//------------------
import error from './error.js';
GModule.set('error', error);

import checkSystem from './checkSystem.js';
GModule.set('checkSystem', checkSystem);

import Config from './config.js';
GModule.set('Config', Config);

import Job from './job.js';
GModule.set('Job', Job);

import WorkerProxy from './workerProxy.js';
GModule.set('WorkerProxy', WorkerProxy);

import WorkerPool_wrap from './workerPool.js';
GModule.set('Pool', WorkerPool_wrap);

import api from './api.js';
GModule.set('api', api);
