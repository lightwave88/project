import $GM from './globalModule.js';

// 取得系統資訊
// 每個進程只有一個
class CheckSystem {
    static getInstance() {
        return new CheckSystem();
    }
    //--------------------------------------------------------------------------
    constructor() {

    }
    //--------------------------------------------------------------------------
    check() {
        const $error = $GM.get('error');
        const EnvError = $error['env_error'];
        let root;

        let _;

        try {
            // nodejs
            let ex_module = require('_extension');
            _ = ex_module.getSource();
        } catch (error) {
            // browser
            root = this._checkRoot();

            if (root != null && typeof root == 'object') {
                _ = root._;
            }
        }
        //------------------
        if (_ == null) {
            throw new Error('no import _');
        }

        const $extension = _['$$$extension'];

        if ($extension == null) {
            throw new Error('no import _extension');
        }
        this.extension = $extension;

        if (!/^browser$/.test($extension.env.system)) {
            throw new EnvError('_.workerPool() must use in browser env');
        }

        const isWorkerEnv = $extension.env.isWorkerEnv;
        if (isWorkerEnv) {
            throw new EnvError('_.workerPool() cant run in worker env');
        }

        $GM.set('_', _);
    }
    //--------------------------------------------------------------------------
    _checkRoot() {
        let root;

        if (typeof self == 'object' && self.self === self) {
            root = self;
        } else if (typeof global == 'object' && global.global === global) {
            root = global;
        }
        root = root || this;

        return root;
    }
}

export default CheckSystem;


