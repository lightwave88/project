import $GM from './globalModule.js';

// 取得系統資訊
// 每個進程只有一個
class CheckSystem {
    static getInstance() {
        return new CheckSystem();
    }
    //--------------------------------------------------------------------------
    constructor(_) {
        this._;
        this.extension;

        this._init(_);
    }

    _init(_) {
        if (_ != null) {
            this._ = _;
        }
    }
    //--------------------------------------------------------------------------
    check() {
        debugger;
        const $error = $GM.get('error');
        const EnvError = $error['env_error'];

        if (this._isNodeJs()) {
            if (this._ == null) {
                let ex_module = require('_extension');
                this._ = ex_module.getSource();
            }
        } else {
            // browser
            let root = this._checkRoot();

            if (root != null && typeof root == 'object') {
                this._ = root._;
            }
        }
        //------------------
        if (this._ == null) {
            throw new Error('no import _');
        }

        this.extension = this._['$$$extension'];
        if (this.extension == null) {
            throw new Error('no import _extension');
        }

        if (!this.extension.env_isBrowser) {
            throw new EnvError('_.workerPool() must use in browser env');
        }
        
        if (this.extension.env_isWorker) {
            throw new EnvError('_.workerPool() cant run in worker env');
        }

        $GM.set('_', this._);
    }
    //--------------------------------------------------------------------------
    _isNodeJs() {
        let res;
        try {
            let fs = require('fs');
            res = (typeof fs == 'object');
        } catch (error) {
            res = false;
        }
        return res;
    }
    //--------------------------------------------------------------------------
    _checkRoot() {
        let root;

        if (typeof self == 'object' && self.self === self) {
            root = self;
        } else if (typeof global == 'object' && global.global === global) {
            root = global;
        }
        root = root || this;

        return root;
    }
}

export default CheckSystem;
