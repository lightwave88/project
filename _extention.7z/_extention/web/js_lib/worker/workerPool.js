import $GM from './globalModule.js';

// 包裝 WorkerPool
// 避免露出太多内部私有函式
class WorkerPool_wrap {
    static getInstance(config) {
        return new WorkerPool_wrap(config);
    }
    //--------------------------------------------------------------------------
    constructor(config) {
        this.$core = new WorkerPool(config);
    }

    get config() {
        return this.$core.config;
    }
    //--------------------------------------------------------------------------
    // 執行任務
    execute(args) {
        this.$core.startWorker();
        return this.$core.notice(args);
    }
    //--------------------------------------------------------------------------
    // 終止 pool 的任務
    close() {
        this.$core.close();
    }
    //--------------------------------------------------------------------------
    // 啓動
    // 預設是接到工作才啓動
    startWorker(config) {
        this.$core.startWorker(config);
    }
    //--------------------------------------------------------------------------
    importScripts(script) {
        this.$core.importScripts(script);
    }
    //--------------------------------------------------------------------------
    setConfig(config) {
        this.$core.setConfig(config);
    }
    //--------------------------------------------------------------------------
    // 設定 worker init 要執行的 callback
    setWorkerInit(...args) {
        this.$core.setWorkerInit.apply(this.$core, args);
    }
}

export default WorkerPool_wrap;
//==============================================================================
// WorkerPool 主體
class WorkerPool {

    constructor(config = {}) {

        // 旗標
        this.$flag = {
            inited: false
        };

        // 工作列表
        this.$jobList = [];

        // 工作人員
        this.$workers = new Set();

        // 是否有解雇的排程
        this.$schedule_handle = null;

        // setting
        this.$config = null;

        this.$importScripts = [];

        // worker 初始化要執行的
        this.$worker_init = {
            args: null,
            callback: null
        };
        //-----------------------
        this._init(config);
    }
    //--------------------------------------------------------------------------
    _init(config) {
        // debugger;
        let Config_class = $GM.get('Config');
        this.$config = Config_class.getInstance(config);
    }
    //--------------------------------------------------------------------------
    get config() {
        return this.$config.get();
    }
    //--------------------------------------------------------------------------
    // 設定參數
    setConfig(key, value) {
        // debugger;
        this.$config.set(key, value);
    }
    //--------------------------------------------------------------------------
    importScripts(script) {
        let scriptList = [];

        if (!Array.isArray(script)) {
            scriptList.push(script);
        }else{
            scriptList = script;
        }

        scriptList.forEach((s)=>{
            this.$importScripts.push(s);
        });
    }
    //--------------------------------------------------------------------------
    // 設定 worker init 要執行的 callback
    setWorkerInit(...args) {
        // debugger;

        if (typeof args[0] != 'function') {
            throw new TypeError('setInt(arg[0]) must be function');
        }

        let callback = args.shift();

        this.$worker_init.args = args;
        this.$worker_init.callback = Function.prototype.toString.call(callback);
    }
    //--------------------------------------------------------------------------
    // 啓動 worker
    startWorker() {
        // debugger;
        if (this.$flag.inited) {
            return;
        }
        console.log('pool 初始化 worker');
        this.$flag.inited = true;

        // 確定有足夠的核心員工
        this._checkCoreWorkerNum();
    }
    //--------------------------------------------------------------------------
    // API
    // 當外部有工作要托付執行
    notice(job_args = []) {
        // debugger;
        console.log('有新工作加入');

        const jobList = this.$jobList;

        if (this.$schedule_handle != null) {
            console.log('之前有排定裁員計劃，停止');
            // 有工作可接了，暫緩解職程序
            clearTimeout(this.$schedule_handle);
            this.$schedule_handle = null;
        }
        //------------------
        const Job_class = $GM.get('Job');
        let newJob;

        if (job_args[0] instanceof Job_class) {
            newJob = job_args[0];
        } else {
            // 做成 job
            newJob = Job_class.getInstance(job_args);
        }
        // debugger;
        // 新工作加入隊列
        jobList.push(newJob);
        //------------------
        // 分配工作
        let job;
        while (true) {
            // debugger;
            if (jobList.length < 1) {
                break;
            }
            // 找員工接工作
            const worker = this._findWorker2takeJob();
            if (worker == null) {
                break;
            }
            job = jobList.shift();
            worker.takeJob(job);
            console.log('員工(%s)接任務', worker.$id);
        }
        return newJob.promise();
    }
    //--------------------------------------------------------------------------
    // API
    // worker 任務結束的囘報
    noticeByWorker(finish_worker, dismiss_worker) {
        // debugger;

        if (finish_worker != null && dismiss_worker != null) {
            throw new Error('error status');
        }

        if (finish_worker != null) {
            console.log('員工(%s)囘報', finish_worker.$id);
        }

        if (dismiss_worker != null) {
            console.log('離職員工回報');
        }
        //------------------
        if (dismiss_worker != null) {
            // 有人離職了
            // 先確定有一定的核心工作人數
            this._checkCoreWorkerNum();
        }

        if (this.$jobList.length < 1) {
            // 沒有工作了，打算裁不必要的員工

            console.log('沒有工作了，打算裁不必要的員工');

            if (this.$schedule_handle != null) {
                console.log('已有裁員排程，不必再排');
            } else {
                // 若沒有解雇排程
                // 新增解雇排程
                this._dismissWorker_by_schedule();
            }

        } else {
            // 還有工作
            console.log('尚有工作要處理');

            if (this.$schedule_handle != null) {
                throw new Error('有裁員排程，奇怪點........');
            }

            if (finish_worker != null) {
                // 你沒事就接工作吧

                console.log('由回報者接工作');

                let job = this.$jobList.shift();
                finish_worker.takeJob(job);
            }

            if (dismiss_worker != null) {
                // debugger;
                // 這位回報者離職了
                // 找其他人接
                let idle_worker = this._findWorker2takeJob();

                if (idle_worker != null) {

                    console.log('找來員工(%s)接工作', finish_worker.$id);

                    job = this.$jobList.shift();
                    idle_worker.takeJob(job);
                } else {
                    console.log('無人有空可接');
                }
            }
        }
    }
    //--------------------------------------------------------------------------
    // 停止 pool 的運作
    close() {

        if (this.$schedule_handle) {
            clearTimeout(this.$schedule_handle);
            this.$schedule_handle = null;
        }

        this.$flag.inited = false;

        this.$jobList.length = 0;

        this.$workers.forEach((w) => {
            // 職員都解僱
            w.dismiss(false);
        });

        this.$workers.clear();
    }
    //--------------------------------------------------------------------------

    // 確定有足夠的核心員工
    _checkCoreWorkerNum() {
        // debugger;
        const $config = this.$config;

        const corePoolSize = $config.get('corePoolSize');

        const $Worker_class = $GM.get('WorkerProxy')

        console.log('檢查核心員工數量，需(%s)位，現共有員工(%s)位', corePoolSize, this.$workers.size);

        while (corePoolSize > this.$workers.size) {
            // debugger;
            console.log('核心員工不夠(%s)位，補齊中', (corePoolSize - this.$workers.size));
            const worker = $Worker_class.getInstance(this);
            this.$workers.add(worker);
        }

        console.log('核心員工數量沒問題');
    }
    //--------------------------------------------------------------------------
    // 找人接工作
    _findWorker2takeJob() {
        // debugger;
        console.log('找人接工作');

        const $config = this.$config;

        let idelWorker = null;
        // 找有空的接工作
        let {
            idle: idleList
        } = this._checkWorkersStatus();

        if (idleList.length > 0) {
            // 既有員工有處在空閑的
            console.log('有閒置中的員工可接工作');

            idelWorker = idleList[0];
            idleList.length = 0;
        } else {

            // 若沒有限制 worker 的最大數量
            let judge_1 = ($config.get('maximumPoolSize') < 0);
            // 雖有限制 worker 的最大數量未超過限制
            let judge_2 = (this.$workers.size < $config.get('maximumPoolSize'))

            if (judge_1 || judge_2) {
                // 若既有的員工都在忙
                // 但有餘額可招募新人

                const $Worker_class = $GM.get('WorkerProxy');

                console.log('既有的員工都在忙，但有餘額可招募新人');

                // 剛招募的人員
                idelWorker = $Worker_class.getInstance(this);
                this.$workers.add(idelWorker);
            }
        }

        if (idelWorker == null) {
            console.log('無人可接工作');
        }

        return idelWorker;
    }

    //--------------------------------------------------------------------------
    // 排程解雇多餘員工
    // 避免一下子解雇太多員工
    _dismissWorker_by_schedule() {
        // debugger;
        console.log('排定裁員排程');

        if (this._is_needFireSomeone() == null) {
            return;
        }

        //------------------
        const keepAliveTime = this.$config.get('keepAliveTime');

        this.$schedule_handle = setTimeout(() => {
            // debugger;
            this.$schedule_handle = null;

            let fireList;
            let dismiss_worker;

            // 必須再做一次檢查
            // 避免計時器中間有變動
            if (null != (fireList = this._is_needFireSomeone())) {
                console.log('裁撤空閑人員');

                // 先解雇一個沒事的員工
                dismiss_worker = fireList[0];

                // worker 離職後不要再多引發一次檢查
                dismiss_worker.dismiss(false);
            }

            // 重新檢查
            this.noticeByWorker(null, dismiss_worker);

        }, keepAliveTime);
    }
    //--------------------------------------------------------------------------
    // 確定 workers 的狀態是否能接工作
    _checkWorkersStatus() {
        // debugger;
        const busyList = [];

        const workerList = Array.from(this.$workers);

        let idleList = workerList.filter((w) => {
            if (w.is_idle()) {
                return true;
            }
            busyList.push(w);
            return false;
        });

        return {
            busy: busyList,
            idle: idleList
        };
    }
    //--------------------------------------------------------------------------
    // 當沒工作可接時
    // 檢查是否有需要解僱的員工嗎
    _is_needFireSomeone() {
        if (this.$workers.size <= this.$config.get('corePoolSize')) {
            // 再次確定有固定班底
            // 中間可能有人發生錯誤，或被强制關閉
            console.log('以到最低需求人數(%s)不裁員', this.$config.get('corePoolSize'));
            return null;
        }

        const {
            idle,
            busy
        } = this._checkWorkersStatus();

        if (idle.length < 1) {
            console.log('沒有空閑中的人員，不裁員');
            return null;
        }

        if (idle.length == 1 && busy.length > 0) {
            // 重點
            // 有人在忙
            // 但只剩一人有空，就暫留
            console.log('有人在忙但只剩一人有空，不裁員');
            return null;
        }

        return idle;
    }
    //--------------------------------------------------------------------------
    // 當有 worker 發生嚴重錯誤
    // 終止 workerPool 的運行
    workerError(worker, er) {
        er = er.message;

        this.close();

        throw new Error(`worker(${worker.$id}): ${er}`);
    }
}
