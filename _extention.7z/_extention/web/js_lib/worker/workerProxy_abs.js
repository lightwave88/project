import $GM from './globalModule.js';

// 抽象類
class WorkerProxy_abs {

    static WORKER_UID = 0;

    static getInstance(pool) {
        throw new Error('need override');
    }
    //--------------------------------------------------------------------------
    // employment: 是否是僱員
    constructor(pool) {
        // debugger;
        this.$pool = pool;

        this.$config = this.$pool.$config;

        this.$timeout = null;

        // 任務超時計時器
        this.$timeout_handle = null;
        //------------------
        this.$id = null;

        // 令牌，供事件辨別是否是系統來的事件
        // 還是使用者發出的事件
        this.$token_id = null;

        // 當前接的任務
        this.$job = null;

        // worker 本體
        this.$worker;
        //------------------
        // 旗標訊號
        this.$flag = {
            busy: false,
            initinated: false
        };
        //------------------
        //callback
        this.$event_end;

        // callback
        this.$event_error;
        //------------------   
        this._init();
    }
    //--------------------------------------------------------------------------
    _init() {
        // debugger;

        this.$id = `W-(${WorkerProxy_abs.WORKER_UID++})`;
        this.$token_id = (new Date()).getTime();
        this.$token_id %= 100000;
        this.$token_id = String(this.$token_id);

        const $config = this.$config;

        if ($config.get('timeout') != null || $config.get('timeout') < 0) {
            // 確定是否有執行的時限
            this.$timeout = $config.get('timeout');
        }

        this.$event_end = this.getEndEvent();
        this.$event_error = this.getErrorEvent();

        this.initialization();
    }
    //--------------------------------------------------------------------------
    // @override
    // 取得本體內容
    // 實例化本體
    // 連接事件
    // 不同系統，有不同的方式
    initialization() {
        throw new Error('need override initialization()');

    }
    //--------------------------------------------------------------------------
    // @override
    // 不同系統，有不同的方式
    postMessage(msg) {
        throw new Error('need override postMessage()');
    }
    //--------------------------------------------------------------------------

    // @override
    // 關閉 worker
    // 不同系統，有不同的方式
    _terminate() {
        throw new Error('need override terminate()');
    }
    //--------------------------------------------------------------------------
    // API 執行任務
    takeJob(job) {

        this._clearTimer();

        const JobClass = $GM.get('Job');
        const $flag = this.$flag;

        if (!(job instanceof JobClass)) {
            throw new TypeError('job typeError(%s)', (typeof job));
        }

        if (!$flag.initinated) {
            // 尚未初始化完成
            this.$job = job.$$$core;
            return;
        }
        //-----------------------
        console.log('worker(%s)接工作', this.$id);
        this.$flag.busy = true;

        this.$job = job.$$$core;
        this.$job.setWorker(this);
        //-----------------------        
        // 取得任務內容
        let jobContent = this.$job.getJobContent();

        let msg = this._setMsg({
            cmd: 'job',
            job: jobContent
        });

        // 請 worker 工作
        this.postMessage(msg);

        // 若工作有時限
        if (this.$timeout != null) {
            this.$timeout_handle = setTimeout(() => {
                this.jobTimeout();
            }, this.$timeout);
        }
    }

    //--------------------------------------------------------------------------
    // API 離職
    dismiss(report = true) {
        console.log('worker(%s)離職', this.$id);

        if (this.$job != null) {
            this.job.reject();
            this.$job = null;
        }

        if (!report) {
            this._close();
            // 不需回報
            return;
        }
        // 回報
        this.next(true);
    }
    //--------------------------------------------------------------------------
    // API 初始化完成
    initinated() {
        // debugger;

        this.$flag.initinated = true;

        if (this.$job != null) {
            // 若初始化完之前有被指派工作
            this.takeJob(this.job);
        } else {
            // 通知 pool 分派任務
            this.next();
        }
    }
    //--------------------------------------------------------------------------
    // API 工作結束
    jobEnd(res) {
        // debugger;

        console.log("worker(%s)任務結束", this.$id);

        this._clearTimer();

        const job = this.$job;

        // 通知 pool
        this.next();

        job.resolve(res);
    }
    //--------------------------------------------------------------------------
    // API 提交的工作發生可接受的錯誤
    jobError(err) {
        // debugger;

        console.log("worker(%s)任務發生錯誤", this.$id);

        this._clearTimer();

        const job = this.$job;

        // 通知 pool
        this.next();

        job.reject(err);
    }
    //--------------------------------------------------------------------------
    // API 工作超時
    jobTimeout() {
        // debugger;
        console.log("worker(%s)任務過時", this.$id);

        const job = this.$job;
        this.$timeout_handle = null;

        // 離職
        this.dismiss();

        job.reject('time out');
    }

    //--------------------------------------------------------------------------
    // API worker 運行錯誤
    workerError(e) {

        const job = this.$job;

        if (job != null) {
            job.reject('worker error');
        }
        const pool = this.$pool;
        
        this._close();
        
        pool.workerError(this, e);
    }
    //--------------------------------------------------------------------------
    // API 使用者中斷工作
    user_stopJop() {

        if (this.$job != null) {
            this.job.resolve();
            this.$job = null;
        }

        // 離職
        this.dismiss();
    }
    //--------------------------------------------------------------------------
    // 自身任務已結束
    // 通知 pool 繼續下一步
    next(close) {

        close = (close === true) ? true : false;

        let finish_w;
        let dismiss_w;

        if (close) {
            dismiss_w = this;
            this._close();
        } else {
            finish_w = this;
            this._reset();
        }

        this.$pool.noticeByWorker(finish_w, dismiss_w);
    }
    //--------------------------------------------------------------------------
    // @override
    getEndEvent() {
        throw new Error('need override _event_getEndEvent');
    }
    //--------------------------------------------------------------------------
    // @override
    getErrorEvent() {
        throw new Error('need override _event_getErrorEvent');
    }
    //--------------------------------------------------------------------------
    // 判斷是否能接工作
    is_idle() {
        if (this.$job != null) {
            // 有任務在身
            return false;
        }
        const flag = this.$flag;

        if (!flag.initinated) {
            // 尚未初始化完成
            return false;
        } else {
            // 已初始化完成
            if (flag.busy) {
                return false;
            }
        }
        return true;
    }
    //--------------------------------------------------------------------------
    _reset() {
        this.$flag.busy = false;
        this.$job = null;
    }
    //--------------------------------------------------------------------------
    // 離職會呼叫
    _close() {

        this._clearTimer();

        this.$pool.$workers.delete(this);

        try {
            this._terminate();
        } catch (error) {

        }

        this.$pool = null;
        this.$timeout = null;
        this.$config = null;
        this.$id = null;
        this.$token_id = null;
        this.$job = null;
        this.$worker = null;
        this.$flag = null;
        this.$event_end = null;
        this.$event_error = null;
    }
    //--------------------------------------------------------------------------
    // 設定要發送的訊息
    _setMsg(setting) {
        // id: 以供辨認是否是系統訊息                      
        let msg = {
            cmd: null,
        };

        // 寫入令牌        
        msg[this.$token_id] = true;

        Object.assign(msg, setting);
        return msg;
    }
    //--------------------------------------------------------------------------
    // 清除計時器
    _clearTimer() {
        if (this.$timeout_handle != null) {
            clearTimeout(this.$timeout_handle);
            this.$timeout_handle = null;
        }
    }
}

export default WorkerProxy_abs;
