import $GM from './globalModule.js';

///////////////////////////////////////////////////////////////////////////////
//
// 預設 worker 會彈性隨效能在(max_workers, min_workers)之間調整數量
//
// 但若不想 worker 的數量自動彈性調整，可以設定(max_workers = min_workers)
//
///////////////////////////////////////////////////////////////////////////////

const $default_config = {};

(function () {

    // 同時能運行最大的 worker 數量
    // 負數代表沒設限
    this.maximumPoolSize = 2;

    // idle 時要維持幾個 workers 待命
    this.corePoolSize = 0;

    // 當 worker 沒任務可接時
    // 閒置多久後會被銷毀
    this.keepAliveTime = (1000 * 60);

    // 任務的時限，預設無時限
    // (null|負數)代表無時限
    this.timeout = null;

}).call($default_config);
//--------------------------------------
// defaultSetting 的包覆者
// 可以做輸入驗證

class Config {
    static getInstance(config) {
        return new Config(config);
    }
    //--------------------------------------------------------------------------
    constructor(config = {}) {
        this.$config = Object.assign({}, $default_config, config);

        // 數值檢查
        Object.keys(this.$config).forEach((k) => {
            if (k in $default_config) {
                let value = this.$config[k];
                this.set(k, value);
            } else {
                delete this.$config[k];
            }
        });
    }
    //--------------------------------------------------------------------------
    set(key, value) {

        let setting = {};

        if (typeof key == 'string') {
            setting[key] = value;
        } else {
            Object.assign(setting, key)
        }

        const $config = this.$config;
        const keyList = Object.keys(setting);

        //debugger;
        keyList.forEach((k) => {
            //debugger;

            if (!(k in $default_config)) {
                throw new Error(`no this attr(${k}) can set`);
            }

            let fn = Config['_' + k];

            let value = setting[k];

            if (typeof fn == 'function') {
                value = fn(this, value);
            }
            $config[k] = value;
        });
    }

    get(key) {
        const $config = this.$config;

        if (key != null) {
            if (!(key in $default_config)) {
                throw new Error(`cant't get this attr(${key})`);
            }
            return $config[key];
        }
        const res = {};

        const setKeyList = Object.keys($default_config);

        setKeyList.forEach((k) => {
            res[k] = $config[k];
        });

        return res;
    }
    //--------------------------------------------------------------------------
    static _maxPoolSize(c, count) {

        const setting = c.$config;

        checkInt(count, 'maxPoolSize must be integer');

        return count;

    }
    //--------------------------------------------------------------------------

    static _maximumPoolSize(c, count) {

        const setting = c.$config;

        checkInt(count, 'maximumPoolSize must be integer');

        const errorList = [];

        if (count < 0) {
            // maximumPoolSize 不設限
            setting.maximumPoolSize = -1;
            return;
        }
        //------------------
        if (count < setting.corePoolSize) {
            errorList.push(`maxPoolSize(${count}) < min_workers(${setting.corePoolSize})`);
        }

        if (count < 1) {
            errorList.push('max_workers must < 1');
        }

        if (errorList.length) {
            let msg = errorList.join("\n");
            throw new TypeError(msg);
        }

        return count;
    }
    //--------------------------------------------------------------------------
    static _corePoolSize(c, count) {

        const setting = c.$config;

        checkInt(count, 'corePoolSize must be integer');

        const errorList = [];

        if (count < 0) {
            errorList.push(`corePoolSize(${count}) < 0`);
        }

        if (setting.maximumPoolSize >= 0) {
            if (count > setting.maximumPoolSize) {
                errorList.push(`corePoolSize(${count}) > max_workers(${setting.maximumPoolSize})`);
            }
        }


        if (errorList.length) {
            let msg = errorList.join("\n");
            throw new TypeError(msg);
        }

        return count;
    }
    //--------------------------------------------------------------------------
    static _keepAliveTime(c, time) {

        const setting = c.$config;

        checkInt(time, 'keepAliveTime must be integer');

        if (time < 0) {
            throw new TypeError(`keepAliveTime(${time}) must be >= 0`);
        }

        return time;
    }
    //--------------------------------------------------------------------------
    // worker 任務的時限
    // time = 0 沒時限
    static _timeout(c, time) {

        const setting = c.$config;

        checkInt(time, 'keepAliveTime must be integer');

        if (time == null) {
            time = null;
        } else {
            time = Number(time);
            if (time < 0) {
                throw new TypeError("timeout must be >= 0");
            }
        }
        return time;
    }
    //--------------------------------------------------------------------------
}

export default Config;

function checkInt(value, $error_msg = '') {
    // debugger;
    let error;
    try {
        value = Number(value);
        if (isNaN(value) || !isFinite(value)) {
            throw new TypeError('NaN');
        }
        let res = value % 1;
        if (res != 0) {
            throw new TypeError('not int');
        }

    } catch (er) {
        error = er;
    }

    if (error == null) {
        return;
    }

    throw new TypeError($error_msg);
}