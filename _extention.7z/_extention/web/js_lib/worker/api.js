import $GM from './globalModule.js';

const get_globalPool = function() {
    const _ = $GM.get('_');
    const extension = _['$$$extension'];

    if (extension['global_workerPool'] == null) {
        const $Pool = $GM.get('Pool');
        extension['global_workerPool'] = $Pool.getInstance();
    }
    return extension['global_workerPool'];
};
//------------------------------------------------------------------------------
// _.worker();
function API(...args) {
    // API 精簡化
    // 等於 _.workPool.execute()
    return API.execute.apply(API, args);
}

export default API;
//------------------------------------------------------------------------------
(function() {

    // 取得 _workerPool.config
    Object.defineProperty(API, 'config', {
        enumerable: true,
        configurable: false,
        // writable: false,
        get: function() {
            const pool = get_globalPool();
            return pool.config;
        }
    });

    this.execute = function(...args) {
        debugger;
        const pool = get_globalPool();
        const pr = pool.execute(args);
        return pr;
    };

    this.close = function() {
        const pool = get_globalPool();
        pool.close();
    };

    //--------------------------------------------------------------------------
    // workerPool 預設一開使并沒有啓動 worker
    // 等待有賦予工作時才會啓動 worker
    // 可以在一開始啓動 worker
    this.startWorker = function(config = {}) {
        // debugger;

        const pool = get_globalPool();

        if (pool.is_inited) {
            return pool;
        }

        if (config != null) {
            pool.setConfig(config);
        }

        pool.startWorker();
        return pool;
    };
    //--------------------------------------------------------------------------
    // worker 必須額外載入的 script 
    this.importScripts = function(script = []) {
        const pool = get_globalPool();
        pool.importScripts(script);
    };
    //--------------------------------------------------------------------------
    this.setConfig = function(config) {
        const pool = get_globalPool();
        pool.setConfig(config);
        return pool;
    };
    //--------------------------------------------------------------------------
    // 指定 worker 初始化要執行的 callback
    this.setWorkerInit = function(...args) {
        // debugger;

        const pool = get_globalPool();
        pool.setWorkerInit.apply(pool, args);

        return pool;
    };
    //--------------------------------------------------------------------------
    // 生成一個獨立於全局 pool 的 pool 
    this.makePool = function(config = {}) {
        const $Pool = $GM.get('Pool');
        const pool = $Pool.getInstance(config);
        return pool;
    };
    //--------------------------------------------------------------------------
    // 形成一個 job
    // 可以提供更多的操作
    this.job = function(...args) {
        const Job_class = $GM.get('Job');
        const job = Job_class.getInstance(args);
        return job;
    };
}).call(API);
