const $error = {};
export default $error;


class EnvError extends Error {
    // 檢查 env 錯誤
}

$error['env_error'] = EnvError;