import WorkerProxy_abs from './workerProxy_abs.js';
import $GM from './globalModule.js'

class WorkerProxy extends WorkerProxy_abs {
    static getInstance(pool) {
        return new WorkerProxy(pool);
    }
    //--------------------------------------------------------------------------
    // 實作 worker 的建立
    initialization() {
        // debugger;

        let workerContent = getWorkerContent(this);

        this.$worker = new Worker(workerContent);

        this.$worker.addEventListener('message', this.$event_end);
        this.$worker.addEventListener('error', this.$event_error);
    }
    //--------------------------------------------------------------------------
    postMessage(msg) {
        try {
            // 對訊息的合法性做檢查
            msg = JSON.stringify(msg);
        } catch (er) {
            throw new TypeError(`postMsg can't pass throught JSON.stringify()`);
        }

        this.$worker.postMessage(msg);
    }
    //--------------------------------------------------------------------------
    // 實作 closeWorker
    _terminate() {
        
        w.removeEventListener('message', this.$event_end);
        w.removeEventListener('error', this.$event_error);

        w.terminate();
    }
    //--------------------------------------------------------------------------
    // 事件 callback
    getEndEvent() {
        return (e) => {
            // debugger;
            const data = e.data;

            console.log('worker 回傳訊息');
            console.dir(data);

            let is_sysMsg = false;

            try {
                is_sysMsg = (this.$token_id in data);
            } catch (error) { 
                is_sysMsg = false;
            }

            if (is_sysMsg) {

                let {
                    msg,
                    status
                } = data;
                // 系統預設事件
                switch (status) {
                    case 'initialized':
                        this.initinated();
                        break;
                    case 'jobError':
                        // 捕捉到的 error
                        this.jobError(msg);
                        break;
                    case 'jobEnd':
                        this.jobEnd(msg);
                        break;
                    default:
                        throw new Error('no status report');
                        break;
                }
            } else {
                // 使用者發射的事件
                if (this.$job != null) {
                    this.$job.recieveMsg(data);
                }
            }
        };
    }
    //--------------------------------------------------------------------------
    // worker 執行錯誤
    getErrorEvent() {
        return (err) => {
            debugger;

            // 沒補抓到的 error
            this.workerError(err);
        };
    }
}

export default WorkerProxy;

////////////////////////////////////////////////////////////////////////////////
// 取得 worker 的内文
function getWorkerContent(w) {
    // debugger;

    let content = '';
    //------------------

    let fn_content_1 = w.$pool.$worker_init.callback || "null";
    let fn_content_2 = workerContent_2();

    let init_args = w.$pool.$worker_init.args;
    init_args = Array.isArray(init_args) ? init_args : [];
    init_args = JSON.stringify(init_args);

    let worker_id = JSON.stringify(w.$id);
    let token_id = JSON.stringify(w.$token_id);

    let scriptList = w.$pool.$importScripts;
    scriptList = Array.isArray(scriptList) ? scriptList : [];
    scriptList = JSON.stringify(scriptList);

    //------------------
    content =
        `
    debugger;

    let $worker_id = ${worker_id};
    let $token_id = ${token_id};
    //------------------
    // import scripts
    let $scriptList = ${scriptList};
    
    $scriptList.forEach((script)=>{
        try {
            importScripts(script);
        } catch (error) {
            error = "script load error:" + error.toString();
            throw new Error(error);
        }    });
    
    //------------------
    let $init_fun = null;
    let $init_args = ${init_args};
    
    try{
        $init_fun = ${fn_content_1};        
    }catch(e){
        throw new Error('init function error');
    }    
    
    if(typeof $init_fun == "function"){
        $init_fun.apply(this, $init_args);
    }    
    //------------------
    debugger;

    const $worker = (${fn_content_2})();    
    
    debugger;

    // 初始化
    $worker.init(self, {        
        "worker_id": $worker_id,
        "token_id": $token_id,
    });

    $scriptList = null;
    $init_args = null;
    $init_fun = null;
    $worker_id = null;
    $token_id = null;`;
    //------------------
    console.log(content);

    let bb = new Blob([content]);

    return URL.createObjectURL(bb);
}
////////////////////////////////////////////////////////////////////////////////

function workerContent_2() {
    const $fun = function () {
        // worker 内文

        const $worker = {
            "_": null,
            id: null,
            "token_id": null,
            runtimeEnv: null,
            // 使用者注冊的
            listenerList: [],
            global: null,
            'proxy_self': null,
            // job 中讓使用者操作的 handle
            'cmd_handle': null,
            init(global, setting) {
                debugger;

                let {
                    worker_id,
                    token_id
                } = setting;

                this.global = global;
                this.id = worker_id;
                this.token_id = token_id;

                if (this.id == null) {
                    throw new Error('no get worker_id');
                }

                if (this.token_id == null) {
                    throw new Error('no get token_id');
                }

                if (this.global._ == null) {
                    throw new Error('no import _');
                }
                this._ = this.global._;

                //------------------

                this.global.addEventListener('message', (e) => {
                    debugger;

                    let data = e.data;

                    try {
                        data = JSON.parse(data);
                    } catch (error) {
                        this.postRunTimeError(er);
                        return;
                    }

                    let is_fromSystem;

                    try {
                        is_fromSystem = (this.token_id in data);
                    } catch (error) {
                        is_fromSystem = false;
                    }

                    if (is_fromSystem) {
                        // 來自系統的訊息

                        const cmd = data.cmd;

                        switch (cmd) {
                            case 'job':
                            default:
                                try {
                                    // 執行任務
                                    this.doSysJob(data.job);
                                } catch (er) {
                                    debugger;
                                    // 執行錯誤
                                    this.postRunTimeError(er);
                                }
                                break;
                        }

                    } else {
                        // 來自使用者發的訊息
                        this.callListener(data);
                    }
                });
                //------------------

                // 通知已經初始化完成
                this.postSysMsg('initialized');
            },
            // 當使用者發射訊號
            // 會呼叫使用者
            callListener(msg) {
                this.listenerList.forEach((callback) => {
                    callback(msg);
                });
            },
            // 發送系統訊息用
            postSysMsg(status, msg) {

                const report = {
                    // 系統訊息的憑證                    
                    status: status
                };

                if (typeof msg == 'object' && !(msg instanceof Error)) {
                    Object.assign(report, msg);
                } else {
                    report.msg = msg;
                }

                switch (status) {
                    // jobEnd
                    case 'jobError':
                    case 'jobEnd':
                        // 清除使用者設定的監聽事件
                        this.listenerList.length = 0;
                        break;
                    default:
                        break;
                }

                report[this.token_id] = true;

                this.postMsg(report);
            },
            // 發送訊息
            postMsg(msg) {
                this.global.postMessage(msg);
            },
            postRunTimeError(er) {
                // job 執行錯誤                
                this.postSysMsg('jobError', er);
            },
            // 重塑 worker 部分預設的 API
            _getProxySelf() {

                if (this['proxy_self'] != null) {
                    return this['proxy_self'];
                }
                //-----------------
                // 遮蔽 self 部分功能
                let s = new Proxy(this.global, {
                    get(t, k) {
                        let res;
                        switch (k) {
                            case 'addEventListener':
                                res = function () { };
                                break;
                            default:
                                res = t[k];
                                break;
                        }
                        return res;
                    },
                    set(t, k, v) {
                        // 禁止在 worker 內部設置 self.onmessage = 
                        switch (k) {
                            case 'onmessage':
                                break;
                            default:
                                t[k] = v;
                                break;
                        }
                        return true;
                    }
                });

                this['proxy_self'] = s;

                return s;
            },
            _buildFun(funText) {
                let fun = new Function('self',
                    `
                    'use strict';
                    
                    // 遮蔽以下的功能與 self
                    const addEventListener = function(...args){};
                    const onmessage = {};
                
                return (${funText});`
                );

                const proxy_self = this._getProxySelf();
                fun = fun(proxy_self);

                return fun;
            },
            _getCmdHandle() {
                if (this['cmd_handle'] != null) {
                    return this['cmd_handle'];
                }
                const $this = this;

                // fun 內部的命令
                const cmdHandle = {
                    resolve(data) {
                        $this.postSysMsg('jobEnd', data);
                    },
                    reject(er) {
                        $this.postSysMsg('jobError', er);
                    },
                    // 註冊一個監視
                    onMsg(callback) {
                        $this.listenerList.push(callback);
                    },
                    postMsg(msg) {
                        $this.postMsg(msg);
                    },
                };
                this['cmd_handle'] = cmdHandle;

                return cmdHandle;
            },
            // 建造一個乾淨的執行環境
            _getRuntimeEnv() {
                if (this['runtimeEnv'] != null) {
                    return this['runtimeEnv'];
                }

                let fun_content =
                    `
                    'use strict';
                    return fun.apply(context, args);
                `;

                const runtimeEnv = new Function('fun', 'context', 'args', fun_content);
                this['runtimeEnv'] = runtimeEnv;

                return runtimeEnv;
            },
            _checkArgs_1(args, funList, context) {
                funList.forEach((index) => {
                    let fn_content = args[index];
                    let fn = this._buildFun(fn_content);
                    args[index] = fn.bind(context);
                });
            },
            _checkArgs_2(args, funList) {
                if (funList.length) {
                    throw new TypeError(`args can't include function`);
                }
            },
            // 執行任務
            doSysJob(jobData) {
                debugger;

                let {
                    // _命令
                    cmd = null,
                    act = null,
                    setting = [],
                    funList = [],
                    id,
                } = jobData;

                let job;
                let context = null;

                if (cmd != null) {
                    context = this._;
                    job = this._[cmd];

                    if (typeof job != 'function') {
                        throw new Error(`no this function _.(${cmd})`);
                    }
                    this._checkArgs_1(setting, funList, context);
                } else {
                    job = this._buildFun(act);

                    this._checkArgs_2(setting, funList);
                    // 插入一個可讓使用者執行命令的 handle
                    setting.unshift(this._getCmdHandle());
                }
                debugger;
                // 建立一個乾淨的執行環境
                const env = this._getRuntimeEnv();

                // 執行任務
                env(job, context, setting);
            },

        };
        //------------------
        return $worker;
    }; // fun end

    return Function.prototype.toString.call($fun);
}
