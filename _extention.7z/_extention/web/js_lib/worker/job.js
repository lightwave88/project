import $GM from './globalModule.js';

class Job_wrap {

    static getInstance(args) {
        return new Job_wrap(args);
    }
    //--------------------------------------------------------------------------
    constructor(args = []) {
        this.$$$core = new Job(args);
    }

    promise() {
        return this.$$$core.$deferred;
    }

    // 終止任務
    // 當任務無法以一般手段終止
    // 只好終止執行他的 worker
    stop() {
        this.$$$core.stop();
    }

    // 對 job 傳送訊息
    postMsg(msg) {
        this.$$$core.postMsg(msg);
    }

    // 接受 job 執行中回傳的訊息
    onMsg(callback) {
        this.$$$core.onMsg(callback);
    }

    // 查詢工作是否結束
    isFinish() {
        return this.$$$core.isFinish();
    }
}

export default Job_wrap;
//------------------------------------------------------------------------------
class Job {

    constructor(setting = []) {
        // debugger;
        this._ = $GM.get('_');

        // 執行任務的 worker
        this.$worker;

        // 使用者的設定
        this.$setting = setting;

        // 註冊事件
        this.$callbackList = [];
        this.$is_finish = false;

        this.$deferred = this._.deferred();

        // 重整過的任務內容
        this.$jobContent;

        this._init();
    }
    //--------------------------------------------------------------------------
    _init() {
        this.$jobContent = this._setJobContent();
    }
    //--------------------------------------------------------------------------
    setWorker(worker) {
        this.$worker = worker;
    }
    //--------------------------------------------------------------------------
    promise() {
        return this.$deferred;
    }

    resolve(d) {
        this.$is_finish = true;
        this.$deferred.resolve(d)
    }

    reject(er) {
        this.$is_finish = true;
        this.$deferred.reject(er);
    }

    // 手動結束使用中的 worker
    stop() {
        this.$worker.user_stopJop();
    }

    postMsg(msg) {
        this.$worker.postMessage(msg);
    }

    onMsg(callback) {
        if (typeof callback != 'function') {
            throw new Error('arg[0] must be function');
        }
        this.$callbackList.push(callback);
    }

    isFinish() {
        return this.$is_finish;
    }

    getJobContent() {
        return this.$jobContent;
    }
    //--------------------------------------------------------------------------
    // 取得任務内容
    _setJobContent() {
         debugger;

        const jobContent = {
            cmd: null,
            act: null,
            setting: [],
            funList: []
        };
        let setting = this.$setting.slice();

        const first = setting.shift();

        setting.forEach((arg, i) => {
            if (typeof arg == 'function') {
                jobContent.funList.push(i);
                arg = $tools.fun2String(arg);
            }
            jobContent.setting.push(arg);
        });

        // debugger;
        if (typeof first == 'string') {
            jobContent.cmd = first;
        } else if (typeof first == 'function') {
            jobContent.act = Function.prototype.toString.call(first);
        } else {
            throw new TypeError('unaccept type of args[0] (' + typeof (first) + ')' + first);
        }
        return jobContent;
    }

    //--------------------------------------------------------------------------
    // worker 收到訊息
    recieveMsg(msg) {
        this.$callbackList.forEach((fun) => {
            fun(msg);
        });
    }
}
