debugger;

import { G } from './g.js';

export default G;