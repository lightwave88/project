debugger;
const G = {};

debugger;
export { G };


debugger;
import { a } from './a.js';

try {
    console.dir(a);
    G['a'] = a;
} catch (error) {
    console.log(error);
}


debugger;
import { b } from './b.js';

try {
    console.dir(b);
    G['b'] = b;
} catch (error) {
    console.log(error);
}