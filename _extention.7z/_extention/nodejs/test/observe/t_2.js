const $util = require('util')

require('_extension').expand('underscore');
const _ = require('underscore');

let data = {};

data = _.observe.ob(data);

_.observe.watch(data,'*.age', function(e){
    debugger;
    
    console.log(JSON.stringify(e));
});

debugger;
data['age'] = 15;

debugger;

delete data['age'];


