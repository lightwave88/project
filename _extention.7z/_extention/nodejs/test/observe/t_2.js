const $util = require('util')

require('_extension').expand('underscore');
const _ = require('underscore');

let data = [0, [5, 4, 3], 2];

_.observe.ob(data);

debugger;
data[1].reverse();

console.log(JSON.stringify(data));


