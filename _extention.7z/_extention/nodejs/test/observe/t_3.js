const $util = require('util')

require('_extension').expand('underscore');
const _ = require('underscore');

let data = {
    a: 5,
    b: [5, 3, 1]
};

data = _.observe.ob(data);

_.observe.watch(data, '*.a', function (e) {
    debugger;
    console.log('*.a');
    console.log(JSON.stringify(e));
});

_.observe.watch(data, '*', function (e) {
    debugger;
    console.log('*');
    console.log(JSON.stringify(e));
});

_.observe.watch(data, '*.b.2', function (e) {
    debugger;
    console.log('*.b.3');
    console.log(JSON.stringify(e));
});

debugger;
data.b.reverse();