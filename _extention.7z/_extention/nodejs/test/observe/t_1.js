
class X{
	static t1(){
		console.log('static t1()');
	}

	t1(){
		console.log('t1()');

		X.t1();
	}
}

let x = new X();
x.t1();
