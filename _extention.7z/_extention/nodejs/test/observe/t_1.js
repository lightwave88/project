require('_extension').expand('underscore');
const _ = require('underscore');

debugger;

let a = [5, { age: 5 }]

let b = _.observe.ob(a);

console.dir(b);

debugger;

console.log(typeof b);
console.log(b instanceof Array);


b.reverse();

console.log(JSON.stringify(b));


