

let data = [1, 2, 3];


let d = new Proxy(data, {
    set: function (t, k, v) {
        debugger;
        console.log('set(%s)',k);
        t[k] = v;
        return true;
    },
    get: function (t, k) {
        debugger;
        console.log('get(%s)',k);
        return t[k];
    }
});


debugger;
d.reverse();