
debugger;

(function x(a, b) {
    debugger;

    console.dir(this);
    console.log(a + b);

}).apply({ age: 15 }, [5, 9]);






