const { MessageChannel, Worker } = require('worker_threads');
const $path = require('path');


let workerPath = $path.resolve(__dirname, './child_2.js');

debugger;
let w_1 = new Worker(workerPath, {
    workerData: {}
});

console.log('require' in global);

w_1.on('message', (e) => {
    debugger;
    console.dir(e);
    console.log('recieve msg(%s)', e);
});

w_1.on('exit', () => {
    debugger;
    console.log('end');
});

w_1.on('error', (er) => {
    debugger;
    console.dir(er);
});

function postMsg() {
    debugger;


    // let importList = [script_path];
    let args = [testCallback, {
        age: 16
    }];
    let funs = [];

    args = args.map((arg, i) => {
        // debugger;
        if (typeof arg == 'function') {
            funs.push(i);
            arg = Function.prototype.toString.call(arg);
        }
        return arg;
    });

    let msg = {
        args,
        funs
    };

    w_1.postMessage(msg);

}

function testCallback() {
    let _ = this.require('underscore');
    return _.random(10, 99);
}


function terminate() {
    console.time('a');
    let p = w_1.terminate();
    p.then(() => {
        console.timeEnd('a');
        debugger;
    });
}

postMsg();

terminate();
