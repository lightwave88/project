let a= {};

a['_@_ob_@_'] = 5;

console.dir(a);
