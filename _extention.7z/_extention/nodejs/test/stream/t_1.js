const R_a = require('./class/r_a.js');
const W_a = require('./class/w_a.js');
const T_a = require('./class/t_a.js');


function t_1() {
    debugger;

    

    let rs = R_a.getInstance(50);
    let ws = W_a.getInstance();
    let ts = T_a.getInstance();

    setTimeout(() => {

        rs.pipe(ts).pipe(ws);
    }, 3000);

}

t_1();