const { Transform } = require('stream');
const child_process = require('child_process');
const $path = require('path');
// 測速
class T_a extends Transform {

    static getInstance() {
        return new T_a();
    }

    constructor(options) {
        super(options);

        this.count = 0;

        this.start;
        this.time;

        this.time_inteval = 10;

        this.record = [];

        this.x = 0;

        this.cp = 0;


        this.on('pipe', () => {
            console.log('pipe');
            this.cp.send('start');
            this.start = (new Date()).getTime();
            this.time = this.start;
        });


        this.on('end', () => {
            
            this.cp.send('end');

            let time = (new Date()).getTime();

            console.log('transform end time=%s', (time - this.start));
            console.log(JSON.stringify(this.record));

            console.log('x=%s', this.x);
            console.log('-------------------');
        });

        let path = $path.resolve(__dirname, './child_1.js');
        this.cp = child_process.fork(path);

        this.cp.on('message', () => {
            this.check();
        });
    }

    check() {
        this.x++;
        // console.log(this.x);
    }
    _transform(chunk, en, done) {
        // debugger;
        let value = chunk.toString('utf8');
        // console.log('tansform(%s) x=%s', value, this.x);

        let time = (new Date()).getTime();
        let time_dif = time - this.time;

        this.count += chunk.length;

        // console.log(time_dif);

        if (time_dif > this.time_inteval) {
            let rate = this.count / time_dif * (1000 / this.time_inteval);

            this.record.push(rate);

            this.time = time;
            this.count = 0;
        }
        this.push(chunk);
        done();
    }


}

module.exports = T_a;