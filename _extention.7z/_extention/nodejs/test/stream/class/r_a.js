const { Readable } = require("stream");

class R_a extends Readable {

    static getInstance(count) {
        return new R_a(count);
    }

    constructor(count, options) {
        debugger;
        super(options);

        this.$re = this.readData.call(this, count);
    }

    _read(size) {
        // debugger;
        // console.log('_read');

        let { value, done } = this.$re.next();

        if (done) {
            value = null;
        }

        if (!this.push(value)) {
            // 若輸入記憶體滿了
            // 不用做啥，也不會丟失資料
            // 會再過一時段重叫 _read()
        }
    }
    // 模擬產生數据
    *readData(count) {
        let c = 0;

        // debugger;
        for (let i = 0; i < count; i++) {
            // debugger;
            for (let j = 0; j < 100; j++) {
                let value = String(c++);
                yield value;
            }
        }
    }
}
module.exports = R_a;
