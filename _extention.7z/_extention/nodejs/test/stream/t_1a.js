const { Readable, Writable } = require("stream");

class X extends Readable {

    constructor(options) {
        debugger;
        super(options);

        this.$re = this.readData.call(this, 95);
    }

    _read(size) {
        // debugger;
        console.log('_read');

        let { value, done } = this.$re.next();

        if (done) {
            this.push(null);
        } else if (value === false) {
            console.log('push too much');
            // 壓入太多了
            // 不要再 push() 了
            // 到時會再呼叫一次 _read()
        }
    }

    *readData(count) {
        let c = 0;
    
        // debugger;
        for (let i = 0; i < count; i++) {
            // debugger;
            for (let j = 0; j < 100; j++) {
    
    
                let value = String(c++);
                let res = this.push(value);
                // debugger;
                console.log('push(%s) status(%s)', value, res);
    
                yield res;
    
            }
        }
    }

    
}



function* readData(count) {
    let c = 0;

    // debugger;
    for (let i = 0; i < count; i++) {
        // debugger;
        for (let j = 0; j < 100; j++) {


            let value = String(c++);
            let res = this.push(value);
            // debugger;
            console.log('push(%s) status(%s)', value, res);

            yield res;

        }
    }
}

class Y extends Writable {
    constructor(name, options) {
        super(options);
        this.name=name;
    }

    _write(chunk, en, close) {
        // debugger;

        setTimeout(() => {
            console.log('(%s)_write(%s)', this.name, chunk.toString('utf8'));
            close(null);
        }, 50);
    }
}



function t_2() {
    debugger;

    let rs = new X();
    let ws_1 = new Y('a');


    rs.pipe(ws_1);
}

t_2();