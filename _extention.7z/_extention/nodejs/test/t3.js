

let x = {
    age: 15,
    area: 12
};

let y = {
    area: 12,
    age: 15,
};


console.log(JSON.stringify(x));
console.log(JSON.stringify(y));






