// debugger;
const _extension = require('./extension.js');
_extension.import(require('./basicTool.js'));

module.exports = _extension;