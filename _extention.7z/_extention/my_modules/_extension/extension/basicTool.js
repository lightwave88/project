


module.exports = function (_) {

    const $injectModules = {};


    //-------------------------------------------------------------------------
    {
        // isPlainObject
        $injectModules['isPlainObject'] = {
            override: false,
            fun: isPlainObject
        };

        function isPlainObject(obj) {

            if (typeof obj != "object") {
                return false;
            }

            if (obj == null) {
                return false;
            }

            let res = Object.prototype.toString.call(obj);

            if (!/^\[object Object\]$/.test(res)) {
                return false;
            }

            if (obj.constructor !== {}.constructor) {
                return false;
            }

            return true;
        }
    }
    //==========================================================================

    {
        // getClassName

        $injectModules['getClassName'] = {
            override: false,
            fun: getClassName
        };

        function getClassName(data) {
            let _toString = Object.prototype.toString;

            let type = typeof (data);

            if (/object/.test(type)) {

                if (data === null) {
                    type = "null";
                } else {
                    type = _toString.call(data);

                    let res = /\[\w+\s+(\w+)\]/.exec(type);
                    if (res && res[1]) {
                        type = res[1];
                    }
                }
            }
            return type;
        }
    }
    //==========================================================================
    {
        // job: [function|promise]
        $injectModules['timeout'] = {
            override: false,
            fun: timeout
        };


        function timeout(job, timeLimit, context) {
            let p1;

            if (typeof timeLimit != 'number') {
                throw new TypeError("timeout arg[1] must be number");
            }

            if (typeof (job) == "function") {

                if (context != null) {
                    job = job.bind(context);
                }
                p1 = new Promise(job);
            } else if (job instanceof Promise) {
                p1 = job;
            } else {
                throw new TypeError("timeout arg[0] must be promise or function");
            }
            //-----------------------
            let _res;
            let _rej;

            let r_p = new Promise(function (res, rej) {

                _res = res;
                _rej = rej;
            });
            //-----------------------
            // 計時器
            let timeHandle = setTimeout(() => {
                _rej(new Error('timeout'));
            }, timeLimit);


            p1.then((data) => {

                clearTimeout(timeHandle);
                timeHandle = null;
                _res(data);
            }, (err) => {
                clearTimeout(timeHandle);
                timeHandle = null;
                _rej(err);
            });
            //-----------------------

            return r_p;
        }
    }
    //==========================================================================
    {

        // promise
        //
        // callback: [function(返回 promise)|promise[]]
        // context: 背後執行對象
        $injectModules['promise'] = {
            override: true,
            fun: _promise
        };

        class Pr extends Promise {
            constructor(executor) {
                debugger;

                super((resolve, reject) => {
                    return executor(resolve, reject);
                });
            }

            always(callback) {
                debugger;
                const p = super.then((d) => {
                    debugger;
                    return callback(null, d);
                }, (er) => {
                    debugger;
                    return callback(er);
                });
                // 反囘原有的 promise
                return p;
            }
        }

        function _promise(callback, context) {
            let p;

            if (callback instanceof Promise) {
                p = Pr.resolve(callback);
            } else if (typeof (callback) == "function") {

                (callback == null) || (callback.bind(context));

                p = new Pr(callback);
            } else if (Array.isArray(callback)) {

                if (context != null) {
                    callback = callback.map(function (fn) {
                        return fn.bind(context);
                    });
                }
                p = Pr.all(callback);
            }
            //-----------------------
            return p;
        }

        _promise.resolve = function (d) {
            return Pr.resolve(d);
        }

        _promise.reject = function (er) {
            return Pr.reject(er);
        }
    }
    //==========================================================================
    {
        // deferred
        class Deferred extends Promise {

            constructor(executor) {
                debugger;
                let res;
                let rej;

                super((resolve, reject) => {
                    debugger;

                    if (typeof executor != 'function') {
                        res = resolve;
                        rej = reject;
                        executor = function () {
                            debugger;
                        };
                    }
                    return executor(resolve, reject);
                });
                debugger;
                if (res != null) {
                    this.resolve = function (d) {
                        res(d);
                    }
                }

                if (rej != null) {
                    this.reject = function (er) {
                        rej(er);
                    };
                }
            }

            always(callback) {
                const p = super.then((d) => {
                    debugger;
                    return callback(null, d);
                }, (er) => {
                    debugger;
                    return callback(er);
                });
                return p;
            }
        }


        $injectModules['deferred'] = {
            override: false,
            fun() {
                return new Deferred();
            }
        };
    }
    //-------------------------------------------------------------------------
    _.$mixin($injectModules);
};
