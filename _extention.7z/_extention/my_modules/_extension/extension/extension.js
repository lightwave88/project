 // 延緩載入
 const $importQueue = [];

 // 一個進程只能對一個 _ 擴增
 // 避免搞得太複雜
 const _extension = {
     "callback_id": 0,
     "_": null,
     '_path': null,
     extensionPath: null,
     env_isBrowser: false,
     env_isNodejs: false,
     env_isWorker: false,
 };
 //----------------------------------------------------------------------
 // 新增 _.$mixin() 功能
 // 可進一步控，制有此功能是否要 override
 $importQueue.push(function (_) {
     _.mixin({
         "$mixin": checkmixin,
         "$import": _import,
     });
 });
 //----------------------------------------------------------------------
 // 一個進程只能對一個 _ 擴增
 // 避免搞得太複雜

 // nodejs 對外的接口
 // nodejs 對外的接口
 const $nodejs_api = {
     import(callback) {
         // debugger;
         _import(callback);
     },
     mixin(data = {}) {
         // debugger;
         checkmixin(data);
     },
     // API 對 _ 擴充
     expand(moduleName) {
         // debugger;
         let _;
         if (typeof moduleName != 'string') {
             _ = moduleName;
         } else {
             _ = require(moduleName);
         }

         let setting = {};

         if (typeof moduleName == 'string') {
             setting['_path'] = require.resolve(moduleName);
         }

         setting.extensionPath = require.resolve('_extension');

         if (_extension._ != null) {
             if (!Object.is(_extension._, _)) {
                 // 只能對一個 _ expand
                 throw new Error(`has expand ${setting['_path']} before`);
             }
         }

         if (_['$$$extension'] == null) {

             link(_);

             setAttr(setting);

             checkImport(_);
         }

         return _;
     },
     getSource() {
         return _extension._;
     },
     getExtension() {
         return _extension;
     }
 };
 //-------------------------------------------------------------------
 (() => {
     // check environment
     if (is_nodeJs()) {
         // nodejs

         _extension.env_isNodejs = true;
         try {
             const {
                 isMainThread
             } = require('worker_threads');
             if (!isMainThread) {
                 _extension.env_isWorker = true;
             }
         } catch (error) {
             console.log(error);
         }

         // 曝露接口
         module.exports = $nodejs_api;
         return;
     }
     //------------------
     const $root = checkRoot();
     const setting = {};
     let _;

     if (typeof window != 'undefined' && typeof document != 'undefined') {
         // browser
         _ = $root._;

         setting.env_isBrowser = true;

     } else if (typeof (WorkerGlobalScope) != 'undefined') {
         // web_worker
         _ = $root._;

         setting.env_isBrowser = true;
         setting.env_isWorker = true;

     } else {
         throw new Error('no support this system');
     }

     link(_);

     setAttr(setting);

     checkImport(_);
 })();
 //----------------------------------------------------------------------
 function is_nodeJs() {
     let res;
     try {
         let fs = require('fs');
         res = (typeof fs == 'object');
     } catch (error) {
         res = false;
     }
     return res;
 }
 //------------------------------------------------------------------------------
 function link(_) {

     if (_['$$$extension'] != null) {
         return;
     }
     _['$$$extension'] = _extension;
     _extension._ = _
 }
 //----------------------------------------------------------------------
 function setAttr(setting = {}) {
     Object.keys(setting).forEach((k) => {
         if (!(k in _extension)) {
             return;
         }
         _extension[k] = setting[k];
     });
 }
 //----------------------------------------------------------------------
 function checkImport(_) {
     // debugger;            

     while ($importQueue.length) {
         let callback = $importQueue.pop();

         // 注入函式
         let imp = callback(_);

         if (imp != null) {
             checkmixin(imp);
         }
     }
 }
 //----------------------------------------------------------------------
 function checkmixin(map) {

     const _ = _extension._;

     if (_ == null) {
         throw new Error('_ not import yet');
     }

     let keys = Object.keys(map);

     // 檢查是否要 override
     keys.forEach((k) => {
         let value = map[k];
         let override = false;
         let fun;

         if (value != null && typeof value == 'object') {
             ({
                 override = false,
                 fun
             } = value);
         } else {
             fun = value;
         }

         if (typeof _[k] == 'function' && !override) {
             // 避免 override
             delete map[k];
         } else {
             map[k] = fun;
         }
     });

     _.mixin(map);
 }
 //----------------------------------------------------------------------
 function checkRoot() {
     let root;

     if (typeof self == 'object' && self.self === self) {
         root = self;
     } else if (typeof global == 'object' && global.global === global) {
         root = global;
     }
     root = root || this;

     return root;
 }
 //----------------------------------------------------------------------
 // 匯入程序
 function _import(callback) {
     // debugger;
     if (typeof callback != 'function') {
         throw new TypeError('importModule args[0] must be function');
     }
     if (_extension._ == null) {
         $importQueue.unshift(callback);
     } else {
         callback(env._);
     }
 }