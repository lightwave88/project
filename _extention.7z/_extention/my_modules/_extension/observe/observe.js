const $GM = require('./gmodule.js');

let $Observe_id = 0;

class Observe {

    static getInstance(value) {
        return new Observe(value);
    }

    constructor(value) {

        // 監聽者
        // 若有 watch 就會設置
        this.$listener = null;

        this.$config = $GM.get('config');
        this.$tool = $GM.get('tool');

        this.$ob_key = this.$config.get('ob_key');

        this.$uid = `ob_${$Observe_id++}`;
        //----------------------------
        this.$proxy;

        // 只能是 collect
        this.$value = value;
        //----------------------------
        // 紀錄有哪些 parent
        // 方便形成路徑
        this.$parentsMap = {};
        //----------------------------
        // 針對 [] 的方法處理
        this.$arrayMethod = null;

        // 記録 [] 有哪些 key 改變
        this.$array_changekeyList = [];
        this.$array_addList = [];
        this.$array_removeList = [];

        // 協調者
        this.$coordinator;

        // 動態記錄，是否已離開數據樹
        this.$pathList = new Map();
        //----------------------------
        // 紀錄那些 key 有變動
        this.$changeKeys = new Map();

        this._init();
    }

    _init() {
        if (!this.$tool.isCollect(this.$value)) {
            throw new TypeError('data must be {},[]');
        }

        if (Array.isArray(this.$value)) {
            this._wrapArrayProxy();
        } else {
            this._wrapObjectProxy();
        }
    }
    //--------------------------------------------------------------------------
    _wrapArrayProxy() {
        const $self = this;
        const $tool = this.$tool;
        const $linkObserve = $GM.get('linkObserve')['linkObserve'];
        const ob_key = this.$ob_key;

        const p_data = new Proxy(this.$value, {
            set(t, k, v) {
                debugger;

                let ob = t[ob_key];
                let remove = null;
                const old_value = t[k];

                try {
                    remove = old_value[ob_key];
                } catch (error) {
                    remove = null;
                    console.log(error);
                }

                // 修正關係
                if (remove != null) {
                    // 舊的需移除父子關係
                    remove.detatch(t);
                }

                //----------------------------
                debugger;

                // 是否來自 arraymethod()
                if (ob.$arrayMethod != null) {
                    // 遇到 [].method();

                    let _v = $linkObserve(v, t);
                    t[k] = _v;

                    ob.recordKeyChange(k);

                    return true;
                }
                //----------------------------
                debugger;
                if (/^length$/i.test(k)) {
                    // length 改變，造成 delete
                    let preValue = t.slice();

                    // 通知把舊數值記録起來
                    ob.noticeValueWillChange();

                    t[k] = v;

                    let afterValue = t.slice();

                    ob.notify_lengthChange(preValue, afterValue);

                    return true;
                }
                //----------------------------
                // 新的，建立父子關係
                let _v = $linkObserve(v, t);

                // 通知把舊數值記録起來
                ob.noticeValueWillChange();

                t[k] = _v;
                //----------------------------
                ob.notify_valueChange(k);

                return true;
            },
            deleteProperty(t, k) {
                debugger;

                let remove = null;
                let ob = t[ob_key];
                let old_value = t[k];

                try {
                    remove = old_value[ob_key];
                } catch (error) {
                    remove = null;
                    console.log(error);
                }
                //----------------------------
                // 修正關係
                if (remove != null) {
                    // 舊的需移除父子關係
                    remove.detatch(t);
                }
                //----------------------------
                debugger;

                // 通知把舊數值記録起來
                ob.noticeValueWillChange();

                delete t[k];

                if (ob.$arrayMethod != null) {
                    // 遇到 [].method();                    
                    ob.recordKeyChange(k);
                    return true;
                }

                ob.notify_valueChange(k);

                return true;
            }
        });

        this.$proxy = p_data;
    }
    //--------------------------------------------------------------------------
    _wrapObjectProxy() {
        const $self = this;
        const $tool = this.$tool;
        const $linkObserve = $GM.get('linkObserve')['linkObserve'];
        const ob_key = this.$ob_key;

        const p_data = new Proxy(this.$value, {
            set(t, k, v) {
                debugger;

                let remove = null;
                let ob = t[ob_key];
                const old_value = t[k];

                try {
                    remove = old_value[ob_key];
                } catch (error) {
                    remove = null;
                    console.log(error);
                }
                //----------------------------
                // 修正關係
                if (remove != null) {
                    // 舊的需移除父子關係
                    remove.detatch(t);
                }
                debugger;

                let _v = $linkObserve(v, t);

                // 通知把舊數值記録起來
                ob.noticeValueWillChange();

                t[k] = _v;
                //----------------------------
                ob.notify_valueChange(k);

                return true;
            },
            deleteProperty(t, k) {
                debugger;

                let remove = null;
                let ob = t[ob_key];
                let old_value = t[k];

                try {
                    remove = old_value[ob_key];
                } catch (error) {
                    remove = null;
                    console.log(error);
                }
                //----------------------------
                // 修正關係
                if (remove != null) {
                    // 舊的需移除父子關係
                    remove.detatch(t);
                }
                //----------------------------
                // 通知把舊數值記録起來
                ob.noticeValueWillChange();

                delete t[k];

                ob.notify_valueChange(k);

                return true;
            }
        });

        this.$proxy = p_data;
    }
    //--------------------------------------------------------------------------
    notify_valueChange(key) {
        debugger;
        console.log('notify_valueChange key(%s)', key);
        console.log('----------------');

        this._nextStep([key]);
    }
    //--------------------------------------------------------------------------
    // 修改 [].length
    notify_lengthChange(preValue, curValue) {
        debugger;

        const ob_key = this.$ob_key;

        let changeKeyList = [];

        if (curValue.length < preValue.length) {
            // [] 數據減少

            // 移除被移除的數據
            for (let i = curValue.length; i < preValue.length; i++) {
                changeKeyList.push(i);
                const element = preValue[i];
                let ob;

                try {
                    ob = element[ob_key];
                } catch (er) {
                    console.log(er);
                }

                if (ob != null) {
                    ob.detatch(this);
                }
            }
        } else if (curValue.length > preValue.length) {
            // [] 數據增加
            for (let i = preValue.length; i < curValue.length; i++) {
                changeKeyList.push(i);
            }
        } else {
            return;
        }

        // console.log('preValue: %s', JSON.stringify(preValue));
        // console.log('curValue: %s', JSON.stringify(curValue));
        console.log('changeKeyList: %s', JSON.stringify(changeKeyList));
        console.log('----------------');

        this._nextStep(changekeyList, 'length');
    }
    //--------------------------------------------------------------------------
    notify_arrayMethod() {
        debugger;

        let changekeyList = this.$array_changekeyList.slice();
        const method = this.$arrayMethod;

        this.afterArrayMethod();

        console.log('array_change method(%s) keyList(%s)', method, JSON.stringify(changekeyList));
        // console.log('preValue: %s', JSON.stringify(preValue));
        // console.log('curValue: %s', JSON.stringify(curValue));
        console.log('----------------');

        this._nextStep(changekeyList, method);
    }
    //--------------------------------------------------------------------------
    addParent(parent) {
        const ob_key = this.$ob_key;

        if (!(parent instanceof Observe)) {
            parent = parent[ob_key];
        }
        const parent_id = parent.$uid;
        let data;

        if (!(parent_id in this.$parentsMap)) {
            this.$parentsMap[parent_id] = {
                count: 0,
                ob: parent
            };
        }

        data = this.$parentsMap[parent_id];
        data.count++;
    }
    //--------------------------------------------------------------------------
    // 與父親分離
    detatch(parent) {
        const ob_key = this.$ob_key;

        if (!(parent instanceof Observe)) {
            parent = parent[ob_key];
        }

        const parent_id = parent.$uid;

        if (parent_id in this.$parentsMap) {
            let data = this.$parentsMap[parent_id];

            if (--data.count == 0) {
                delete this.$parentsMap[parent_id];
            }
        }
    }
    //--------------------------------------------------------------------------
    // proxy 的報告
    recordKeyChange(key) {
        if (!/^\d+$/.test(key)) {
            return;
        }
        this.$array_changekeyList.push(key);
    }
    //--------------------------------------------------------------------------
    // [].method 最後必須 reset
    afterArrayMethod() {
        this.$array_changekeyList.length = 0;
        this.$arrayMethod = null;
    }
    //--------------------------------------------------------------------------
    // 往下一步處理
    _nextStep(changeKeyList, changeEvent) {
        debugger;
        // const $CheckPath = $GM.get('CheckPath_test');
        const $CheckPath = $GM.get('CheckPath');
        const checkPath = $CheckPath.getInstance(this, changeKeyList, changeEvent);

        // 交給下一個模組處理
        checkPath.findPath();
    }
    //--------------------------------------------------------------------------
    // 使用者加入 watch
    addWatch(path = '', callback) {
        debugger;

        if (this.$listener == null) {
            const $Listener_class = $GM.get('Listener');
            this.$listener = $Listener_class.getInstance(this);
        }
        debugger;
        this.$listener.addWatch(path, callback);
    }

    //--------------------------------------------------------------------------
    noticeValueWillChange() {
        Observe.noticeValueWillChange(this);
    }


    // 往上冒泡通知 listener 數據將變化
    static noticeValueWillChange(target) {
        debugger;
        const $config = $GM.get('config');
        const $ob_key = $config.get('ob_key');

        const $Observe = $GM.get('Observe');

        if (!(target instanceof $Observe)) {
            throw new TypeError('obj not instanceof Observe');
        }

        if (target.$listener != null) {
            // 通知 listener 監視的 value 將變動
            let listener = target.$listener;
            listener.valueWillChange();
        }

        // 往上擺拜訪徑
        let parentList = Object.values(target.$parentsMap);

        if (!parentList.length) {
            // 到頂了
            // this._recordPathResult(pathList);
            return;
        }

        parentList = parentList.map((d) => {
            return d.ob;
        });

        //------------------
        // 檢查自身在 parent 的位置
        parentList.forEach((parent) => {
            debugger;

            if (Array.isArray(parent.$value)) {

                parent.$value.forEach((value, i) => {
                    debugger;
                    let ob;
                    try {
                        ob = value[$ob_key];
                    } catch (e) {}

                    if (ob == null) {
                        return;
                    }
                    if (ob.$uid === target.$uid) {
                        Observe.noticeValueWillChange(parent);
                        debugger;
                    }
                });
            } else {
                const data = parent.$value;
                for (let k in data) {
                    if (!data.hasOwnProperty(k)) {
                        continue;
                    }
                    debugger;
                    const value = data[k];
                    let ob;
                    try {
                        ob = value[$ob_key];
                    } catch (e) {}

                    if (ob == null) {
                        continue;
                    }
                    if (ob.$uid === target.$uid) {
                        Observe.noticeValueWillChange(parent);
                        debugger;
                    }
                }
            }

        });
    }
}

module.exports = Observe;
