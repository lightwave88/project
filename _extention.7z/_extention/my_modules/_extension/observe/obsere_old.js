
!(function (global) {
    ////////////////////////////////////////////////////////////////////////////
    //
    // 2018/11/18
    //
    // _.observe(data, {
    //      wrap: boolean,
    //      watch:[
    //          {
    //              name: 非必要(方便移除)
    //              rule: function|string,
    //              handler: callback
    //              deep: (0, 1, 2)[default = 1]
    //          }
    //      ]
    // })
    //
    ////////////////////////////////////////////////////////////////////////////
    let _;
    if (typeof Window !== "undefined" && global instanceof Window) {
        if (typeof global._ === "object" || typeof global._ === "function") {
            _ = global._;
        }
    } else if (typeof module === "object") {
        // node.js
        try {
            _ = require("../lodash");
        } catch (e) {
        }
        //----------------------------
        if (typeof _ === "undefined") {
            try {
                _ = require("../underscore");
            } catch (e) {
            }
        }
        //----------------------------
        if (typeof _ === "undefined") {
            throw new Error("need require underscore or lodash");
        }
    }

    ////////////////////////////////////////////////////////////////////////////
    // api
    //
    // 支援 {}, [], Map(非 obj 的 key)
    //
    //
    // _.observe(data, wrap, options)
    // data => 要被監控的數據
    // wrap => 返回直接的數據，還是要包起來，增加更多 API 操作
    // options => 主要以 watches 為主
    //
    _.mixin({
        observe: observeCommand
    });
    //==========================================================================
    // 所需要的工具
    let $tool = {};

    // 取得 extetion 的全域變數
    let $extension = _.$$extension;

    (function (_self) {

        _self.hasProto = ('__proto__' in {});

        _self.arrayProto = Array.prototype;
        _self.mapProto = Map.prototype;

        // 繼承 array的物件
        _self.arrayProtoClone = Object.create(_self.arrayProto);
        _self.mapProtoClone = Object.create(_self.mapProto);
        //----------------------------
        // array 要監視的方法
        _self.arrayMethodsNameList = [
            'push',
            'pop',
            'shift',
            'unshift',
            'splice',
            'sort',
            'reverse'
        ];
        // map 要監視的方法
        _self.mapMethodsNameList = [
            'set',
            'delete',
            'clear'
        ];

        _self.arrayKeys = Object.getOwnPropertyNames(_self.arrayProtoClone);
        _self.mapKeys = Object.getOwnPropertyNames(_self.mapProtoClone);
        //======================================================================
        // 為 arrayProtoClone.method 插入觀察者
        _self.arrayMethodsNameList.forEach(function (method) {

            // array 原始的方法
            let original = _self.arrayProto[method];

            // 在 array.proto 寫下方法
            _.defineProperty(_self.arrayProtoClone, method, function arrayReact() {
                // debugger;

                // 裡面會有 remove, add ,update
                var args = Array.from(arguments);
                //----------------------------

                var ob = this.__us_ob__;
                ob.$$arrayMethod = method;

                // 遇到 [undefined].pop() 會出問題
                var result = original.apply(this, args);

                var add = [];
                var remove = [];

                // debugger;

                switch (method) {
                    case 'push':
                    case 'unshift':
                        add = args;
                        break;
                    case 'pop':
                    case 'shift':
                        remove = result;
                        break;
                    case 'splice':
                        add = args.slice(2);
                        remove = result;
                        break;
                }

                if (!Array.isArray(add)) {
                    add = (add === undefined ? [] : [add]);
                }

                if (!Array.isArray(remove)) {
                    remove = (remove === undefined ? [] : [remove]);
                }
                //----------------------------

                // reset
                ob.$$arrayMethod = '';

                ob.$$notify_by_arrayMethod(method, {
                    add: add,
                    remove: remove
                });

                return result;
            });
        });
        //======================================================================
        _self.mapMethodsNameList.forEach(function (methodName) {
            let original = _self.mapProto[methodName];

            _.defineProperty(_self.mapProtoClone, methodName, function () {
                // debugger;

                var args = Array.from(arguments);

                let key = args[0];
                let value = args[1];
                let ob = this.__us_ob__;
                let oldValueList = [];

                if (typeof key === 'object' || key == null) {
                    throw new Error('Map no support object key');
                }

                switch (methodName) {
                    case "set":
                        value = JSONObserver._observe(value, ob, key);
                        args[1] = value;
                        oldValueList.push(this.get(key));
                        ob.$$addChangeKey(key);
                        break;
                    case "delete":
                        oldValueList.push(this.get(key));
                        ob.$$addChangeKey(key);
                        break;
                    case "clear":

                        this.forEach(function (v, k) {
                            oldValueList.push(v);
                            ob.$$addChangeKey(k);
                        }, this);

                        break;
                    default:
                }

                let result = original.apply(this, args);

                ob.$$notify_by_mapMethod(methodName, oldValueList);

                return result;
            });
        });
        //======================================================================
        // Augment an target Object or Array by intercepting
        // the prototype chain using __proto__
        _self.protoAugment = function (target, src, keys) {
            // 設定原型
            target.__proto__ = src;
            /* eslint-enable no-proto */
        }
        //======================================================================
        // Augment an target Object or Array by defining
        // hidden properties.
        _self.copyAugment = function (target, src, keys) {
            // debugger;
            for (var i = 0, l = keys.length; i < l; i++) {
                var key = keys[i];
                _.defineProperty(target, key, src[key]);
            }
        }
        //======================================================================
        // 簡單物件比值，物件比位址不比值(避免太深的運算)
        // (只做 === 比較)
        _self.looseEqual = function (a, b) {

            let typeA = _.getClass(a);
            let typeB = _.getClass(b);

            if (/map|set/.test(typeA) || /map|set/.test(typeB)) {
                throw new TypeError("can't handle map, set");
            }
            //----------------------------
            if (a === b) {
                return true
            }
            let isObjectA = _.isObject(a);
            let isObjectB = _.isObject(b);
            //----------------------------
            if (isObjectA && isObjectB) {
                try {
                    if (Array.isArray(a) && Array.isArray(b)) {

                        if (a.length === b.length) {
                            return a.every(function (e, i) {
                                let res = looseEqual(e, b[i]);
                                return res;
                            });
                        } else {
                            return false;
                        }
                    } else if (_.isPlainObject(a) && _.isPlainObject(b)) {
                        var keysA = Object.getOwnPropertyNames(a);
                        var keysB = Object.getOwnPropertyNames(b);

                        if (keysA.length === keysB.length) {
                            return keysA.every(function (key) {
                                let res = looseEqual(a[key], b[key]);
                                return res;
                            });
                        } else {
                            return false;
                        }

                    } else {
                        /* istanbul ignore next */
                        return false
                    }
                } catch (e) {
                    /* istanbul ignore next */
                    return false
                }
            } else if (!isObjectA && !isObjectB) {
                if (typeA !== typeB) {
                    return false;
                } else {
                    return (a === b);
                }
            } else {
                return false;
            }
        };
        //======================================================================
        // 只針對 {}, []
        _self.shallowCopy = function (data) {
            let res;

            if (typeof data === "object" && data != null) {
                let type = _.getClass(data);

                switch (type) {
                    case "array":
                        res = data.slice();
                        break;
                    case "object":

                        if (_.isPlainObject(data)) {
                            res = {};

                            for (let k in data) {
                                if (data.hasOwnProperty(k)) {
                                    res[k] = data[k];
                                }
                            }
                        } else {
                            res = data;
                        }
                        break;
                    default:
                        res = data;
                }
            } else {
                res = data;
            }
            return res;
        };
        //======================================================================
        // 處理 path
        // 將 a[b].c => 化為 a.b.c
        _self.filterPath = function (path) {

            path = path.replace(/\[([^\[\]]+?)\]/g, function (m, g_1) {
                // 將 [a] 轉為 .a
                let res = ".";
                let key;

                if (/^['"].*['"]$/.test(g_1)) {
                    // g_1 = ['a']
                    // (')無法通過 JSON.parse()
                    g_1 = g_1.replace(/'/g, '"');
                    key = JSON.parse(g_1);
                } else {
                    // g_1 = [a]
                    key = g_1;
                }

                key = String(key);

                return (res + key);
            });

            path = path.replace(/^[\.]|[\.]$/, '');

            return path;
        };
    })($tool);

    ////////////////////////////////////////////////////////////////////////
    //
    // 對外的 API
    //
    ////////////////////////////////////////////////////////////////////////
    // wrap => 是否要將數據包起來
    // 形成一個簡易使用的 api 介面
    // data => 要設置監控的數據
    // options => watchoptions
    function observeCommand(data, options) {
        debugger;

        options = options || {};

        let wrap = (options.wrap ? true : false);
        let watchOptions = options.watch;
        //----------------------------
        // 數據檢查

        if (!Array.isArray(data) && !_.isPlainObject(data)) {
            throw new TypeError('_.observe(data) data must be [],{}');
        }
        //----------------------------
        let coordinator
        let ob;

        debugger;
        // 包含觀察者的數據
        let reativeData = makeObserver(data);

        debugger;

        // 讓 root 觀察者與協調者橋接
        ob = reativeData.__us_ob__;
        ob.$$addCoordinator(watchOptions);
        //----------------------------
        if (wrap) {
            return ob.$$coordinator;
        }

        return reativeData;
    }
    //======================================================================
    // 第2層 API
    (function (fn) {
        // 取得 coordinator
        fn.coordinator = function (data) {
            if (data != null && typeof data.__us_ob__ !== 'undefined' &&
                    typeof data.__us_ob__.$$coordinator !== 'undefined') {
                return data.__us_ob__.$$coordinator;
            }
            return undefined;
        };
        //==================================================================
        // 關閉通知
        fn.off = function () { };

        // 開啟更新通知，若之前關閉的話
        fn.on = function () { };

        // 強制更新
        fn.update = function () { };

        fn.addWatch = function () { };

        fn.removeWatch = function () { };

        // 搭配外部模組用
        fn.addWatchByModule = function () { };

        // 搭配外部模組用
        fn.removeWatchByModule = function () {};

        // 複製沒有proxy乾淨的數據
        fn.clone = function () { };
    })(observeCommand);


    ////////////////////////////////////////////////////////////////////////
    //
    // 協調者
    // 作為 data 與 watch 間的協調
    //
    ////////////////////////////////////////////////////////////////////////
    function Coordinator(ob, watchOptions) {
        // debugger;

        this.$$fn = Coordinator;
        this.$$cid;
        // 與他協調的觀察者
        this.$$ob = ob;
        //----------------------------
        // 用此速度會變慢，各模組要各自再比較數據
        // 可能會重複不少步驟，暫時停用
        this.$$listenerMap = new Map();

        // 使用者設定的 watch
        this.$$user_watchRuleList = [];

        // 給外部模組用
        // 與一般使用者分開
        this.$$module_watchRuleList = [];
        //----------------------------
        // 可決定是否要反應
        // 還是安靜的更新數據
        this.$$reaction = true;
        //----------------------------
        this.__construct(watchOptions);
    }
    //----------------------------
    try {
        // 讓 Observe 有 events
        _.event(Coordinator.prototype);
    } catch (error) {
        console.dir(error);
    }
    //======================================================================
    (function (_self) {
        _self.$$uid = 0;
    })(Coordinator);

    //======================================================================
    (function () {
        this.__construct = function (watchOptions) {
            // debugger;
            this.$$cid = "Coordinator_" + this.$$fn.$$uid++;

            // 建構 watch 並與之連結
            this.$$addWatch(watchOptions, this.$$user_watchRuleList);

        };
        //======================================================================
        // 數據操作
        // 設定數據
        this.set = function (path, value) {
            let pathList = [];
            let key;


            path = $tool.filterPath(path);
            pathList = path.split('.');
            key = pathList.pop();

            if (key == null || key.length == 0) {
                throw new Error('no set key');
            }
            //----------------------------
            if (!this.$$has(pathList)) {
                throw new Error("can't set()");
            }

            let data = this.$$get(pathList);

            if (!Array.isArray(data) || !_.isPlainObject(data)) {
                throw new Error("can't set()");
            }

            data[key] = value;
        };
        //======================================================================
        // 數據操作
        // 取得數據
        this.get = function (path, noProxy) {
            let pathList = [];
            let key;

            if (typeof path === 'string' && path.length != 0) {
                path = $tool.filterPath(path);
                pathList = path.split('.');
            }

            return this.$$get(pathList, noProxy);
        };
        //======================================================================
        // 數據操作
        this.$$get = function (pathList, noProxy) {
            if (noProxy) {
                return this.$$path_clearValue(pathList);
            } else {
                return this.$$path_proxy(pathList);
            }
        };
        //======================================================================
        // 刪除數據
        this.delete = function (path) {
            let pathList = [];
            let data;
            let key;

            path = $tool.filterPath(path);
            pathList = path.split('.');
            key = pathList.pop();

            if (key == null || key.length == 0) {
                return undefined;
            }

            data = this.$$path_proxy(pathList);
            let res;

            if (Array.isArray(data)) {
                key = Number(key);
                res = data[key];
                data.splice(key, 1);
            } else if (_.isPlainObject(data)) {
                res = data[key];
                delete data[key];
            } else {
                return undefined;
            }
            return res;
        };
        //======================================================================
        // 數據操作
        // 是否有設定此數據
        this.has = function (path) {
            debugger;
            path = $tool.filterPath(path);
            let pathList = path.split('.');

            return this.$$has(pathList);
        };
        //======================================================================
        // 數據操作
        this.$$has = function (pathList) {
            let length = pathList.length;
            let data = this.$$ob.$$proxy;

            let key;

            while ((key = pathList.shift()) !== undefined) {
                // debugger;

                if (data == null) {
                    return false;
                }

                if (!data.hasOwnProperty(key)) {
                    return false;
                }
                //----------------------------
                if (Array.isArray(data)) {
                    data = data[Number(key)];
                } else {
                    data = data[key];
                }
            }
            return true;
        };
        //======================================================================
        // 關閉數據響應
        this.off = function () {
            this.$$reaction = false;
        };
        //======================================================================
        // 打開數據響應
        this.on = function () {
            this.$$reaction = true;
        };
        //======================================================================
        // 命令與其合作的模組強制更新
        this.update = function () {
            this.$$reaction = true;

            this.$$module_watchRuleList.forEach(function (watchRule) {
                watchRule.$update();
            }, this);

            this.$$user_watchRuleList.forEach(function (watchRule) {
                watchRule.$update();
            }, this);

        };
        //======================================================================
        // 使用者 API
        // options = [{name, handler, rule}]
        this.addWatch = function (options) {
            this.$$addWatch(options, this.$$user_watchRuleList);
        };

        // 開放給外部其他模組用
        // 與使用者操作分開
        // options = [{name, handler, rule, module}]
        this.addWatchByModule = function (callsign, options) {
            this.$$addWatch(options, this.$$module_watchRuleList, true);
        };
        //======================================================================
        // 使用者 API
        // options => {rule, deep} 根據給的這兩個 key 來移除
        this.removeWatch = function (options, name) {
            // 未
            // 檢查 this.$$user_watchRuleList
        };
        // 開放給外部其他模組用
        // 與使用者操作分開
        // options => {module, rule, deep} 根據給的這兩個 key 來移除
        this.removeWatchByModule = function (options, name) {
            // 未
            // 檢查 this.$$module_watchRuleList
        };
        //======================================================================

        // 被數據變動的觀察者呼叫
        // pathKeyList => 有哪些更改過的 path
        this.$notify = function (eventName, pathList) {
            debugger;
            console.log("--------- notify -----------");

            // 產生規矩
            let ruleList = this.$$generateRule(pathList);

            console.dir(ruleList);
            // console.log(JSON.stringify(ruleList));
            console.log("---------------------------");

            // 提醒所屬的 watch
            this.$$notifyWatchs(ruleList);


        };
        //==================================================================
        // 建構 watch 並與之連結
        this.$$addWatch = function (watchOptions, watchRuleList, operateByModule) {
            debugger;

            operateByModule = operateByModule || false;

            if (watchOptions == null) {
                watchOptions = [];
            } else if (_.isPlainObject(watchOptions)) {
                watchOptions = [watchOptions];
            }

            for (let i = 0; i < watchOptions.length; i++) {

                let options = watchOptions[i];

                if (operateByModule && typeof options !== 'string') {
                    throw new Error('watch options no set moduleName')
                }

                let rule = options['rule'];
                let deep = (typeof options['deep'] === 'number' ? options['deep'] : 1);

                if (typeof rule === 'string') {

                    rule = $tool.filterPath(rule);

                } else if (typeof rule === 'function') {

                    if (typeof rule['_bc_eventGuid'] === 'undefined') {
                        _.defineProperty(rule, "_bc_eventGuid", $extension.callback_guid++, false);
                    }
                }

                options['deep'] = deep;
                options['rule'] = rule;

                // 根據使用者給的 watchSetting，以[rule, deep]為 key
                // 找出所屬的 watchRule
                let watchRule = this.$$findWatchRule(options, watchRuleList);

                // 相應(rule, deep)的 watchRule，給予一個 job
                watchRule.addJob(options);
            }
        };
        //==================================================================
        // 根據使用者給的 watchSetting，以[rule, deep]為 key
        // 找出所屬的 watchRule
        this.$$findWatchRule = function (options, watchRuleList) {

            let rule = options['rule'];
            let deep = options['deep'];
            let watchRule;
            for (let i = 0; i < watchRuleList.length; i++) {
                watchRule = watchRuleList[i];

                if (typeof rule !== typeof watchRule.$$originRule) {
                    continue;
                }

                if (deep !== watchRule.$$deep) {
                    continue;
                }

                if (typeof rule === 'function' &&
                        watchRule.$$originRule._bc_eventGuid === rule._bc_eventGuid) {
                    return watchRule;
                } else if (typeof rule === 'string' && watchRule.$$originRule === rule) {
                    return watchRule;
                }
            }
            //----------------------------
            // 根據 rule, deep 沒找到相符的(watchRule)

            watchRule = new WatchRule(this, options);
            watchRuleList.push(watchRule);

            return watchRule;
        };
        //==================================================================
        // 整理 pathList
        // 抓出屬於自己的 pathList
        this.$$generateRule = function (pathList) {
            // debugger;

            let ruleList = [];

            for (let i = 0; i < pathList.length; i++) {
                // debugger;
                let path = pathList[i].slice();
                let cd = path.shift();

                if (cd.$$cid === this.$$cid) {
                    let pathString = path.join(".");

                    let reg = pathString.replace(/\./g, "\\.");
                    reg = new RegExp(("^" + reg), "i");

                    let rule = {
                        pathString: pathString,
                        reg: reg
                    };

                    ruleList.push(rule);
                }
            }
            return ruleList;
        };

        //==================================================================
        // 提醒所屬的 watch
        this.$$notifyWatchs = function (ruleList) {
            debugger;

            this.$$module_watchRuleList.forEach(function (watchRule) {
                watchRule.$notify(ruleList, this.$$reaction);
            }, this);

            this.$$user_watchRuleList.forEach(function (watchRule) {
                watchRule.$notify(ruleList, this.$$reaction);
            }, this);
        };
        //==================================================================
        // 根據path 取得 value(非proxy)
        // 被 WatchItem 呼叫
        this.$$path_clearValue = function (pathList) {

            let data = this.$$ob.$$value;
            let key;
            while ((key = pathList.shift()) !== undefined) {

                if (data == null) {
                    return undefined;
                }

                if (!data.hasOwnProperty(key)) {
                    return undefined;
                }
                //----------------------------
                if (Array.isArray(data)) {
                    data = data[Number(key)];
                } else {
                    data = data[key];
                }
                //----------------------------
                // 取出乾淨的數據(非 proxy)
                if (typeof data === 'object' && data != null &&
                        typeof data.__us_ob__ !== 'undefined') {
                    data = data.__us_ob__.$$value;
                }
            }
            //---------------------
            return data;
        };
        //==================================================================
        // 根據 path 取出數據
        this.$$path_proxy = function (pathList) {
            let data = this.$$ob.$$proxy;

            let key;
            while ((key = pathList.shift()) !== undefined) {

                if (data == null) {
                    return undefined;
                }

                if (!data.hasOwnProperty(key)) {
                    return undefined;
                }
                //----------------------------
                if (Array.isArray(data)) {
                    data = data[Number(key)];
                } else {

                    data = data[key];
                }
            }
            //---------------------
            return data;
        };
    }).call(Coordinator.prototype);
    ////////////////////////////////////////////////////////////////////////////
    //
    // watch
    //
    ////////////////////////////////////////////////////////////////////////////

    // options =>
    function WatchRule(coordinator, options) {
        // 隸屬的協調者
        this.$$coordinator = coordinator;

        this.$$jobList = [];

        // 改變之前的值
        this.$$prevValue;
        //----------------------------
        // key
        // 使用者設定的 rule
        this.$$originRule;

        // key
        // [0,1,2]
        // 0 => 只要有改變訊息就反應
        // 1 => 根據淺比較反應(快)
        // 2 => 深度比較(慢)
        this.$$deep = 1;
        //----------------------------
        // 規則
        // 一種 ruleSetting
        this.$$rule = {
            pathString: '',
            reg: undefined,
            pathList: []
        };
        this.$$ruleFn;
        //----------------------------
        this.__construct(options);
    }

    (function () {
        this.__construct = function (options) {
            // debugger;

            options = options || {};

            let rule = options.rule;
            if (typeof options.deep === 'number') {

                if (options.deep > 2 || options.deep < 0) {
                    throw new Error('deep options must be (0, 1, 2)');
                }
                this.$$deep = options.deep;
            }

            //----------------------------
            // rule
            this.$$originRule = rule;

            if (typeof rule === "function") {

                this.$$ruleFn = rule;

            } else {
                debugger;
                this.$$rule.pathString = String(rule);

                if (this.$$rule.pathString.length) {
                    this.$$rule.pathList = this.$$rule.pathString.split(".");
                    this.$$rule.reg = this.$$rule.pathString.replace(/\./g, "\\.");
                    this.$$rule.reg = new RegExp(("^" + this.$$rule.reg), "i");
                } else {
                    // 若沒指定要監聽的 path
                    // 那就是監聽 root
                    this.$$rule.pathList = [];
                    this.$$rule.reg = /^[\s\S]+/;
                }
            }
            //----------------------------
            // 更新要監測的數據
            let _value;
            if (this.$$ruleFn) {
                debugger;
                _value = this.$$getruleFnValue();
            } else {
                _value = this.$$getValue();
            }
            //----------------------------
            switch (this.$$deep) {
                case 0:
                case 1:
                    this.$$prevValue = $tool.shallowCopy(_value);
                    break;
                default:
                try {
                    this.$$prevValue = JSON.parse(JSON.stringify(_value));
                } catch (e) {
                    this.$$prevValue = undefined;
                }
            }

        };
        //==================================================================
        this.addJob = function (options) {
            options = options || {};

            let handler = options.handler;

            let job = {
                module: (options.module || ''),
                name: (options.name || ''),
                handler: options.handler
            };

            this.$$jobList.push(job);
        };
        //==================================================================
        // 強制每個 watch 更新
        this.$update = function () {
            debugger;

            let newValue;
            if (this.$$ruleFn) {
                newValue = this.$$getruleFnValue();
            } else {
                newValue = this.$$getValue();
            }
            //----------------------------
            // 更新要監測的數據
            switch (this.$$deep) {
                case 0:
                case 1:
                    newValue = $tool.shallowCopy(newValue);
                    break;
                default:
                try {
                    // 也許費時
                    // 也許以後交給 worker
                    newValue = JSON.parse(JSON.stringify(newValue));
                } catch (e) {
                    newValue = undefined;
                }
            }
            //----------------------------
            // 通知每個 job
            this.$$jobList.forEach(function (job) {
                let handler = job.handler;
                handler.apply(this.$$coordinator, [newValue, this.$$prevValue]);
            }, this);
            //----------------------------

            this.$$prevValue = newValue;
        };

        //==================================================================
        // 當有數據變動的資訊時
        // 會呼叫此
        // ruleList => 有變動的(path)
        // reaction => 是否要反應
        // 但一定要更新數據
        this.$notify = function (ruleList, reaction) {
            debugger;

            // 是否合乎事件
            if (this.$$deep !== 0 && !this.$$checkEvent(ruleList)) {
                return;
            }
            //----------------------------
            // 更新要監測的數據
            let newValue;

            if (this.$$ruleFn) {
                newValue = this.$$getruleFnValue();
            } else {
                newValue = this.$$getValue();
            }
            //----------------------------
            let change = false;

            if (reaction) {
                // 數值比較
                // 要比較數值
                switch (this.$$deep) {
                    case 1:
                        change = !$tool.looseEqual(newValue, this.$$prevValue);
                        break;
                    case 2:
                        // 非常費時
                        // 以後轉到 worker
                        newValue = JSON.parse(JSON.stringify(newValue));
                        change = !_.isEqual(newValue, this.$$prevValue);
                        break;
                    default:
                        change = true;
                }
            }
            //----------------------------

            // 通知每個 job
            if (change) {
                this.$$jobList.forEach(function (job) {
                    let handler = job.handler;
                    handler.apply(this.$$coordinator, [newValue, this.$$prevValue]);
                }, this);
            }

            //----------------------------
            // 更新數據
            this.$$prevValue = newValue;
        };
        //==================================================================
        this.$$getruleFnValue = function () {
            let data = this.$$coordinator.$$ob.$$value;
            return this.$$ruleFn.call(null, data);
        };
        //==================================================================
        // 是否合乎當前數據的變動
        this.$$checkEvent = function (ruleList) {
            debugger;

            let res = false;

            if (this.$$ruleFn) {
                // 若 rule 是 function
                res = true;

            } else {
                // 若 rule 是 string
                let reg = this.$$rule.reg;
                let pathString = this.$$rule.pathString;

                ruleList.some(function (rule, i) {
                    debugger;
                    let rule_pathString = rule.pathString;
                    let rule_reg = rule.reg;

                    let judge_1 = rule_reg.test(pathString);
                    let judge_2 = reg.test(rule_pathString);
                    if (judge_1 || judge_2) {
                        res = true;
                        return true;
                    }

                }, this);
            }

            return res;
        };
        //==================================================================
        // 更新監視的數據
        this.$$getValue = function () {
            debugger;

            let data = this.$$coordinator.$$ob.$$value;
            let newValue;

            if (this.$$ruleFn) {
                let cloneData = JSON.parse(JSON.stringify(data));
                newValue = this.$$ruleFn.call(null, cloneData);
            } else {
                // 必須由(coordinator)那邊取值
                let pathList = this.$$rule.pathList.slice();
                newValue = this.$$coordinator.$$path_clearValue(pathList);
            }
            return newValue;
        };
        //==================================================================

    }).call(WatchRule.prototype);

    ////////////////////////////////////////////////////////////////////////////
    //
    // 在數據後面設置觀察者
    //
    ////////////////////////////////////////////////////////////////////////////

    // start here
    // options = {
    //  link: 讓 parent, child 連結的函式
    // }
    // parent, key => 內部使用

    function makeObserver(value) {
        // debugger;

        // 檢查數據類型
        if (value == null || (typeof value != 'object')) {
            if (!Array.isArray(value) && !_.isPlainObject(value)) {
                throw new TypeError('cant be observer');
            }
        }
        //----------------------------
        var observe;

        if (typeof value.__us_ob__ === 'undefined') {
            observe = new JSONObserver(value);

            // 可移到 JSONObserver.construct 裏
            _.defineProperty(value, '__us_ob__', observe);
        } else {
            observe = value.__us_ob__;
        }
        // debugger;
        //----------------------------
        let res;

        let augment = $tool.hasProto ? $tool.protoAugment : $tool.copyAugment;
        if (Array.isArray(value)) {

            JSONObserver.$$walkArray(value);

            // 替換 [] 的原型方法
            augment(value, $tool.arrayProtoClone, $tool.arrayKeys);
            res = observe.$$proxy;
        } else if (value instanceof Map) {

            JSONObserver.$$walkMap(value);
            // 替換 map 的原型方法
            augment(value, $tool.mapProtoClone, $tool.mapKeys);
            res = observe.$$value;

        } else if (_.isPlainObject(value)) {

            JSONObserver.$$walkPlainObject(value);
            res = observe.$$proxy;
        }
        //----------------------------
        // debugger;

        return res;
    }
    ////////////////////////////////////////////////////////////////////////
    //
    // 數據的背後觀察者
    // 放在數據的(__us_ob__)裏，並且不可枚舉
    //
    // 要加入 controller 找數據底下的 __us_ob__
    //
    ////////////////////////////////////////////////////////////////////////
    // options => [remove]
    function JSONObserver(value) {
        this.fn = JSONObserver;
        this.$$cid;
        //----------------------------
        this.$$proxy;
        this.$$value; // 只能是 object
        //----------------------------
        this.$$arrayMethod = ''; // for judge

        // 紀錄有哪些 parent
        // 方便形成路徑
        this.$$parentsMap = {};

        // 協調者
        this.$$coordinator;
        // 動態記錄，是否已離開數據樹
        this.$$pathList = new Map();
        //----------------------------
        // 紀錄那些 key 有變動
        this.$$changeKeys = new Map();
        //----------------------------
        this.__construct(value);
    }
    //==========================================================================
    // 類別方法
    (function (fn) {
        fn.$$uid = 0;

        //======================================================================
        // 確定 {} 的屬性都會成為 observer
        fn.$$walkPlainObject = function (obj) {

            let observe = obj.__us_ob__;

            for (let k in obj) {
                let child = obj[k];
                let newValue = fn._observe(child, observe, k);
                obj[k] = newValue;
            }
        };
        //======================================================================
        // 確定 [] 的屬性都會成為 observer
        fn.$$walkArray = function (items) {
            let observe = items.__us_ob__;
            for (let i = 0, l = items.length; i < l; i++) {

                let child = items[i];
                let newValue = fn._observe(child, observe, i);
                items[i] = newValue;
            }
        };
        //======================================================================
        fn._observe = function (value, parent, key) {
            // debugger;

            if (value == null || typeof value !== 'object') {
                return value;
            }

            let ob;

            if (value.hasOwnProperty('__us_ob__')) {
                ob = value.__us_ob__;

            } else if ((Array.isArray(value) || _.isPlainObject(value))) {
                // 進入遞迴
                value = makeObserver(value);
                ob = value.__us_ob__;

            } else {
                throw new Error("");
            }

            if (ob) {
                // 此步驟物最主要的步驟
                // 與 parent 連結
                ob.$$addParent(parent);
            }
            /*--------------------------*/
            return value;
        }
    })(JSONObserver);

    //==========================================================================

    (function () {
        this.__construct = function (value) {
            this.$$cid = ("observer_" + (this.fn.$$uid++));
            this.$$value = value;

            this.$$wrapProxy();
        };
        //======================================================================
        // 在外層包 proxy
        // 利用 proxy 監聽的性質
        this.$$wrapProxy = function () {
            if (Array.isArray(this.$$value)) {
                this.$$proxy = new Proxy(this.$$value, {
                    set: function (t, k, v, p) {
                        // debugger;

                        let old_o;
                        let eventName = 'change';

                        let ob = t.__us_ob__;
                        //----------------------------
                        if (/length/i.test(k)) {
                            // length 改變，造成 delete

                            let prevLength = t[k];
                            t[k] = v;
                            ob.$$notify_by_lengthChange(t, prevLength, v);

                            return true;
                        }
                        //----------------------------
                        if (typeof t[k] === 'undefined') {
                            eventName = 'add';
                        } else {
                            if (_.isObject(t[k]) && typeof t[k].__us_ob__ !== "undefined") {
                                old_o = t[k].__us_ob__;
                            }
                        }
                        //----------------------------
                        let _v = JSONObserver._observe(v, ob, k);
                        t[k] = _v;
                        //----------------------------
                        ob.$$notify_by_proxyChange(eventName, Number(k), old_o);

                        return true;
                    },
                    deleteProperty: function (t, k) {
                        // debugger;

                        let index = Number(k);

                        let parent_ob = t.__us_ob__;
                        let old_o;

                        if (_.isObject(t[k]) && typeof (t[k].__us_ob__) !== 'undefined') {
                            old_o = t[k].__us_ob__;
                        }

                        delete t[k];

                        // debugger;
                        parent_ob.$$notify_by_proxyChange('delete', Number(k), old_o);

                        return true;
                    }
                });
            } else if (_.isPlainObject(this.$$value)) {
                this.$$proxy = new Proxy(this.$$value, {
                    set: function (t, k, v, p) {
                        // debugger;

                        let eventName = 'change';
                        let old_o;

                        let parent_ob = t.__us_ob__;
                        //----------------------------
                        if (typeof t[k] === 'undefined') {
                            eventName = 'add';
                        } else {
                            if (_.isObject(t[k]) && typeof (t[k].__us_ob__) !== 'undefined') {
                                old_o = t[k].__us_ob__;
                            }
                        }
                        //----------------------------
                        var _v = JSONObserver._observe(v, parent_ob, k);
                        t[k] = _v;
                        //----------------------------
                        parent_ob.$$notify_by_proxyChange(eventName, k, old_o);

                        return true;
                    },
                    deleteProperty: function (t, k) {
                        // debugger;

                        let parent_ob = t.__us_ob__;
                        let old_o;

                        if (_.isObject(t[k]) && typeof (t[k].__us_ob__) !== 'undefined') {
                            old_o = t[k].__us_ob__;
                        }
                        //----------------------------
                        delete t[k];

                        parent_ob.$$notify_by_proxyChange('delete', k, old_o);

                        return true;
                    }
                });
                // console.dir(this.$$proxy);
            }
        };


    }).call(JSONObserver.prototype);

    /*========================================================================*/
    (function () {

        // call by arrayMethos
        this.$$notify_by_arrayMethod = function (method, options) {
            // debugger;

            options = options || {
                add: [],
                remove: []
            };

            let add = options.add;
            let remove = options.remove;

            let event;

            event = 'change';

            if (/sort|reverse/i.test(method)) {
                // event = 'sort';
            } else {
                if (add.length) {
                    // event += '.add';
                }

                if (remove.length) {
                    // event += '.delete'
                }
            }
            //----------------------------
            options.remove.forEach(function (value) {
                // debugger;

                if (value != null && typeof value.__us_ob__ !== 'undefined') {
                    let ob = value.__us_ob__;
                    ob.$$removeParent(this);
                }
            }, this);
            //----------------------------
            // event = 'array.' + event;

            this.$$notifyListener(event);

        };
        //======================================================================
        // call by item
        this.$$notify_by_proxyChange = function (event, key, del_ob) {
            // debugger;

            if (key == null) {
                throw new Error("key == null");
            }
            this.$$addChangeKey(key);

            if (del_ob instanceof JSONObserver) {
                del_ob.$$removeParent(this, key);
            }

            if (this.$$arrayMethod.length) {
                return;
            }

            this.$$notifyListener(event);
        };
        //======================================================================
        // 應付 length 的改變
        // add | remove
        this.$$notify_by_lengthChange = function (parentValue, prevLength, newLength) {
            // debugger;

            if (this.$$arrayMethod) {
                return;
            }

            prevLength = parseInt(prevLength, 10);
            newLength = parseInt(newLength, 10);

            let parentOb = parentValue.__us_ob__;
            let eventName = '';
            let start, end;


            if (newLength === prevLength) {
                // no change
                return;
            } else if (newLength > prevLength) {

                for (let i = prevLength; i < newLength; i++) {
                    this.$$addChangeKey(i);
                }

                parentOb.$$notifyListener('add');
                return;
            } else {
                // remove

                eventName = 'delete';
                start = newLength;
                end = prevLength;

                for (let i = start; i < end; i++) {
                    // debugger;

                    let judeg = (_.isObject(parentValue[i]) && typeof (parentValue[i].__us_ob__) !== 'undefined');

                    if (judge) {
                        this.$$addChangeKey(i);
                        let child_ob = parentValue[i].__us_ob__;
                        child_ob.$$removeParent(parentOb);
                    }
                }
            }
            parentOb.$$notifyListener('delete');
        };
        //======================================================================
        this.$$notify_by_mapMethod = function (method, oldValueList) {
            // debugger;

            for (let i = 0; i < oldValueList.length; i++) {
                let v = oldValueList[i];

                if (typeof v.__us_ob__ !== 'undefined') {
                    let ob = v.__us_ob__;
                    ob.$$removeParent(this);
                }
            }

            this.$$notifyListener('change');
        };
    }).call(JSONObserver.prototype);
    ////////////////////////////////////////////////////////////////////////////
    (function () {

        // 形成樹狀結構必要的步驟
        this.$$addParent = function (parent) {

            if (parent.$$cid == this.$$cid) {
                // 自己不能指派為自己的子孫
                // 會造成無窮回圈
                throw new Error('.......');
            }

            if (parent instanceof JSONObserver) {
                // 自己不能在 parent 鏈中
                // 會變死循環
                parent.$$check_1(this);
            }

            this.$$parentsMap[parent.$$cid] = parent;
        };
        //==================================================================
        this.$$addPath = function (pathList) {
            let path = pathList.reverse();
            this.$$pathList.set(path, true);
        }
        //==================================================================
        // 會遞迴往上檢查
        this.$$check_1 = function (target) {
            // debugger;

            for (let id in this.$$parentsMap) {
                let p = this.$$parentsMap[id];

                if (p instanceof JSONObserver) {
                    if (p.$$cid === target.$$cid) {
                        throw new Error('you cant be your father');
                    }

                    p.$$check_1(target);
                }
            }
        };
        //======================================================================
        // 當數據從某個數據移除時
        // 背後的 ob 也必須斷除彼此間的關係
        this.$$removeParent = function (parent) {
            // debugger;
            let p_ob;
            let p_value;
            let self_cid = this.$$cid;

            if (parent instanceof JSONObserver) {
                p_ob = parent;
                p_value = parent.$$value;
            } else if (typeof parent.__us_ob__ !== 'undefined' &&
                    (parent.__us_ob__ instanceof JSONObserver)) {
                p_ob = parent.__us_ob__;
                p_value = parent;
            }
            //----------------------------
            // 重要處
            // check del
            // 雖然自己被刪除了，但可能還有分身存在
            // 若有分身就不刪除
            //
            if (p_value instanceof Map) {

                try {
                    p_value.forEach(function (v, k) {
                        if (v != null && typeof v.__us_ob__ !== 'undefined') {
                            let ob = v.__us_ob__;
                            if (ob.$$cid === self_cid) {
                                throw new Error("break");
                            }
                        }
                    }, this);
                } catch (error) {
                    return;
                }
            } else if (Array.isArray(p_value)) {

                for (let i = 0; i < p_value.length; i++) {
                    let v = p_value[i];

                    if (v != null && typeof v.__us_ob__ !== 'undefined') {
                        let ob = v.__us_ob__;
                        if (ob.$$cid === self_cid) {
                            return;
                        }
                    }
                }
            } else if (_.isPlainObject(p_value)) {
                for (let k in p_value) {
                    let v = p_value[k];

                    if (v != null && typeof v.__us_ob__ !== 'undefined') {
                        let ob = v.__us_ob__;
                        if (ob.$$cid === self_cid) {
                            return;
                        }
                    }
                }
            }
            //----------------------------
            delete this.$$parentsMap[p_ob.$$cid];
        };
        //======================================================================
        this.$$addChangeKey = function (key) {
            this.$$changeKeys.set(key, true);
        };
        //======================================================================
        // 提醒所屬的 view
        // 檢查資料的變動
        // 然後叫所屬的 controller 自己去判斷是否要 render
        this.$$notifyListener = function (eventName) {
            // debugger;

            // 找到變動者自己在樹據樹中的位置
            this.$$findPath();
            //----------------------------
            // $$changeKeys
            // 紀錄變動者有哪些項目變動
            let changeKes = [];

            this.$$changeKeys.forEach(function (v, k) {
                changeKes.push(k);
            });

            this.$$changeKeys.clear();

            // console.dir(changeKes);
            //----------------------------
            // pathList
            let _pathList = [];

            this.$$pathList.forEach(function (v, k) {
                _pathList.push(k);
            });

            this.$$pathList.clear();
            //----------------------------
            let pathKeyList = [];
            let coordinatorMap = new Map();

            if (changeKes.length) {

                for (let i = 0; i < _pathList.length; i++) {
                    let path = _pathList[i];

                    // 取得協調者
                    let coordinator = path[0];
                    coordinatorMap.set(coordinator, true);

                    for (let j = 0; j < changeKes.length; j++) {
                        let key = changeKes[j];
                        let pathKey = path.slice();
                        pathKey.push(key);
                        pathKeyList.push(pathKey);
                    }
                }
            } else {
                pathKeyList = _pathList;
            }

            //----------------------------
            // 呼叫協調者
            coordinatorMap.forEach(function (v, coordinator) {
                coordinator.$notify(eventName, pathKeyList);
            });
        };
        //======================================================================
        this.$$addCoordinator = function (watchOptions) {
            let error;
            if (this.$$coordinator) {
                error = "data(" + JSON.stringify(this.$$value) + ") has set Coordinator";
                throw new Error(error);
            } else {
                this.$$coordinator = new Coordinator(this, watchOptions);
            }
        };
        //======================================================================
        // 核心
        //
        // target => 數據變動的節點(最底部)
        this.$$findPath = function (target, pathList) {
            // debugger;

            let self_cid = this.$$cid;

            target = target || this;
            pathList = pathList || [];

            //----------------------------
            if (typeof this.$$coordinator !== "undefined") {
                // 重要步驟
                // 碰到一個重要節點
                // 紀錄路徑資訊

                // 拷貝
                let _pathList = pathList.slice();

                // _pathList.push(this.$$cid);
                _pathList.push(this.$$coordinator);

                target.$$addPath(_pathList);
            }
            //----------------------------

            for (let $cid in this.$$parentsMap) {

                let p = this.$$parentsMap[$cid];

                // 取得 parent.path
                // 用遞回，層層向上
                // let parentPath = p.$$findPath(target);
                //----------------------------

                if (Array.isArray(p.$$value)) {
                    // array
                    for (let i = 0; i < p.$$value.length; i++) {
                        let c_value = p.$$value[i];

                        if (typeof c_value.__us_ob__ !== 'undefined') {
                            if (c_value.__us_ob__.$$cid === self_cid) {

                                // 拷貝
                                let _pathList = pathList.slice();
                                _pathList.push(i);
                                p.$$findPath(target, _pathList);
                            }
                        }
                    }
                } else if (p.$$value instanceof Map) {
                    // map

                    p.$$value.forEach(function (c_value, k) {
                        if (typeof c_value.__us_ob__ !== 'undefined') {
                            if (c_value.__us_ob__.$$cid === self_cid) {

                                // 拷貝
                                let _pathList = pathList.slice();
                                _pathList.push(k);
                                p.$$findPath(target, _pathList);
                            }
                        }
                    }, this);

                } else if (_.isPlainObject(p.$$value)) {
                    // {}
                    for (let k in p.$$value) {
                        let c_value = p.$$value[k];

                        if (typeof c_value.__us_ob__ !== 'undefined') {
                            if (c_value.__us_ob__.$$cid === self_cid) {

                                // 拷貝
                                let _pathList = pathList.slice();
                                _pathList.push(k);
                                p.$$findPath(target, _pathList);
                            }
                        }
                    }
                }
            }
            //----------------------------
        };

    }).call(JSONObserver.prototype);
    //======================================================================



})(this || {});


