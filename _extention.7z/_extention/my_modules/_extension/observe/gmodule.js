const $GModule = new Map();
module.exports = $GModule;

debugger;

$GModule.set('config', require('./config.js'));

$GModule.set('tool', require('./tool.js'));

$GModule.set('EventData', require('./eventData.js'));

$GModule.set('CheckPath', require('./checkPath.js'));

// $GModule.set('CheckPath_test', require('./checkPath_test.js'));

$GModule.set('WatchItem', require('./watchItem.js'));

$GModule.set('Listener', require('./listener.js'));

$GModule.set('Observe', require('./observe.js'));

$GModule.set('linkObserve', require('./link_observe.js'));

$GModule.set('CheckSystem', require('./checkSystem.js'));

$GModule.set('api', require('./api.js'));