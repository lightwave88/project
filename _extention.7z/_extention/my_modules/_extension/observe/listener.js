const $GM = require('./gmodule.js');



// 與 observer 成 1:1 關係
class Listener {
    static getInstance(observe) {
        return new Listener(observe);
    }
    //--------------------------------------------------------------------------
    constructor(observe) {
        this.$observe = observe;

        // 消除往後會發生的重複
        // prev_value, curent_value 要用的
        // 一個物件若同時是一個物件的多個孩子(極端例子)
        // 會造成重複的通知
        this.$getPath_id = null;
        //------------------
        this.$value;

        // for test
        this.$prev_value = [];
        //------------------

        this.$tool = $GM.get('tool');

        // map 可消除重複的 變動數據
        this.$changPathList = new Map();

        this.$changeEventList = [];

        // 要監視的 path
        // 排序為 top2bottom
        this.$watchItemList = [];
    }
    //--------------------------------------------------------------------------
    _init() {
        debugger;
        // 記録數據
        // this.$value = this.$tool.copyValue(this.$observe.$value);
    }
    //--------------------------------------------------------------------------
    // 接受通知數據將變動，記録變動前的數據
    valueWillChange() {
        let value = this.$observe.$value;
        value = this.$tool.copyValue(value);        
        this.$prev_value.push(value); 
    }
    //--------------------------------------------------------------------------
    // API 加入 watrchs
    addWatch(path = '', callback) {
        debugger;

        let watch = this._get_watchItem(path);

        debugger;
        watch.on(callback);
    }
    //--------------------------------------------------------------------------
    // 由 checkPath 呼叫
    // 通知數據造成的變動已經結束
    // 準備對 watchs 發出通知
    dataChange(pathList = [], changeEvent) {
        debugger;
        // 交易
        // 未
        let start_transaction = false;

        pathList.forEach((path) => {
            debugger;
            let {
                id,
                pathList: pList
            } = this.$tool.getPathKey(path);

            if (!this.$changPathList.has(id)) {
                // 避免相同的 path 多次激發
                // 記録
                this.$changPathList.set(id, pList);
            }
        });

        if (typeof changeEvent == 'string') {
            this.$changeEventList.push(changeEvent);
        }
        //------------------
        if (start_transaction) {
            // 若啓動交易
            // 記録起來
            // 沒其他動作
        } else {
            // 通知所有 watchItem
            // 記録數據的變化

            this.commit();
        }
    }
    //--------------------------------------------------------------------------
    // 處理排序
    _get_watchItem(path) {
        debugger;

        // 取得 path 的 id
        let {
            id,
            pathList
        } = this.$tool.getPathKey(path);

        let watch = this.$watchItemList.find((w) => {
            return (w.$id === id);
        });

        if (watch == null) {
            // 沒有對應 path 的 watch
            // 插入一個新的 watch，並排序

            const $WatchItem = $GM.get('WatchItem');

            // 沒有相對應 path 的 watchItem
            // 就新增一個
            watch = $WatchItem.getInstance(this, id, pathList);

            // 排序(topDown)
            // 找出要插入的位置
            let insert_index = this.$watchItemList.findIndex((w) => {
                debugger;
                if (watch.compareLevel(w) <= 0) {
                    return true;
                }
            });
            //------------------
            debugger;

            if (insert_index < 0) {
                insert_index = this.$watchItemList.length;
                this.$watchItemList[insert_index] = watch;
            } else {
                this.$watchItemList.splice(insert_index, 0, watch);
            }

            // 更新 watchItems 的排序
            this.$watchItemList.forEach((w, i) => {
                w.$order_index = i;
            });
        }

        return watch;
    }
    //--------------------------------------------------------------------------
    getEvent() {

    }

    //--------------------------------------------------------------------------
    async commit() {
        debugger;

        const arrayMethod = (this.$changeEventList.length == 1) ? this.$changeEventList[0] : undefined;

        // const prev_value = this.$value;
        const prev_value = this.$prev_value[0];
        const current_value = this.$tool.copyValue(this.$observe.$value);
        this.$value = current_value;

        // 有哪些變動的 path
        const changPathList = [];        
        this.$changPathList.forEach((value, id)=>{
            changPathList.push(value);
        });
        
        // important
        // 非同步前必須 reset 一些數據
        // 避免數據污染
        this._resetData();        
        //------------------
        debugger;

        // 先確定這次的數據變動會牽扯到那些 watch
        let watchList = this.$watchItemList.filter((w) => {
            debugger;
            if (w.isYou(changPathList)) {
                return true;
            }
            return false;
        });
        //------------------
        debugger;

        // 找出有可能有變動的 watchItem
        // 進一步確定監視的數據是否有變動
        watchList = watchList.filter((w) => {
            debugger;
            // watch 必須確認數據是否變動，並回報
            let {
                change,
                watch
            } = w.isValueChange(prev_value, current_value);
            return change;
        });
        //------------------
        debugger;

        // 排序
        // 確定事件發出的順序
        const $config = $GM.get('config');
        const emit_order = $config.get('emit_order');
        let order_arg;

        if (emit_order == 'topDown') {
            order_arg = 1;
        } else if (emit_order == 'bottomUp') {
            order_arg = -1;
        } else {
            throw new Error('no set order');
        }

        watchList.sort((a, b) => {
            let sort_res = (a.$order_index - b.$order_index);
            sort_res = sort_res * order_arg;
            return sort_res;
        });
        //------------------
        debugger;
        // finall
        watchList.forEach((w) => {
            debugger;
            w.emit({
                arrayMethod
            });
        });
        // 按階層順序執行 wactchItem.callbacks

       
    }
    //--------------------------------------------------------------------------
    _resetData() {
        this.$changeEventList.length = 0;
        this.$changPathList.length = 0;
        this.$prev_value.length = 0;
    }

}

module.exports = Listener;
