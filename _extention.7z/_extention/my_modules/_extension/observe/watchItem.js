const $GM = require('./gmodule.js');

class WatchItem {

    static getInstance(listener, id = '', pathList = []) {
        return new WatchItem(listener, id, pathList);
    }
    //--------------------------------------------------------------------------
    constructor(listener, id = '', pathList = []) {

        // 排序的順位
        this.$order_index;
        // key
        this.$id = id;
        this.$pathList = pathList;

        this.$listener = listener;

        this.$tool = $GM.get('tool');
        //----------------------------
        this.$prev_value;
        this.$current_value;

        //----------------------------
        this.$callbackList = [];
    }
    //--------------------------------------------------------------------------
    // 增加 watch
    on(callback) {
        this.$callbackList.push(callback);
    }
    //--------------------------------------------------------------------------
    set_orderIndex(index) {
        this.$order_index = index;
    }
    //--------------------------------------------------------------------------
    // 確定監視的 path 有變動
    // 執行任務 callback
    emit(event) {
        debugger;
        let data = {
            path: (this.$id),
            p: (this.$prev_value),
            c: (this.$current_value),
        }

        event = Object.assign({}, data);

        console.log('watch(%s) emit', this.$id);

        this.$callbackList.forEach((fn) => {
            fn(event);
        });

        this.$prev_value = null;
        this.$current_value = null;
    }
    //--------------------------------------------------------------------------
    async async_isValueChange(prevValue, currentValue) {
        debugger;
        const $tool = this.$tool;
        const $this = this;

        debugger;
        const _prevValue = $tool.getValueByPath(prevValue, this.$pathList);
        const _currentValue = $tool.getValueByPath(currentValue, this.$pathList);

        // 非同步(確認數據是否改變)
        let res = await $tool.async_looseEqual(_prevValue, _currentValue);

        if (res == false) {
            // 若數據有變動，記録起來
            // 等待執行 callback;
            this.$prev_value = _prevValue;
            this.$current_value = _currentValue;
        }
        debugger;
        return {
            res,
            watch: $this,
        };
    }
    //--------------------------------------------------------------------------
    // callby listener
    // 非同步
    // 檢查監視的 path 數據是否變動
    // 並回報 listener 由 listener 決定 emit 的順序
    isValueChange(prevValue, currentValue) {
        // debugger;
        const $tool = this.$tool;
        const $this = this;

        // debugger;
        const _prevValue = $tool.getValueByPath(prevValue, this.$pathList);
        const _currentValue = $tool.getValueByPath(currentValue, this.$pathList);

        // 同步
        let change = !$tool.looseEqual(_prevValue, _currentValue);

        // debugger;

        if (change) {
            // 若數據有變動，記録起來
            // 等待執行 callback;
            this.$prev_value = _prevValue;
            this.$current_value = _currentValue;
        }
        // debugger;
        return {
            change,
            watch: $this,
        };
    }
    //--------------------------------------------------------------------------
    // 排序用，越底層權重越大
    compareLevel(watchItem) {
        // debugger;
        let res;

        let self_level = this.$pathList.length;
        let other_level = watchItem.$pathList.length;

        if (self_level == other_level) {
            res = 0;
        } else {
            res = (self_level > other_level) ? 1 : -1;
        }
        return res;
    }
    //--------------------------------------------------------------------------
    // important
    // 判斷 watch 是否可能受到變動路徑的影響
    isYou(pathList) {
        debugger;
        console.dir(this.$pathList);
        // [[],[]...]
        let f_res = pathList.some((p_list) => {
            // debugger;
            let longList;
            let shortList;

            // 數據的變動是否來自 top
            let isParentEvent = true;

            // 監視的數據是否是事件的源頭
            let isSource = false;

            if (p_list.length > this.$pathList.length) {
                longList = p_list;
                shortList = this.$pathList;
            } else {
                isParentEvent = false;
                shortList = p_list;
                longList = this.$pathList;
            }
            // debugger;

            let allMatch = shortList.every((v, i) => {
                let r = (v == longList[i]);
                return r;
            });

            return allMatch;
        });
        //------------------
        debugger;
        return f_res;
    }

}

module.exports = WatchItem;
