const $GM = require('./gmodule.js');
// about path format
const $REG_1 = /\["(.+?)"\]|\['(.+?)'\]|\[(.+?)\]/;

const $tool = {

    //--------------------------------------------------------------------------
    getClass(obj) {
        //debugger;
        let type = typeof (obj);

        if (type == "object") {

            if (obj === null) {
                type = "null";
            } else {
                type = Object.prototype.toString.call(obj);

                let res = type.split(/\s+/g);
                if (res && res[1]) {
                    type = res[1].trim();
                    type = type.replace(/\][^]*$/, '');
                }
            }
        }

        return type;
    },
    //--------------------------------------------------------------------------
    isCollect(data) {
        //debugger;
        if (Array.isArray(data)) {
            return true;
        } else if ($tool.isPlainObject(data)) {
            return true;
        }
        return false;
    },
    //--------------------------------------------------------------------------
    isPlainObject(obj) {
        //debugger;
        if (typeof obj != "object") {
            return false;
        }

        if (obj == null) {
            return false;
        }

        let res = $tool.getClass(obj);
        res = res.toLowerCase()

        if (res != "object") {
            return false;
        }

        if (obj.constructor !== {}.constructor) {
            return false;
        }

        return true;
    },
    //--------------------------------------------------------------------------
    defProperty(obj, key, val, enumerable) {
        Object.defineProperty(obj, key, {
            value: val,
            enumerable: !!enumerable,
            writable: true,
            configurable: true
        });
    },
    //--------------------------------------------------------------------------
    // 針對 array
    protoAugment(target, src) {
        target.__proto__ = src;
    },
    //--------------------------------------------------------------------------
    // 針對 array
    copyAugment(target, src) {
        const keys = Object.getOwnPropertyNames(src);

        for (var i = 0, l = keys.length; i < l; i++) {
            var key = keys[i];
            $tool.defProperty(target, key, src[key]);
        }
    },
    //--------------------------------------------------------------------------
    // for test
    // 未來用 _.workPool() 取代
    async_looseEqual(a, b) {
        return new Promise((resolve, rej) => {
            setTimeout(() => {
                let res = $tool.looseEqual(a, b);
                resolve(res);
            }, 0);
        });
    },
    //--------------------------------------------------------------------------
    looseEqual(a, b) {
        // debugger;

        let isCollect_a = $tool.isCollect(a);
        let isCollect_b = $tool.isCollect(b);

        // 相同的集合即使有相同值
        // 系統仍認為是不同
        // 必須進一步手動處理
        //----------------------------
        if (isCollect_a && isCollect_b) {
            // 物件相比

            if (Array.isArray(a) && Array.isArray(b)) {
                // 二者同為 array

                if (a.length === b.length) {
                    return a.every((e, i) => {
                        let res = $tool.looseEqual(e, b[i]);
                        return res;
                    });
                } else {
                    return false;
                }
            } else if (!Array.isArray(a) && !Array.isArray(b)) {
                // 二者同為 plaingObj

                var keysA = Object.getOwnPropertyNames(a);
                var keysB = Object.getOwnPropertyNames(b);

                if (keysA.length === keysB.length) {
                    return keysA.every((key) => {
                        let res = $tool.looseEqual(a[key], b[key]);
                        return res;
                    });
                } else {
                    return false;
                }

            } else {
                // 兩集合的形態不同
                return false
            }

        } else {
            // 不屬於集合形態
            // 包含物件與基本形態

            // 形態相同比值
            let is_equal = Object.is(a, b);
            return is_equal;
        }
    },
    //--------------------------------------------------------------------------
    filterPath() {

    },
    //--------------------------------------------------------------------------
    getObserve(data) {

        const $config = $GM.get('config');
        const ob_key = $config.get('ob_key');

        if (!$tool.isCollect(data)) {
            const toString = Object.prototype.toString;
            let msg = `${toString.call(data)} cant set observe`;
            throw new TypeError(msg);
        }

        let observe = data[ob_key] || null;

        return observe;

    },
    //--------------------------------------------------------------------------
    copyValue(data) {
        //debugger;

        let value;

        try {
            value = JSON.stringify(data);
            if (typeof value != "string") {
                value = data;
            } else {
                value = JSON.parse(value);
            }
        } catch (error) {
            value = data;
            console.log(error);
        }

        return value;
    },
    //--------------------------------------------------------------------------
    // 取得統一的 path 格式
    // path 格式 (*.a.0.b)
    getPathKey(path) {
        // debugger;
        
        let pathList;
        if (Array.isArray(path)) {
            pathList = path.map((v) => {
                // 把所有 key 都化為 string
                return ("" + v);
            });

            // 開頭格式修正
            if (pathList[0] != '*') {
                pathList.unshift('*');
            }
            path = pathList.join('.');
        } else if (typeof path == 'string') {

            let reg = RegExp($REG_1, 'g');

            // 整理 path 格式
            path = path.replace(reg, (m, g1, g2, g3) => {
                let key;
                [g1, g2, g3].some((k) => {
                    if (k != null) {
                        key = k;
                        return;
                    }
                });
                return `.${key}`;
            });

            // 開頭格式修正
            let firstChar = path.charAt(0);
            if (firstChar == '.') {
                path = '*' + path;
            } else if (firstChar != '*') {
                path = '*.' + path;
            }

            // path 是文字
            pathList = path.split('.');
        } else {
            console.dir(path);
            throw new TypeError('path format error');
        }
        return {
            id: path,
            pathList
        };
    },
    //--------------------------------------------------------------------------
    getValueByPath(value, pathList) {
        // debugger;
        
        if(pathList[0] = '*'){
            pathList = pathList.slice(1);
        }
        
        pathList.some((k) => {
            // debugger;
            try {
                if (Array.isArray(value)) {
                    k = parseInt(k, 10);
                }
                value = value[k];
            } catch (e) {
                value = undefined;
                return true;
            }
        });

        return value;
    },
    observeKeyName(){
        const $config = $GM.get('config');
        let ob_key = $config.get('ob_key');
        return ob_key;
    }

};

module.exports = $tool;
