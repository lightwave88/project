const $GM = require('./gmodule.js');

module.exports = { linkObserve };
//------------------------------------------------------------------------------
let $augment = null;

function linkObserve(data, parent = null) {
    const $tool = $GM.get('tool');
    if (!$tool.isCollect(data)) {
        // 只有 {}.[] 可設 observe
        return data;
    }
    //----------------------------
    debugger;
    const $Observe = $GM.get('Observe');

    if ($augment == null) {
        $augment = $tool.hasProto ? $tool.protoAugment : $tool.copyAugment;
    }

    // 生成觀察者
    let observe = $tool.getObserve(data);
    let res;

    // 避免太頻繁的遞回檢查
    let need_checkChild = false;

    if (observe == null) {
        need_checkChild = true;

        observe = $Observe.getInstance(data);
        let ob_key = $tool.observeKeyName();
        // 可移到 JSONObserver.construct 裏
        $tool.defProperty(data, ob_key, observe, false);

        if (Array.isArray(data)) {
            // 替換 [] 的原型方法
            $augment(data, _getArrayProtoClone());
        }
    }

    if (parent != null) {
        observe.addParent(parent);
    }
    //----------------------------
    debugger;
    if (need_checkChild) {
        if (Array.isArray(data)) {
            _walkArray(data);
        } else {
            _walkPlainObject(data);
        }
    }
    //----------------------------
    res = observe.$proxy;
    return res;
}
//------------------------------------------------------------------------------

function _walkArray(data) {
    for (let i = 0; i < data.length; i++) {
        let child = data[i];

        let _child = linkObserve(child, data);

        if (child !== _child) {
            data[i] = _child;
        }
    }
}
//------------------------------------------------------------------------------
function _walkPlainObject(obj) {
    for (let k in obj) {
        if (!obj.hasOwnProperty(k)) {
            continue;
        }
        let child = obj[k];
        let _child = linkObserve(child, obj);

        if (child !== _child) {
            obj[k] = _child;
        }
    }
}
//------------------------------------------------------------------------------
function _getArrayProtoClone() {

    let arrayProtoClone = null;

    const arrayProto = Array.prototype;

    const arrayMethodsNameList = [
        'push',
        'pop',
        'shift',
        'unshift',
        'splice',
        'sort',
        'reverse'
    ];

    return (() => {

        if (arrayProtoClone == null) {
            const $tool = $GM.get('tool');
            const ob_key = $GM.get('config').get('ob_key');

            // 初始化 arrayProtoClone

            arrayProtoClone = Object.create(arrayProto);


            arrayMethodsNameList.forEach((method) => {

                // array 原始的方法
                let original = arrayProto[method];

                // 在 array.proto 寫下方法
                $tool.defProperty(arrayProtoClone, method, function arrayReact() {
                    debugger;

                    // const preValue = $tool.copyValue(this);

                    // 裡面會有 remove, add ,update
                    let args = Array.from(arguments);
                    //----------------------------

                    const ob = this[ob_key];
                    ob.$arrayMethod = method;

                    // 通知把舊數值記録起來
                    ob.noticeValueWillChange();
                    
                    // 數據變動
                    let result = original.apply(this, args);

                    debugger;
                    // const afterValue = $tool.copyValue(this);

                    let add = [];
                    let remove = [];

                    switch (method) {
                        case 'push':
                        case 'unshift':
                            add = args;
                            break;
                        case 'pop':
                        case 'shift':
                            remove = result;
                            break;
                        case 'splice':
                            add = args.slice(2);
                            remove = result;
                            break;
                    }

                    if (!Array.isArray(add)) {
                        add = (add === undefined ? [] : [add]);
                    }

                    if (!Array.isArray(remove)) {
                        remove = (remove === undefined ? [] : [remove]);
                    }
                    //----------------------------
                    ob.notify_arrayMethod();

                    return result;
                });
            });

        }
        return arrayProtoClone;
    })();
}






