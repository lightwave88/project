debugger;
const $GM = require('./gmodule.js');


// 引入程序
module.exports = function (_) {
    // debugger;

    const $CheckSys = $GM.get('CheckSystem');
    const $checkSys = $CheckSys.getInstance(_);
    $checkSys.check();
    //-----------------------
    const $api = $GM.get('api');
    const tool = $GM.get('tool');
    // test
    $api.tool = tool;

    _.$mixin({
        "observe": $api
    });

};