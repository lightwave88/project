const $GM = require('./gmodule.js');
const $util = require('util');

let $find_id = 0;

// 簡單測試版
class CheckPath_test {
	static getInstance(ob, childKeyList) {
		return new CheckPath_test(ob, childKeyList);
	}

	constructor(ob, childKeyList = []) {
		this.$observe = ob;
		this.$childKeyList = childKeyList;
		this.$ob_key;

		// 有哪些改變路徑
		this.$changePathList = [];
		//------------------
		let config = $GM.get('config');
		this.$ob_key = config.get('ob_key');

	}
	//--------------------------------------------------------------------------
	main() {
		// 消除往後會發生的重複
		// prev_value, curent_value 要用的
		// 一個物件若同時是一個物件的多個孩子(極端例子)
		// 會造成重複的通知
		let id = `id_${$find_id}`;
		$find_id = ($find_id + 1) % 10000;

		// 找到變動者自己在樹據樹中的位置
		this.findPath(id, this.$observe);
		//------------------
		this._sortOutPathData();

		console.log(JSON.stringify(this.$changePathList));
		console.log($util.inspect(this.$changePathList));
	}
	//--------------------------------------------------------------------------
	_sortOutPathData() {
		let res = [];

		this.$changePathList.forEach((pathList) => {
			pathList.reverse();

			this.$childKeyList.forEach((k) => {
				let c_pathList = pathList.slice();
				c_pathList.push(k);
				res.push(c_pathList);
			});

		});

		this.$changePathList.length = 0;
		this.$changePathList = res;
	}
	//--------------------------------------------------------------------------
	// important
	findPath(id, target, pathList = []) {
		debugger;

		const $Observe = $GM.get('Observe');

		if (!(target instanceof $Observe)) {
			throw new TypeError('obj not instanceof Observe');
		}
		//----------------------------
		let parentList = Object.values(target.$parentsMap);

		if (!parentList.length) {
			// 到頂了
			this._recordPathResult(pathList);
			return;
		}
		parentList = parentList.map((d) => {
			return d.ob;
		});

		// 檢查自身在 parent 的位置
		parentList.forEach((parent) => {

			if (Array.isArray(parent.$value)) {

				parent.$value.forEach((value, i) => {
					debugger;
					let ob;
					try {
						ob = value[this.$ob_key];
					} catch (e) {}

					if (ob == null) {
						return;
					}
					if (ob.$uid === target.$uid) {
						let c_pathList = pathList.slice();

						let index = (typeof i == 'number') ? `${i}` : i;
						c_pathList.push(index);

						this.findPath(id, parent, c_pathList);
						debugger;
					}
				});
			} else {
				const data = p.$value;
				for (let k in data) {
					if (!data.hasOwnProperty(k)) {
						continue;
					}
					const value = data[k];
					let ob;
					try {
						ob = value[this.$ob_key];
					} catch (e) {}

					if (ob == null) {
						return;
					}
					if (ob.$uid === target.$uid) {
						let c_pathList = pathList.slice();
						c_pathList.push(i);
						this.findPath(id, parent, c_pathList);
						debugger;
					}
				}
			}

		});
	}
	//--------------------------------------------------------------------------

	_recordPathResult(path) {
		this.$changePathList.push(path);
	}
	//--------------------------------------------------------------------------
}

module.exports = CheckPath_test;
