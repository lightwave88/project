const $GM = require('./gmodule.js');

class CheckSystem {

    static getInstance(_) {
        return new CheckSystem(_);
    }

    constructor(_ = null) {
        this.root;
        this._;

        if (_ != null) {
            // 來自 node.js
            this._ = _;
    }
    }
    //--------------------------------------------------------------------------
    check() {
        // debugger;

        if (this._isNodeJs()) {

        } else {
            this.root = this._checkRoot();


            try {
                this._ = this.root._;
            } catch (er) {
                console.log(er);
            }

        }
        if (this._ == null) {
            throw new Error('no impoert _');
        }
        $GM.set('_', this._);
    }
    //--------------------------------------------------------------------------
    _isNodeJs() {
        let res;
        try {
            let checkList = [process, require('fs')];
            res = checkList.every((obj) => {
                return (obj != null && typeof obj == 'object');
            });
        } catch (error) {
            res = false;
        }
        return res;
    }
    //--------------------------------------------------------------------------
    _checkRoot() {
        let root;

        if (typeof self == 'object' && self.self === self) {
            root = self;
        } else if (typeof global == 'object' && global.global === global) {
            root = global;
        }
        root = root || this;

        return root;
    }
}

module.exports = CheckSystem;

