
const $config = {
    // observe 的 key
    ob_key: "_@_ob_@_",
    
    // [bottomUp|topDown]
    "emit_order": "topDown"
};
//------------------------------------------------------------------------------`
class Config {
    static getInstance() {
        return new Config();
    }
    //--------------------------------------------------------------------------
    set(k, v) {
        $config[k] = v;
    }
    //--------------------------------------------------------------------------
    get(k = null) {
        let res = null;
        if (k != null && (k in $config)) {
            res = $config[k];
        } else {
            res = Object.assign({}, $config);
        }

        return res;
    }
}

module.exports = (function () {
    return Config.getInstance();
})();

