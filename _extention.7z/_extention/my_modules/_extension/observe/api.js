const $GM = require('./gmodule.js');

// 精簡的命令
const $api = function() {

};

module.exports = $api;


$api.monitor = function(path, job, option) {

};

// array 專用，濾除 array.childs 的變化事件
// 專注結構的變化
$api.monitorSelf = function(path, job, option) {

};
//------------------------------------------------------------------------------
$api.watch = function(data, path, callback) {
    debugger;
    
    const $tool = $GM.get('tool');

    const observe = $tool.getObserve(data);
    
    if(observe == null){
        throw new TypeError('data should be init');
    }    
    observe.addWatch(path, callback);
};
//------------------------------------------------------------------------------
$api.ob = function(data) {
    debugger;

    const {
        linkObserve
    } = $GM.get("linkObserve");

    let proxyData = linkObserve(data);
    return proxyData;
};
