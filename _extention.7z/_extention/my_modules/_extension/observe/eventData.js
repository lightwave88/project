const $GM = require('./gmodule.js');

// 在事件中取得資料的方式
// 在非同步狀態很需要
// 參考 backbone
class EventData {

}

module.exports = EventData;
