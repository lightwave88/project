const $GM = require('./gmodule.js');
const $util = require('util');

// 簡單測試版
class CheckPath {
    static getInstance(ob, childKeyList, changeEvent) {
        return new CheckPath(ob, childKeyList, changeEvent);
    }
    //--------------------------------------------------------------------------
    // 對 ob 來說，有哪些 childs 變動
    constructor(ob, childKeyList = [], changeEvent) {
        this.$observe = ob;
        this.$childKeyList = childKeyList;

        // 改變的事件是啥麽，針對 []
        this.$changeEvent = changeEvent;

        // ob 的 valueKey
        this.$ob_key;

        this.$listener = null;
        //-----------------------
        // listener => [[],[]];
        this.$change_listenerList = new Map();

        // 有哪些改變路徑
        this.$changePathList = [];
        //-----------------------
        let config = $GM.get('config');
        this.$ob_key = config.get('ob_key');
    }
    //--------------------------------------------------------------------------
    // 告訴 listener 變化的路徑
    findPath() {

        // 找到變動者自己在樹據樹中的位置
        this._findPath(this.$observe);
        //------------------        
        // 通知 listeners 這次的通知已經結束
        // 可繼續下一步
        this._noticeListenersEnd();

        console.log(JSON.stringify(this.$changePathList));
        console.log($util.inspect(this.$changePathList));

        this._reset();
    }
    //--------------------------------------------------------------------------
    // important
    // 當屬據變化 findPath() 只會執行一次
    // 但可能會多次通知 listeber 
    _findPath(target, pathList = []) {
        debugger;

        const $Observe = $GM.get('Observe');

        if (!(target instanceof $Observe)) {
            throw new TypeError('obj not instanceof Observe');
        }
        //----------------------------
        // 重點
        // 記録這次變動會跟那些 listener 有關
        this._recordListener(target, pathList);
        //----------------------------
        // 往上擺拜訪徑
        let parentList = Object.values(target.$parentsMap);

        if (!parentList.length) {
            // 到頂了
            // this._recordPathResult(pathList);
            return;
        }
        //----------------------------
        parentList = parentList.map((d) => {
            return d.ob;
        });

        // 檢查自身在 parent 的位置
        parentList.forEach((parent) => {

            if (Array.isArray(parent.$value)) {

                parent.$value.forEach((value, i) => {
                    debugger;
                    let ob;
                    try {
                        ob = value[this.$ob_key];
                    } catch (e) {}

                    if (ob == null) {
                        return;
                    }
                    if (ob.$uid === target.$uid) {
                        let c_pathList = pathList.slice();

                        let index = (typeof i == 'number') ? ("" + i) : i;
                        c_pathList.push(index);

                        this._findPath(parent, c_pathList);
                        debugger;
                    }
                });
            } else {
                const data = parent.$value;
                for (let k in data) {
                    if (!data.hasOwnProperty(k)) {
                        continue;
                    }
                    debugger;
                    const value = data[k];
                    let ob;
                    try {
                        ob = value[this.$ob_key];
                    } catch (e) {}

                    if (ob == null) {
                        continue;
                    }
                    if (ob.$uid === target.$uid) {
                        let c_pathList = pathList.slice();
                        c_pathList.push(k);
                        this._findPath(parent, c_pathList);
                        debugger;
                    }
                }
            }

        });
    }
    //--------------------------------------------------------------------------
    // for test
    _recordPathResult(path) {
        this.$changePathList.push(path);
    }
    //--------------------------------------------------------------------------

    _recordListener(ob, pathList) {

        if (ob.$listener == null) {
            return;
        }
        debugger;

        const $tool = $GM.get('tool');
        const listener = ob.$listener;

        pathList = pathList.slice();
        pathList.reverse();

        const {
            pathList: _pathList
        } = $tool.getPathKey(pathList);

        //------------------
        // 記録有哪些 listener 要通知
        if (!this.$change_listenerList.has(listener)) {
            this.$change_listenerList.set(listener, []);
        }
        let dataList = this.$change_listenerList.get(listener);
        dataList.push(_pathList);
    }
    //--------------------------------------------------------------------------
    // checkPath 程序已結束
    // 任務交給 listener
    _noticeListenersEnd() {
        // debugger;
        let listenerList = Array.from(this.$change_listenerList);

        // [[],[]]
        const f_pathList = [];

        // 確保從高層開始往下呼叫的順序
        // 依序通知 listener
        for (let i = listenerList.length; i > 0; i--) {
            // debugger;
            const data = listenerList[i - 1];
            let [listener, pathList] = data;

            pathList.forEach((p) => {
                // debugger;

                this.$childKeyList.forEach((k) => {
                    // debugger;
                    let pList = p.slice();
                    pList.push(k);
                    f_pathList.push(pList);
                });
            });
            //------------------
            debugger;
            // 通知 listener, checkPath 程序已結束
            // 並且告知 listener 所有有變動的 path
            listener.dataChange(f_pathList, this.$changeEvent);
        }
    }
    //--------------------------------------------------------------------------
    _reset() {
        this.$change_listenerList.clear();
    }
}

module.exports = CheckPath;
