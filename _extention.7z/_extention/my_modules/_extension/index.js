
// _extension 本體
const $extesion = require('./extension');
module.exports = $extesion;
//==============================================================================

// debugger;
// worker
// $extesion.importModule(require('./worker'));
// debugger;
// observe
$extesion.import(require('./observe'));