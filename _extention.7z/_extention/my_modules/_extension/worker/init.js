
const get_globalPool = (function () {
    // 封閉的值
    let $globalPool;

    return () => {
        if ($globalPool == null) {

            const $GM = require('./globalModule.js');
            const $Pool_class = $GM.get('pool_class');
            $globalPool = new $Pool_class();
        }
        return $globalPool;
    };

})();

//------------------------------------------------------------------------------
module.exports = Api;
// _.worker();
function Api(...args) {
    let pool = get_globalPool();
    return pool.execute(args);
}

(function () {

    this.setConfig = function (config) {
        let pool = get_globalPool();
        pool.setConfig(config);
    };

    this.makePool = function () {

    };

    //------------------
    // worker 必須額外載入的 script
    this.setImportScript = function (script) {

    };

}).call(Api);