const $globalModule = new Map();

module.exports = {
    init: init,
    module: $globalModule,
    inject: inject,
};

// 初始化
function init(injects) {

    for (let key in injects) {
        inject(key, injects[key]);
    }
    inject('systemInfo', require('./systeminfo.js'));

    inject('config', require('./config.js'));

    inject('pool_class', require('./workerPool.js'));
}


function inject(name, obj) {
    $globalModule.set(name, obj);
}
