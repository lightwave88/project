const WorkerProxy_abs = require('./workerProxy_abs.js');
const $GM = require('./globalModule.js');


// node.js 環境下用的 worker
class NodeJsWorkerProxy extends WorkerProxy_abs {

    constructor(manager) {
        super(manager);
    }
    //----------------------------------------------------------
    initialization() {

        const $systemInfo = $GM.get('systemInfo');
        this.worker_path = $systemInfo.get('workerPath');


        this.worker = new Worker(this.worker_path, {
            workerData: {}
        });

        this.worker.on('error', this.getErrorEvent());
        this.worker.on('message', this.getEndEvent());

    }

    terminate() {

    }
    //----------------------------------------------------------
    getEndEvent() {
        return (() => {

        });
    }
    //----------------------------------------------------------
    getErrorEvent() {
        return (() => {

        });
    }
}

module.exports = NodeJsWorkerProxy;