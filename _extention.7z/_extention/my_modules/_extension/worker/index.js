// 引入 worker 的程序
moule.exports = function (_) {
    debugger;

    // _ 已導入
    // 可開始初始化 _.worker() 模組
    const {init: init_fun} = require('./globalModule.js');

    try {
        init_fun({
            _: _
        });
    } catch (error) {
        // 注入模組出問題
        console.log(error);
        return;
    }

    const api = require('./api.js');

    _.$mixin({
        workerPool: {
            fun: api,
            override: true,
        }
    });
}