// worker 的本體
const {
    isMainThread,
    parentPort,
    workerData
} = require('worker_threads');

//--------------------------------------
let {
    "_path": _path,
    extensionPath,
    scriptList,
    worker_id,
    token_id,
    init,
} = workerData;
//------------------------------------------------------------------------------
if (!isMainThread) {
    debugger;

    // 引入模組    
    const _ = require(extension1Path).expand(_path);








    const $worker = getWorker();

    $worker.init(_, {        
        worker_id,
        token_id,
    });
}

//------------------------------------------------------------------------------
function getWorker() {
    // worker 内文

    const $worker = {
        id: null,
        "token_id": null,
        runtimeEnv: null,
        // 使用者注冊的
        listenerList: [],
        global: null,
        'proxy_self': null,
        // job 中讓使用者操作的 handle
        'cmd_handle': null,
        init(_, setting) {
            debugger;

            let {
                worker_id,
                token_id
            } = setting;

            this.global = global;
            this.id = worker_id;
            this.token_id = token_id;

            if (this.id == null) {
                throw new Error('no get worker_id');
            }

            if (this.token_id == null) {
                throw new Error('no get worker_id');
            }
            //------------------
            scriptList.forEach((script) => {
                try {
                    this.global.importScripts(script);
                } catch (error) {
                    error = "script load error:" + error.toString();
                    throw new Error(error);
                }
            });

            if (init.fn != null) {
                let init_fn = this._buildFun(init.fn);
                init_fn.apply(this.global, init.args);
            }
            //------------------
            this.global.addEventListener('message', (e) => {
                debugger;

                let data = e.data;

                try {
                    data = JSON.parse(data);
                } catch (error) {
                    this.postRunTimeError(er);
                    return;
                }

                let is_fromSystem;

                try {
                    is_fromSystem = (this.$id_2 in data);
                } catch (error) {
                    is_fromSystem = false;
                }

                if (is_fromSystem) {
                    // 來自系統的訊息

                    const cmd = data.cmd;

                    switch (cmd) {
                        case 'job':
                        default:
                            try {
                                // 執行任務
                                this.doSysJob(data.job);
                            } catch (er) {
                                debugger;
                                // 執行錯誤
                                this.postRunTimeError(er);
                            }
                            break;
                    }

                } else {
                    // 來自使用者發的訊息
                    this.callListener(data);
                }
            });
            //------------------

            // 通知已經初始化完成
            this.postSysMsg('initialized');
        },
        // 當使用者發射訊號
        // 會呼叫使用者
        callListener(msg) {
            this.listenerList.forEach((callback) => {
                callback(msg);
            });
        },
        // 發送系統訊息用
        postSysMsg(status, msg) {

            const report = {
                // 系統訊息的憑證                    
                status: status
            };

            if (typeof msg == 'object' && !(msg instanceof Error)) {
                Object.assign(report, msg);
            } else {
                report.msg = msg;
            }

            switch (status) {
                // jobEnd
                case 'jobError':
                case 'jobEnd':
                    // 清除使用者設定的監聽事件
                    this.listenerList.length = 0;
                    break;
                default:
                    break;
            }

            report[this.$id_2] = true;

            this.postMsg(report);
        },
        // 發送訊息
        postMsg(msg) {
            this.global.postMessage(msg);
        },
        postRunTimeError(er) {
            // job 執行錯誤                
            this.postSysMsg('jobError', er);
        },
        // 重塑 worker 部分預設的 API
        _getProxySelf() {

            if (this['proxy_self'] != null) {
                return this['proxy_self'];
            }
            //-----------------
            // 遮蔽 self 部分功能
            let s = new Proxy(this.global, {
                get(t, k) {
                    let res;
                    switch (k) {
                        case 'addEventListener':
                            res = function() {};
                            break;
                        default:
                            res = t[k];
                            break;
                    }
                    return res;
                },
                set(t, k, v) {
                    // 禁止在 worker 內部設置 self.onmessage = 
                    switch (k) {
                        case 'onmessage':
                            break;
                        default:
                            t[k] = v;
                            break;
                    }
                    return true;
                }
            });

            this['proxy_self'] = s;

            return s;
        },
        _buildFun(funText) {
            const content =
                `
                    'use strict';
                    
                    // 遮蔽以下的功能與 self
                    const addEventListener = function(...args){};
                    const onmessage = {};
                
                return (${funText});`

            let fun = new Function('self', content);

            const proxy_self = this._getProxySelf();
            fun = fun(proxy_self);

            return fun;
        },
        _getCmdHandle() {
            if (this['cmd_handle'] != null) {
                return this['cmd_handle'];
            }
            const $this = this;

            // fun 內部的命令
            const cmdHandle = {
                resolve(data) {
                    $this.postSysMsg('jobEnd', data);
                },
                reject(er) {
                    $this.postSysMsg('jobError', er);
                },
                // 註冊一個監視
                onMsg(callback) {
                    $this.listenerList.push(callback);
                },
                postMsg(msg) {
                    $this.postMsg(msg);
                },
            };
            this['cmd_handle'] = cmdHandle;

            return cmdHandle;
        },
        // 建造一個乾淨的執行環境
        _getRuntimeEnv() {
            if (this['runtimeEnv'] != null) {
                return this['runtimeEnv'];
            }

            let fun_content =
                `
                    'use strict';
                    return fun.apply(context, args);
                `;

            const runtimeEnv = new Function('fun', 'context', 'args', fun_content);
            this['runtimeEnv'] = runtimeEnv;

            return runtimeEnv;
        },
        _checkArgs_1(args, funList, context) {
            funList.forEach((index) => {
                let fn_content = args[index];
                let fn = this._buildFun(fn_content);
                args[index] = fn.bind(context);
            });
        },
        _checkArgs_2(args, funList) {
            if (funList.length) {
                throw new TypeError(`args can't include function`);
            }
        },
        // 執行任務
        doSysJob(jobData) {
            debugger;

            let {
                // _命令
                cmd = null,
                    act = null,
                    setting = [],
                    funList = [],
                    id,
            } = jobData;

            let job;
            let context = null;
            let $_;

            if (cmd != null) {
                context = _;

                if (this.global._ == null) {
                    throw new Error('_ no import');
                }
                $_ = this.global._;

                job = $_[cmd];

                if (job == null) {
                    throw new Error(`no this function _.(${cmd})`);
                }

                this._checkArgs_1(setting, funList, context);
            } else {
                job = this._buildFun(act);

                this._checkArgs_2(setting, funList);
                // 插入一個可讓使用者執行命令的 handle
                setting.unshift(this._getCmdHandle());
            }
            debugger;
            // 建立一個乾淨的執行環境
            const env = this._getRuntimeEnv();

            // 執行任務
            env(job, context, setting);
        },

    };
    //------------------
    return $worker;
}
