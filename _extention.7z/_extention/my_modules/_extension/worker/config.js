const {module: $GM} = require('./globalModule.js');

///////////////////////////////////////////////////////////////////////////////
//
// 預設 worker 會彈性隨效能在(max_workers, min_workers)之間調整數量
//
// 但若不想 worker 的數量自動彈性調整，可以設定(max_workers = min_workers)
//
///////////////////////////////////////////////////////////////////////////////

const $default_config = {};

(function () {


    // 同時能運行最大的 worker 數量
    // 複數代表沒設限
    this.maximumPoolSize = 2;

    // idle 時要維持幾個 workers 待命
    this.corePoolSize = 0;

    // 當 worker 沒任務可接時
    // 閒置多久後會被銷毀
    this.keepAliveTime = (1000 * 60);

    // 任務的時限，預設無時限
    // 負數代表無時限
    this.timeout = null;

}).call($default_config);
//--------------------------------------
// defaultSetting 的包覆者
// 可以做輸入驗證

const $configKeyList = [
    'maximumPoolSize',
    'maxPoolSize',
    'corePoolSize',
    'keepAliveTime',
    'timeout',
];

class Config {
    static getInstance(config) {
        return new Config(config);
    }

    constructor(config) {
        this.$$$config = Object.assign({}, $default_config, config);

        // 數值檢查
        Object.keys($default_config).forEach((k) => {
            this[k] = this.$$$config[k];
        });
    }
    //--------------------------------------------------------------------------
    setConfig(config = {}) {
        debugger;
        Object.keys.forEach((k) => {
            debugger;

            if (!$configKeyList.includes(k)) {
                throw new Error(`no this attr(${k}) can set`);
            }
            this[k] = config[k];
        });
    }

    getConfig(key) {
        if (key != null) {
            if (!$configKeyList.includes(key)) {
                throw new Error(`cant't get this attr(${key})`);
            }
            return this[key];
        }
        const $config = {};

        $configKeyList.forEach((k) => {
            $config[k] = this[k];
        });

        return $config;
    }
    //--------------------------------------------------------------------------
    set maxPoolSize(count) {
        this.maximumPoolSize = count;

    }

    get maxPoolSize() {
        return this.maximumPoolSize;
    }

    set maximumPoolSize(count) {

        const setting = this.$$$config;

        const errorList = [];

        if (count < 0) {
            // maximumPoolSize 不設限
            setting.maximumPoolSize = -1;
            return;
        }
        //------------------
        if (count < setting.corePoolSize) {
            errorList.push(`maxPoolSize(${count}) < min_workers(${setting.corePoolSize})`);
        }

        if (count < 1) {
            errorList.push('max_workers must < 1');
        }

        if (errorList.length) {
            let msg = errorList.join("\n");
            throw new Error(msg);
        }

        setting.maximumPoolSize = count;
    }

    get maximumPoolSize() {
        return this.$$$config.maximumPoolSize;
    }
    //--------------------------------------------------------------------------
    set corePoolSize(count) {

        const setting = this.$$$config;

        const errorList = [];

        if (count < 0) {
            errorList.push(`corePoolSize(${count}) < 0`);
        }


        if (setting.maximumPoolSize >= 0) {
            if (count > setting.maximumPoolSize) {
                errorList.push(`corePoolSize(${count}) > max_workers(${setting.maximumPoolSize})`);
            }
        }


        if (errorList.length) {
            let msg = errorList.join("\n");
            throw new Error(msg);
        }

        setting.corePoolSize = count;
    }

    get corePoolSize() {
        return this.$$$config.corePoolSize;
    }
    //--------------------------------------------------------------------------
    set keepAliveTime(time) {

        if (time < 0) {
            throw new Error(`keepAliveTime(${time}) must be >= 0`);
        }

        this.$$$config.idleTime = time;
    }

    get keepAliveTime() {
        return this.$$$config.idleTime;
    }
    //--------------------------------------------------------------------------
    // worker 任務的時限
    // time = 0 沒時限
    set timeout(time) {

        if (time == null) {
            time = null;
        } else {
            time = Number(time);
            if (time < 0) {
                throw new Error("timeout must be >= 0");
            }
        }
        this.$$$config.timeout = time;
    }

    get timeout() {
        return this.$$$config.timeout;
    }
    //--------------------------------------------------------------------------

}

module.exports = Config;


function checkInt(value, attrName = '') {
    let count;
    let errorMsg;
    try {
        count = Number(value);
        if (isNaN(count) || !isFinite(count)) {
            errorMsg = 'NaN';
        }

    } catch (error) {
        errorMsg = "" + error;
    }

    if (errorMsg != null) {
        throw new TypeError(`${attrName} ${errorMsg}`);
    }

    return count;
}