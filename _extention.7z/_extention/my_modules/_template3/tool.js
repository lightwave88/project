const $tool = {};
module.exports = $tool;


/**
 * php isset()
 */
$tool.isset = function (obj) {
    if (typeof obj === 'undefined') {
        return false;
    }
    if (obj == null) {
        return false;
    }
    return true;
};
//------------------------------------------------------------------------------
/**
 * php empty()
 *
 * 但 '0' => true
 */
$tool.empty = function (obj) {
    let res;
    try {
        res = !Boolean(obj);
    } catch (error) {
        res = true;
    }
    return res;
};
//--------------------------------------------------------------------------
/**
 * 是否是 {}
 */
$tool.is_plainObject = function (o) {
    'use strict';

    const toString = Object.prototype.toString;

    const target = {};
    const target_type = toString.call(target);

    let type = toString.call(o);

    // 字串比較
    let judge = Object.is(type, target_type);

    if (!judge) {
        return judge;
    }
    try {
        // 比較建構式
        judge = Object.is(o.constructor, target.constructor);
    } catch (error) {
        console.log(error);
        judge = false;
    }
    return judge;
}

//------------------------------------------------------------------------------

//
// 取代不穩定的
// RegExp.leftContext...等

$tool.RegExpContext = function (options) {
    // debugger;

    let {
        all, match, index
    } = options;

    if (all == null) {
        throw new Error(`no set 'all'`);
    }

    if (match == null) {
        throw new Error(`no set 'match'`);
    }

    if (typeof (index) != "number") {
        throw new Error(`no set 'index'`);
    }

    let j = index + match.length;
    let leftContext = all.substring(0, index);
    let rightContext = all.substring(j, all.length);

    return {
        leftContext,
        rightContext,
        lastMatch: match,
        end: (j - 1)
    };
}
//------------------------------------------------------------------------------
{
    const HTMLESCAPE_MAP = {
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#x27;',
    };

    // 脫逸會影響 html 標簽辨識的符號
    $tool.escape_html = function (html) {
        // debugger;

        let list = Object.keys(HTMLESCAPE_MAP);
        let reg = list.join('');
        reg = `[${reg}]`;
        reg = RegExp(reg, 'g');

        let res = html.replace(reg, function (m) {
            // debugger;
            // console.log("escape(%s, %s)", m, HTMLESCAPE_MAP[m]);
            return HTMLESCAPE_MAP[m];
        });
        return res;
    };
}
//------------------------------------------------------------------------------
{

    // 脫義(`)
    // 避免在 `...` 內部出現問題
    const REG_1 = /[`]/;

    $tool.escape_templateString = function (content) {
        let reg = RegExp(REG_1, 'g');

        content = content.replace(reg, function (m, g1) {
            return "&#x60";
        });

        return content;
    }
}
//------------------------------------------------------------------------------
{
    $tool.find_tagEnd = function (content, get_attributes) {
        const p = new Process(content, get_attributes);
        return p.main();
    };

    // tag.head 的規則
    //先捕捉 atrribute 格式
    // 若無則捕捉標籤結尾
    const $reg_1 =
            /([^/\s>]+?)(?:\s*=\s*(["'])(.*?)\2\s*|(\s{1,})|([/]?>))|\s*([/]?>)/;

    // 抓標籤的頭部
    // 標籤的第一個字必須是[a-z]
    const $reg_2 = /$<[a-z][^\s/>]*/;

    // 把 attr 的 ${} 還原
    const $reg_3 = /\$\{(\d+)\}/;

    class Process {
        constructor(content, need_getAttributes = true) {
            this.replaceList = [];

            this.start_index = 0;
            this.end_index = null;

            this.content = content;
            this.is_singleTag = null;

            this.tmp_tagContent = null;
            this.need_getAttributes = need_getAttributes;
        }
        //----------------------------------------------------------------------
        main() {
            // debugger;

            this._step_1();

            // 第一次只確定標籤結尾位置
            // ${} 可能會影響取得 attributes 的正確性 
            let res = this.getAttrs(this.content);

            if (res == null) {
                // 沒找到結束標籤
                return null;
            }
            //-------------
            let {
                tag_content,
                end_index,
                attributes,
            } = res;

            // 確定標籤結尾位置
            this.end_index = end_index;

            // 使用者是否需要取得 attributes
            // 若標籤內有 ${}
            if (this.need_getAttributes && this._escape_templateString(tag_content)) {
                // debugger;
                // 在 escape ${} 後再次重取 attributes
                // 確保 attributes[key, value] 能正確取得
                ({attributes} = this.getAttrs(this.tmp_tagContent));

                console.log("attribute: %s", JSON.stringify(attributes));

                // 還原 ${}
                attributes = this._checkAttributes(attributes);
            }

            // this.attributes = attributes;

            let content = this.content.substring(0, (this.end_index + 1));

            return {
                content,
                index: (this.end_index),
                single: (this.is_singleTag),
                attributes
            };
        }
        //----------------------------------------------------------------------
        _step_1() {
            // debugger;
            const reg_1 = RegExp($reg_2, 'g');
            if (null != (reg_1.exec(this.content))) {
                this.start_index = reg_1.lastIndex;
            }
        }
        //----------------------------------------------------------------------
        _escape_templateString(content) {
            // 去掉惱人的 ${}
            // ${}的內容
            // 有可能會影響 attributes[key, value] 的判別

            const reg_1 = /(\$\{)|(\})/g;

            const contentList = [];

            let find = 0;

            let startList = [];
            let endList = [];

            let _index = 0;

            while (true) {
                let res = reg_1.exec(content);

                if (res == null) {
                    contentList.push(content.substring(_index));
                    break;
                }
                //-------------
                let {
                    index,
                    1: start_1,
                    2: end_1
                } = res;

                let lastIndex = reg_1.lastIndex;

                if (start_1) {
                    // 抓到 ${

                    if (startList.length == 0) {
                        // ${ 前面的文本
                        let prev = content.substring(_index, index);
                        contentList.push(prev);
                    }
                    startList.push(index);

                } else if (end_1) {
                    // 抓到 }

                    if (startList.length > 0) {
                        // 確定有 ${ 開頭的存在
                        endList.push((lastIndex - 1));
                    }
                }
                //-------------
                // 處理 ${ ${} } 的套嵌特性
                if (startList.length > 0 && startList.length == endList.length) {

                    // 有採用 ${}
                    find++;

                    _index = endList.pop();
                    _index += 1;

                    let target = content.substring(startList[0], _index);

                    startList.length = 0;
                    endList.length = 0;

                    let i = this.replaceList.length;
                    this.replaceList.push(target);

                    contentList.push("${" + i + "}");
                }

            } // endWhile
            //-------------

            if (find > 0) {
                // 有找到 ${} 且正確關閉
                this.tmp_tagContent = contentList.join("");
                return true;
            }

            if (startList.length > 0) {
                throw new Error('Unterminated template');
            }

            this.tmp_tagContent = content;
            return false;
        }
        //----------------------------------------------------------------------
        // 把 attr 的 ${} 還原
        _checkAttributes(attributes) {
            // debugger;

            let keyList = Object.getOwnPropertyNames(attributes);

            keyList.forEach((key) => {
                // debugger;

                let value = attributes[key];

                let reg_1 = RegExp($reg_3, "g");
                key = key.replace(reg_1, (m, k) => {

                    if (key in attributes) {
                        delete attributes[key];
                    }

                    k = parseInt(k, 10);
                    let replace = this.replaceList[k];
                    return replace;
                });
                //------------------

                if (typeof (value) != "string") {
                    return;
                }

                reg_1 = RegExp($reg_3, "g");

                value = value.replace(reg_1, (m, k, index) => {
                    // debugger;
                    k = parseInt(k, 10);
                    let replace = this.replaceList[k];
                    return replace;
                });
                attributes[key] = value;
            });

            return attributes;
        }
        //----------------------------------------------------------------------

        getAttrs(content) {
            // debugger;
            const attributes = {};

            const reg_1 = RegExp($reg_1, 'ug');
            reg_1.lastIndex = this.start_index;
            //------------------
            let r_value = {
                tag_content: null,
                end_index: null,
                attributes: attributes
            };

            while (true) {
                // debugger;

                let res = reg_1.exec(content);

                if (res == null) {
                    return null;
                }

                let {
                    0: match,
                    1: key,
                    // '"
                    2: symbol,
                    3: value,
                    4: no_value,
                    5: end_1,
                    6: end_2,
                } = res;


                let lastIndex = reg_1.lastIndex;
                let end;


                if (end_2 != null) {
                    // 結尾

                    end = end_2;

                } else if (end_1 != null) {
                    // 結尾，並有一個無質屬性

                    end = end_1;
                    attributes[key] = null;

                } else if (no_value != null) {
                    // 一個無質屬性
                    attributes[key] = null;
                } else if (symbol != null) {
                    attributes[key] = value;
                }
                //-------------
                if (end != null) {
                    r_value.tag_content = content.substring(0, lastIndex);
                    r_value.end_index = lastIndex - 1;

                    this.is_singleTag = /^\//.test(end);

                    break;
                }

            } // endWhile

            return r_value;
        }
    }



}
//------------------------------------------------------------------------------

// <%= %> 內容的整理
$tool.checkCommandContent = function (content) {
    content = content.trim();
    content = content.replace(/;\s*$/, '');
    return content;
};
//------------------------------------------------------------------------------
{

    // 用在 attr="<%= %>"
    // 把 command 還原 
    const SPLIT_CONTENT = /(.*?)\[@(\w+)\((\d+)\)@\](.*)$/;
    // 標簽屬性 command 的還原
    // 重要的功能
    $tool.attr_mergeCommand = function (attrValue, commandList) {
        // debugger;

        if (commandList == null) {
            throw new Error("no commandList");
        }
        let valueContent;
        //-------------
        let res = SPLIT_CONTENT.exec(attrValue);

        if (res == null) {
            // attrValue 沒有 command            
            valueContent = `(\`${attrValue}\`)`;
        } else {

            // attrValue 有 command
            let {
                index,
                1: head,
                2: type,
                3: key,
                4: foot,
            } = res;

            head = head.trim();
            foot = foot.trim();

            if (head.length || foot.length) {
                // attrValue 只能如下格式
                // key="<%= %>"
                // 不可如下 key="...<%= %>..."
                throw new Error(`...`);
            }

            if ("C".localeCompare(type) != 0) {
                // param.value 只能用 <%= %>
                throw new Error(`...`);
            }

            key = parseInt(key, 10);

            let {name, content: command} = commandList[key];

            if ("<%=".localeCompare(name) != 0) {
                // 錯誤的命令
                // param.value 只能用 <%= %>
                throw new Error(`...`);
            }
            valueContent = command.trim();
            valueContent = $tool.checkCommandContent(valueContent);
            valueContent = "(" + valueContent + ")";
        }
        //------------------  
        return valueContent;
    }
}