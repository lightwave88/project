const $GM = require('../gmodules.js');
const Node_ABS = require('./abstratNode.js');

const $export = {};
module.exports = $export;

{
    // 沒有命令的節點
    class HtmlNode extends Node_ABS {

        constructor(userOptions, content) {
            super(userOptions);
            this.fn = HtmlNode;
            this.content = content;
            this.context = "";

            this._buildContext();
        }
        //----------------------------------------------------------------------
        _buildContext() {
            let content;
            if (true) {
                // 若採用 template_string
                content = this.fn.$$$escape_templateString(this.content);
            }
            content = "$out.print(`" + content + "`);\n";
            this.context = content;
        }
        //----------------------------------------------------------------------
        $$$printCommand() {
            return this.context;
        }
        //----------------------------------------------------------------------
        // 轉換成 scriptNode
        toScriptNode() {
            return new ScriptNode(this.userOptions, this.content);
        }
        //----------------------------------------------------------------------
        toString() {
            return `[html(${this.context})]`;
        }
    }
    $export['html'] = HtmlNode;
}
//==============================================================================
{
    /**
     * script 內容
     * 不包括 <script> 標籤
     */
    class ScriptNode extends Node_ABS {

        // isTag:是否是標籤內容
        constructor(userOptions, content) {
            super(userOptions);
            this.fn = ScriptNode;
            this.content = content;
            this.context = "";

            this._buildContext();
        }
        //----------------------------
        _buildContext() {
            // 內文不能經過 String.template 轉換
            let content = JSON.stringify(this.content);
            content = `$out.print(${content});\n`;

            this.context = content;
        }

        //----------------------------
        $$$printCommand() {
            return this.context;
        }

        //----------------------------
        toString() {
            return `[script(${this.context})]`;
        }

    }
    $export['script'] = ScriptNode;
}

//==============================================================================


