const splitTag_setting = {};
module.exports = splitTag_setting;


splitTag_setting["repalceSymbol"] = {
    j: ["[@J(", ")@]"],
    c: ["[@C(", ")@]"],
    a: ["[@A(", ")@]"]
}

{
    splitTag_setting["setNode"] = {
        j: function (index, content) {

            const node = {
                content
            };

            const symbol = splitTag_setting.repalceSymbol['j'];

            return {
                replace: (symbol[0] + index + symbol[1]),
                node
            }
        },
        c: function (index, { name, content }) {

            const node = {
                name,
                content
            };

            const symbol = splitTag_setting.repalceSymbol['c'];
            return {
                replace: (symbol[0] + index + symbol[1]),
                node
        }
        },
        a: function (index, { name, params, childs }) {

            const node = {
                name,
                params,
                childs
            };

            const symbol = splitTag_setting.repalceSymbol['a'];
            return {
                replace: (symbol[0] + index + symbol[1]),
                node
        }
        }
    }

    function check(data) {
        for (const key in data) {
            if (data.hasOwnProperty(key)) {
                if (data[key] == null) {
                    throw new Error(`no set data["${key}"]`);
                }
            }
        }
    }
}
