const $tool = require('../../tool.js');
const $config = require('../../config.js');
//-----------------------

// 判斷是否是 <% %>, <action:...> 的標籤頭
const ACTION_TAG_HEAD_REG = /(<@action:(\w+?))(?=\/|>|\s)/;

const TAG_HEAD_REG = /<(\/)?([^\s/]+?)(?=(\s|>|\/))/;

const REPLACE_ACTIONNAME = /@action(?=[:])/;

// 驗證標籤用
const REG_1 = /<[/]?@action:(\w+)/;
//==============================================================================
// tag 格式錯誤
class TagFormatError extends Error {
    constructor(msg) {
        super(msg);
    }
}
//==============================================================================

class SplitAction {

    static main(content, actionMap) {
        debugger;

        let remain = content;
        const contentList = [];

        while (remain.length) {
            debugger;

            // remain 進入分析
            let res;

            try {
                // 分析是否有 <action> 標籤
                res = FindAction.findStart(remain);
            } catch (error) {
                if (error instanceof TagFormatError) {
                    // 出現格式錯誤
                    contentList.push(remain);
                    break;
                } else {
                    throw error;
                }
            }
            //-------------
            let {
                node,
                checked,
                remain: _remain,
                    find
            } = res;


            if (checked != null) {
                contentList.push(checked);
            }

            if (node != null) {
                node = addNode(node, actionMap);
                contentList.push(node);
            }

            if (!find) {
                // 沒找到
                break;
            }

            remain = _remain || '';
        } //endWhile

        return contentList.join('');
    }
}

SplitAction.symbol_head = '[@A(';
SplitAction.symbol_foot = ')@]';

module.exports = SplitAction;
//==============================================================================

class FindAction {

    static findStart(content, parent) {
        const o = new FindAction(content, parent);
        return o.findStart();
    }

    static findStart_1(content, parent) {
            const o = new FindAction(content, parent);
            return o.findStart_1();
        }
        //--------------------------------------------------------------------------
    constructor(content, parent) {
            this.content = content;
            this.parent = parent;
            this.result = {
                node: undefined,
                end: undefined,
                checked: '',
                remain: '',
                // 是否有找到<action>
                find: false,
            };

            // 是否是單標籤
            this.is_singleTag = false;

            this.action;
            this.remain = '';
            this.attributes = {};
            this.childList = [];
        }
        //--------------------------------------------------------------------------
        // 找出<action>標籤
        //
        // 找尋標籤的起始
    findStart() {
            debugger;

            const result = this.result;

            (() => {
                if (!this._findHeadStart()) {
                    result.checked = this.remain;
                    return;
                }

                if (!this._findHeadEnd()) {
                    throw new TagFormatError();
                }

                if (this.is_singleTag) {
                    // 此 <action> 是單標籤
                    return;
                }

                // 會進入遞迴分析
                this._findChilds();
            })();
            //-------------

            if (this.parent == null && this.childList.length > 0) {
                this._sortOutChilds();
            }

            return result;
        }
        //--------------------------------------------------------------------------

    findStart_1() {
            debugger;

            this.remain = this.content;
            const result = this.result;

            // 內文是否有合乎規格的標籤
            const reg_1 = transformReg(TAG_HEAD_REG, 'g');
            let res = reg_1.exec(this.remain);

            if (res == null) {
                // 沒找到任何可能標籤
                result.checked = this.remain;
                return result;
            }
            //------------------
            let {
                0: match,
                1: foot,
                2: tagName,
                index
            } = res;

            foot = !!foot;

            this.remain = this.remain.substring(reg_1.lastIndex);

            //------------------

            // 是否可能是 <action> 標籤
            const reg_2 = transformReg(REG_1);
            let res_2 = reg_2.exec(match);


            if (res_2 == null) {
                // 可能是 <html> 標籤
                throw new Error(`(${tagName}) can't inside action_tag`);
            } else {
                // 可能是 <action>
                let {
                    1: action
                } = res_2;

                this.action = action;

                (() => {

                    if (!this._findHeadEnd()) {
                        // 標籤格式錯誤
                        throw new TagFormatError();
                    }
                    //------------------
                    if (this.is_singleTag) {
                        // 此 <action> 是單標籤
                        return;
                    }

                    // 此 <action> 應該是雙標籤
                    if (foot) {
                        // 若是結尾標籤
                        // 前面必定要有所對應的起始標籤
                        if (Object.is(this.action, this.parent.action)) {
                            // 是 parent 的結尾

                            result.remain = this.remain;
                            result.end = true;
                            // find
                            // find
                            return;
                        }
                        throw new Error(`error ended tag(${action})`);
                    }

                    // 會進入遞迴分析
                    this._findChilds();
                })();

            }
            return result;
        }
        //--------------------------------------------------------------------------
        // 找尋標籤的起始
        //
    _findHeadStart() {
            debugger;

            const reg_1 = transformReg(ACTION_TAG_HEAD_REG, 'gu');

            this.remain = this.content;

            let res = reg_1.exec(this.remain);
            if (res == null) {
                return false;
            }

            let {
                1: head,
                2: action,
                index
            } = res;

            let lastIndex = index + head.length;

            this.result.checked = this.content.substring(0, index);
            this.action = action;
            this.remain = this.content.substring(lastIndex);

            return true;
        }
        //--------------------------------------------------------------------------
        // 確定起頭標籤的結束
        //
    _findHeadEnd() {
            debugger;

            const result = this.result;

            // 確定頭部標籤的結束
            let res = $tool.find_tagEnd(this.remain);
            if (res == null) {
                return false;
            }
            //------------------
            let {
                index,
                attributes,
                single,
            } = res;

            if (/^param$/.test(this.action)) {
                if (this.parent == null) {
                    // <param> 必須要有父標籤
                    throw new Error(`<param> must have parent`);
                }
                // <action:param> 的 attributes 必須整理
                attributes = sortOutParamAttributes(attributes);
            }
            debugger;

            Object.assign(this.attributes, attributes);
            this.remain = this.remain.substring((index + 1));

            // 是單標籤，還是雙標籤
            if (single) {
                this.is_singleTag = true;
            } else {
                this.is_singleTag = false;
            }
            //------------------
            if (this.is_singleTag) {
                result.find = true;
                result.node = setNode(this);
                result.remain = this.remain;
            }

            return true;
        }
        //--------------------------------------------------------------------------
        // 會進入遞迴
    _findChilds() {
            debugger;

            const result = this.result;
            let remain = this.remain;

            //------------------
            // 找尋合乎規格的標籤開頭
            while (remain.length > 0) {
                debugger;

                // 深入遞迴繼續尋找
                let res = FindAction.findStart_1(remain, this);

                let {
                    node,
                    checked,
                    remain: _remain,
                        find,
                        end = false,
                } = res;


                if (end) {
                    // 找到結尾
                    result.find = true;
                    result.remain += checked + _remain;
                    break;
                }

                if (!find) {
                    throw new Error(`tag(${this.action}) no closed`);
                }

                if (node != null) {
                    this.childList.push(node);
                }


                remain = _remain;
            } // endWhile
            //------------------

            result.node = setNode(this);

        }
        //--------------------------------------------------------------------------
        // 整理 childNode
    _sortOutChilds() {
        debugger;
        console.dir(this.childList);
    }
}


//==============================================================================
/**
 * 有關於 <action:> 標籤的轉換
 * 預設是 <jsp:...>
 * 使用者可自定
 *
 * @param {*} reg
 * @param {*} options
 */
function transformReg(reg, options) {
    const action_name = $config.get("action_name");

    let _reg = reg.source;

    const replace_reg = RegExp(REPLACE_ACTIONNAME.source, 'g');

    _reg = _reg.replace(replace_reg, `${action_name}`);

    if (!options) {
        options = '';
    }

    return RegExp(_reg, options);
}
//----------------------------
function addNode(node, actionMap) {
    let index = actionMap.length;
    actionMap.push(node);

    let replace =
        `${SplitAction.symbol_head}${index}${SplitAction.symbol_foot}`;
    return replace;
}
//----------------------------
function setNode({
    action = null,
        attributes = null,
        childList = []
}) {

    attributes = Object.assign({}, attributes);

    return {
        action, attributes, childList
    };
}
//----------------------------
function sortOutParamAttributes(attributes) {
    let res = {};
    let key;
    let value = '';

    if ('name' in attributes) {
        key = attributes['name'];

        if ('value' in attributes) {
            value = attributes['value'];
        }

        res[key] = value;
    }

    return res;
}
