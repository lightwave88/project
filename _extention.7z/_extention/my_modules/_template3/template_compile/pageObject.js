const $GM = require('./gmodules.js');
const $file = require('../file.js');

/**
 * 處理頁面內的系統操作
 */
class Page {

    static async require(page) {

    }

    static require_sync(page, userOptions) {
        debugger;

        const $splite_tag = $GM.get('splite_tag');

        // 取得 page 的內容
        let content = $file.file_get_contents_sync(page);
        //-------------
        // 分析為 nodelist
        let nodeList = $splite_tag.main_sync(content, userOptions);
        //-------------
        // 將 nodeList 化為 command
        let command = '';
        nodeList.forEach((node) => {
            // 每個節點代表不同的指令
            command += node.$$$printCommand();
        });

        // console.log('require:%s', command);
        //-------------
        return command;
    }
    //--------------------------------------------------------------------------
    constructor(userOptions = {}) {
        debugger;
        this.$$$fn = Page;
        this.$$$userOptions = userOptions;

        // requirePage 的内文
        this.$$$requireContent = null;

        // requirePage 的建構 function
        this.$$$reguireCommand = null;

        // 頁面會使用的重要模組
        this.$$$modules = {};
    }

    $$$setModule(key, value) {
        let modules = {};
        if (key != null && typeof (key) == "string") {
            modules[key] = value;
        } else {
            Object.assign(modules, key);
        }

        if ("$page" in modules) {
            delete modules["$page"];
        }

        Object.assign(this.$$$modules, modules);
    }
    //--------------------------------------------------------------------------
    /**
     * API
     *
     * @param {*} options
     * 
     * base_dir: 來自當前的 base_dir;
     */
    requirePage(options, base_dir) {
        debugger;

        const $path = require('path');

        // 要引入的頁面
        let { page } = options;

        if ($path.isAbsolute(page)) {
            throw new Error("require.page must be relative path");
        }

        const { include_dir, sync } = this.$$$userOptions;

        if (include_dir == null) {
            throw new Error(`no assign include_dir`);
        }

        // include_dir 必須修改
        // 改為當前 scope.base_dir(執行腳本的路徑)
        page = $path.resolve(include_dir, page);

        console.log("requirePath(%s)", page);

        if (sync == true) {
            this.$$$requireContent = this.$$$fn.require_sync(page, this.$$$requireContent);
        } else {
            // 返回 promise
            return this.$$$fn.require(page, this.$$$requireContent);
        }
    }
    //--------------------------------------------------------------------------
    /**
     * 取得 require 的結果
     */
    $$$getRequireContent() {
        let res = this.$$$requireContent;
        this.$$$requireContent = null;

        console.log('requireContent:\n%s', res);
        return res;
    }
    //--------------------------------------------------------------------------
    // 動態 include
    // 可以是 sync, async
    include(page, data) {
        debugger;

        const $out = this.$$$modules['$out'];
        const $compile = this.$$$modules['compile'];

        $compile.setTemplateFile(page);
        /**
         * 讀取 file.content
         * 並解析成 render_fun
         */
        let res = $compile.compile();

        if (res instanceof Promise) {
            debugger;
            let p = res.then((fn) => {
                return fn(data);
            });

            p = p.then((content) => {
                $out.push(content);
            });

            return p;
        } else {
            debugger;
            let fn = res;
            let content = fn(data);
            $out.push(content);
        }
    }
    //--------------------------------------------------------------------------
}



module.exports = Page;

