// 取得系統資訊
class SystemInfo {
    static getInstance() {
        return new SystemInfo();
    }

    constructor() {
        this.system = null;

        this.workerPath = null;

        this['_path'] = null;

        this.extensionPath = null;

        this['_'] = null;

        this.$$$init();
    }

    $$$init() {
        debugger;

        let _;

        if (typeof (module) != 'undefined' && module.exports) {
            // nodejs
            let extension_module = require('_extension');
            _ = extension_module['_'];

        } else {
            // browser
            let root = this.$$$checkRoot();
            _ = root['_'];
        }
        const $extension = _['$$$extension'];

        this['_'] = _;
        this['_path'] = $extension['_path'];
        this.extensionPath = $extension.extensionPath;
        this.system = $extension.system;
    }

    $$$checkRoot() {
        let root;

        if (typeof self == 'object' && self.self === self) {
            root = self;
        } else if (typeof global == 'object' && global.global === global) {
            root = global;
        }
        root = root || this;

        return root;
    }

    setWorkerPath(path) {
        this.workerPath = path;
    }
}

module.exports = (() => {
    debugger;
    return SystemInfo.getInstance();
})();