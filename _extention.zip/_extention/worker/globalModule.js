const $globalModule = new Map();

module.exports = $globalModule;

debugger;
$globalModule.set('config',require('./config.js'));

debugger;
$globalModule.set('systeminfo', require('./systeminfo.js'));
