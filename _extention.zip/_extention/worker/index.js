// 引入各個子模組





(() => {
    debugger;

    let $root;

    if (typeof module != 'undefined' && module.exports) {
        // nodejs

        const $extension = require('_extension');

        $extension.import(nodejs_import);

        return;
    }
    //------------------

})();


function nodejs_import(_) {
    debugger;

    const $api = require('./api.js');
    return {
        worker: $api
    };
}