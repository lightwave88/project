
// _extension 本體
const $extension = require('_extension/head');
module.exports = $extension;
//==============================================================================
debugger;
// 引入其他模組
require('./basicTools');

debugger;
require('./worker');