const $fs = require('fs');

const DEFAULT_CONFIG = {
    // 檔案系統的預設
    "file_sync": false,

    // 指定 template_file 的目錄
    "include_dir": undefined,

    // <jsp:action>
    "action_name": "jsp",

    // 是否採用 js.string_template 解析
    "string_template": false,
};
//==============================================================================
class Config {
    static get_instance() {
        if (Config.instance == null) {
            Config.instance = new Config();
        }
        return Config.instance;
    }
    //--------------------------------------------------------------------------
    constructor() {
        this.config;
        //------------------
        this.reset();
    }
    //--------------------------------------------------------------------------
    get(key) {
        let res;
        if (key == null) {
            res = Object.assign({}, this.config);
        } else {
            res = this.config[key];
        }
        return res;
    }
    //--------------------------------------------------------------------------
    set(key, value) {

        let setting;

        if (typeof key == 'object') {
            setting = key;
        } else {
            setting = {
                key: value
            };
        }

        let keyList = Object.getOwnPropertyNames(setting);

        keyList.forEach((key) => {
            if (key in this.config) {
                this.config[key] = setting[key];
            }
        });

        this.config[key] = value;
    }
    //--------------------------------------------------------------------------
    reset() {
        this.config = Object.assign({}, DEFAULT_CONFIG);
    }
    //--------------------------------------------------------------------------
    loadConfigFile(file) {
        if (!$fs.existsSync(file)) {
            throw new Error(`config_file(${file}) no exists`)
        }
        let setting = require(file);

        this.set(setting);
    }
    //--------------------------------------------------------------------------
}

module.exports = Config.get_instance();
