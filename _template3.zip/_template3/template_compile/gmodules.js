const $GM = new Map();
module.exports = $GM;
//----------------------------
/**
 * 一次把 template_compile 子模組的所有
 * 模組都 load
 */
if (!$GM.has('config')) {
    $GM.set('config', require('../config.js'));
}

if (!$GM.has('tool')) {
    $GM.set('tool', require('../tool'));
}

if (!$GM.has('nodeList_1')) {
    $GM.set('nodeList_1', require('./node/node_1.js'));
}

if (!$GM.has('nodeList_2')) {
    $GM.set('nodeList_2', require('./node/node_2.js'));
}


if (!$GM.has('nodeList_3')) {
    $GM.set('nodeList_3', require('./node/node_3.js'));
}

if (!$GM.has('compile')) {
    $GM.set('compile', require('./compile.js'));
}

if (!$GM.has('splite_tag')) {
    $GM.set('splite_tag', require('./split_tag.js'));
}

if (!$GM.has('page')) {
    $GM.set('page', require('./pageObject.js'));
}

if (!$GM.has('out')) {
    $GM.set('out', require('./outObject.js'));
}

