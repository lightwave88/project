// 父模組是(split_tag.js)

const $setting = require('./setting.js');
const $setNodeList = $setting["setNode"];

const $tool = require('../../tool.js');

const JS_HEAD = /<script(?=[>\s])/;
const JS_FOOT = /<\/script\s*>/;


class SplitJs {

    static main(content, parent) {
        const o = new SplitJs(content, parent);
        return o.main();
    }
    //--------------------------------------------------------------------------
    constructor(content, parent) {
        this.fn = SplitJs;
        this.content = content;
        this.parent = parent;

        this.commandBlocks = this.parent.commandBlocks;
        this.jsBlocks = this.parent.jsBlocks;

        this.contentList = [];
    }
    //--------------------------------------------------------------------------
    main() {

        let remain = this.content;

        // 把 <script> 分離出來
        while (remain.length > 0) {

            // 找 <script>
            let {
                nodes, remain: _remain
            } = this._find(remain);

            nodes.forEach((str) => {
                this.contentList.push(str);
            });
            remain = _remain;
        }

        const r_value = this.contentList.join("");
        this.contentList.length = 0;

        return r_value;
    }
    //--------------------------------------------------------------------------
    _find(_content) {
        const content = _content;

        const nodeList = [];

        const r_value = {
            remain: "",
            nodes: nodeList
        };


        const reg_1 = RegExp(JS_HEAD, 'g');

        let res = reg_1.exec(content);

        if (res == null) {
            // console.log('no find script:\n%s', content);
            // 沒找到任何 <script>
            this._addHtmlNode(content, nodeList);
            return r_value;
        }
        //------------------
        console.log('find script:\n%s', content);
        let lastIndex = reg_1.lastIndex;

        let {
            index: js_head_start,
        } = res;

        // <script> 之前的文本
        let str = content.substring(0, js_head_start);
        this._addHtmlNode(str, nodeList);
        //------------------
        // 找頭部的結尾
        str = content.substring(lastIndex);
        const res_2 = $tool.find_tagEnd(str);

        if (res_2 == null) {
            throw new Error('<script> no close');
        }

        let {
            index: js_head_end,
            attributes,
        } = res_2;

        let is_command = false;

        if (attributes['class'] != null) {
            // is command

            let $class = attributes['class'].trim();
            if ("_".localeCompare($class) == 0) {
                is_command = true;
            }
        }

        js_head_end = lastIndex + js_head_end;
        lastIndex = js_head_end + 1;

        if (!is_command) {
            // 標籤的 head
            let _tag_content = content.substring(js_head_start, (
                    js_head_end + 1));
            this._addHtmlNode(_tag_content, nodeList);
        }
        //------------------
        // 找尾部
        const reg_2 = RegExp(JS_FOOT, 'g');
        reg_1.lastIndex = lastIndex;

        const res_3 = reg_2.exec(content);

        if (res_3 == null) {
            throw new Error('<script> no end');
        }

        let {
            index: js_foot_sart
        } = res_3;

        lastIndex = reg_2.lastIndex;

        //------------------
        const tag_context = content.substring((js_head_end + 1),
                js_foot_sart);

        // 標籤內容
        str = this._setNode(tag_context, is_command);
        nodeList.push(str);
        //------------------
        if (!is_command) {
            // 標籤的 foot
            let _tag_content = content.substring(js_foot_sart, lastIndex);
            this._addHtmlNode(_tag_content, nodeList);
        }
        //------------------

        r_value.remain = content.substring(lastIndex);

        return r_value;
    }
    //--------------------------------------------------------------------------
    _setNode(content, is_command) {
        if (!content.length) {
            return;
        }

        let index, node, replace;
        if (is_command) {
            const fn = $setNodeList["c"];
            index = this.commandBlocks.length;


            ({
                node, replace
            } = fn(index, {
                name: '<%',
                content
            }));

            this.commandBlocks.push(node);

        } else {
            const fn = $setNodeList["j"];
            index = this.jsBlocks.length;

            ({
                node, replace
            } = fn(index, content));

            this.jsBlocks.push(node);
        }

        return replace;
    }
    //--------------------------------------------------------------------------
    _addHtmlNode(content, nodeList) {
        if (content == null || !content.length) {
            return;
        }
        nodeList.push(content);
    }
}

module.exports = SplitJs
