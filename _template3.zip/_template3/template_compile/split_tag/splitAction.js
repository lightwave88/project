// 父模組是(split_tag.js)

const $setting = require('./setting.js');
const $setNode = $setting["setNode"]["a"];

const $tool = require('../../tool.js');
const $config = require('../../config.js');
const $util = require('util');
//-----------------------

// 判斷是否是 <% %>, <action:...> 的標籤頭
const ACTION_TAG_HEAD_REG = /(<@action:(\w+?))(?=\/|>|\s)/;

const REPLACE_ACTIONNAME = /@action(?=[:])/;

// 驗證標籤用
const REG_1 = /\s*<([/]?)@action:(\w+)/;

const $ChildAction = new Set([
    'param',
    'params'
]);
//==============================================================================

class SplitAction {

    static main(content, parent) {
        debugger;

        const actionBlocks = parent.actionBlocks;

        let remain = content;
        const contentList = [];

        while (remain.length) {
            debugger;

            // remain 進入分析
            let res;

            // 分析是否有 <action> 標籤
            res = FindAction.findStart(remain, parent);
            //-------------
            let {
                node,
                checked,
                remain: _remain,
            } = res;

            if (checked != null) {
                contentList.push(checked);
            }

            if (node != null) {
                node = setNode(node, actionBlocks);
                contentList.push(node);
            } else {
                break;
            }

            remain = _remain || '';
        } //endWhile

        debugger;
        return contentList.join('');
    }
}

module.exports = SplitAction;
//==============================================================================

class FindAction {

    static findStart(content, parent) {
        const o = new FindAction(content, void (0));
        o.setParentModule(parent);
        return o.findStart();
    }

    static findStart_1(content, parent) {
        const o = new FindAction(content, parent);
        o.setParentModule(parent.parentModule);
        return o.findStart_1();
    }
    //--------------------------------------------------------------------------
    constructor(content, parentNode) {
        this.fn = FindAction;

        this.parentModule;
        this.content = content;
        this.parentNode = parentNode;
        this.result = {
            node: undefined,
            end: undefined,
            checked: '',
            remain: '',
            // 是否有找到<action>
            find: false,
        };

        // 是否是單標籤
        this.is_singleTag = false;

        this.action;
        this.remain = '';
        this.params = {};
        this.childList = [];
    }

    setParentModule(parent) {
        this.parentModule = parent;
    }
    //--------------------------------------------------------------------------
    // 找出<action>標籤
    //
    // 找尋標籤的起始
    findStart() {
        debugger;

        const result = this.result;

        (() => {
            if (!this._findHeadStart()) {
                this._noFindActionTag(this.content);
                return;
            }

            if (!this._findHeadEnd()) {
                throw new Error("format error");
            }

            if (this.is_singleTag) {
                this._findActionTag(this.remain);
                // 此 <action> 是單標籤
                return;
            }

            // 會進入遞迴分析
            this._findChilds();
        })();
        //-------------

        if (this.parentNode == null && this.childList.length > 0) {
            result.node = sortOutChildTree(result.node);
        }

        return result;
    }
    //--------------------------------------------------------------------------

    findStart_1() {
        debugger;

        this.remain = this.content;
        const result = this.result;

        (() => {
            // debugger;

            // 內文是否有合乎規格的 <action>標籤
            const reg_1 = transformReg(REG_1, 'g');
            let res = reg_1.exec(this.remain);

            if (res == null) {
                // 沒找到任何可能的 <action> 標籤
                this._noFindActionTag(this.content);
                return;
            }
            //------------------
            let {
                0: match,
                1: foot,
                2: action,
                index
            } = res;

            foot = !!foot;

            let lastIndex = reg_1.lastIndex;

            this.remain = this.remain.substring(lastIndex);

            this.action = action;
            //------------------

            if (!this._findHeadEnd()) {
                // 標籤格式錯誤
                this._noFindActionTag(this.content);
                return;
            }
            //------------------

            if (foot) {
                // 若是結尾標籤(必然是雙標籤)
                // 前面必定要有所對應的起始標籤

                console.log("%s, %s", this.action, this.parentNode.action);
                if (Object.is(this.action, this.parentNode.action)) {
                    // 是 parent 的結尾

                    result.remain = this.remain;
                    result.end = true;
                    // find
                    // find
                    return;
                }
                throw new Error(`error ended tag(${action})`);
            } else if (this.is_singleTag) {
                // 此 <action> 是單標籤
                this._findActionTag(this.remain);
                return;
            }
            //------------------

            // 會進入遞迴分析
            this._findChilds();
        })();
        return result;
    }
    //--------------------------------------------------------------------------
    // 找尋標籤的起始
    //
    _findHeadStart() {
        // debugger;

        const reg_1 = transformReg(ACTION_TAG_HEAD_REG, 'gu');

        this.remain = this.content;

        let res = reg_1.exec(this.remain);
        if (res == null) {
            return false;
        }

        let {
            1: head,
            2: action,
            index
        } = res;

        let lastIndex = index + head.length;

        this.result.checked = this.content.substring(0, index);
        this.action = action;
        this.remain = this.content.substring(lastIndex);

        return true;
    }
    //--------------------------------------------------------------------------
    // 確定起頭標籤的結束
    //
    _findHeadEnd() {
        // debugger;

        const result = this.result;

        // 確定頭部標籤的結束
        let res = $tool.find_tagEnd(this.remain);
        if (res == null) {
            return false;
        }
        //------------------
        let {
            index,
            attributes,
            single,
        } = res;

        console.log('(%s)attributes=>%s', this.action, JSON.stringify(attributes));    

        this._check_1(attributes);

        this.remain = this.remain.substring((index + 1));

        // 是單標籤，還是雙標籤
        if (single) {
            this.is_singleTag = true;
        } else {
            this.is_singleTag = false;
        }

        return true;
    }
    //--------------------------------------------------------------------------
    // 會進入遞迴
    _findChilds() {
        debugger;

        let remain = this.remain;
        //------------------
        // 找尋合乎規格的標籤開頭
        while (remain.length > 0) {
            debugger;

            // 深入遞迴繼續尋找
            let res = FindAction.findStart_1(remain, this);

            let {
                node,
                remain: _remain,
                end = false,
            } = res;


            if (end) {
                // 找到結尾
                this._findActionTag(_remain);
                return;
            }

            if (node != null) {
                this.childList.push(node);
            } else {
                throw new Error(`tag(${this.action}) no closed`);
            }

            remain = _remain;
        } // endWhile
        //------------------
        throw new Error(`tag(${this.action}) no closed`);
    }
    //--------------------------------------------------------------------------
    _findActionTag(remain) {

        this._check_2();

        const result = this.result;

        // 暫時性的節點
        result.node = setTempNode(this);
        result.remain += remain;

    }
    //--------------------------------------------------------------------------
    _noFindActionTag(checked) {
        this.result.checked = checked;
        this.result.remain = '';
    }
    //--------------------------------------------------------------------------
    // 一些 <action> 規則的檢查
    _check_1(attributes) {

        if (!this.action) {
            throw new Error(`no actionName`);
        }

        if (this.parentNode == null) {
            // 有些標籤必須是 child
            if ($ChildAction.has(this.action)) {
                // <param> 必須要有父標籤
                throw new Error(`<${this.action}> must have parent`);
            }
        }

        if (/^param$/.test(this.action)) {
            // <action:param> 的 attributes 必須整理
            attributes = sortOutParamAttributes(attributes);
        }

        Object.assign(this.params, attributes);
    }
    //--------------------------------------------------------------------------
    _check_2() {
        if (/^param$/.test(this.action) && this.childList.length) {
            // <param> 是最根本節點
            // 不能有子節點
            throw new Error(`<param> can't have childTag`);
        }
    }
}


//==============================================================================
/**
 * 有關於 <action:> 標籤的轉換
 * 預設是 <jsp:...>
 * 使用者可自定
 *
 * @param {*} reg
 * @param {*} options
 */
function transformReg(reg, options) {
    const action_name = $config.get("action_name");

    let _reg = reg.source;

    const replace_reg = RegExp(REPLACE_ACTIONNAME.source, 'g');

    _reg = _reg.replace(replace_reg, `${action_name}`);

    if (!options) {
        options = '';
    }

    return RegExp(_reg, options);
}
//----------------------------
function setNode(node, actionBlocks) {
    let index = actionBlocks.length;

    let { node: n, replace } = $setNode(index, node);

    actionBlocks.push(n);
    return replace;
}
//----------------------------
function setTempNode({ action = null, params = null, childList = [] }) {

    params = Object.assign({}, params);

    return {
        name: action,
        params,
        childs: childList
    };
}
//----------------------------
// 整理 <action:param>的 atributes
function sortOutParamAttributes(params) {
    let res = {};
    let key;
    let value = '';

    let keyList = Object.getOwnPropertyNames(params);
    if ('name' in params && 'value' in params) {
        // jsp 舊規則，需要兩個 attributes，沉長
        key = params['name'];
        res[key] = params['value'];
    } else if(keyList.length){
        key = keyList[0];
        res[key] = params[key];
    }else{
        throw new Error("param attribute format error");
    }

    return res;
}
//----------------------------

function sortOutChildTree(p_node) {
    debugger;

    const targetList = [p_node];

    let i = 0;

    // 抓出父子結構
    while (true) {
        let node = targetList[i++]

        if (node == null) {
            break;
        }

        node.childs.forEach((_node) => {
            targetList.push(_node);
        });
    }
    //------------------
    debugger;
    // 確定從最底層搞起
    // 避免用遞迴，呼叫太多 function
    let node;
    while (targetList.length > 0) {
        debugger;

        node = targetList.pop();

        let actiopnName = node.name;
        if (/^param$/.test(actiopnName)) {
            // <param> 是最底層的節點
            // 不能有子節點
            continue;
        }
        //------------------
        node.childs = node.childs.filter((_node) => {
            debugger;
            let actiopnName = _node.name;

            if (/^param[s]?$/.test(actiopnName)) {
                Object.assign(node.params, _node.params);
                return false;
            }
            return true;
        });
        //------------------       

    } // endWhile

    return node;
}
