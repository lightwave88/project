const $GM = require('../gmodules.js');
const Node_ABS = require('./abstratNode.js');

const $export = {};
module.exports = $export;

/**
 * 基本命令標籤
 */
class CommandNode_ABS extends Node_ABS {

    static $$$addClass(name) {
        let $class = this;
        $export[name] = $class;
    }
    //----------------------------
    constructor(userOptions, name, content) {
        super(userOptions);

        this.content = content || '';
        this.name = name;
    }

}
//==============================================================================
{
    // <% %>
    class CommandNode_1 extends CommandNode_ABS {

        $$$printCommand() {
            return this.content;
        }
        //----------------------------
        toString() {
            return `[<% ${this.content} %>]`;
        }

    }

    CommandNode_1.$$$addClass("<%");
}
//==============================================================================
{

    // <%= %>
    class CommandNode_2 extends CommandNode_ABS {

        constructor(userOptions, name, content) {
            super(userOptions, name, content);
            this.fn = CommandNode_2;
            this.context = "";

            this._buildContext();
        }
        //----------------------------
        _buildContext() {
            const $tool = $GM.get('tool');

            let textContent = $tool.checkCommandContent(this.content);
            textContent = `$out.print(${textContent});\n`;
            this.context = textContent;
        }
        //----------------------------
        $$$printCommand() {
            return this.context;
        }
        //----------------------------
        toString() {
            return `[<%= ${this.context} %>]`;
        }
    }

    CommandNode_2.$$$addClass("<%=");
}

