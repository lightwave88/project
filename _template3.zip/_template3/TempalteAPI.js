const $Compile = require("./template_compile");

class TemplateAPI {

    static getInstance() {
        return new TemplateAPI();
    }

    constructor() { }

    // 取得 compile 物件
    // 可以獨立擴充功能
    getCompile(options) {
        return $Compile.getInstance(options);
    }
    //--------------------------------------------------------------------------
    // 產生一個 renderFun
    compile(options) {
        const compile = this.getCompile(options);
        return compile.compile();
    }
    //--------------------------------------------------------------------------
    display(data, options) {
        debugger;
        const compile = this.getCompile(options);
        return compile.display(data);
    }
    //--------------------------------------------------------------------------
    // 擴展用
    // 取得需要擴展的 module
    getClass(moduleName) {
        switch (moduleName) {
            case '$page':

                break;
            case '$out':
                break;
            default:
                throw new Error(`no this class(${moduleName}) can get`);
                break;
        }
    }
}

module.exports = TemplateAPI;
